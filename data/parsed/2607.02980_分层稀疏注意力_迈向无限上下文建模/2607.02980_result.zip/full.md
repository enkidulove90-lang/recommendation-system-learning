# Hierarchical Sparse Attention Done Right: Toward Infinite Context Modeling

Xiang Hu<sup>1∗</sup> Xinyu Wei<sup>2∗</sup> Hao Gu<sup>3∗</sup> Minshen Zhang<sup>4∗</sup> Tian Liang<sup>1</sup> Huayang Li<sup>1</sup> Lei Zhu<sup>1</sup> Yan Wang<sup>1</sup> Sirui Han<sup>3</sup> Yushi Bai<sup>1</sup> Kewei Tu<sup>2</sup> Haitao Mi<sup>1</sup> Leo Liang<sup>1</sup> <sup>1</sup>Tencent HY Team, <sup>2</sup>ShanghaiTech University, <sup>3</sup>The Hong Kong University of Science and Technology <sup>4</sup>University of California, San Diego https://github.com/Tencent-Hunyuan/HiLS-Attention

![](images/cfbfd9bc58e1d0ef9831029fe4d9e118c5403322ff70bbb338f407b4d522cfcb.jpg)  
(a)

![](images/17263f133e188e56c33da5c32be604af963773c6240ecefd70da47f0989a9f0a.jpg)

![](images/3910e66005a2c815969ece851bfefdfba716c4c160f99928979c18adece5ec46.jpg)

![](images/ef72ad4504b06eee955513bcdc654d97ca2b3f6ea46d0968d348611c8e9cdf0f.jpg)  
(b)

(c)  
![](images/8ce31a1255913e77c1194984ff1cc2072192d9d11ae9dbccb6bc4dcbcc12f269.jpg)  
(d)  
Figure 1: After only 50B continued-training tokens, HiLS-Attention inherits the capability of full attention while bringing two key advantages: strong ultra-long context extrapolation beyond the YaRN-extended 4× length (Fig. 1a) and faster inference (Fig. 1b) . Meanwhile, it preserves comparable performance for short- and medium-context tasks, within both the original training length and the YaRN-extrapolated range (Fig. 1c & 1d).

## Abstract

Scaling modern large language models (LLMs) to long contexts is limited by the quadratic computation cost, and poor length extrapolation of dense attention. Chunk-wise sparse attention offers a promising alternative, but all existing methods fall short of full attention because of their inaccurate chunk selection. We propose Hierarchical Landmark Sparse (HiLS) Attention, a chunk-wise sparse attention mechanism that learns chunk selection end-to-end under the language-modeling (LM) loss. HiLS factorizes attention hierarchically: each query performs attention independently with each retrieved chunk to extract chunk-specific information, and the resulting outputs are fused according to chunk retrieval scores. By incorporating retrieval scores into the forward attention computation, HiLS optimizes them directly with the LM loss, enabling end-to-end retrieval learning and native sparse training. Experimental results in Fig 1 show that HiLS-Attention achieves performance comparable to, and in some cases better than, full attention at in domain context lengths. Meanwhile, HiLS-Attention extrapolates more than 64× the training context length with 90% retrieval accuracy, far beyond full attention. Moreover, existing full-attention models can be converted to HiLS-Attention with lightweight continued pretraining, preserving in-domain performance while acquiring ultra-long-context extrapolation. Together with its sparse KV access and computation, HiLS-Attention breaks the usual efficiency-performance trade-off, enabling long-context LLMs that are both more efficient and more effective on general long-context tasks than their full-attention counterparts.

## 1 Introduction

The ability to model and utilize long contexts has become a fundamental desired capability of modern Large Language Models (LLMs) [1, 2]. Consequently, scaling the context window has emerged as a key research frontier, underpinning a wide range of long-context applications such as long-horizon agentic tasks, complex reasoning, and large-scale information integration. Despite recent progress [3], scaling context windows remains challenging for full attention due to its quadratic complexity, poor length extrapolation performance, and KV cache cost that grows with the context length.

Recently, chunk-wise sparse attention methods [4, 5, 6, 7] provide a promising alternative. They selectively attend to relevant context chunks to maintain a constant computational cost, while dynamically swapping the corresponding KV caches into fast memory on demand to prevent memory explosion. Despite their recent progress, no existing chunk-wise native sparse attention methods have achieved performance on par with full attention methods. While the performance gap may appear small for large-scale models on short-context tasks, it becomes pronounced in longer-context settings that demand precise in-context retrieval. This limitation is

![](images/016aa14aa2e9feb89007846210d4a124819b6cb57a07b63a51c78b9c57e77f73.jpg)  
Figure 2: In-context retrieval results.

clearly exposed in parameter-constrained models, as evidenced by the substantial long-context retrieval gap in Fig. 2. We argue that inaccurate chunk selection is the core challenge, which stems from weak chunk summaries and the lack of end-to-end optimization of the selection process. The nonparametric chunk summaries such as mean-pooling, have limited expressiveness and may lose crucial information. Although parametric summaries could be more expressive, existing methods use them only to score chunks for selection: after the hard top-K chunk IDs are chosen, the summaries and chunk scores are discarded. Consequently, the language-modeling (LM) loss cannot directly optimize the summaries or selection scores to suppress irrelevant chunks and promote chunks more useful for next-token prediction, leading to inaccurate chunk selection.

This observation motivates two desiderata: chunk summaries should be trainable end-to-end with the LM loss, and expressive enough to capture the chunk-level importance induced by full attention. To explore this, we start from the naive Block Sparse Attention (BSA), which computes full attention, aggregates token-level attention mass within each chunk, and selects the top-K chunks with the largest mass. Although naive BSA requires full attention computation and offers no computational savings, it yields a full-attention-derived chunk selection pattern. We use this pattern as a starting point to derive HiLS-Attention, an end-to-end learnable sparse attention mechanism with sufficient expressiveness to capture such chunk-level mass. First, to estimate chunk mass without computing full attention, we append a special landmark token [8] to each chunk, from which we derive an expressive chunk summary key. The query-summary-key scoring operation follows the first-order Taylor expansion of the full-attention induced chunk mass, thereby forming a learnable chunk-mass surrogate. Second, HiLS makes this retrieval process end-to-end learnable by using the surrogate scores as part of the forward attention weights, via the hierarchical factorization illustrated in Fig. 3. In this factorization, attention mass is first allocated across retrieved chunks and then distributed among tokens within each chunk. This avoids the quadratic full-attention pass required by naive BSA, thereby substantially reducing the computational cost during both training and inference. As a result, block selection becomes end-to-end learnable under the LM objective, allowing HiLS to assign higher scores to chunks that are more useful for prediction and suppress irrelevant ones.

To validate HiLS-Attention’s alignment with naive BSA and full attention, and more importantly, assess its performance for long-context modeling, we conduct comprehensive experiments across model scales from 345M to 7B parameters, covering perplexity evaluation, short-context benchmarks, and long-context benchmarks. At the 345M scale, HiLS-Attention achieves comparable perplexity to full attention and better in-domain RULER [9] performance. Remarkably, despite pretrained with only 8K context length, it extrapolates to 4M context length while maintaining over 90% accuracy on needle-in-a-haystack retrieval, corresponding to a 512× length extrapolation. We further find that the advantage of HiLS-Attention becomes more pronounced with 256K training context length. On a challenging variable-tracking task, it improves over full attention by up to 50%. At the 7B scale, we can convert a full-attention model to HiLS-Attention with only 50B tokens of continual training, preserving short-context performance while substantially outperforming full-attention baselines on LongBench [10] and exceeding the YaRN-extended [11] base model. These results suggest that HiLS-Attention can not only match but also surpass these baselines in multiple settings.

To our best knowledge, our work is the first to provide strong empirical evidence that native sparse attention can achieve both superior long-context performance and more efficient long-context inference. Together, its strong in-domain performance, superior length extrapolation, and efficient long-context inference position HiLS-Attention as a promising alternative to full attention and a core building block for future ultra-long context modeling.

In summary, our key contributions are as follows:

• We propose HiLS-Attention, a native sparse attention mechanism based on a hierarchical softmax, enabling end-to-end trainable sparse retrieval.

• We connect HiLS-Attention to naive BSA from an expressiveness perspective, showing that an effective chunk summary should be mathematically aligned with the first-order Taylor expansion of the full-attention-induced chunk mass, thereby providing sufficient representational capacity for accurate block selection.

• Our extensive experiments show that full-attention models can be cost-effectively converted to HiLS-Attention, preserving short-context performance while surpassing full attention in both in-domain long-context tasks and ultra-long-context extrapolation.

## 2 Preliminary

In this section, we review the formulation of naive Block Sparse Attention (BSA) and analyze why existing methods fail to preserve the fidelity of chunk selection.

## 2.1 Naive Block Sparse Attention

Given an input token sequence $\pmb { x } = \{ x _ { 1 } , x _ { 2 } , \dots , x _ { N } \}$ , we partition it into non-overlapping chunks of a uniform size S, where the j-th token belongs to the $c ( j )$ -th chunk $( c ( j ) = \lfloor j / S \rfloor )$ . With BSA, the query token attends to two distinct sequence segments: a local sliding window containing the corresponding token and K globally selected distant chunks outside this window.

To avoid overlap between the local window and the retrieved distant chunks, we align the local window with the chunk partition by rounding its left boundary down to the nearest chunk boundary:

![](images/9a1d0f56182fb5fb080b8e3f6e9de3c45041d8f235ca06f16307b15ca9444463.jpg)  
Figure 3: An overview of HiLS-Attention. We omit the scaling factor $\textstyle { \frac { 1 } { \sqrt { d } } }$ for simplicity. Naive block sparse attention selects the top-K chunks by their exact mass $Z _ { c } , \mathbf { e } . \mathbf { g } .$ ., chunks 1 and 3 when $K = 2$ , but computing all $Z _ { c }$ requires a full QK computation. HiLS-Attention instead uses compressed chunk keys $k _ { c } ^ { \prime }$ to efficiently estimate a chunk-mass surrogate $Z _ { c } ^ { \prime } \propto \exp ( q ^ { \top } k _ { c } ^ { \prime } )$ . It factorizes attention into two stages: an inter-chunk softmax, which specifies the total attention mass assigned to each chunk, and an intra-chunk softmax, which distributes each chunk’s attention mass among its tokens. Since $Z _ { c } ^ { \prime }$ parameterizes the forward attention weights, gradients from the next-token prediction loss can be directly backpropagated to the compressed key $k _ { c } ^ { \prime } ,$ , enabling end-to-end learning.

given a window size $W .$ , the aligned left boundary at position i is $\begin{array} { r } { \ell ( i ) = \left| \frac { i - W + 1 } { S } \right| S } \end{array}$ . Consequently, at time step i, the candidate chunks indices available for retrieval from the historical context form an indices set $\begin{array} { r } { \mathcal { C } _ { i } = \{ 0 , 1 , . . . , \frac { \ell ( i ) } { S } - 1 \} } \end{array}$

Let $\mathbf { q } _ { i } , \mathbf { k } _ { j } , \mathbf { v } _ { j } \in \mathbb { R } ^ { d }$ denote the standard query of $x _ { i }$ , and key and value vectors of $x _ { j }$ with dimension $d .$ The token-to-token attention logit is defined as $\begin{array} { r } { s _ { i , j } = \frac { \mathbf q _ { i } ^ { \top } \mathbf k _ { j } } { \sqrt { d } } } \end{array}$ . In the full-attention setting, we define the chunk mass of a token group as the sum of token-level exponentiated attention logits. Thus, the chunk masses assigned to the local sliding-window attention (SWA) region and to a distant chunk $c \in { \mathcal { C } } _ { i }$ for token position i are respectively given by

$$
Z _ {i, \mathrm{swa}} = \sum_ {j = \ell (i)} ^ {i} \exp (s _ {i, j}), Z _ {i, c} = \sum_ {j \in \mathcal {T} _ {c}} \exp (s _ {i, j}),\tag{1}
$$

Since selecting chunks according to normalized attention mass is equivalent to selecting them according to $\bar { Z _ { i , c } } ,$ naive BSA chooses

$$
\boldsymbol {\mathcal {I}} _ {i} = \left\{c \in \mathcal {C} _ {i} \mid \operatorname{rank} _ {\downarrow} (Z _ {i, c}) <   K \right\},\tag{2}
$$

where ran $\tau _ { \downarrow } ( Z _ { i , c } )$ ranks chunks in $\mathcal { C } _ { i }$ in descending order of $Z _ { i , c } ,$ so $\pmb { \mathcal { Z } } _ { i }$ contains the top- $K$ chunk indices. The query then attends only to selected tokens, i.e., tokens from the selected chunks and the local sliding window. Thus, we have

$$
\begin{array}{l} \mathcal {Z} _ {i} = \sum_ {c \in \mathcal {I} _ {i}} Z _ {i, c} + Z _ {i, \text { swa }}, \\ w _ {i, j} = \left\{ \begin{array}{l l} \frac {\exp (s _ {i , j})}{\mathcal {Z} _ {i}}, & j \text {   is   selected }, \\ 0, & \text { otherwise } \end{array} \right. \quad \mathbf {o} _ {i} = \sum_ {j \leq i} w _ {i, j} \mathbf {v} _ {j}, \end{array}\tag{3}
$$

where the softmax weights are normalized only over the selected tokens, while all unselected tokens receive zero weight.

## 2.2 Expressiveness Limitations of Existing Methods

While naive BSA yields exact chunk selection, computing the precise $Z _ { i , c }$ requires evaluating all token-level logits $s _ { i , j }$ within chunk $c ,$ which diminishes the computational advantages of attention sparsity during training. Therefore, an ideal sparse attention mechanism should estimate the chunk mass without explicitly computing all token-to-token scores. In particular, if one could construct a chunk-level summary key $\mathbf { k } _ { c } ^ { \prime }$ such that

$$
\exp \left(\frac {\mathbf {q} _ {i} ^ {\top} \mathbf {k} _ {c} ^ {\prime}}{\sqrt {d}}\right) \approx Z _ {i, c} = \sum_ {j \in \mathcal {T} _ {c}} \exp (s _ {i, j}) \Longleftrightarrow \frac {\mathbf {q} _ {i} ^ {\top} \mathbf {k} _ {c} ^ {\prime}}{\sqrt {d}} \approx \log Z _ {i, c},\tag{4}
$$

then chunk selection could be performed efficiently using only chunk-level representations. However, the target log $Z _ { i , c }$ is a LogSumExp function, whose behavior depends on the logit distribution within the chunk:

$$
\log Z _ {i, c} = \log \sum_ {j \in \mathcal {T} _ {c}} \exp (s _ {i, j}) \approx \left\{ \begin{array}{l l} \text { mean } _ {j \in \mathcal {T} _ {c}} (s _ {i, j}) + \log S, & \text { if   logits   are   nearly   uniform }, \\ \max _ {j \in \mathcal {T} _ {c}} (s _ {i, j}), & \text { if   one   logit   dominates   the   others }. \end{array} \right.\tag{5}
$$

A detailed derivation is provided in Appendix A.

Most sparse attention methods approximate such chunk-level representations using mean-pooled keys [5, 6]. Specifically, by setting $\mathbf { k } _ { c } ^ { \prime }$ as the average key within chunk $c ,$ we have

$$
\mathbf {k} _ {c} ^ {\prime} = \frac {1}{S} \sum_ {j \in \mathcal {T} _ {c}} \mathbf {k} _ {j}, \quad \frac {\mathbf {q} _ {i} ^ {\top} \mathbf {k} _ {c} ^ {\prime}}{\sqrt {d}} = \frac {\mathbf {q} _ {i} ^ {\top} \left(\frac {1}{S} \sum_ {j \in \mathcal {T} _ {c}} \mathbf {k} _ {j}\right)}{\sqrt {d}} = \frac {1}{S} \sum_ {j \in \mathcal {T} _ {c}} \frac {\mathbf {q} _ {i} ^ {\top} \mathbf {k} _ {j}}{\sqrt {d}} = \mathrm{mean} _ {j \in \mathcal {T} _ {c}} (s _ {i, j}).\tag{6}
$$

Thus, the resulting chunk score corresponds to the mean of token-level logits.

This reveals a fundamental limitation: mean logits are effective only when logits are nearly uniform, whereas max logits are accurate only when a single token dominates. Since logit distributions vary across queries, heads, and data, neither mean nor max logits [12] can consistently represent chunk mass faithfully. This mismatch may alter chunk rankings and cause important chunks to be missed.

## 3 Methodology

The above analysis motivates us to replace non-parametric chunk summaries with learnable summaries for chunk selection. We propose HiLS-Attention, a fully differentiable sparse attention mechanism that replaces the chunk mass $Z _ { i , c }$ with a surrogate $\hat { Z } _ { i , c }$ computed from learned chunk summaries. This raises two key research questions:

## Research Question 3.1

• RQ1: Can the LogSumExp chunk mass log $Z _ { i , c }$ be approximated in a tractable form using only the interaction between the query $\mathbf { q } _ { i }$ and a compact chunk summary?

• RQ2: How can we learn $\hat { Z } _ { i , c }$ end-to-end so that chunk selection is optimized jointly with the language-modeling loss?

Answering RQ1: A Linear Surrogate for Chunk Mass. To identify a tractable surrogate for the LogSumExp chunk mass, we first examine its Taylor expansion. This reveals a useful affine structure for chunk-level scoring, as formalized in the following proposition. The detailed derivation is provided in Appendix B.

Proposition 3.1 (LogSumExp Linearization). For any chunk $c ,$ the LogSumExp of query-key logits can be linearized as:

$$
\log \sum_ {j \in \mathcal {T} _ {c}} \exp \left(\frac {\mathbf {q} ^ {\top} \mathbf {k} _ {j}}{\sqrt {d}}\right) \approx \underbrace {\frac {\mathbf {q} ^ {\top} \mathbf {k} _ {c} ^ {\prime}}{\sqrt {d}} + b _ {c} ^ {\prime}} _ {\text {surrogate score}},\tag{7}
$$

where $\mathbf { k } _ { c } ^ { \prime }$ and $b _ { c } ^ { \prime }$ are computedfrom a learnable query $\mathbf { q } _ { c } ^ { \prime }$ and $\mathbf { k } _ { i }$ in chunk $c _ { * }$ where $i \in [ c S , ( c + 1 ) S )$ the concatenation of $\mathbf { k } _ { i }$ is denoted by $\mathbf { K } _ { c } \in \mathbb { R } ^ { S \times d }$ . Specifically,

$$
s _ {j} = \frac {(\mathbf {q} _ {c} ^ {\prime}) ^ {\top} \mathbf {k} _ {j}}{\sqrt {d}}, \quad p _ {j} = \frac {\exp (s _ {j})}{\sum_ {k \in \mathcal {T} _ {c}} \exp (s _ {k})}, \underbrace {\mathbf {k} _ {c} ^ {\prime} = \sum_ {j \in \mathcal {T} _ {c}} p _ {j} \mathbf {k} _ {j}} _ {\text {Attn} (\mathbf {q} _ {c} ^ {\prime}, \mathbf {K} _ {c}, \mathbf {K} _ {c})}, \quad b _ {c} ^ {\prime} = \underbrace {- \sum_ {j \in \mathcal {T} _ {c}} p _ {j} \log p _ {j}} _ {\text {Entropy}}.\tag{8}
$$

Eq. (7) expresses the chunk-level surrogate score as the sum of a relevance term and a bias term. The learnable query $\mathbf { q } _ { c } ^ { \prime }$ serves as a proxy for queries that may attend to chunk c, inducing an attention distribution over its keys. The weighted sum of keys defines the chunk summary $\mathbf { k } _ { c } ^ { \prime }$ , and $\mathbf { q } ^ { \top } \mathbf { k } _ { c } ^ { \prime } / \sqrt { d }$ measures its relevance to the current query. The bias $b _ { c } ^ { \prime }$ is the entropy of this distribution, capturing token-level mass beyond the linear relevance term. Specifically, $b _ { c } ^ { \prime }$ adaptively interpolates between two regimes in Eq (5): it approaches log S for nearly uniform scores and 0 when a single score dominates. Both $\mathbf { k } _ { c } ^ { \prime }$ and $b _ { c } ^ { \prime }$ can be computed via $\mathrm { A t t n } ( \mathbf { \dot { q } } _ { c } ^ { \prime } , \mathbf { K } _ { c } , \mathbf { K } _ { c } )$ . The computational cost is $O ( S )$ per chunk; therefore, for a sequence of length N with $\mathbf { \bar { \rho } } N / S$ chunks, the total cost is $O ( N )$

To instantiate $\mathbf { q } _ { c } ^ { \prime } ,$ we append a special landmark token [8] to the end of each chunk, and use its query vector as $\mathbf { q } _ { c } ^ { \prime }$ . The resulting pair $\left( \mathbf { k } _ { c } ^ { \prime } , b _ { c } ^ { \prime } \right)$ serves as an entropy-calibrated compressed key for chunk-level routing: we score each chunk by the linear surrogate in Eq. (7), select the top-K chunks, and estimate the partition function as follows:

$$
\begin{array}{l} \hat {s} _ {i, c} = \frac {\mathbf {q} _ {i} ^ {\top} \mathbf {k} _ {c} ^ {\prime}}{\sqrt {d}} + b _ {c} ^ {\prime}, \quad \boldsymbol {\mathcal {I}} _ {i} = \{c \in \mathcal {C} _ {i} | \mathrm{rank} _ {\downarrow} (\hat {s} _ {i, c}) <   K \}, \\ \hat {Z} _ {i, c} = \exp (\hat {s} _ {i, c}), \quad \hat {\mathcal {Z}} _ {i} = \sum_ {c \in \mathcal {I} _ {i}} \hat {Z} _ {i, c} + Z _ {i, \mathrm{swa}}, \end{array}\tag{9}
$$

This enables a native sparse-training implementation: each query routes over all $N / S$ chunk summaries, keeps the top-K chunks, and attends only to constant selected tokens. Thus, the routing cost, $O ( N / S )$ per token and $O ( N ^ { 2 } / S )$ per sequence, is the only quadratic term.

In conclusion, RQ1 is answered by showing that the LogSumExp chunk mass log $Z _ { i , c }$ can be expressed in the form of Eq. (7), where each chunk is represented by a compact summary $\left( \mathbf { k } _ { c } ^ { \prime } , b _ { c } ^ { \prime } \right)$ derived from the learnable landmark query $\mathbf { q } _ { c } ^ { \prime }$

Answering RQ2: Hierarchical softmax. To make $\mathbf { q } _ { c } ^ { \prime }$ learnable, a core idea is to enable $\hat { Z } _ { i , c }$ to participate in the forward pass of attention mass computation. Thus, we factorize the attention mass into an intra-chunk normalized term and an inter-chunk mass term, where the latter can be replaced by the learnable mass surrogate $\hat { Z } _ { i , c } .$ For tokens in selected chunks and the local sliding window, their normalized attention weight can be reformulated as

$$
w _ {i, j} = \frac {\exp (s _ {i , j})}{\mathcal {Z} _ {i}} = \underbrace {\frac {\exp (s _ {i , j})}{Z _ {i , c (j)}}} _ {\text {intra - chunk}} \times \underbrace {\frac {Z _ {i , c (j)}}{\mathcal {Z} _ {i}}} _ {\text {inter - chunk}} \approx \frac {\exp (s _ {i , j})}{Z _ {i , c (j)}} \times \underbrace {\frac {\hat {Z} _ {i , c (j)}}{\hat {\mathcal {Z}} _ {i}}} _ {\text {surrogate}},\tag{10}
$$

where $\hat { Z } _ { i , c ( j ) } = Z _ { i , \mathrm { s w a } }$ when $\ell ( i ) \leq j \leq i$ Intuitively, the model first aggregate relevant information within each selected chunk, then fuse chunk-level information according to the learned surrogate mass. Since $\hat { Z } _ { i , c }$ impacts the final attention weights, gradients from the LM loss can supervise the landmark representation learning and encourage chunks more useful for prediction to receive a larger mass. Empirically, this self-supervised surrogate outperforms naive BSA (Tab. 1 and Tab. 2), suggesting that end-to-end learning offers more effective allocation of attention mass.

## 4 Practical Design Choices

This section details our practical design choices on HiLS implementation across model architecture, GPU kernel design, and continuous training recipe.

## 4.1 Architectural Design

We follow mainstream open-source Transformer architectures such as Qwen3 [13] but replacing the standard full-attention with HiLS attention. In addition, we empirically find that slight architectural adjustments can better unleash the potential of HiLS attention, which we introduce below.

Positional Encoding. Empirically, when training with an 8K context length, we find that HiLS attention performs worse than the full-attention baseline in perplexity with standard RoPE [14]. Replacing RoPE with a partial RoPE variant, however, enables HiLS attention to outperform full attention in perplexity. Specifically, we adopt HoPE [15] positional encoding, which retains the RoPE dimensions whose rotation periods do not exceed the pre-training context length, and replaces the remaining dimensions with NoPE.

Low-Rank Query Calibration. In Eq. $\begin{array} { r } { ( 9 ) , \hat { \mathcal { Z } } _ { i } = \sum _ { c } \hat { Z } _ { i , c } + Z _ { i , \mathrm { s w a } } } \end{array}$ combines chunk-level mass surrogates with token-level attention mass. Since the chunk representation $\mathbf { k } _ { c } ^ { \prime }$ is not a token key but a compressed summary of multiple tokens, the original token-level query $\mathbf { q } _ { i }$ may not be optimal for estimating chunk-level mass. To better calibrate chunk scores, we introduce a lightweight lowrank query calibration (Q-Cal) module for the chunk-level surrogate. Empirically, this module significantly improves perplexity and length extrapolation. Specifically, denoting the hidden state of $x _ { i }$ as $\mathbf { h } _ { i } \in \mathbb { R } ^ { d _ { \mathrm { m o d e } } }$ <sup>l</sup> , the adapted query $\hat { \mathbf { q } } _ { i }$ and chunk score $\hat { s } _ { i , j }$ are formulated as:

$$
\Delta \mathbf {q} _ {i} = \mathbf {W} ^ {\mathrm{up}} \mathbf {W} ^ {\mathrm{down}} \mathbf {h} _ {i}, \quad \hat {\mathbf {q}} _ {i} = \mathbf {q} _ {i} + \Delta \mathbf {q} _ {i}, \quad \hat {s} _ {i, c} = \frac {\hat {\mathbf {q}} _ {i} ^ {\top} \mathbf {k} _ {c} ^ {\prime}}{\sqrt {d}} + b _ {c} ^ {\prime}\tag{11}
$$

where $\mathbf { W } ^ { \mathrm { u p } } \in \mathbb { R } ^ { d \times r }$ and $\mathbf { W } ^ { \mathrm { d o w n } } \in \mathbb { R } ^ { r \times d _ { \mathrm { m o d e l } } }$ represent the low-rank projection weights with $r \ll$ $d _ { \mathrm { m o d e l } }$

HiLS-Attention in GQA. Modern LLMs often adopt grouped-query attention (GQA) [16] to reduce KV cache memory, where multiple query heads share the same key-value head. This requires adapting the chunk-selection procedure of HiLS-Attention from the standard MHA setting. In MHA, each query head can independently select its own top-K chunks. In GQA, however, query heads within the same group should use the same retrieved chunk set, so that the selected tokens can be gathered once and processed efficiently with batched attention kernels. However, query heads in the same GQA group may attend to different chunks. To preserve head-level flexibility under the shared-retrieval constraint, we compute normalized chunk weights for each query head separately, aggregate them by taking the maximum over heads within the group, and select the top-K chunks using these group-level scores. In this way, a chunk can be selected if it is important to any head in the group. We provide the full formalization of this GQA-aware chunk selection procedure in Appendix C.

Landmark token free alternative. To avoid the engineering and implementation overhead of landmark tokens, we propose an alternative implementation. Instead of computing a unique query per chunk via landmark tokens, we employ a shared learnable query for each layer. Empirically, this approach achieves comparable in-domain performance, though its extrapolation capability degrades significantly. More details are given in the experiments.

## 4.2 Hardware-Efficient Kernel Design

An implementation challenge for sparse attention is that different tokens correspond to distinct chunk sets. Consequently, a naive implementation fails to achieve speedups and can cause memory explosion. In practice, efficient sparse attention requires hardware-software co-design.

NSA [5] provides a representative kernel design. As shown in Fig. 4a, NSA processes one query token at a time and loads its selected K/V chunks. For each selected chunk, the Tensor Core computation has shape $( G , d ) \times ( d , S )$ , where G is the number of query heads sharing the same K/V head under GQA, d is the head dimension, and S is the chunk size. Since Tensor Cores are most efficient when the matrix tile dimension is at least 16, MHA with $G = 1$ leads to severe under-utilization, effectively padding the query-head dimension from 1 to 16. NSA mitigates this issue by relying on GQA with $\bar { G } \geq 1 \bar { 6 }$ . However, this implicitly requires a query-to-KV head ratio of at least 16, which limits its applicability.

Instead, HiLS-Attention batches computation across both query tokens and query heads. Since adjacent query tokens often retrieve highly overlapping chunks, with the top-k overlap ratio reported to be as high as 80% [7], we group M adjacent query tokens and compute attention over the union of their selected chunks, as illustrated in Fig. 4b. This changes the Tensor Core computation to $( M \times G , d ) \times ( d , S )$ , so efficient Tensor Core utilization only requires $M \times G \geq 1 6 ,$ rather than $G \geq 1 6$ . Meanwhile, taking the union of selected chunks allows the packed queries to reuse loaded K/V chunks, reducing redundant memory access. This design does not require a large GQA group size and can also be applied to speculative decoding [17].

## 4.3 Continuous Training Strategies

To preserve the model’s original capabilities, we evaluate two continued-training strategies: (1) a lightweight, nearly training-free setup that freezes the base model and updates only the newly introduced parameters, and (2) full-parameter tuning.

![](images/6c6c59bd3ff6f128342b0006e4ffa05ce7cdb775af0a17656c08a4e29979d58a.jpg)

![](images/294d26099cc5cd0fb8f0914e6eaa47d05ff39cc69652523a6d74f1548067d88d.jpg)  
Figure 4: Kernel design of NSA and HiLS-Attention. Kernel design of NSA and HiLS-Attention. (a) NSA handles one query token per tile and computes attention over its selected chunks. Each Tensor Core operation has shape $( \bar { G } , \bar { d } ) \times ( d , S )$ , where G is the GQA group size and S is the chunk size. (b) HiLS-Attention packs M adjacent query tokens, attends to the union of their selected chunks, and enlarges the Tensor Core operation to $( \dot { M } \times \dot { G } , \dot { d } ) \times \dot { ( d , S ) }$ . This packing reuses overlapping K/V chunks across adjacent tokens.

• Landmark Token Tuning: In this setting, all base model parameters are frozen. The only trainable parameters are the landmark token embeddings and the projection matrices W<sup>up</sup>, W<sup>down</sup> in Eq. (10), accounting for less than 1% of total parameters. Empirically, we find that training on no more than 5B tokens is sufficient to achieve performance comparable to the base model.

• Full-Parameter Tuning: In this setting, the landmark token embeddings and low-rank query adapter parameters are randomly initialized, while all other parameters are inherited from the base model. All parameters are then jointly updated. This strategy is particularly effective when replacing the positional encoding with HoPE, thereby maximizing length generalization.

## 5 Small-scale Studies

We first conduct small-scale experiments to rigorously evaluate HiLS-Attention against diverse baselines and investigate the empirical impact of each core component on its performance, in order to gain further insight on the behavior of HiLS-Attention.

## 5.1 Main experiments

Setup. Following the architectural configurations of GPT-2 Medium [18], we train decoder-only transformers from scratch at the 345M parameter scale with different attention methods. All the models are initialized and trained using the same recipe with 8K context length (see details in Appendix E). For all the sparse attention variants, we allocate a 2K-token activation budget alongside a 512-token local sliding window, following findings of prior works that a 512-token window provides a strong efficiency-quality trade-off [19].

RULER [9] is a synthetic long-context task that inserts specified needles into the context and asks corresponding questions at the end, requiring the model to retrieve the relevant needles from the context. It is therefore commonly used to evaluate a model’s ability to retrieve task-relevant information from long inputs. Because small models have limited instruction-following ability, standard RULER-style prompts may not provide a clean measurement of in-context retrieval. We therefore convert 5% of the training samples into RULER-style Needle-in-a-Haystack (NIAH) tasks. This is achieved by inserting multiple needles into the context and appending the corresponding query and answer at the end.

Baselines. We benchmark HiLS-Attention against three categories of attention methods: (1) Full At tention, and its extrapolation-enhanced variant with HoPE position embedding Full-Attn (HoPE) [15]; (2) Sliding-Window Attention (SWA), with a fixed 512-token window size across all layers; and (3) State-of-the-Art Sparse Attention, including Native Sparse Attention (NSA) [5], DashAttention [20],

Table 1: Perplexity (PPL) of models with 345M parameters trained on 8K context and evaluated with different context lengths (from 64 to 512K). For fair comparison, some baselines add the extra 0.6% parameters introduced by HiLS-attention to their MLP modules, denoted as “extra MLP”. Since the InfLLM v2 kernel only supports head dimensions ≥ 128, it is not directly aligned with the other models using head dimension 64. We mark InfLLM v2 with an asterisk (\*) to indicate that its results are reported for reference. Bold numbers indicate the best PPL at each context length, and underlined numbers indicate the second-best PPL. Overall, HiLS-Attention achieves consistently strong performance across context lengths and demonstrates better long-context extrapolation.

<table><tr><td>Models</td><td>Extra #Param</td><td>64</td><td>128</td><td>512</td><td>8K</td><td>32K</td><td>128K</td><td>512K</td></tr><tr><td>Full-Attn RoPE</td><td>-</td><td>33.92</td><td>26.89</td><td>18.68</td><td>4.96</td><td> $> 10^{2}$ </td><td></td><td></td></tr><tr><td>Full-Attn HoPE</td><td>-</td><td>34.15</td><td>26.97</td><td>18.73</td><td>4.95</td><td>6.42</td><td> $> 10^{2}$ </td><td></td></tr><tr><td>Full-Attn HoPE (extra MLP)</td><td>0.6%</td><td>34.28</td><td>27.12</td><td>18.76</td><td>4.95</td><td>5.85</td><td> $> 10^{2}$ </td><td></td></tr><tr><td>SWA-RoPE</td><td>-</td><td>35.38</td><td>27.94</td><td>19.30</td><td>8.95</td><td>9.01</td><td>8.44</td><td>8.47</td></tr><tr><td>NSA-RoPE</td><td>0.2%</td><td>34.15</td><td>27.11</td><td>18.85</td><td>5.01</td><td>7.62</td><td>11.75</td><td>19.14</td></tr><tr><td>Dash-Attention-RoPE</td><td>0.006%</td><td>33.70</td><td>26.74</td><td>18.67</td><td>5.00</td><td> $> 10^{2}$ </td><td></td><td></td></tr><tr><td>HSA-Ultralong</td><td>12.7%</td><td>33.19</td><td>26.26</td><td>21.50</td><td>8.81</td><td>5.84</td><td>4.99</td><td>4.54</td></tr><tr><td>Naive-BSA-HoPE</td><td>-</td><td>36.12</td><td>29.06</td><td>20.45</td><td>4.94</td><td>3.94</td><td>8.67</td><td>OOM</td></tr><tr><td>HiLS-Attn-HoPE</td><td>0.6%</td><td>33.97</td><td>26.91</td><td>18.65</td><td>4.94</td><td>4.34</td><td>4.71</td><td>5.95</td></tr><tr><td>InfLLM v2*</td><td>0.006%</td><td>33.71</td><td>26.74</td><td>18.55</td><td>4.95</td><td>13.68</td><td>64.24</td><td>OOM</td></tr></table>

InfLLM v2 [21] and HSA-UltraLong [22]. For fair comparison, we use the same sparsity-related hyperparameters across all sparse baselines, including the local sliding-window size 512, chunk size 64, and top-K 32. This ensures that different methods operate under a comparable attention budget.

Evaluation Metrics. As small models have limited instruction-following ability, we assess model capability via language modeling perplexity (PPL) and in-context retrieval performance. We quantify retrieval capability using the RULER benchmark [9], focusing on three representative evaluation primitives: Single Needle (S-N), Multi-Key Multi-Query (MK-MQ, with 6 KV pairs and 2 ordered retrieval queries), and Variable Tracking (VT, comprising 6 assignments spanning up to 2 pointer hops). We argue that evaluating sparse attention on RULER should be conducted on small-scale models, since most tasks are essentially “find & copy” and larger models may compensate for retrieval inaccuracies with broader information bandwidth.

Table 2: RULER results for 345M models trained with an 8K context length. We additionally report ultra-long extrapolation results of HiLS-Attn-HoPE at 1M–4M context lengths. HiLS is the only native sparse attention method that achieves perfect in-domain NIAH performance, while also demonstrating remarkable extrapolation capability.

<table><tr><td rowspan="2">Models</td><td colspan="3">8K</td><td colspan="3">16K</td><td colspan="3">32K</td><td colspan="3">128K</td><td colspan="3">512K</td></tr><tr><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td></tr><tr><td>Full-Attn RoPE</td><td>100</td><td>97</td><td>34</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>Full-Attn HoPE</td><td>100</td><td>98</td><td>36</td><td>99</td><td>97</td><td>21</td><td>72</td><td>11</td><td>11</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>Full-Attn HoPE (extra MLP)</td><td>100</td><td>99</td><td>39</td><td>100</td><td>97</td><td>13</td><td>83</td><td>19</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>SWA-RoPE</td><td>18</td><td>8</td><td>22</td><td>4</td><td>1</td><td>11</td><td>8</td><td>2</td><td>7</td><td>2</td><td>1</td><td>12</td><td>0</td><td>1</td><td>8</td></tr><tr><td>NSA-RoPE</td><td>49</td><td>17</td><td>16</td><td>6</td><td>5</td><td>4</td><td>5</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>Dash-Attention-RoPE</td><td>92</td><td>67</td><td>34</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>HSA-Ultralong</td><td>87</td><td>79</td><td>23</td><td>92</td><td>75</td><td>17</td><td>82</td><td>74</td><td>15</td><td>80</td><td>60</td><td>21</td><td>65</td><td>42</td><td>8</td></tr><tr><td>Naive-BSA-HoPE</td><td>100</td><td>97</td><td>23</td><td>99</td><td>89</td><td>16</td><td>98</td><td>77</td><td>13</td><td>46</td><td>0</td><td>0</td><td>-</td><td>-</td><td>-</td></tr><tr><td>HiLS-Attn-HoPE</td><td>100</td><td>95</td><td>72</td><td>100</td><td>94</td><td>65</td><td>100</td><td>95</td><td>68</td><td>99</td><td>95</td><td>61</td><td>99</td><td>91</td><td>66</td></tr><tr><td>InfLLM v2*</td><td>77</td><td>39</td><td>25</td><td>21</td><td>0</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>-</td><td>-</td><td>-</td></tr><tr><td rowspan="4"></td><td colspan="12">Results on longer context length</td><td rowspan="4"></td><td rowspan="4"></td><td rowspan="4"></td></tr><tr><td rowspan="2" colspan="3">Models</td><td colspan="3">1M</td><td colspan="3">2M</td><td colspan="3">4M</td></tr><tr><td colspan="3">S-N MK-MQ VT</td><td colspan="3">S-N MK-MQ VT</td><td colspan="3">S-N MK-MQ VT</td></tr><tr><td colspan="3">HiLS-Attn-HoPE</td><td>100</td><td>97</td><td>53</td><td>97</td><td>87</td><td>50</td><td>96</td><td>89</td><td>43</td></tr></table>

Results and Analysis. Tab. 1 and 2 present the small-scale evaluation results. Based on these empirical results, we have the following key observations.

Table 3: Perplexity for 345M models continue trained with a 256K context length on 10B tokens.

<table><tr><td>Models</td><td>Extra #Param</td><td>8K</td><td>32K</td><td>128K</td><td>256K</td><td>512K</td><td>1M</td></tr><tr><td colspan="8"> $RoPE \theta = 1 \times 10^7$ </td></tr><tr><td>Full-Attn RoPE</td><td>-</td><td>9.11</td><td>8.86</td><td>8.11</td><td>7.49</td><td>7.54</td><td>8.61</td></tr><tr><td>HiLS-Attn-HoPE</td><td>0.6%</td><td>9.08</td><td>8.88</td><td>8.15</td><td>7.45</td><td>7.37</td><td>8.08</td></tr><tr><td colspan="8"> $RoPE \theta = 1 \times 10^4$ </td></tr><tr><td>Full-Attn RoPE</td><td>-</td><td>9.22</td><td>9.17</td><td>8.54</td><td>7.87</td><td>7.82</td><td>9.18</td></tr><tr><td>Full-Attn HoPE</td><td>-</td><td>9.20</td><td>8.93</td><td>8.15</td><td>7.53</td><td> $>10^2$ </td><td></td></tr><tr><td>HiLS-Attn-HoPE</td><td>0.6%</td><td>9.09</td><td>8.89</td><td>8.17</td><td>7.51</td><td>7.55</td><td>8.44</td></tr></table>

• Expressiveness limitations prevent perfect NIAH, even under in-domain settings. On the simplest Single-NIAH task, only Naive BSA and HiLS-Attention sustain performance comparable to full attention within the 8K in-domain context length. By contrast, existing sparse attention that use mean-pooled summaries, including NSA, DashAttention, and InfLLM v2, show noticeable degradation. This supports our analysis in Sec. 2.2: mean-pooled chunk summaries have limited expressiveness, as they dilute highly concentrated attention mass—precisely the pattern required by NIAH, where only a few needle tokens dominate.

• HiLS-Attention learns more robust sparse attention allocation than naive BSA. HiLS-Attn achieves PPL comparable to naive-BSA at the training length (4.94 v.s. 4.94 at 8K), but performs much better under context interpolation (≤ 256K) and extrapolation (> 256K). Together with the RULER results (where HiLS significantly leads for both within and beyond the training context length settings), this suggests that HiLS does not simply mimic the behavior of full-attention and estimate the full-attention-induced chunk mass, but it indeed learns more effective sparse attention allocation over important context tokens. A possible reason is that token-level full attention has an inherent noise issue: as long as a token logit is not −∞, the token receives non-zero attention mass. Since the model cannot learn −∞ attention logits for all irrelevant tokens in practice, these irrelevant tokens inevitably consume small but nonzero probability mass, injecting noise to the probability mass. As the context grows longer, these small noisy masses accumulate over many irrelevant tokens, making the full-attention-induced chunk mass a noisy selection signal. This may lead naive BSA to suboptimal chunk selection, which is consistent with its inferior downstream performance compared with HiLS.

• Compression Enhances In-context Retrieval. HiLS-Attn not only outperforms naive-BSA, but also substantially surpasses full attention on variable tracking (VT), a task that requires multi-hop reasoning. We attribute this gain to compression: it allows token-level noise to partially cancel out while preserving shared semantic signals, thereby yielding more reliable retrieval representations. Concretely, if each key can be decomposed as $\mathbf { k } _ { i } = \mathrm { s e m a n t i c } ( \mathbf { k } _ { i } ) + \mathrm { n o i s e } ( \mathbf { k } _ { i } )$ , then compression aggregates multiple keys into $\mathbf { k } _ { c } ^ { \prime }$ . The noise terms, being less aligned, tend to cancel out, while the shared semantic signal is preserved, yielding a cleaner representation. Therefore, compression may lead to better in-context retrieval. From this perspective, we conjecture that HiLS’s strong extrapolation ability stems from its improved in-domain retrieval capability.

## 5.2 Long-context Scaling

Under the aforementioned setting, the sparsity of HiLS-Attention remains no less than 25%, i.e., 2K out of an 8K context. To evaluate the model’s performance under even higher sparsity, we extend the training context length to 256K while keeping a maximum of 2K tokens activated, thereby validating its capabilities in both sparser and longer-context regimes.

Continued-Training Setup. To validate HiLS-Attention under a longer training context length, we continue training the 345M checkpoints from the previous 8K-context models using a 256K context length. Before continued training, we enlarge the RoPE base from $1 \times 1 0 ^ { 4 } \mathrm { ~ t o ~ } 1 \times 1 0 ^ { 7 }$ for the RoPE-based positional components to expand the perceptible range of global positions. The continued training data are from allenai/dolma3\_longmino\_mix-50B-1025 [23], i.e., the long-context mixture used for Olmo 3 7B long-context training. We train both the Full-Attn and HiLS-Attn-HoPE models under the same settings.

Table 4: RULER results for 345M models continue trained with a 256K context length on 10B tokens.

<table><tr><td rowspan="2">Models</td><td colspan="3">8K</td><td colspan="3">32K</td><td colspan="3">128K</td><td colspan="3">256K</td><td colspan="3">512K</td><td colspan="3">1M</td></tr><tr><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td></tr><tr><td colspan="19"> $RoPE \theta = 1 \times 10^7$ </td></tr><tr><td>Full-Attn RoPE</td><td>100</td><td>2</td><td>1</td><td>100</td><td>5</td><td>3</td><td>100</td><td>5</td><td>7</td><td>99</td><td>6</td><td>5</td><td>41</td><td>1</td><td>0</td><td>2</td><td>0</td><td>0</td></tr><tr><td>HiLS-Attn-HoPE</td><td>100</td><td>2</td><td>51</td><td>100</td><td>11</td><td>54</td><td>99</td><td>6</td><td>50</td><td>100</td><td>5</td><td>56</td><td>97</td><td>13</td><td>51</td><td>96</td><td>5</td><td>46</td></tr><tr><td colspan="19"> $RoPE \theta = 1 \times 10^4$ </td></tr><tr><td>Full-Attn RoPE</td><td>11</td><td>7</td><td>0</td><td>3</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>Full-Attn HoPE</td><td>99</td><td>19</td><td>12</td><td>99</td><td>41</td><td>5</td><td>96</td><td>36</td><td>7</td><td>84</td><td>30</td><td>7</td><td>2</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>HiLS-Attn-HoPE</td><td>100</td><td>87</td><td>42</td><td>98</td><td>87</td><td>44</td><td>100</td><td>75</td><td>54</td><td>98</td><td>79</td><td>42</td><td>97</td><td>64</td><td>19</td><td>96</td><td>64</td><td>22</td></tr></table>

Results. After extending the training context to 256K, Tab. 3 shows that HiLS-Attention consistently achieves lower perplexity across all settings when evaluated at a length of 256K than full attention.

We observe several interesting phenomena. First, without enlarging the RoPE base, Full-Attn RoPE almost fails on all RULER tasks, showing that the original positional range is insufficient for 256K contexts. However, when the RoPE base is enlarged, both are near zero on MK-MQ, suggesting that changing the RoPE base breaks the retrieval pattern learned within 8K. Surprisingly, HiLS-Attn-HoPE still performs better than Full-Attn RoPE on variable tracking (VT). This aligns with our earlier observation that compression can enhance in-context retrieval in § 5.1. VT requires retrieving a small number of relevant variable assignments from a long context; under full attention, irrelevant tokens still receive small but nonzero attention mass, and their accumulated noise can dilute the useful retrieval signal. By contrast, HiLS uses compressed-key retrieval, where token-level noise can partially cancel out while shared semantic signals are preserved, leading to cleaner retrieval and better VT performance.

Second, HiLS-Attn-HoPE consistently outperforms Full-Attn HoPE/RoPE under the same 256K training setting, despite activating at most 2K tokens. This shows that HiLS-Attention’s sparsity does not sacrifice model capability; instead, accurate sparse retrieval can yield lower perplexity and much stronger long-context retrieval ability.

Overall, these results suggest that HiLS-Attn provides a promising path toward ultra-long or even infinite-context training. Infinite-context training must rely on native sparse attention to keep the attention cost bounded, whose key challenge is to ensure that the sparsely selected blocks contain relevant KV states. The strong length-extrapolation ability of HiLS-Attn provides a highly feasible approach to this problem: it can learn retrieval patterns in short contexts and generalize them to much longer contexts, enabling reliable block selection with ultra-long training length. Combined with the fixed computation cost of sparse attention, this makes infinite-context training practically possible.

## 5.3 Ablation Study

Configurations. To isolate the contributions of each component in HiLS-Attention, we benchmark the default setting against the variants in Tab. 5.

Main Findings. The ablation results in Tab. 6 and 7 show that HoPE positional encoding, query augmentation, and landmark tokens all contribute to the overall performance improvement.

• Impact of Low-Rank Query Calibration: Excluding the low-rank path (w/o Q-Cal in Tab. 6) severely degrades performance, whereas overly expanding the rank dimension (r=128 in Table 7) conversely impairs length extrapolation. We conjecture that $\Delta Q$ helps decouple token-level attention from the chunk-level mass surrogate, as they operate at different information level. Although this phenomenon is consistently observed in our experiments, the underlying mechanism is not yet fully understood, and we leave a more principled investigation to future work.

• Necessity of Landmark Tokens: While the landmark-free variant (w/o lmk, shared $\mathbf { q } _ { c } )$ offers a viable in-domain alternative, its context extrapolation capability degrades rapidly. This demonstrates that specific landmark tokens are indispensable for robust generalization over ultra-long sequences. As discussed in Sec. 3, the effectiveness of a chunk compressed-key is determined by the quality of its learned query $\mathbf { q } _ { c } ^ { \prime } .$ . Since the shared $\mathbf { q } _ { c }$ is only a fixed set of parameters, its expressive power is inherently limited and may fail to capture diverse chunk-level semantics. By contrast, landmark-token queries are produced by the full Transformer computation, including both attention and MLP layers, allowing them to exploit the model’s full capacity and adaptively encode each chunk. This explains why landmark tokens are essential for robust long-context extrapolation.

Table 5: Summary of ablation variants and their configuration details.

<table><tr><td>Ablation Variants</td><td>Description</td></tr><tr><td colspan="2">Query Calibration (Q-Cal) Variants</td></tr><tr><td>w/ Q-Cal (r)</td><td>Employ the low-rank query projection in Eq. (11) with rank r.</td></tr><tr><td>w/ full-rank</td><td>Replaces the low-rank projection with a full-rank linear transformation  $\hat{\mathbf{q}}_{i} = \mathbf{W}^{\hat{Q}}\mathbf{h}_{i}$ , where  $\mathbf{W}^{\hat{Q}} \in \mathbb{R}^{d_{model} \times d_{model}}$ .</td></tr><tr><td>w/o Q-Cal</td><td>Remove the extra  $\Delta \mathbf{q}$  term from the query.</td></tr><tr><td colspan="2">Chunk Summarization Variants</td></tr><tr><td>w/o Prop. 3.1</td><td>Use the raw landmark token key directly as the routing key  $\mathbf{k}'_{c}$  without Taylor expansion rectification in Eq (7).</td></tr><tr><td>LMK-Attn</td><td>Align with Landmark Attention [8] by removing the extra  $\Delta \mathbf{q}$  and using the landmark key.</td></tr><tr><td>w/ mean pooling</td><td>Use mean-pooled keys as the summary  $\mathbf{k}'_{c}$  for each chunk.</td></tr><tr><td>w/o lmk, shared  $\mathbf{q}_{c}$ </td><td>Remove landmark tokens and replace  $\mathbf{q}'_{c}$  in Eq. (8) with a shared query  $\mathbf{q}_{c}$ .</td></tr></table>

Table 6: Ablation perplexity (PPL) of 345M models trained on 8K context.

<table><tr><td>Models</td><td>Extra #Param</td><td>64</td><td>128</td><td>512</td><td>8K</td><td>32K</td><td>128K</td><td>512K</td></tr><tr><td colspan="9">HiLS-Attn-HoPE</td></tr><tr><td>w/ Q-Cal (r = 64)</td><td>0.6%</td><td>33.97</td><td>26.91</td><td>18.65</td><td>4.94</td><td>4.34</td><td>4.71</td><td>5.95</td></tr><tr><td>w/ Q-Cal (r = 128)</td><td>1.2%</td><td>33.89</td><td>26.77</td><td>18.61</td><td>4.95</td><td>4.26</td><td>4.54</td><td>5.85</td></tr><tr><td>w/ full-rank</td><td>4.9%</td><td>34.02</td><td>26.93</td><td>18.66</td><td>4.94</td><td>4.62</td><td>5.03</td><td>6.52</td></tr><tr><td>w/o Q-Cal</td><td>0%</td><td>34.04</td><td>26.86</td><td>18.68</td><td>4.97</td><td>7.21</td><td>12.40</td><td>16.93</td></tr><tr><td>w/o Prop. 3.1</td><td>0.6%</td><td>34.13</td><td>27.05</td><td>18.74</td><td>4.97</td><td>4.28</td><td>4.73</td><td>6.61</td></tr><tr><td>LMK-Attn</td><td>0%</td><td>34.02</td><td>26.93</td><td>18.75</td><td>4.98</td><td>6.36</td><td>10.97</td><td>14.10</td></tr><tr><td>w/ mean pooling</td><td>0.6%</td><td>33.82</td><td>27.14</td><td>19.03</td><td>5.04</td><td>4.85</td><td>5.55</td><td>8.00</td></tr><tr><td>w/o lmk, shared qc</td><td>0.6%</td><td>34.02</td><td>26.92</td><td>18.65</td><td>4.94</td><td>4.71</td><td>5.50</td><td>7.94</td></tr><tr><td colspan="9">HiLS-Attn-RoPE</td></tr><tr><td>w/ Q-Cal (r = 64)</td><td>0.6%</td><td>34.61</td><td>27.30</td><td>18.89</td><td>5.00</td><td>&gt;102</td><td></td><td></td></tr><tr><td>w/ full-rank</td><td>4.9%</td><td>34.04</td><td>26.96</td><td>18.73</td><td>4.97</td><td>&gt;102</td><td></td><td></td></tr><tr><td>w/o Q-Cal</td><td>0%</td><td>34.10</td><td>26.97</td><td>18.76</td><td>5.03</td><td>9.66</td><td>10.46</td><td>24.94</td></tr><tr><td colspan="9">HiLS-Attn-NoPE</td></tr><tr><td>w/ Q-Cal (r = 64)</td><td>0.6%</td><td>36.57</td><td>28.94</td><td>20.01</td><td>5.13</td><td>9.69</td><td>37.46</td><td>89.89</td></tr><tr><td>w/ full-rank</td><td>4.9%</td><td>36.07</td><td>28.63</td><td>19.83</td><td>5.10</td><td>5.37</td><td>28.26</td><td>82.31</td></tr><tr><td>w/o Q-Cal</td><td>0%</td><td>36.78</td><td>29.10</td><td>20.09</td><td>5.17</td><td>29.02</td><td>&gt;102</td><td></td></tr></table>

• Efficacy of Positional Encodings: Incorporating HoPE yields the best performance, significantly outperforming alternative methods such as RoPE and NoPE. By applying RoPE only to dimensions whose rotation periods are covered during training and NoPE otherwise, HoPE avoids out-ofdistribution positional rotations beyond the training length. Although HoPE brings marginal gains in length extrapolation and perplexity for full attention, its integration with HiLS-Attention delivers substantial gains in both in-domain performance and long-context extrapolation. We hypothesize that HoPE improves HiLS-Attention by reducing the interference of rotary positional encodings during chunk compression. Since chunk compression performs a weighted aggregation over keys $\mathbf { k } _ { i } ,$ , applying RoPE to all dimensions also aggregates different positional rotations, which can distort the resulting semantic representation. The NoPE dimensions in HoPE provide a positionindependent semantic subspace, helping preserve chunk semantics and thereby improving both in-domain performance and length extrapolation.

Table 7: Ablation RULER results for 345M models trained with an 8K context length.

<table><tr><td rowspan="2">Models</td><td colspan="3">8K</td><td colspan="3">16K</td><td colspan="3">32K</td><td colspan="3">128K</td><td colspan="3">512K</td></tr><tr><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td></tr><tr><td colspan="16">HiLS-Attn-HoPE</td></tr><tr><td>w/ Q-Cal (r = 64)</td><td>100</td><td>95</td><td>72</td><td>100</td><td>94</td><td>65</td><td>100</td><td>95</td><td>68</td><td>99</td><td>95</td><td>61</td><td>99</td><td>91</td><td>66</td></tr><tr><td>w/ Q-Cal (r = 128)</td><td>100</td><td>94</td><td>64</td><td>100</td><td>89</td><td>47</td><td>97</td><td>92</td><td>64</td><td>95</td><td>89</td><td>57</td><td>91</td><td>86</td><td>56</td></tr><tr><td>w/ full-rank</td><td>100</td><td>98</td><td>75</td><td>96</td><td>88</td><td>57</td><td>97</td><td>89</td><td>64</td><td>92</td><td>91</td><td>54</td><td>92</td><td>77</td><td>56</td></tr><tr><td>w/o Q-Cal</td><td>99</td><td>77</td><td>49</td><td>98</td><td>74</td><td>20</td><td>88</td><td>64</td><td>23</td><td>71</td><td>33</td><td>5</td><td>39</td><td>1</td><td>0</td></tr><tr><td>w/o Prop. 3.1</td><td>100</td><td>93</td><td>69</td><td>100</td><td>89</td><td>60</td><td>98</td><td>91</td><td>57</td><td>97</td><td>91</td><td>63</td><td>83</td><td>83</td><td>52</td></tr><tr><td>LMK-Attn</td><td>96</td><td>79</td><td>38</td><td>76</td><td>47</td><td>23</td><td>65</td><td>31</td><td>9</td><td>17</td><td>9</td><td>8</td><td>3</td><td>1</td><td>0</td></tr><tr><td>w/ mean pooling</td><td>92</td><td>68</td><td>29</td><td>82</td><td>34</td><td>11</td><td>70</td><td>23</td><td>12</td><td>55</td><td>3</td><td>1</td><td>24</td><td>2</td><td>1</td></tr><tr><td>w/o lmk, shared  $q_c$ </td><td>99</td><td>80</td><td>35</td><td>98</td><td>82</td><td>22</td><td>95</td><td>71</td><td>20</td><td>85</td><td>32</td><td>10</td><td>54</td><td>2</td><td>4</td></tr><tr><td colspan="16">HiLS-Attn-RoPE</td></tr><tr><td>w/ Q-Cal (r = 64)</td><td>99</td><td>81</td><td>52</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>w/ full-rank</td><td>100</td><td>90</td><td>57</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>w/o Q-Cal</td><td>84</td><td>74</td><td>29</td><td>39</td><td>20</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td colspan="16">HiLS-Attn-NoPE</td></tr><tr><td>w/ Q-Cal (r = 64)</td><td>100</td><td>90</td><td>64</td><td>98</td><td>81</td><td>47</td><td>68</td><td>41</td><td>21</td><td>22</td><td>15</td><td>4</td><td>7</td><td>2</td><td>0</td></tr><tr><td>w/ full-rank</td><td>90</td><td>88</td><td>70</td><td>85</td><td>73</td><td>53</td><td>70</td><td>47</td><td>27</td><td>24</td><td>23</td><td>7</td><td>3</td><td>4</td><td>0</td></tr><tr><td>w/o Q-Cal</td><td>96</td><td>41</td><td>26</td><td>91</td><td>34</td><td>17</td><td>32</td><td>4</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr></table>

Table 8: Downstream task evaluation results for 1.4B model after 300B-token training.

<table><tr><td>Models</td><td>LAMBADA</td><td>HellaSwag</td><td>PIQA</td><td>WinoGrande</td><td>OpenBookQA</td><td>ARC-e25-shot</td><td>ARC-c25-shot</td><td>ARC-e</td><td>ARC-c</td><td>AVG</td></tr><tr><td>Random-Guess</td><td>-</td><td>25.00</td><td>50.00</td><td>50.00</td><td>25.00</td><td>25.00</td><td>25.00</td><td>25.00</td><td>25.00</td><td>25.00</td></tr><tr><td>Full-Attn RoPE</td><td>57.13</td><td>51.99</td><td>70.51</td><td>56.51</td><td>22.60</td><td>68.25</td><td>36.95</td><td>44.44</td><td>29.49</td><td>48.65</td></tr><tr><td>HiLS-Attn HoPE</td><td>57.05</td><td>52.21</td><td>72.14</td><td>55.64</td><td>22.50</td><td>70.02</td><td>37.97</td><td>45.86</td><td>28.14</td><td>49.06</td></tr></table>

## 6 Large-scale Experiments

## 6.1 Training from scratch

To further test whether native sparse training can match full attention at a larger scale, we train a 1.4B-parameter model from scratch on 300B tokens. We track perplexity and length extrapolation performance throughout training, and evaluate the final model on multiple downstream tasks. We use full attention with RoPE as the baseline, as it achieves lower perplexity than full attention with HoPE within 512-token context in Tab. 1, forming a stronger baseline for benchmarks whose average sequence length is below 64 tokens. We evaluate PPL and NIAH tasks every 20K steps to track extrapolation stability and their performance discrepancy during training. Details about the model hyperparameters and training recipe are given in Appendix D. Benchmark details are listed in Appendix F.

Results. Fig. 5(a) shows that the results are consistent with our small-scale findings: HiLS-attention and full-attention achieve almost identical PPL across different context lengths and training stages, especially close at 8K. This indicates that HiLS-attention, despite being trained with native sparsity, preserves short-context modeling ability that is fully comparable to full-attention. Figure 5(b) confirms that HiLS-Attention’s extrapolation remains stable without decaying over training. Furthermore, Tab. 8 reveals that despite native sparse training—where HiLS-attention attends to less than half of the tokens of full-attention—it still achieves comparable or better performance, thanks to its accurate retrieval. Overall, although HiLS-Attention modifies the standard attention form and is trained from scratch with native sparsity, it remains comparable to full-attention on short-context tasks while showing substantially stronger length extrapolation.

## 6.2 Continue Pre-Training with HiLS-Attention

Since prompt lengths in most benchmarks rarely exceed 1,000 tokens — with Tab. 8 averaging under 64 tokens — they often fall entirely within HiLS-Attention’s sliding-window range. Therefore, we scale up the model size and evaluate on practical long-context tasks like LongBench [10] to validate its efficacy in real-world long-range scenarios.

(a)  
(b)  
![](images/6859311329b07a4af3f77ba713fa93d5a27bfd6b44635cf64aa50f1f7876e46b.jpg)  
Figure 5: Perplexity (a) and RULER accuracy (b) of the 1.4B model at different training steps. Left: Full-Attention with RoPE; right: HiLS-Attention with HoPE. The annotated values on the curves correspond to the final checkpoint (143k steps), which is highlighted with star markers and thicker lines. The detailed per-step results are deferred to Appendix H (Tab. 15 & Tab. 16).

Setup. We start from the Olmo3-1025-7B base checkpoint [24], which uses standard MHA and a repeating pattern of three 4K sliding-window layers followed by one full-attention layer [25]. We replace the full-attention layers with HiLS-Attn and reduce the sliding-window size from 4K to 512 tokens, preserving the 3:1 pattern while shifting long-range modeling to the HiLS retrieval branch.

Following the small- and medium-scale settings, we set the chunk size to 64 and the HiLS top-k to 32, which retrieves 32 × 64 = 2048 tokens under the 8K continue-pretraining length. Detailed training recipe can be found in Appendix E.

We compare HiLS-Attn variants against two baselines in Tab. 9.

LMK token tuning follows the training-free recipe in Sec. 4.3: all base parameters are frozen, and only the inserted landmark-token embeddings and the W<sup>up</sup>, W<sup>down</sup> projections are updated. In this stage, we conduct training on 5B tokens and use the same learning-rate schedule as above.

Olmo3-512swa-CPT is a full-parameter continued-pretraining baseline that keeps the original fullattention layers but reduces the sliding-window size in every SWA layer from 4K to 512 tokens, matching the local window used by our HiLS-Attn models. This baseline isolates the effect of shrinking the local attention window without introducing HiLS retrieval; it uses the same 50B-token continued-pretraining recipe and optimizer schedule as the HiLS models.

Results. The results on the 7B model are generally consistent with those on small- and mediumscale models: HiLS results are overall comparable or even slightly better than baselines (including full-attention) on general tasks. We note that the slightly higher 8K perplexity of HiLS-Attn-HoPE-Q-Cal in Tab. 10 (3.234 v.s. 3.236) mainly comes from the migration cost of continuing training from a full-attention checkpoint, which is not observed from native HiLS-Attention training from scratch. The gap consistently shrinks with more training tokens, and detailed results are provided in the Appendix G. Considering that most tasks in Tab. 9 have an average length of around 1K, this only indicates that HiLS-Attention has on-par ability to full attention in short contexts. In contrast, the LongBench results in Tab. 11 can sufficiently demonstrate the long-context capability of HiLS-Attention. Even with the extrapolation enhancement provided by YaRN [11], there remains a noticeable gap on LongBench compared with the training-free HiLS-Attention.

Table 9: General Downstream task results for OLMo3-7B continue pretraining.

<table><tr><td rowspan="2">Benchmarks</td><td colspan="2">Freezing param.</td><td colspan="4">Full param. CPT</td></tr><tr><td>Olmo3 Base</td><td>LMK token tuning</td><td>Olmo3 512swa</td><td>HiLS-Attn HoPE-Q-Cal</td><td>HiLS-Attn RoPE-Q-Cal</td><td>HiLS-Attn NoPE-Q-Cal</td></tr><tr><td colspan="7">Long-Context Retrieval</td></tr><tr><td>RULER-8K</td><td>11.34</td><td>22.33</td><td>99.67</td><td>99.00</td><td>98.67</td><td>99.67</td></tr><tr><td>RULER-16K</td><td>3.67</td><td>2.00</td><td>33.00</td><td>98.67</td><td>50.67</td><td>73.33</td></tr><tr><td>RULER-64K</td><td>0.00</td><td>1.00</td><td>1.33</td><td>97.33</td><td>4.33</td><td>0.33</td></tr><tr><td>RULER-128K</td><td>0.00</td><td>0.67</td><td>0.00</td><td>94.67</td><td>1.00</td><td>0.00</td></tr><tr><td>Average</td><td>3.75</td><td>6.50</td><td>33.50</td><td>97.42</td><td>38.67</td><td>43.33</td></tr><tr><td colspan="7">General Knowledge</td></tr><tr><td>MMLU(5-shot)</td><td>59.90</td><td>58.07</td><td>59.12</td><td>56.58</td><td>56.69</td><td>56.51</td></tr><tr><td>GPQA(5-shot)</td><td>29.29</td><td>32.32</td><td>31.31</td><td>34.34</td><td>24.75</td><td>29.80</td></tr><tr><td>Hellaswag(10-shot)</td><td>44.17</td><td>43.25</td><td>42.96</td><td>38.71</td><td>33.17</td><td>34.24</td></tr><tr><td>ARC-c(25-shot)</td><td>53.56</td><td>52.88</td><td>55.59</td><td>55.93</td><td>54.92</td><td>53.90</td></tr><tr><td>BoolQ(5-shot)</td><td>61.01</td><td>61.10</td><td>64.22</td><td>64.71</td><td>63.43</td><td>63.43</td></tr><tr><td>Race(3-shot)</td><td>73.89</td><td>70.34</td><td>72.97</td><td>69.75</td><td>69.50</td><td>70.21</td></tr><tr><td colspan="7">Mathematics</td></tr><tr><td>CMath</td><td>41.53</td><td>42.08</td><td>39.98</td><td>43.35</td><td>42.44</td><td>40.16</td></tr><tr><td>GSM8K</td><td>37.00</td><td>37.00</td><td>33.43</td><td>36.85</td><td>35.71</td><td>35.03</td></tr><tr><td colspan="7">Code</td></tr><tr><td>CRUX</td><td>24.62</td><td>24.62</td><td>24.50</td><td>25.12</td><td>25.62</td><td>25.75</td></tr><tr><td>HumanEval+</td><td>20.10</td><td>19.50</td><td>19.50</td><td>18.90</td><td>18.90</td><td>17.70</td></tr><tr><td>MBPP+</td><td>37.60</td><td>33.80</td><td>32.30</td><td>32.60</td><td>33.30</td><td>31.10</td></tr><tr><td>Average</td><td>43.88</td><td>43.18</td><td>43.24</td><td>43.35</td><td>41.68</td><td>41.62</td></tr></table>

Table 10: Validation perplexity on the Olmo3 pretraining corpus at different context lengths. Lower is better. Models are continued-pretrained at 8K length. Perplexity values are reported to three decimal places to better highlight small differences across models.

<table><tr><td>Models</td><td>512</td><td>8K</td><td>16K</td><td>64K</td><td>128K</td><td>256K</td></tr><tr><td>Olmo3-base</td><td>10.396</td><td>3.997</td><td>6.898</td><td>11.003</td><td>11.226</td><td>14.554</td></tr><tr><td>LDM token tuning</td><td>10.394</td><td>3.470</td><td>5.124</td><td>7.058</td><td>6.126</td><td>7.770</td></tr><tr><td>Olmo3-512swa-CPT</td><td>10.180</td><td>3.234</td><td>4.398</td><td>5.218</td><td>6.984</td><td>12.760</td></tr><tr><td>HiLS-Attn-HoPE</td><td>10.201</td><td>3.236</td><td>2.772</td><td>2.722</td><td>2.550</td><td>3.095</td></tr><tr><td>HiLS-Attn-RoPE</td><td>10.200</td><td>3.242</td><td>3.770</td><td>4.454</td><td>4.709</td><td>6.546</td></tr><tr><td>HiLS-Attn-NoPE</td><td>10.235</td><td>3.248</td><td>2.895</td><td>27.117</td><td>51.911</td><td>73.896</td></tr></table>

Table 11: LongBench-v1 scores grouped by context length. Overall is weighted by the number of samples in each dataset.

<table><tr><td rowspan="2">Method</td><td colspan="6">LongBench-v1 &lt;8K</td><td colspan="6">LongBench-v1 &gt;8K</td><td rowspan="2">Overall ↑ (%)</td></tr><tr><td>SDoc</td><td>MDoc</td><td>Summ.</td><td>Few-shot</td><td>Synth.</td><td>Code</td><td>SDoc</td><td>MDoc</td><td>Summ.</td><td>Few-shot</td><td>Synth.</td><td>Code</td></tr><tr><td>Olmo3-Base</td><td>36.9</td><td>33.9</td><td>23.4</td><td>63.8</td><td>5.8</td><td>61.8</td><td>11.4</td><td>14.4</td><td>12.1</td><td>36.0</td><td>3.3</td><td>41.0</td><td>29.0</td></tr><tr><td>LDM token tuning</td><td>32.1</td><td>30.4</td><td>20.6</td><td>62.2</td><td>4.1</td><td>60.9</td><td>14.3</td><td>17.5</td><td>13.3</td><td>43.1</td><td>2.6</td><td>49.2</td><td>28.8</td></tr><tr><td>Olmo3-512swa-CPT</td><td>37.4</td><td>27.8</td><td>22.1</td><td>64.1</td><td>4.1</td><td>59.4</td><td>10.0</td><td>14.2</td><td>12.9</td><td>33.6</td><td>3.2</td><td>32.9</td><td>28.0</td></tr><tr><td>+ YaRN 32K</td><td>34.1</td><td>30.6</td><td>21.5</td><td>64.0</td><td>3.5</td><td>60.0</td><td>18.6</td><td>24.8</td><td>18.0</td><td>51.9</td><td>2.5</td><td>49.6</td><td>31.7</td></tr><tr><td>HiLS-Attn-HoPE</td><td>36.4</td><td>37.8</td><td>24.6</td><td>64.6</td><td>4.7</td><td>59.3</td><td>23.3</td><td>25.0</td><td>18.1</td><td>50.7</td><td>5.3</td><td>51.0</td><td>33.2</td></tr><tr><td>HiLS-Attn-RoPE</td><td>37.2</td><td>33.1</td><td>22.2</td><td>61.0</td><td>5.4</td><td>60.6</td><td>17.5</td><td>17.3</td><td>14.0</td><td>42.0</td><td>4.3</td><td>47.1</td><td>30.0</td></tr><tr><td>HiLS-Attn-NoPE</td><td>37.5</td><td>34.3</td><td>23.6</td><td>64.4</td><td>5.4</td><td>62.3</td><td>22.3</td><td>24.9</td><td>17.8</td><td>50.9</td><td>4.2</td><td>48.7</td><td>33.2</td></tr></table>

![](images/d48826f419b2ab9d9bd2697d2a72038e1af8a1c025eaf089ecebff4ec92a8a98.jpg)  
Figure 6: Inference latency of HiLS-Attention vs. full attention at the 345M scale on a single NVIDIA H800 (batch size 1, bf16, chunk size 64, top-k = 32, 512-token sliding window). Prefill is the warm-run latency for the full input; decode is the median per-token latency with CUDA graphs. Speedup is full attention / HiLS-Attention (> 1 means HiLS-Attention is faster). HiLS-Attention reaches parity at ∼16K and is $1 3 . { \overset { \cdot } { 5 } } \times / 1 5 . 7 \times$ faster (prefill/decode) at 512K.

## 7 Analysis

## 7.1 Inference Efficiency of HiLS-Attention

We benchmark the end-to-end inference latency of HiLS-Attention against full attention in the SGLang [26] inference engine on a single NVIDIA H800 GPU. To ensure an apple-to-apple comparison, both backends share the same Triton attention-kernel infrastructure and differ only in the attention algorithm. In particular, the full-attention baseline is run with the same Triton kernels rather than a vendor-optimized paged-attention implementation. We use the 345M-scale architecture of Sec. 5.1 with chunk size 64, top-k = 32, and a 512-token sliding window. We set the paging granularity of the KV cache equal to the chunk size, and decode in a single stream (batch size 1) in bf16. We report warm-run prefill latency for the full input and the median per-token decode latency with CUDA graphs enabled.

As shown in Fig. 6, the cost of HiLS-Attention is governed by its fixed retrieval budget (K × chunk = 2048 tokens) plus the local sliding window, rather than by the full context length. Consequently its prefill latency grows near-linearly with context length while full attention grows quadratically. Its per-token decoding latency stays effectively constant (O(1)) while full attention grows linearly with the KV-cache length. The latency curves of the two methods cross over at roughly 16K tokens: below this length, the cost of top-k retrieval is not yet amortized, so full attention is faster; at and beyond 16K, HiLS-Attention reaches parity on prefill and is already faster on decoding. Past the crossover the gap widens rapidly with length—at 512K context HiLS-Attention is 13.5× faster in prefill (5.0 s vs. 67.0 s) and 15.7× faster per decode step (5.5 ms vs. 85.9 ms)—making HiLS-Attention substantially more practical than full attention for long-context serving while matching its quality (Sec. 5.1).

## 7.2 Chunk Overlap

We next validate a key empirical assumption behind the HiLS-Attention kernel: adjacent autoregressive queries retrieve highly overlapping chunks. This is especially important for MHA models, where GQA-style head grouping, as used in NSA, is unavailable to enlarge the GEMM dimension for Tensor Cores. HiLS-Attention therefore adopts a one-load-multiple-compute strategy: it groups M adjacent queries, loads the union of their retrieved chunks once, and computes attention for all M queries over this shared set. The union may introduce a few invalid query–chunk pairs, but it improves data reuse, reduces memory traffic, and better utilizes Tensor Cores.

![](images/b94224c6c69812e7215dd2e3a9734bfe9ef9f7f87a055e194029c6b07dcbdd45.jpg)

![](images/857f6c1c13b00536f458b9b19dff64b48fc4470a569c1fefd7530ee485c64c3e.jpg)  
Figure 7: Chunk-id overlap among adjacent query tokens. Left: loaded union size for the final $M = 1 6$ queries versus the visible historical chunks; percentages denote loaded fractions. Right: normalized overlap as group size M increases, with the dashed line showing inter-block reuse at $M = 1 6$ . Error bars show standard deviation across HiLS layers and heads, and shaded regions show the layer-wise min–max range.

For a block of $M > 1$ adjacent queries, let $\mathcal { I } _ { m }$ denote the top-K retrieved chunks of the m-th query. We measure the normalized chunk-overlap ratio as

$$
\mathrm{Overlap} = \frac {M K - \left| \bigcup_ {m = 1} ^ {M} \mathcal {I} _ {m} \right|}{(M - 1) K},\tag{12}
$$

where Overlap = 1 means perfect overlap and Overlap = 0 means no overlap. We evaluate the Olmo3-7B continued-pretraining checkpoint on pretraining sequences with chunk size 64 and top-K = 32. We use M = 16 for tail-block loading from 4K to 64K contexts, and sweep $M \in$ {2, 4, 8, 16, 32, 64} for the overlap ratio, with M = 1 included as the single-query baseline.

Fig. 7 shows strong chunk sharing among adjacent queries. For the final M = 16 queries, the visible historical pool grows from 57 to 1032 chunks as context increases from 4K to 64K, yet the loaded union grows only from 43.6 to 102.1 chunks, reducing the loaded fraction from 76.4% to 9.9%. Moreover, 92.8% of chunks in a query block already appeared in the previous block on average, further supporting adjacent-query packing and one-load-multiple-compute.

## 8 Related Work

Existing sparse attention methods can be broadly categorized into token-wise [27] and block-wise approaches. We focus on block-wise sparse attention, as it can potentially support native sparse training, which is essential for infinitely long context modeling. We further distinguish block-wise methods by whether their chunk summaries are parameterized. This distinction is important because chunk selection relies on summaries as proxies for chunk relevance, and their fidelity directly affects whether relevant chunks can be accurately retrieved.

None-parametric summaries. Many block-wise sparse attention methods, including NSA [5], MoBA [6], use mean-pooled chunk representations for efficient chunk selection. DashAttention [20] introduces a learnable gate based on InfLLM v2 [21]. Nevertheless, as shown in Tab. 2, these methods fail to achieve perfect needle retrieval even in the training length, suggesting inaccurate chunk selection. SeerAttention [28] also uses mean pooling as the chunk summary, but the chunk selection is distilled from full-attention. Since the upper bound of a distillation-based method is full attention, we do not include it in our experiments.

Parametric summaries. Landmark Attention (LMK-Attn) [8] first introduced landmark tokens to learn chunk summaries, but requires dense attention during training and applies sparsification only at inference. Moreover, its significant higher perplexity than the full-attention baseline makes it difficult to match full attention on downstream tasks. HSA series [22, 29] enables sparse training via specialized kernel design and empirically shows strong length generalization [30] by combining NoPE-based HSA with RoPE-based SWA. However, HSA integrates with SWA as a cross-attention module, which introduces substantial parameter overhead. Furthermore, after prolonged training, the perplexity (PPL) becomes dominated by SWA, as demonstrated in Tab. 1.

Compared with LMK-Attn, our work enables native sparse training and provides a more accurate estimate of chunk mass. LMK-Attn lags behind the full-attention baseline because it uses only the landmark token key as the chunk summary. In contrast, our method, grounded in Proposition 3.1, achieves substantially better perplexity and extrapolation. Inspired by HSA’s use of NoPE, we adopt HoPE [15] to preserve in-domain positional awareness while enabling ultra-long context extrapolation. We provide an intuitive comparison with other sparse attention methods across multiple dimensions in Tab. 12.

<table><tr><td>Method</td><td>Perfect NIAH</td><td>Full QK</td><td>Extrapolation</td><td>Training Strategy</td><td>Supports CPT</td></tr><tr><td>Full-Attention</td><td>Yes</td><td>Yes</td><td>&lt; 2×</td><td>End-to-End</td><td>Yes</td></tr><tr><td>Seer-Attention</td><td>Yes</td><td>Yes</td><td>—</td><td>Distillation</td><td>Yes</td></tr><tr><td>NSA</td><td>No</td><td>No</td><td>&lt; 2×</td><td>End-to-End</td><td>Yes</td></tr><tr><td>DSA</td><td>Yes</td><td>Yes</td><td>—</td><td>Distillation</td><td>Yes</td></tr><tr><td>Dash-Attention</td><td>No</td><td>No</td><td>&lt; 2×</td><td>End-to-End</td><td>Yes</td></tr><tr><td>LMK-Attn</td><td>Yes</td><td>Yes</td><td>&lt; 32×</td><td>End-to-End</td><td>Yes</td></tr><tr><td>HSA</td><td>No</td><td>No</td><td>&gt;64×</td><td>End-to-End</td><td>No</td></tr><tr><td>HiLS-Attention</td><td>Yes</td><td>No</td><td>&gt;64×</td><td>End-to-End</td><td>Yes</td></tr></table>

Table 12: Comparison of sparse-attention variants in terms of in-context retrieval capability, require full QK computation during training, extrapolation ability, training strategy, and compatibility with CPT. The weaknesses of each method are highlighted in red.

## 9 Discussion & Conclusion

This work introduces HiLS-Attention, a sparse attention mechanism featuring end-to-end retrieval learning and native sparse training. Our experiments show that HiLS-Attention exhibits strong length extrapolation ability. This raises a natural question: what is the source of such extrapolation ability, and is it only reflected under out-of-distribution context lengths?

Our hypothesis We argue that stronger extrapolation essentially stems from more accurate incontext retrieval, which is enabled by the compression-and-retrieval inductive bias of HiLS-Attention. During compression, token-level noise can partially be canceled out, while shared semantic signals are preserved. This leads to higher-quality retrieval key representations. The advantage of HiLS-Attention for in-domain retrieval becomes especially evident under longer contexts. As long-context capability becomes increasingly important for modern LLMs and agent models, our findings provide useful insights for improving long-context modeling.

Toward infinite context modeling Although HiLS-attention achieves ultra-long context capability mainly through extrapolation in this work, it also provides a practical route toward training with ultralong contexts. Its key advantage lies in its native sparsity during training and length generalization. Unlike full-attention or distillation-based methods [27], which score all token-level pairs with quadratic complexity $O ( L ^ { 2 } )$ , HiLS first compresses each chunk into a lightweight summary via intra-chunk attention. Each query token then retrieves from only $L / S$ chunk summaries, resulting in a per-token retrieval cost of $\bar { O } ( \bar { L } / S )$ and a sequence-level retrieval cost of $O ( L ^ { 2 } / S )$

Once the relevant chunks are retrieved, the actual token-level attention is restricted to the selected chunks and a local window, yielding a per-token attention cost of $O ( K S )$ and a total attention cost of $O ( L K S )$ . Thus, the only remaining superlinear component is retrieval, which can be further reduced to approximately $\dot { O ( L \log ( L / \bar { S } ) } ,$ ) with approximate nearest-neighbor search methods like FAISS [31].

Limitation and Future works HiLS-Attention does not support context parallelism yet, so its effectiveness under larger training context lengths remains to be fully validated. In addition, unselected chunks receive no gradient updates. The underlying mechanism by which Q-Cal improves extrapolation and in-domain performance is still not fully understood. We leave further validation and improvement to future work.

## References

[1] Tom Brown, Benjamin Mann, Nick Ryder, Melanie Subbiah, Jared D Kaplan, Prafulla Dhariwal, Arvind Neelakantan, Pranav Shyam, Girish Sastry, Amanda Askell, et al. Language models are few-shot learners. Advances in neural information processing systems, 33:1877–1901, 2020. 2

[2] Josh Achiam, Steven Adler, Sandhini Agarwal, Lama Ahmad, Ilge Akkaya, Florencia Leoni Aleman, Diogo Almeida, Janko Altenschmidt, Sam Altman, Shyamal Anadkat, et al. Gpt-4 technical report. arXiv preprint arXiv:2303.08774, 2023. 2

[3] Hao Liu, Matei Zaharia, and Pieter Abbeel. Ringattention with blockwise transformers for near-infinite context. In The Twelfth International Conference on Learning Representations, 2024. URL https: //openreview.net/forum?id=WsRHpHH4s0. 2

[4] Xiang Hu, Zhihao Teng, Jun Zhao, Wei Wu, and Kewei Tu. Efficient length-generalizable attention via causal retrieval for long-context language modeling. In Forty-second International Conference on Machine Learning, 2025. URL https://openreview.net/forum?id=6HVcoIbZoC. 2

[5] Jingyang Yuan, Huazuo Gao, Damai Dai, Junyu Luo, Liang Zhao, Zhengyan Zhang, Zhenda Xie, Yuxing Wei, Lean Wang, Zhiping Xiao, Yuqing Wang, Chong Ruan, Ming Zhang, Wenfeng Liang, and Wangding Zeng. Native sparse attention: Hardware-aligned and natively trainable sparse attention. In Proceedings of the 63rd Annual Meeting ofthe Associationfor Computational Linguistics (Volume 1: Long Papers), pages 23078–23097, Vienna, Austria, July 2025. Association for Computational Linguistics. ISBN 979-8-89176- 251-0. doi: 10.18653/v1/2025.acl-long.1126. URL https://aclanthology.org/2025.acl-long. 1126/. 2, 5, 7, 8, 17

[6] Enzhe Lu, Zhejun Jiang, Jingyuan Liu, Yulun Du, Tao Jiang, Chao Hong, Shaowei Liu, Weiran He, Enming Yuan, Yuzhi Wang, Zhiqi Huang, Huan Yuan, Suting Xu, Xinran Xu, Guokun Lai, Yanru Chen, Huabin Zheng, Junjie Yan, Jianlin Su, Yuxin Wu, Neo Y. Zhang, Zhilin Yang, Xinyu Zhou, Mingxing Zhang, and Jiezhong Qiu. Moba: Mixture of block attention for long-context llms. CoRR, abs/2502.13189, 2025. doi: 10.48550/ARXIV.2502.13189. URL https://doi.org/10.48550/arXiv.2502.13189. 2, 5, 17

[7] Yuxiang Huang, Pengjie Wang, Jicheng Han, Weilin Zhao, Zhou Su, Ao Sun, Hongya Lyu, Hengyu Zhao, Yudong Wang, Chaojun Xiao, Xu Han, and Zhiyuan Liu. Nosa: Native and offloadable sparse attention, 2026. URL https://arxiv.org/abs/2510.13602. 2, 7

[8] Amirkeivan Mohtashami and Martin Jaggi. Random-access infinite context length for transformers. Advances in Neural Information Processing Systems, 36:54567–54585, 2023. 3, 6, 12, 17

[9] Cheng-Ping Hsieh, Simeng Sun, Samuel Kriman, Shantanu Acharya, Dima Rekesh, Fei Jia, Yang Zhang, and Boris Ginsburg. Ruler: What’s the real context size of your long-context language models? arXiv preprint arXiv:2404.06654, 2024. 3, 8, 9, 25

[10] Yushi Bai, Xin Lv, Jiajie Zhang, Hongchang Lyu, Jiankai Tang, Zhidian Huang, Zhengxiao Du, Xiao Liu, Aohan Zeng, Lei Hou, et al. Longbench: A bilingual, multitask benchmark for long context understanding. In Proceedings of the 62nd annual meeting of the association for computational linguistics (volume 1: Long papers), pages 3119–3137, 2024. 3, 14

[11] Bowen Peng, Jeffrey Quesnelle, Honglu Fan, and Enrico Shippole. YaRN: Efficient context window extension of large language models. In The Twelfth International Conference on Learning Representations, 2024. URL https://openreview.net/forum?id=wHBfxhZu1u. 3, 14

[12] Xunhao Lai, Weiqi Xu, Yufeng Yang, Qiaorui Chen, Yang Xu, Lunbin Zeng, Xiaolong Li, Haohai Sun, Haichao Zhu, Vito Zhang, and Pengyu Zhao. Minimax sparse attention, 2026. URL https: //arxiv.org/abs/2606.13392. 5

[13] An Yang, Anfeng Li, Baosong Yang, Beichen Zhang, Binyuan Hui, Bo Zheng, Bowen Yu, Chang Gao, Chengen Huang, Chenxu Lv, et al. Qwen3 technical report. arXiv preprint arXiv:2505.09388, 2025. 6

[14] Jianlin Su, Murtadha Ahmed, Yu Lu, Shengfeng Pan, Wen Bo, and Yunfeng Liu. Roformer: Enhanced transformer with rotary position embedding. Neurocomputing, 568:127063, 2024. 6

[15] Yuhan Chen, Ang Lv, Jian Luan, Bin Wang, and Wei Liu. HoPE: A novel positional encoding without long-term decay for enhanced context awareness and extrapolation. In Wanxiang Che, Joyce Nabende, Ekaterina Shutova, and Mohammad Taher Pilehvar, editors, Proceedings ofthe 63rd Annual Meeting ofthe Associationfor Computational Linguistics (Volume 1: Long Papers), pages 23044–23056, Vienna, Austria, July 2025. Association for Computational Linguistics. ISBN 979-8-89176-251-0. doi: 10.18653/v1/2025. acl-long.1123. URL https://aclanthology.org/2025.acl-long.1123/. 6, 8, 18

[16] Joshua Ainslie, James Lee-Thorp, Michiel de Jong, Yury Zemlyanskiy, Federico Lebron, and Sumit Sanghai. GQA: Training generalized multi-query transformer models from multi-head checkpoints. In Houda Bouamor, Juan Pino, and Kalika Bali, editors, Proceedings ofthe 2023 Conference on Empirical Methods in Natural Language Processing, pages 4895–4901, Singapore, December 2023. Association for Computational Linguistics. doi: 10.18653/v1/2023.emnlp-main.298. URL https://aclanthology. org/2023.emnlp-main.298/. 7

[17] Yaniv Leviathan, Matan Kalman, and Yossi Matias. Fast inference from transformers via speculative decoding. In International Conference on Machine Learning, pages 19274–19286. PMLR, 2023. 7

[18] Alec Radford, Jeffrey Wu, Rewon Child, David Luan, Dario Amodei, and Ilya Sutskever. Language models are unsupervised multitask learners. OpenAI Technical Report, 2019. 8

[19] Bailin Wang, Chang Lan, Chong Wang, and Ruoming Pang. Rattention: Towards the minimal sliding window size in local-global attention models, 2025. URL https://arxiv.org/abs/2506.15545. 8

[20] Yuxiang Huang, Nuno M. T. Gonçalves, Federico Alvetreti, Lei Li, Xu Han, Edoardo M. Ponti, André F. T. Martins, and Marcos V. Treviso. Dashattention: Differentiable and adaptive sparse hierarchical attention, 2026. URL https://arxiv.org/abs/2605.18753. 8, 17

[21] Weilin Zhao, Zihan Zhou, Zhou Su, Chaojun Xiao, Yuxuan Li, Yanghao Li, Yudi Zhang, Weilun Zhao, Zhen Li, Yuxiang Huang, Ao Sun, Xu Han, and Zhiyuan Liu. Infllm-v2: Dense-sparse switchable attention for seamless short-to-long adaptation, 2025. URL https://arxiv.org/abs/2509.24663. 9, 17

[22] Xiang Hu, Zhanchao Zhou, Ruiqi Liang, Zehuan Li, Wei Wu, and Jianguo Li. Every token counts: Generalizing 16m ultra-long context in large language models. In The 64th Annual Meeting ofthe Association for Computational Linguistics, 2026. URL https://openreview.net/forum?id=HLADC0mFG8. 9, 17

[23] Allen Institute for AI. dolma3\_longmino\_mix-50b-1025 dataset. https://huggingface.co/ datasets/allenai/dolma3\_longmino\_mix-50B-1025, 2025. Accessed: 2026-06-08. 10

[24] Allen Institute for AI. Olmo-3-1025-7b (stage1-step999000). https://huggingface.co/allenai/ Olmo-3-1025-7B/tree/stage1-step999000, 2025. 14

[25] Team Olmo, Allyson Ettinger, Amanda Bertsch, Bailey Kuehl, David Graham, David Heineman, Dirk Groeneveld, Faeze Brahman, Finbarr Timbers, Hamish Ivison, et al. Olmo 3. arXiv preprint arXiv:2512.13961, 2025. 14

[26] Lianmin Zheng, Liangsheng Yin, Zhiqiang Xie, Chuyue Sun, Jeff Huang, Cody Hao Yu, Shiyi Cao, Christos Kozyrakis, Ion Stoica, Joseph E. Gonzalez, Clark Barrett, and Ying Sheng. Sglang: Efficient execution of structured language model programs, 2024. URL https://arxiv.org/abs/2312.07104. 16

[27] Aixin Liu, Aoxue Mei, Bangcai Lin, Bing Xue, Bingxuan Wang, Bingzheng Xu, Bochao Wu, Bowei Zhang, Chaofan Lin, Chen Dong, et al. Deepseek-v3. 2: Pushing the frontier of open large language models. arXiv preprint arXiv:2512.02556, 2025. 17, 18

[28] Yizhao Gao, Zhichen Zeng, Dayou Du, Shijie Cao, Peiyuan Zhou, Jiaxing Qi, Junjie Lai, Hayden Kwok-Hay So, Ting Cao, Fan Yang, and Mao Yang. Seerattention: Learning intrinsic sparse attention in your llms, 2025. URL https://arxiv.org/abs/2410.13276. 17

[29] Xiang Hu, Jiaqi Leng, Jun Zhao, Kewei Tu, and Wei Wu. Hardware-aligned hierarchical sparse attention for efficient long-term memory access. Advances in Neural Information Processing Systems, 38:88925–88950, 2026. 17

[30] Jiaqi Leng, Xiang Hu, Junxiong Wang, Jianguo Li, Wei Wu, and Yucheng Lu. Understanding and improving length generalization in hierarchical sparse attention models. In The Fourteenth International Conference on Learning Representations, 2026. URL https://openreview.net/forum?id=iHqdSQk6qc. 17

[31] Matthijs Douze, Alexandr Guzhva, Chengqi Deng, Jeff Johnson, Gergely Szilvasy, Pierre-Emmanuel Mazaré, Maria Lomeli, Lucas Hosseini, and Hervé Jégou. The faiss library. IEEE Transactions on Big Data, 12(2):346–361, 2026. doi: 10.1109/TBDATA.2025.3618474. 18

[32] Allen Institute for AI. Dolma 3 mix 6t-1025-7b dataset. https://huggingface.co/datasets/ allenai/dolma3\_mix-6T-1025-7B/tree/main, 2025. 24, 25

[33] Denis Paperno, Germán Kruszewski, Angeliki Lazaridou, Ngoc-Quan Pham, Raffaella Bernardi, Sandro Pezzelle, Marco Baroni, Gemma Boleda, and Raquel Fernández. The lambada dataset: Word prediction requiring a broad discourse context. In Proceedings of the 54th annual meeting of the association for computational linguistics (volume 1: Long papers), pages 1525–1534, 2016. 25

[34] Rowan Zellers, Ari Holtzman, Yonatan Bisk, Ali Farhadi, and Yejin Choi. Hellaswag: Can a machine really finish your sentence? In Proceedings of the 57th annual meeting of the association for computational linguistics, pages 4791–4800, 2019. 25

[35] Yonatan Bisk, Rowan Zellers, Jianfeng Gao, Yejin Choi, et al. Piqa: Reasoning about physical commonsense in natural language. In Proceedings of the AAAI conference on artificial intelligence, volume 34, pages 7432–7439, 2020. 25

[36] Keisuke Sakaguchi, Ronan Le Bras, Chandra Bhagavatula, and Yejin Choi. Winogrande: An adversarial winograd schema challenge at scale. Communications ofthe ACM, 64(9):99–106, 2021. 25

[37] Todor Mihaylov, Peter Clark, Tushar Khot, and Ashish Sabharwal. Can a suit of armor conduct electricity? a new dataset for open book question answering. In Proceedings of the 2018 conference on empirical methods in natural language processing, pages 2381–2391, 2018. 25

[38] Peter Clark, Isaac Cowhey, Oren Etzioni, Tushar Khot, Ashish Sabharwal, Carissa Schoenick, and Oyvind Tafjord. Think you have solved question answering? try arc, the ai2 reasoning challenge. arXiv preprint arXiv:1803.05457, 2018. 25

[39] Dan Hendrycks, Collin Burns, Steven Basart, Andy Zou, Mantas Mazeika, Dawn Song, and Jacob Steinhardt. Measuring massive multitask language understanding. Proceedings of the International Conference on Learning Representations (ICLR), 2021. 25

[40] David Rein, Betty Li Hou, Asa Cooper Stickland, Jackson Petty, Richard Yuanzhe Pang, Julien Dirani, Julian Michael, and Samuel R. Bowman. GPQA: A graduate-level google-proof q&a benchmark. In First Conference on Language Modeling, 2024. URL https://openreview.net/forum?id=Ti67584b98. 25

[41] Christopher Clark, Kenton Lee, Ming-Wei Chang, Tom Kwiatkowski, Michael Collins, and Kristina Toutanova. BoolQ: Exploring the surprising difficulty of natural yes/no questions. In NAACL, 2019. 25

[42] Guokun Lai, Qizhe Xie, Hanxiao Liu, Yiming Yang, and Eduard Hovy. RACE: Large-scale ReAding comprehension dataset from examinations. In Martha Palmer, Rebecca Hwa, and Sebastian Riedel, editors, Proceedings of the 2017 Conference on Empirical Methods in Natural Language Processing, pages 785–794, Copenhagen, Denmark, September 2017. Association for Computational Linguistics. doi: 10.18653/v1/D17-1082. URL https://aclanthology.org/D17-1082. 25

[43] Tianwen Wei, Jian Luan, Wei Liu, Shuang Dong, and Bin Wang. Cmath: Can your language model pass chinese elementary school math test?, 2023. URL https://arxiv.org/abs/2306.16636. 25

[44] Karl Cobbe, Vineet Kosaraju, Mohammad Bavarian, Mark Chen, Heewoo Jun, Lukasz Kaiser, Matthias Plappert, Jerry Tworek, Jacob Hilton, Reiichiro Nakano, Christopher Hesse, and John Schulman. Training verifiers to solve math word problems. arXiv preprint arXiv:2110.14168, 2021. 25

[45] Alex Gu, Baptiste Rozière, Hugh Leather, Armando Solar-Lezama, Gabriel Synnaeve, and Sida I. Wang. Cruxeval: A benchmark for code reasoning, understanding and execution, 2024. URL https://arxiv. org/abs/2401.03065. 25

[46] Jiawei Liu, Chunqiu Steven Xia, Yuyao Wang, and Lingming Zhang. Is your code generated by chatGPT really correct? rigorous evaluation of large language models for code generation. In Thirty-seventh Conference on Neural Information Processing Systems, 2023. URL https://openreview.net/forum? id=1qvx610Cu7. 26

[47] Jiawei Liu, Songrun Xie, Junhao Wang, Yuxiang Wei, Yifeng Ding, and Lingming Zhang. Evaluating language models for efficient code generation. In First Conference on Language Modeling, 2024. URL https://openreview.net/forum?id=IBCBMeAhmC. 26

[48] Jacob Austin, Augustus Odena, Maxwell Nye, Maarten Bosma, Henryk Michalewski, David Dohan, Ellen Jiang, Carrie Cai, Michael Terry, Quoc Le, and Charles Sutton. Program synthesis with large language models, 2021. URL https://arxiv.org/abs/2108.07732. 26

## A Justification of Equation 5

Let $S = | \mathcal { T } _ { c } |$ and write $s _ { j } ~ = ~ s _ { i , j }$ . When the logits are nearly uniform, let $s _ { j } = \bar { s } + \delta _ { j }$ where $\begin{array} { r } { \bar { s } = \frac { 1 } { S } \sum _ { j } s _ { j } } \end{array}$ and $\textstyle \sum _ { j } \delta _ { j } = 0$ . Then

$$
\log \sum_ {j} \exp (s _ {j}) = \bar {s} + \log \sum_ {j} \exp (\delta_ {j})\tag{13}
$$

$$
= \bar {s} + \log \left(S + \frac {1}{2} \sum_ {j} \delta_ {j} ^ {2} + O (\| \delta \| ^ {3})\right)\tag{14}
$$

$$
= \bar {s} + \log S + O \left(\frac {1}{S} \sum_ {j} \delta_ {j} ^ {2}\right).\tag{15}
$$

Hence, for small within-chunk logit variance, log $\begin{array} { r } { \sum _ { j } \exp ( s _ { j } ) \approx \operatorname* { m e a n } _ { j } ( s _ { j } ) + \log S } \end{array}$

When one logit dominates, let $M = \operatorname* { m a x } _ { j } s _ { j }$ and $j ^ { \star } = \arg \operatorname* { m a x } _ { j } s _ { j }$ . Then

$$
\log \sum_ {j} \exp (s _ {j}) = M + \log \left(1 + \sum_ {j \neq j ^ {\star}} \exp (s _ {j} - M)\right).\tag{16}
$$

If $M - s _ { j }$ is large for all $j \neq j ^ { \star }$ , the second term is negligible, and therefore log $\textstyle \sum _ { j } \exp ( s _ { j } )$ ≈ $M = \operatorname* { m a x } _ { j } s _ { j }$

## B Proof of Proposition 3.1

Given $\pmb q \in \mathbb { R } ^ { d }$ and $\mathbf { K } \in \mathbb { R } ^ { S \times d } .$ , where S is the block size, we explain how to estimate the Log-Sum-Exp function $\begin{array} { r } { { \mathrm { ~  ~ \omega ~ } } ^ { 2 } f ( \pmb q ) = \log \sum _ { j = 1 } ^ { S } \exp ( \pmb q \mathbf { K } _ { j } ) } \end{array}$ through the first-order Taylor expansion at $\pmb { q } _ { c }$ :

$$
f (\boldsymbol {q}) \approx f (\boldsymbol {q} _ {c}) + \nabla f (\boldsymbol {q} _ {c}) ^ {\top} (\boldsymbol {q} - \boldsymbol {q} _ {c}),\tag{17}
$$

where we have:

$$
\begin{array}{l} \nabla f (\boldsymbol {q} _ {c}) = \nabla_ {\boldsymbol {q} _ {c}} \Big (\log \sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j}) \Big) \\ \qquad = \frac {1}{\sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})} \nabla_ {\boldsymbol {q} _ {c}} \Big (\sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j}) \Big) \\ \qquad = \frac {1}{\sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})} \Big (\sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j}) \mathbf {K} _ {j} \Big) \\ \qquad = \sum_ {j = 1} ^ {S} \underbrace {\frac {\exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})}{\sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})}} _ {p _ {j}} \mathbf {K} _ {j} \\ \qquad = \boldsymbol {k} _ {c}. ^ {\prime}. \end{array}\tag{18}
$$

(19)

(20)

Thus, we can re-formalize Eq.17 as follows:

(21)

$$
\begin{array}{l} f (\boldsymbol {q}) \approx \log \sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j}) + \boldsymbol {k} _ {c} ^ {\prime} ^ {\top} (\boldsymbol {q} - \boldsymbol {q} _ {c}) \\ \stackrel {(i)} {=} \boldsymbol {k} _ {c} ^ {\prime} ^ {\top} \boldsymbol {q} + \Big (\log \sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j}) - \boldsymbol {k} _ {c} ^ {\prime} ^ {\top} \boldsymbol {q} _ {c} \Big) \\ \stackrel {(i i)} {=} \boldsymbol {k} _ {c} ^ {\prime} ^ {\top} \boldsymbol {q} + \Big (\log \sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j}) - \sum_ {j = 1} ^ {S} p _ {j} \boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j} \Big) \\ \stackrel {(i i i)} {=} \boldsymbol {k} _ {c} ^ {\prime} ^ {\top} \boldsymbol {q} + \Big (\underbrace {\log \sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})} _ {\text {Constant}} - \sum_ {j = 1} ^ {S} p _ {j} \big (\log p _ {j} + \underbrace {\log \sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})} _ {\text {Constant}} \big) \Big) \\ \stackrel {(i v)} {=} \boldsymbol {k} _ {c} ^ {\prime} ^ {\top} \boldsymbol {q} - \sum_ {j = 1} ^ {S} p _ {j} \log p _ {j} \end{array}\tag{22}
$$

where (i) re-orders the equation with the second term be a bias value, (ii) re-uses Eq. 19, (iii) re-formalizes ${ \pmb q } _ { c } ^ { \top } { \bf K } _ { j }$ as follows:

$$
\begin{array}{r l} & {\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j} = \log \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})} \\ & {\quad = \log \underbrace {\frac {\exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})}{\sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j})}} _ {p _ {j}} + \log \sum_ {j = 1} ^ {S} \exp (\boldsymbol {q} _ {c} ^ {\top} \mathbf {K} _ {j}),} \end{array}\tag{23}
$$

and (iv) cancels the constant terms. The final objective is the same as Eq. 7

## C HiLS-Atention in GQA

Considering an arbitrary group in GQA, given $\mathbf { q } _ { i } \in \mathbb { R } ^ { G \times d }$ and $\mathbf { k } _ { i } , \mathbf { v } _ { i } \in \mathbb { R } ^ { d }$ , where $G$ query heads share one KV head. Note that in GQA mode, the shape of $\mathbf { k } _ { c } ^ { \prime }$ is consistent with that of the query, i.e., $\mathbf { k } _ { c } ^ { \prime } \in \mathbb { R } ^ { G \times d }$ . We have:

$$
\begin{array}{l} s _ {i, j} ^ {h} = \frac {\left(\mathbf {q} _ {i} ^ {h}\right) ^ {\top} \mathbf {k} _ {j}}{\sqrt {d}}, \quad \hat {s} _ {i, c} ^ {h} = \frac {\left(\hat {\mathbf {q}} _ {i} ^ {h}\right) ^ {\top} \mathbf {k} _ {c} ^ {\prime}}{\sqrt {d}} + b _ {c} ^ {\prime}, \quad \hat {s} _ {i, c} = \underset {h} {\operatorname{argmax}} (\hat {s} _ {i, c} ^ {h}), \\ Z _ {i, \mathrm{swa}} ^ {h} = \sum_ {j \in \mathcal {T} _ {c}} \exp (s _ {i, j} ^ {h}), \quad \hat {Z} _ {i, c} ^ {h} = \exp (\hat {s} _ {i, c} ^ {h}), \\ \boldsymbol {\mathcal {I}} _ {i} = \{c \in \mathcal {C} _ {i} | \mathrm{rank} _ {\downarrow} (\hat {s} _ {i, c}) <   K \}, \quad \hat {\mathbb {Z}} _ {i} ^ {h} = \sum_ {c \in \boldsymbol {\mathcal {I}} _ {i}} \hat {Z} _ {i, c} ^ {h} + Z _ {i, \mathrm{swa}} ^ {h}, \end{array}\tag{24}
$$

$$
w _ {i, j} ^ {h} = \left\{ \begin{array}{l l} \frac {\exp (s _ {i , j} ^ {h})}{Z _ {i , c (j)} ^ {h}} \cdot \frac {\hat {Z} _ {i , c (j)} ^ {h}}{\hat {\mathbb {Z}} _ {i} ^ {h}} & , \text {   if   } j <   \ell (i) \text {   and   } c (j) \in \boldsymbol {\mathcal {I}} _ {i} \\ \frac {\exp (s _ {i , j} ^ {h})}{\hat {\mathbb {Z}} _ {i} ^ {h}} & , \text {   if   } \ell (i) \leq j \leq i \\ 0 & , \text {   otherwise   } \end{array} \right., \quad \mathbf {o} _ {i} ^ {h} = \sum_ {j} w _ {i, j} ^ {h} \mathbf {v} _ {j} ^ {h}.
$$

## D Hyper-parameters

## E Training recipes

Small-scale models. The training data is based on OLMo/Dolma pre-training corpora [32], mixed with 5% RULER-style synthetic examples to provide the instruction-following ability needed to answer RULER-style retrieval queries. The training context length is 8K, the global batch size is 128, and the models are trained for 30K optimizer steps, corresponding to approximately 30B training tokens. We use the AdamW optimizer with a constant learning-rate schedule of $3 \times 1 0 ^ { - 4 }$ Unless otherwise specified, all models share the same tokenizer, training data, training length, and optimization configuration. We evaluate the small-scale models from two perspectives: perplexity is used to measure language modeling ability, while RULER [9] is used to evaluate long-context random access and order-aware retrieval capability.

<table><tr><td>Hyperparameter</td><td>Small scale</td><td>Medium scale</td><td>Large scale</td></tr><tr><td>Parameters</td><td>345M</td><td>1.4B</td><td>7B</td></tr><tr><td>Layers</td><td>16</td><td>22</td><td>32</td></tr><tr><td>Hidden size</td><td>1024</td><td>2048</td><td>4096</td></tr><tr><td>FFN size</td><td>4096</td><td>5632</td><td>11008</td></tr><tr><td>Q/KV heads</td><td>16/2</td><td>32/4</td><td>32/32</td></tr><tr><td>HiLS layers</td><td>every layer</td><td>every layer</td><td>every 4 layers</td></tr><tr><td>SWA window</td><td>512</td><td>512</td><td>512</td></tr><tr><td>Chunk size</td><td>64</td><td>64</td><td>64</td></tr><tr><td>HiLS top-K</td><td>32</td><td>32</td><td>32</td></tr><tr><td>LoRA-Q bottleneck</td><td>64</td><td>128</td><td>256</td></tr><tr><td>Vocab size</td><td>100278 + 1</td><td>100278 + 1</td><td>100278 + 1</td></tr></table>

Table 13: Model hyperparameters used in the small-, medium-, and large-scale experiments. The vocab size is the original OLMo3 vocabulary plus one additional landmark-token embedding. Chunk/Top-k = 64/32 corresponds to retrieving 2048 tokens.

7B continue pre-training recipe. For continue pretraining, we use the OLMo3 pretraining corpus distribution. Specifically, we train from the tokenized OLMo3 500B-token [32] pretraining pool and sample approximately 50B tokens for adaptation by drawing 8K sequences from this pool. We set the maximum sequence length to 8192, the global batch size to 512, and train for 13K optimizer steps. The learning rate warms up for 1K steps to $2 \times 1 0 ^ { - 4 }$ and then follows a cosine decay to $2 \times 1 0 ^ { - 5 }$ The original OLMo3-Base checkpoint is not instruction-tuned and therefore lacks the instruction-following ability needed to answer RULER-style retrieval queries at test time. To make long-context retrieval comparisons meaningful after CPT, we mix on-the-fly synthesized RULER examples into the training stream at a 5% rate: with this probability, each sampled 8K pretraining sequence is converted into one of the three evaluation tasks—single needle-in-a-haystack, multiquery, and variable tracking—while the remaining 95% of samples stay as plain corpus text. All continued-pretraining models in Table 9, including Olmo3-512swa-CPT and the HiLS-Attn variants, follow this recipe; the Olmo3-Base row reports the original checkpoint without RULER-augmented CPT.

## F Downstream Evaluation Details

• LAMBDA [33]

• HellaSwag [34]

• PIQA [35]

• WinoGrande [36]

• OpenBookQA [37]

• ARC-challenge [38]

• ARC-esay: an easy subset of ARC-challenge

• MMLU [39]

• GPQA [40]

• BoolQ [41]

• RACE [42]

• CMATH [43]

• GSM8K [44]

• CRUX [45]

• HumanEval+ [46, 47]

• MBPP+ [46, 48]

## G Perplexity at Different CPT Steps

Table 14 reports in-domain perplexity on the OLMo3 pretraining corpus at 128, 512, and 8K context lengths for CPT checkpoints from 6K to 13K. We define the signed gap as ∆PPL = $\mathrm { P P L _ { H i L S - A t t n } - \mathrm { P P L _ { O l m o 3 - 5 1 2 s w a - C P T } ~ ( p o s i t i v e = H i L S } }$ worse). The gap is largest at short context early in training (e.g., +0.23 at 128 tokens, 6K) and shrinks with more steps (down to +0.02–+0.06 at 128 and +0.02–+0.03 at 512 by 10K–13K), while staying within ±0.01 at 8K throughout.

<table><tr><td rowspan="2">CPT Step</td><td colspan="3">ΔPPL</td></tr><tr><td>128 tokens</td><td>512 tokens</td><td>8K tokens</td></tr><tr><td>6K</td><td>+0.23</td><td>+0.07</td><td>+0.01</td></tr><tr><td>7K</td><td>+0.13</td><td>+0.07</td><td>+0.00</td></tr><tr><td>8K</td><td>+0.19</td><td>+0.06</td><td>+0.01</td></tr><tr><td>9K</td><td>+0.02</td><td>+0.04</td><td>+0.00</td></tr><tr><td>10K</td><td>+0.06</td><td>+0.02</td><td>-0.01</td></tr><tr><td>11K</td><td>+0.06</td><td>+0.02</td><td>+0.00</td></tr><tr><td>12K</td><td>+0.05</td><td>+0.02</td><td>+0.00</td></tr><tr><td>13K</td><td>+0.05</td><td>+0.03</td><td>+0.01</td></tr></table>

Table 14: Signed perplexity gap across CPT steps: ∆PPL = PPL<sub>HiLS-Attn-HoPE-LoRA</sub> − PPL<sub>Olmo3-512swa-CPT</sub>. Positive ∆ means HiLS-Attn has higher (worse) perplexity.

## H Per-Step Results of the 1.4B Model

We provide the full per-step perplexity (Table 15) and RULER (Table 16) numbers of the 1.4B model across training steps.

Table 15: Perplexity for 1.4B model after 300B-token training with an 8K context length.

<table><tr><td></td><td>#steps</td><td>64</td><td>128</td><td>512</td><td>8K</td><td>32K</td><td>128K</td><td>512K</td></tr><tr><td rowspan="8">Full-Attn RoPE</td><td>20k</td><td>33.78</td><td>25.94</td><td>17.56</td><td>4.63</td><td> $> 10^{2}$ </td><td></td><td></td></tr><tr><td>40k</td><td>31.01</td><td>23.81</td><td>16.08</td><td>4.39</td><td> $> 10^{2}$ </td><td></td><td></td></tr><tr><td>60k</td><td>29.47</td><td>22.61</td><td>15.30</td><td>4.29</td><td>5.87</td><td> $> 10^{2}$ </td><td></td></tr><tr><td>80k</td><td>28.21</td><td>21.72</td><td>14.69</td><td>4.20</td><td>5.49</td><td> $> 10^{2}$ </td><td></td></tr><tr><td>100k</td><td>27.25</td><td>20.92</td><td>14.16</td><td>4.12</td><td>6.09</td><td> $> 10^{2}$ </td><td></td></tr><tr><td>120k</td><td>26.60</td><td>20.40</td><td>13.79</td><td>4.05</td><td>6.56</td><td> $> 10^{2}$ </td><td></td></tr><tr><td>140k</td><td>26.18</td><td>20.05</td><td>13.56</td><td>4.02</td><td>8.28</td><td> $> 10^{2}$ </td><td></td></tr><tr><td>143k</td><td>26.17</td><td>20.05</td><td>13.56</td><td>4.02</td><td>8.60</td><td> $> 10^{2}$ </td><td></td></tr><tr><td rowspan="8">HiLS-Attn HoPE</td><td>20k</td><td>33.88</td><td>26.03</td><td>17.58</td><td>4.63</td><td>4.10</td><td>4.69</td><td>7.08</td></tr><tr><td>40k</td><td>31.10</td><td>23.84</td><td>16.11</td><td>4.40</td><td>4.03</td><td>4.68</td><td>6.62</td></tr><tr><td>60k</td><td>29.47</td><td>22.55</td><td>15.30</td><td>4.29</td><td>4.17</td><td>5.65</td><td>8.49</td></tr><tr><td>80k</td><td>28.20</td><td>21.67</td><td>14.70</td><td>4.20</td><td>3.98</td><td>5.30</td><td>8.35</td></tr><tr><td>100k</td><td>27.40</td><td>20.98</td><td>14.19</td><td>4.12</td><td>4.00</td><td>5.38</td><td>8.24</td></tr><tr><td>120k</td><td>26.63</td><td>20.39</td><td>13.79</td><td>4.05</td><td>3.99</td><td>5.43</td><td>8.48</td></tr><tr><td>140k</td><td>26.26</td><td>20.08</td><td>13.57</td><td>4.02</td><td>4.08</td><td>5.54</td><td>8.53</td></tr><tr><td>143k</td><td>26.21</td><td>20.03</td><td>13.55</td><td>4.02</td><td>4.08</td><td>5.54</td><td>8.58</td></tr></table>

Table 16: RULER results of the 1.4B model at different training steps during 300B-token training.

<table><tr><td rowspan="2"></td><td rowspan="2">Steps</td><td colspan="3">8K</td><td colspan="3">16K</td><td colspan="3">32K</td><td colspan="3">128K</td><td colspan="3">512K</td></tr><tr><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td><td>S-N</td><td>MK-MQ</td><td>VT</td></tr><tr><td rowspan="8">Full-Attn RoPE</td><td>20k</td><td>99</td><td>58</td><td>71</td><td>4</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>40k</td><td>100</td><td>99</td><td>82</td><td>35</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>60k</td><td>100</td><td>99</td><td>86</td><td>33</td><td>15</td><td>11</td><td>4</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>80k</td><td>100</td><td>99</td><td>94</td><td>44</td><td>19</td><td>11</td><td>5</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>100k</td><td>100</td><td>99</td><td>91</td><td>35</td><td>14</td><td>4</td><td>2</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>120k</td><td>100</td><td>98</td><td>95</td><td>27</td><td>2</td><td>3</td><td>3</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>140k</td><td>100</td><td>97</td><td>95</td><td>27</td><td>0</td><td>3</td><td>2</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>143k</td><td>100</td><td>96</td><td>94</td><td>21</td><td>0</td><td>2</td><td>3</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td rowspan="8">HiLS-Attn HoPE</td><td>20k</td><td>100</td><td>100</td><td>77</td><td>100</td><td>98</td><td>66</td><td>99</td><td>95</td><td>61</td><td>99</td><td>93</td><td>56</td><td>79</td><td>90</td><td>60</td></tr><tr><td>40k</td><td>100</td><td>98</td><td>75</td><td>100</td><td>99</td><td>60</td><td>100</td><td>95</td><td>64</td><td>99</td><td>95</td><td>65</td><td>85</td><td>91</td><td>64</td></tr><tr><td>60k</td><td>100</td><td>99</td><td>84</td><td>100</td><td>99</td><td>67</td><td>100</td><td>97</td><td>71</td><td>94</td><td>98</td><td>59</td><td>67</td><td>94</td><td>54</td></tr><tr><td>80k</td><td>100</td><td>100</td><td>85</td><td>100</td><td>98</td><td>74</td><td>100</td><td>96</td><td>77</td><td>99</td><td>91</td><td>68</td><td>76</td><td>84</td><td>50</td></tr><tr><td>100k</td><td>100</td><td>100</td><td>90</td><td>100</td><td>100</td><td>71</td><td>100</td><td>96</td><td>76</td><td>94</td><td>98</td><td>71</td><td>64</td><td>92</td><td>52</td></tr><tr><td>120k</td><td>100</td><td>99</td><td>90</td><td>100</td><td>99</td><td>70</td><td>100</td><td>99</td><td>76</td><td>98</td><td>97</td><td>70</td><td>87</td><td>97</td><td>64</td></tr><tr><td>140k</td><td>100</td><td>98</td><td>88</td><td>100</td><td>96</td><td>76</td><td>100</td><td>97</td><td>81</td><td>96</td><td>95</td><td>69</td><td>75</td><td>96</td><td>60</td></tr><tr><td>143k</td><td>100</td><td>98</td><td>91</td><td>100</td><td>99</td><td>76</td><td>100</td><td>99</td><td>73</td><td>99</td><td>99</td><td>68</td><td>92</td><td>99</td><td>60</td></tr></table>