# A counterexample to the theorem of Laplace-Lagrange on the stability of semimajor axes

Andrew Clarke

Jacques Fejoz

Marcel Guardia

March 13, 2023

## Abstract

A longstanding belief has been that the semimajor axes, in the Newtonian planetary problem, are stable. In the course of the XIX century, Laplace, Lagrange and others gave stronger and stronger arguments in this direction, thus culminating in what has commonly been referred to as the first Laplace-Lagrange stability theorem. In the problem with 3 planets, we prove the existence of orbits along which the semimajor axis of the outer planet undergoes large random variations thus disproving the theorem of Laplace-Lagrange. The time of instability varies as a negative power of the masses of the planets. The orbits we have found fall outside the scope of the theory of Nekhoroshev-Niederman because they are not confined by the conservation of angular momentum and because the Hamiltonian is not (uniformly) convex with respect to the Keplerian actions.

## Contents

1 Introduction 2
1.1 On the stability of semimajor axes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2
1.2 Main results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3
1.3 Remark on Nekhoroshev theory and weak convexity . . . . . . . . . . . . . . . . . . . . . . . . 5
1.4 Main ideas of the proof of Theorem 1 and moderately versus strongly hierarchical regimes .. 6
2 Main results in Deprit coordinates 8
2.1 The Jacobi and Deprit coordinates ..... 8
2.2 Arnold diffusion in Deprit coordinates ..... 10
3 Computation of the secular Hamiltonian 12
3.1 Expansion of the perturbing function in Legendre polynomials ..... 12
3.2 Averaging of the mean anomalies $\ell_1$ and $\ell_2$ ..... 12
3.3 Taylor expansion of the secular Hamiltonian ..... 14
4 First-order integrable dynamics 19
5 Analysis of the inner dynamics 21
6 Computation of the scattering map 26
7 Shadowing in a Poincaré Section 32
7.1 Reduction to a Poincaré Map ..... 33
7.2 Transition chains of almost invariant tori ..... 35
7.3 Orbits of the four-body problem shadowing the transition chains ..... 38
8 Proof of Theorems 1 and 3 39
8.1 The planetary regime: Proof of Theorem 3 ..... 39
8.2 Proof of Theorem 1 ..... 41

A A refinement of Moser's trick 41  
B The scattering map of a normally hyperbolic invariant manifold 43  
C A general shadowing argument 44  
D Derivatives of the inner Hamiltonian 47

## 1 Introduction

## 1.1 On the stability of semimajor axes

Consider the 4-body problem, namely the motion of 4 bodies, numbered from 0 to 3, moving in the 3- dimensional space and subject to the Newtonian universal attraction:

$$
\ddot {x} _ {j} = \sum_ {\stackrel {0 \leq i \leq 3} {i \neq j}} m _ {i} \frac {x _ {i} - x _ {j}}{\| x _ {i} - x _ {j} \| ^ {3}},\tag{1}
$$

where $x _ { j } \in \mathbb { R } ^ { 3 }$ is the position and $m _ { j } ~ > ~ 0$ the mass of body j. Of particular interest is the planetary problem, where the masses of bodies 1, 2, 3 (planets) are small with respect to body 0 (Sun), and where each planet revolves around the Sun along an approximate, slowly deforming Keplerian ellipse. In the first approximation, the problem consists of three uncoupled Kepler problems whose ellipses are fixed in space, together with their geometric elements determining the shape of the ellipses and their position in space. The question is to determine the long term influence of the mutual attraction of planets on the elliptical positions and elements. In this article, we will also consider the hierarchical problem, where masses are fixed (or within some compact set of (0, )) and successive semimajor axes’ ratios $a _ { j } / a _ { j + 1 }$ are small.

Euler and Lagrange had failed to prove the stability of semimajor axes of planets in the Solar System. In 1776, in a commendable tour de force Laplace was able to overcome the dificulties his predecessors had met. He wrote [46]:

J’ai trouv´e [que l’in´egalit´e s´eculaire des demi grands axes est] absolument nulle; d’o\`u je conclus que l’alt´eration du mouvement moyen de Jupiter, si elle existe, n’est point due \`a l’action de Saturne.<sup>1</sup>

Here Laplace is neglecting second order terms in the masses of the planets, as well as third order terms in the eccentricities and inclinations of planets.

Lagrange later proved that this result holds for arbitrary eccentricities and inclinations. This is the “first stability theorem of Laplace and Lagrange”. About the 1808 M´emoire of Lagrange [45], Arago commented: “Le 17 aoˆut 1808, [Lagrange] lit au Bureau des longitudes, et le lundi suivant 22, \`a l’Acad´emie des sciences, un des plus admirables M´emoires qu’ait jamais trac´es la plume d’un math´ematicien” (F. Arago, Œuvres compl\`etes, 1854, p. 654).<sup>2</sup>

Poisson later proved that the conclusion of the theorem holds at the second order in the masses of the planets [53]. His proof is a cornerstone of Hamiltonian perturbation theory, but is lengthy and complicated. Lagrange simplified it substantially (see his Œuvres, t. VI, p. 735), but to the point where Lagrange’s argument is flawed, as his editor M. Serret mentions. The later correction made in [44] is not satisfactory either, as Mathieu noticed [48]... (see [47, 29] and references therein).

Nowadays the first stability theorem of Laplace-Lagrange-Poisson-Mathieu is a simple consequence of the existence of the Delaunay coordinates for the two-body problem. In these symplectic coordinates, the variable which is conjugate to the fast Keplerian angle (mean anomaly) is a function of the semimajor axis.

So, outside Keplerian resonances, for the (first order) secular system obtained by averaging out the mean anomalies, semimajor axes are first integrals.

In order to explain the irregularities of Jupiter and Saturn, Laplace called on comets. Comets had unknown masses, so it was a convenient argument (which actually was a fortunate motivation for Laplace to get interested in probabilities). Yet, there is an intricate interplay between small parameters in the parameter space (masses of the planets, distance to mean motion resonances, distance to circular motions, etc.). It is a mistake to infer the stability of the semimajor axes from the low order analysis that had been carried out, and indeed, averaging out the outer mean anomalies becomes irrelevant when the mean motion of outer planets is slower than the secular dynamics of inner planets.

More recently, after the proof of Arnold’s theorem on the existence of a set of positive Lebesgue measure of invariant tori in the planetary problem [1, 26], Herman has speculated that “in some respect Lagrange and Laplace, against Newton, are correct in the sense of measure theory and that in the sense of topology, the above question [on the stability], in some respect, could show Newton is correct” [41].

It is the purpose of the present article to disprove the belief in the Laplace-Lagrange stability of the semimajor axis, as well as Herman’s conjectural dichotomy. Instability occurs on a set of positive Lebesgue measure of the 4-body problem in the planetary regime, in a time which is an inverse power of the masses of the planets.

## 1.2 Main results

Consider 4 bodies whose motion is governed by Newton’s equation (1). We will assume that $m _ { 0 } \neq m _ { 1 } . ^ { 3 }$ For the sake of simplicity, let us first focus on the “hierarchical regime”; it is the asymptotic regime where masses are fixed, while body 2 revolves around and far away from bodies 0 and 1, and body 3 revolves around and even farther away from bodies $0 ,$ 1 and 2. (We will make some more precise hypotheses below.) Each body thus primarily undergoes the attraction of one other body: bodies 0 and 1 are close to being isolated, body 2 primarily undergoes the attraction of a fictitious body located at the center of mass of 0 and 1, and body 3 primarily undergoes the attraction of a fictitious body located at the center of mass of 0, 1 and 2. We think of body 0 as the Sun and of the three other bodies as planets. The Jacobi coordinates are well suited for this regime, but we defer their definition to a later stage. Assuming that the center of mass is fixed, the small displacements of the Sun may be recovered from the positions of the planets.

Some notation: let $a _ { 1 } , a _ { 2 }$ and $a _ { 3 }$ be the semimajor axes of the planets, $e _ { 1 } , e _ { 2 }$ and $e _ { 3 }$ be their eccentricities, and $C _ { 1 } , C _ { 2 }$ and $C _ { 3 }$ their angular momenta. In the hierarchical regime, for eccentricities bounded away from $1 , a _ { 1 } \ll a _ { 2 } \ll a _ { 3 }$ . Even further (and unlike in [13]), we will consider a strongly hierarchical regime, where not only the semimajor axes ratios $\alpha _ { i } = { a _ { i } } / { a _ { i + 1 } }$ are small, but even the ratios of the ratios $\alpha _ { i } / \alpha _ { i + 1 }$ are small, in the following quantitative manner:

$$
a _ {1} = O (1) \ll a _ {2} \ll a _ {3} ^ {1 / 3}.\tag{2}
$$

Here is the rough description of the scales of times:

• The fastest frequencies are the mean motions (Keplerian frequencies) of the two inner planets. Since $a _ { 1 } \ll a _ { 2 }$ , these inner mean motions do not interfere, which allows us to average out the mean anomalies, without resonances.

• The next frequencies are the secular frequencies of the two inner planets. They govern the rotation of the plane of the ellipses around their angular momentum vector $C _ { 1 } + C _ { 2 }$ , and the rotation of the ellipses in their plane, as well as the quasiperiodic oscillations of the corresponding inclinations and eccentricities. The dynamics of the truncated relevant normal form (“quadrupolar dynamics” of planets 1 and 2) is still integrable, as noticed by Harrington [40], due to the fact that the quadrupolar Hamiltonian does not depend on the argument of the outer pericenter $g _ { 2 }$

• In the strongly hierarchical regime, the outer semimajor axis is so large that the mean motion of planet 3 is slower than secular frequencies of the two inner planets.

• Then come the secular frequencies of the (outer) planet 3, approximately determined by the quadrupolar Hamiltonian of planets 2 and 3. The conservation of the total angular momentum vector $C =$ $C _ { 1 } + C _ { 2 } + C _ { 3 } \simeq C _ { 3 }$ prevents significant changes in the plane of the outer ellipse, or of the product $a _ { 3 } \sqrt { 1 - e _ { 3 } ^ { 2 } }$ . On the other hand, it does not prevent major (joint) changes in $a _ { 3 }$ or $e _ { 3 }$

Similarly to the regime studied in [13], along the orbits we will prove the existence of the two inner planets will be close to the hyperbolic secular singularity of the quadrupolar Hamiltonian or to the associated stable and unstable manifolds. In particular, their mutual inclination will be large.

We will pay special attention to two quantities:

• the semimajor axis $a _ { 3 }$ of the outer planet

• the normalized angular momentum $\tilde { C } _ { 2 } \in \mathbb { B } ^ { 3 }$ of planet 2, defined as the vector orthogonal to the plane of its ellipse and whose norm is $\lVert \tilde { C } _ { 2 } \rVert = \sqrt { 1 - e _ { 2 } ^ { 2 } }$

Theorem 1 (Main theorem). Consider the 4-body problem with masses $m _ { j } > 0 , j = 0 , 1 , 2 , 3$ with $m _ { 0 } \neq m _ { 1 }$ For every finite itinerary $\tilde { C } _ { 2 } ^ { 1 } , . . . , \tilde { C } _ { 2 } ^ { k } \in \mathbb { B } ^ { 3 } , a _ { 3 } ^ { 1 } , . . . , a _ { 3 } ^ { k } \in [ 1 , + \infty )$ and every $\delta > 0$ , there exists an open set of initial conditions whose trajectories realise the prescribed itinerary up to precision δ.

This theorem is a consequence of Theorems 2 and 3 below, which contain a more detailed description of the difusing orbits.

Let us make some comments on Theorem 1.

• The drifting time needed to follow the prescribed itinerary in the theorem satisfies

$$
0 <   T <   C (m _ {0}, m _ {1}, m _ {2}, m _ {3}) \frac {N}{\delta^ {\kappa}},\tag{3}
$$

where C is a constant depending only on the masses and the exponent $\kappa > 0$ does not depend on N nor on the itinerary. To be more precise, call $\alpha _ { i } = a _ { i } / a _ { i + 1 } , i = 1 , 2$ , the semimajor axis ratios. As δ tends to zero, the $\alpha _ { i } { ' }$ s will be chosen polynomially smaller, and the drifting time itself depends polynomially on the $\alpha _ { i } { ' } \mathrm { s }$

• As stated, Theorem 1 assumes small semi major axis ratios, for fixed masses. In Section 8.1, we provide asymptotic estimates when we let the masses of the planets tend to 0, i.e. in the planetary regime where $m _ { j } = \rho \tilde { m } _ { j }$ for $j = 1 , 2 , 3$ with $\rho > 0$ small. Then, one possibility is to let the semimajor axes of planets 1 and 2 tend to 0 as $\rho \to 0$ . In that case, the drifting time satisfies

$$
0 <   T <   C (m _ {0}, \tilde {m} _ {1}, \tilde {m} _ {2}, \tilde {m} _ {3}) \frac {N}{\delta^ {\kappa} \rho^ {\nu}}.\tag{4}
$$

Another possibility is to place planets 1 and 2 at a uniform distance (with respect to $\rho )$ from the Sun and place planet 3 very far away, so that $a _ { 3 } \sim \rho ^ { - 2 / 3 }$ . That is the setting considered in Theorem 3 below, where we provide the concrete exponent $\nu = 3 5 / 3$

Note that the instability time is polynomial with respect to the masses of the planets. See Section 1.3 below for the comparison of the regime of Theorem 1 with those regimes where Nekhoroshev Theory can be applied to prove exponential stability of the semimajor axes.

• The novelty of the unstable behavior presented in this paper compared to that of [13] is the evolution of the semimajor axis $a _ { 3 }$ of the third planet. Indeed, in the moderately hierarchical regime considered in [13], $a _ { 3 }$ is stable, whereas in the strongly hierarchical regime it can follow any prescribed itinerary (see Section 1.4 below for a comparison between the two regimes).

On the contrary, the changes in the normalized angular momentum of the second planet are the same in both regimes. Let us briefly describe what the changes in ${ \tilde { C } } _ { 2 }$ imply in terms of the orbital elements of the second planet. Indeed, fixing a prescribed itinerary $\tilde { C } _ { 2 } ^ { 0 } , . . . , \tilde { C } _ { 2 } ^ { N } \in B ^ { 3 }$ is equivalent to prescribing any itinerary in: the eccentricity $e _ { 2 } ^ { k }$ , the mutual inclination $\theta _ { 2 3 } ^ { k }$ between planets 2 and 3, and the longitude $h _ { 2 } ^ { k }$ of the node of planet 2, for $k = 0 \ldots N$ . Then, we can construct an orbit and times $t _ { 0 } < t _ { 1 } < \cdots < t _ { N }$ such that the osculating orbital elements satisfy

$$
| e _ {2} (t _ {k}) - e _ {2} ^ {k} | \leq \delta , \qquad | \theta_ {2 3} (t _ {k}) - \theta_ {2 3} ^ {k} | \leq \delta , \qquad | h _ {2} (t _ {k}) - h _ {2} ^ {k} | \leq \delta \qquad \text {for} k = 0, 1,..., N.
$$

As already mentioned, the angular momentum of the third body is almost constant and therefore, the evolution of $e _ { 3 }$ is determined by the evolution of $a _ { 3 }$

Finally, the evolution of the eccentricity $e _ { 1 }$ of the first planet, and the mutual inclination $\theta _ { 1 2 }$ between planets 1 and 2, cannot be controled since they are prescribed by the difusion mechanism. Let us briefly mention that:

– The eccentricity $e _ { 1 }$ does change but it can start arbitrarily close to 0. That is, the initial configuration can have all planets performing close to circular motion.

– The mutual inclination $i _ { 1 2 }$ always stays above 55 degrees.

One can see [13] for a more detailed description of the evolution of $e _ { 1 }$ and $i _ { 1 2 }$ .

• A further step would be to estimate the local probability of instability in some given time [3, Section 6.4.7].

• In our Solar System, semimajor axes seem very stable. There are some exceptions. Notably, the semimajor axis of the Moon is drifting. But this is due to non-Hamiltonian, tidal efects [24]. Also, at the early stages of our Solar System, planets migrated towards the exterior of the Solar System. But this migration too is a non-conservative phenomenon, explained by the interaction with the planetesimal disk [37].

Orbits described in theorem 1 show wild variations of elliptical elements, and, plausibly, subsequent collisions of neighboring planets and their accretion. We may conjecture that only the observation of many extra-solar systems might exhibit one day such transient behavior.

## 1.3 Remark on Nekhoroshev theory and weak convexity

Due to the proper degeneracy of the Keplerian approximation, standard Nekhoroshev theory does not apply in a straightforward way to the planetary problem. Yet it has been successfully extended to the planetary problem [50, 51] (see also [3, 6.3.4]). In particular, Niederman proved the following conditional result regarding a Hamiltonian perturbation of a properly degenerate integrable system: provided that the actions in the degenerate (i.e. secular) directions remain in some bounded region, the actions conjugate to the fast angles are stable over an exponentially long time. He then showed that this model can be applied to the planetary problem. In the neighborhood of coplanar and circular ellipses (the maximum of the angular momentum), the conservation of the angular momentum prevents the degenerate actions (encoding eccentricities and inclinations) to undergo any substantial instability, so the actions conjugate to the fast angles (encoding the semimajor axes) are indeed stable over an exponentially long time.

The regimes of the 4-body problem studied in the present paper difer from Niederman’s work in two respects:

• In the planetary regime, the conservation of the angular momentum does not prevent secular variables from drifting because of the high inclination of the two inner planets.

• In the hierarchical problem, the convexity of the fast, Keplerian part is weak, because of the large outer semimajor axes.

Hence neither Nekhoroshev theory nor Niederman’s adaptation applies. (Incidentally, a proof ad absurdum is that the conclusion of Theorem 1 would contradict Nekhoroshev theory.)

Regarding the weak convexity (for a numerical investigation, see [39]), let us mention the following open question. Consider the toy Hamiltonian

$$
H (\theta , r) = r _ {1} ^ {2} + r _ {2} ^ {2} + \epsilon^ {\alpha} r _ {3} ^ {2} + \epsilon f (\theta , r),
$$

where $\epsilon \ll 1$ and $0 \leq \alpha \leq 1$ . H is Nekhoroshev-stable for $\alpha = 0$ and, trivially, unstable for $\alpha = 1$ . But, more precisely, how does the radius of confinement of r deteriorate as α grows from 0 to 1? The classical proof as well as more recent examples should provide a precise answer to this question.

## 1.4 Main ideas of the proof of Theorem 1 and moderately versus strongly hierarchical regimes

The orbits constructed in Theorem 1 rely on an Arnold difusion mechanism [2]. Progress in the understanding of Arnold difusion in nearly-integrable Hamiltonian systems in these last decades has been remarkable, especially for two and a half degrees of freedom (see [4, 6, 10, 16, 17, 18, 21, 35, 43, 49, 54], or [5, 9, 15, 20, 33, 34, 36, 55] for results in higher dimension). However, most of these results deal with generic nearly-integrable Hamiltonian systems in $C ^ { r }$ or $C ^ { \infty }$ regularity whereas results in the analytic category, including results in Celestial Mechanics, are rather scarce. See the discussion in Section 1.1 of [13] for more details.

Indeed, even if Arnold in his seminal paper conjectured that his difusion mechanism should be present in the 3-body problem, as far as the authors know, the only complete analytical proofs of Arnold difusion in celestial mechanics are [13, 22, 38]. Other works in the field rely on computer-assisted computations [8, 28], on computer-assisted proofs [7], or on the assumption of a plausible transversality hypothesis [56].

In order to prove Theorem 1 we adapt what are usually referred to as the geometric and topological methods of Arnold difusion. Although some of the geometric ideas could now be considered classical, others are contemporary (in particular a topological shadowing result proven recently by the same authors in [14]). While explaining the overview of the proof, we will compare the moderately hierarchical regime considered in [13] with the strongly hierarchical regime considered in the present paper.

The classical geometric approach used to prove Arnold difusion both in the present paper and in [13] can be broken down into the following steps.

• Prove the existence of a normally hyperbolic invariant cylinder (See Appendix B for the definition). The “vertical” components of the cylinder are the actions in which we want to drift.

• Prove that the invariant manifolds of the cylinder intersect transversely along homoclinic channels. Orbits in the channel are heteroclinic orbits between diferent orbits in the cylinder. This is encoded in a scattering map [19]. One can obtain an asymptotic formula for it through Poincar´e-Melnikov Theory.

• Construct an iterated function system consisting of the inner dynamics and the scattering map, and show that its orbits (called pseudo-orbits) display a drift in the action variables.

• Use a shadowing argument to obtain orbits which follow closely these pseudo-orbits.

To carry out these steps in the 4 body problem, both in [13] and in the present paper we consider the hierarchical regime which makes the 4-body problem nearly integrable. In [13] we consider what we call the moderately hierarchical regime, where we assume

$$
a _ {1} = O (1) \ll a _ {2} \ll a _ {3} ^ {6 / 1 1} \ll a _ {2} ^ {1 2 / 1 1}\tag{5}
$$

whereas in the present paper we consider the strongly hierarchical regime (2). Both regimes lead to a nearly integrable setting. However, they lead to diferent hierarchies of time scales, and to diferent first-order efective models. Let us describe them. To this end, we express the 4-body problem in a good set of coordinates, which reduces the dimension of the model by eliminating its first integrals. First, we consider Jacobi coordinates to eliminate the translation invariance and then we use the Deprit coordinates to perform the symplectic reduction by rotational symmetry (see [12]). After this reduction, the 4-body problem becomes a Hamiltonian system with seven degrees of freedom. In Section 2 we state the main results of this paper in Deprit coordinates.

The two faster frequencies of the 4-body problem in Deprit coordinates are, in both the strongly and moderately hierarchical regimes, the mean anomalies of the first two planets. Moreover, they evolve at diferent time scales to one another. This implies that they can be averaged out up to arbitrarily high order in $a _ { 2 } ^ { - 1 }$ . If one ignores the higher order terms, one can reduce the dimension by 2 and end up with a five degree of freedom Hamiltonian depending on $a _ { 1 }$ and $a _ { 2 }$ , which can be treated as parameters.

In the moderately hierachical regime (5), the third fastest frequency is the mean anomaly of the third planet. Proceeding analogously, in that regime it too can be averaged out up to high order which leads to a 4 degree of freedom Hamiltonian. This Hamiltonian is usually called the secular Hamiltonian since it models the slow evolution of the osculating ellipses.

On the contrary, in the strongly hierachical regime, since the third planet is placed much further away, the third mean anomaly becomes slower and it cannot be averaged out. For this reason, in the present paper we analyse the 5 degree of freedom Hamiltonian which, by an abuse of language, we also call the secular Hamiltonian. It models the slow evolution of the osculating ellipses of the three planets plus the motion of the third planet on its osculating ellipse.

In both regimes, the next step is to expand the secular Hamiltonian in powers of $1 / a _ { 2 }$ and $a _ { 2 } / a _ { 3 }$ using the Legendre polynomials. This is done in Section 3. The first term in the expansion is the so-called quadrupolar Hamiltonian of the first two planets, which is integrable, and the second term is the so-called octupolar Hamiltonian which captures the next order of interaction between planets 1 and 2. The subsequent orders in the expansion involve the interaction between planets 2 and 3. It is at these orders where the analysis of the moderately and strongly hierarchical regimes difers considerably. In [13] we need both the quadrupolar and octupolar Hamiltonians associated to planets 2 and 3 whereas in the present paper the approximate dynamics does not depend on the octupolar term. The reason is that, since we do not average the mean anomaly $\ell _ { 3 } .$ , the quadrupolar term adds “more non-integrability” to the model. Indeed, the quadrupolar Hamiltonian depends on all the secular variables which was not the case in [13].

Next, we analyse the normally hyperbolic cylinder and its invariant manifolds for the secular Hamiltonian. The first appropriate approximation is that of the quadrupolar Hamiltonian of planets 1 and 2 (see Section 4). It is well known that it posesses a hyperbolic singularity, which appears when the mutual inclination between planets 1 and 2 is larger than around 40 degrees. This hyperbolic singularity corresponds to a normally hyperbolic invariant cylinder in the full phase space. Moreover, the integrability implies that its stable and unstable manifolds coincide along a homoclinic manifold.

Fenichel Theory [30, 31, 32] implies that the normally hyperbolic invariant cylinder is persistent. In Section 5, we analyse the induced dynamics of the secular Hamiltonian on the cylinder, usually called the inner dynamics. We prove that it is integrable up to an arbitrarily high order and that it has torsion, provided that the mutual inclination of planets 1 and 2 is larger than 55 degrees. Note that the cylinder in the present paper has two dimensions more than the cylinder considered in [13], as the mean anomaly of planet 3 and the semimajor axis a<sub>3</sub> provide additional inner variables.

The results in [27] combined with classical perturbation techniques imply that the stable and unstable invariant manifolds of the cylinder of the secular Hamiltonian intersect transversely along two homoclinic channels. Orbits in these channels are heteroclinic orbits which “connect” diferent points in the cylinder. Such connections are encoded in the scattering maps (see [19] and Appendix B for the definition). Section 6 is devoted to the computation of the first order of these maps by means of Poincar´e-Melnikov Theory.

Once the inner dynamics and the outer dynamics (i.e. the scattering maps) have been analysed, the last step is to combine them to achieve drift in the actions. This is done in Section 7. First, we construct pseudo-orbits (i.e. orbits of the iterated function system consisting of a Poincar´e map induced by the inner dynamics and the two scattering maps) that follow any prescribed itinerary in the actions such that the scattering maps map “approximately invariant tori” of the inner dynamics transversely across other such tori. Then, referring to an argument contained in a previous paper by the authors [14] which provides rather flexible shadowing results, we show that there are orbits of both the secular Hamiltonian and the four-body problem Hamiltonian which follow closely the pseudo-orbits. Moreover, the shadowing methods in [14] allow us also to obtain time estimates.

Finally, in Section 8.1 we explain how to deal with the planetary regime where the masses of the three planets are arbitrarily small.

## Acknowledgments

The authors are grateful to Laurent Niederman for an illuminating discussion regarding Nekhoroshev estimates.

A. Clarke and M. Guardia are supported by the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation programme (grant agreement No. 757802). This work is part of the grant PID-2021-122954NB-100 funded by MCIN/AEI/10.13039/501100011033 and “ERDF A way of making Europe”. M. Guardia is also supported by the Catalan Institution for Research and Advanced Studies via an ICREA Academia Prize 2019. This work is also supported by the Spanish State Research Agency, through the Severo Ochoa and Mar´ıa de Maeztu Program for Centers and Units of Excellence in R&D (CEX2020-001084-M). This work is also partially supported by the project of the French Agence Nationale pour la Recherche CoSyDy (ANR-CE40-0014).

## 2 Main results in Deprit coordinates

The first step towards a proof of Theorem 1 is to find a suitable set of coordinates in which we can analyse the problem. In particular, as is well-known, the 4-body problem has many symmetries which can be exploited to reduce the dimension of the phase space. To this end, in Section 2.1 we explain how to express the 4-body problem in Jacobi coordinates, thus reducing by translational symmetry, and then pass to Deprit coordinates to reduce by rotational symmetry. In Section 2.2 we state a more detailed version of Theorem 1 in Deprit coordinates.

## 2.1 The Jacobi and Deprit coordinates

The 4-body problem is a Hamiltonian system with respect to the Hamiltonian

$$
H = \sum_ {0 \leq j \leq 3} \frac {y _ {j} ^ {2}}{2 m _ {j}} - \sum_ {0 \leq i <   j \leq 3} \frac {m _ {i} m _ {j}}{\| x _ {j} - x _ {i} \|},\tag{6}
$$

and the symplectic form $\Omega = d q \wedge$ dp where $x _ { j } \in \mathbb { R } ^ { 3 }$ is the position of body $j$ and $y _ { j } \in \mathbb { R } ^ { 3 }$ its conjugate linear momentum.

The Jacobi coordinates $( q _ { j } , p _ { j } ) \in \mathbb { R } ^ { 3 } \times \mathbb { R } ^ { 3 } , j = 0 , 1 , 2 , 3$ , are defined as

$$
\left\{ \begin{array}{l} q _ {0} = x _ {0} \\ q _ {1} = x _ {1} - x _ {0} \\ q _ {2} = x _ {2} - \sigma_ {0 1}   x _ {0} - \sigma_ {1 1}   x _ {1} \\ q _ {3} = x _ {3} - \sigma_ {0 2}   x _ {0} - \sigma_ {1 2}   x _ {1} - \sigma_ {2 2}   x _ {2} \end{array} \right. \quad \left\{ \begin{array}{l} p _ {0} = y _ {0} + y _ {1} + y _ {2} + y _ {3} \\ p _ {1} = y _ {1} + \sigma_ {1 1}   y _ {2} + \sigma_ {1 1}   y _ {3} \\ p _ {2} = y _ {2} + \sigma_ {2 2}   y _ {3} \\ p _ {3} = y _ {3}. \end{array} \right.
$$

where

$$
\sigma_ {i j} = \frac {m _ {i}}{M _ {j}} \qquad \mathrm{and} \qquad M _ {j} = \sum_ {i = 0} ^ {j} m _ {i}.\tag{7}
$$

A direct computation implies that this transformation is symplectic, in the sense that $d q \wedge d p = d x \wedge d y$ . The Hamiltonian (6) expressed in these coordinates does not depend on $q _ { 0 } .$ , and therefore $p _ { 0 }$ is a first integral. Without loss of generality, we may restrict to $p _ { 0 } = 0$ and consider the reduced phase space with coordinates $( q _ { j } , p _ { j } ) _ { j = 1 , 2 , 3 }$ . Then, the Hamiltonian (6) becomes

$$
H = F _ {\mathrm{Kep}} + F _ {\mathrm{per}}\tag{8}
$$

where

$$
F _ {\mathrm{Kep}} = \sum_ {j = 1} ^ {3} \left(\frac {p _ {j} ^ {2}}{2 \mu_ {j}} - \frac {\mu_ {j} M _ {j}}{\| q _ {j} \|}\right)\tag{9}
$$

$$
\begin{array}{r} F _ {\mathrm{per}} = \sum_ {j = 2} ^ {3} \frac {\mu_ {j} M _ {j}}{\| q _ {j} \|} - \frac {m _ {0} m _ {2}}{\| q _ {2} + \sigma_ {1 1} q _ {1} \|} - \frac {m _ {0} m _ {3}}{\| q _ {3} + \sigma_ {2 2} q _ {2} + \sigma_ {1 1} q _ {1} \|} - \frac {m _ {1} m _ {2}}{\| q _ {2} - \sigma_ {0 1} q _ {1} \|} \\ - \frac {m _ {1} m _ {3}}{\| q _ {3} + \sigma_ {2 2} q _ {2} + (\sigma_ {1 1} - 1) q _ {1} \|} - \frac {m _ {2} m _ {3}}{\| q _ {3} + (\sigma_ {2 2} - 1) q _ {2} \|} \end{array}\tag{10}
$$

with the reduced masses $\mu _ { j }$ defined, for each $j = 1 , 2 , 3 ,$ , by

$$
\mu_ {j} ^ {- 1} = M _ {j - 1} ^ {- 1} + m _ {j} ^ {- 1}.
$$

The next step is to pass to Deprit coordinates, which are well suited to the symmetry of rotations. These coordinates were discovered originally by Deprit [23], but their eficacy in the N-body problem was noticed only recently by Chierchia and Pinzari [11]. Let us denote by

$$
C _ {j} = q _ {j} \times p _ {j}
$$

the angular momentum of the $j ^ { \mathrm { t h } }$ fictitious body and let

$$
C = C _ {1} + C _ {2} + C _ {3}
$$

be the total angular momentum vector. Let $k _ { j }$ be the $j ^ { \mathrm { t h } }$ element of the standard orthonormal basis of $\mathbb { R } ^ { 3 }$ and define the nodes $\nu _ { j }$ by

$$
\nu_ {1} = \nu_ {2} = C _ {1} \times C _ {2}, \quad \nu_ {3} = (C _ {1} + C _ {2}) \times C _ {3}, \quad \nu_ {4} = k _ {3} \times C.
$$

For a non-zero vector $z \in \mathbb { R } ^ { 3 }$ and two non-zero vectors $u , v$ lying in the plane orthogonal to $z ,$ denote by $\alpha _ { z } ( u , v )$ the oriented angle between $u , v ,$ with orientation defined by the right hand rule with respect to $z .$ Denote by $\Pi _ { j }$ the pericenter of $q _ { j }$ on its Keplerian ellipse. The Deprit variables $( \ell _ { j } , L _ { j } , \gamma _ { j } , \Gamma _ { j } , \psi _ { j } , \Psi _ { j } ) _ { j = 1 , 2 , 3 }$ are defined as follows:

• $\ell _ { j }$ is the mean anomaly of $q _ { j }$ on its Keplerian ellipse;

$$
\bullet L _ {j} = \mu_ {j} \sqrt {M _ {j} a _ {j}};
$$

$$
\bullet \gamma_ {j} = \alpha_ {C _ {j}} (\nu_ {j}, \Pi_ {j});
$$

$$
\bullet \Gamma_ {j} = \| C _ {j} \|;
$$

$$
\bullet \psi_ {1} = \alpha_ {(C _ {1} + C _ {2})} (\nu_ {3}, \nu_ {2}), \psi_ {2} = \alpha_ {C} (\nu_ {4}, \nu_ {3}), \psi_ {3} = \alpha_ {k _ {3}} (k _ {1}, \nu_ {4});
$$

$$
\bullet \Psi_ {1} = \| C _ {1} + C _ {2} \|, \Psi_ {2} = \| C _ {1} + C _ {2} + C _ {3} \| = \| C \|, \Psi_ {3} = C \cdot k _ {3}.
$$

The Deprit variables are analytic and symplectic over the open subset in which the 3 terms of $F _ { \mathrm { K e p } }$ are negative, the eccentricities of the Keplerian ellipses belong to $( 0 , 1 )$ and the nodes $\nu _ { j }$ are nonzero (see [11, 23] or [13, Appendix $\mathrm { A l } )$ . Actions $\Psi _ { 2 }$ and $\Psi _ { 3 }$ are commuting first integrals.

The orbital elements can be expressed in terms of Deprit cordinates:

• The osculating eccentricities are defined by

$$
e _ {j} = \sqrt {1 - \frac {\Gamma_ {j} ^ {2}}{L _ {j} ^ {2}}}, \qquad j = 1, 2, 3.\tag{11}
$$

• The mutual inclination $i _ { 1 2 }$ between planets 1 and 2, measured as the oriented angle between $C _ { 1 }$ and $C _ { 2 } .$ , is defined via its cosine by

$$
\cos i _ {1 2} = \frac {\Psi_ {1} ^ {2} - \Gamma_ {1} ^ {2} - \Gamma_ {2} ^ {2}}{2 \Gamma_ {1} \Gamma_ {2}}.\tag{12}
$$

• The mutual inclination $i _ { 2 3 }$ between planet 3 and the inner two planets, measured as the oriented angle between $S _ { 1 } = C _ { 1 } + C _ { 2 }$ and $C _ { 3 }$ , is defined via its cosine by

$$
\cos i _ {2 3} = \frac {\Psi_ {2} ^ {2} - \Gamma_ {3} ^ {2} - \Psi_ {1} ^ {2}}{2 \Gamma_ {3} \Psi_ {1}}.\tag{13}
$$

## 2.2 Arnold difusion in Deprit coordinates

In this section we give a precise reformulation of Theorem 1 in terms of the Deprit coordinates. To this end, let us recall that we assume the masses $m _ { 0 } , m _ { 1 } , m _ { 2 } , m _ { 3 } > 0$ are fixed and satisfy $m _ { 0 } \neq m _ { 1 }$ . We consider a regime of increasingly separated bodies. In terms of the semimajor axes, we assume that

$$
a _ {1} \ll a _ {2} \ll a _ {3} ^ {1 / 3}\tag{14}
$$

which, in terms of Deprit, reads

$$
L _ {1} \ll L _ {2} \ll L _ {3} ^ {1 / 3}.\tag{15}
$$

We assume that the eccentricities of the bodies are uniformly bounded away from 0 and 1, and therefore the other Deprit actions $\Gamma _ { j } , j = 1 , 2 , 3 .$ , and $\Psi _ { j } , j = 1 , 2$ , have significantly diferent sizes. Indeed they satisfy

$$
\Gamma_ {i} \sim L _ {i} \quad \mathrm{for} \quad i = 1, 2, 3 \qquad \mathrm{and} \qquad \Psi_ {i} \sim \Gamma_ {i + 1} \qquad \mathrm{for} \qquad i = 1, 2.
$$

Let us explain which actions may drift under these assumptions. The semimajor axes $L _ { 1 }$ and $L _ { 2 }$ are almost constant due to the fact that the conjugate angles $\ell _ { 1 } , \ell _ { 2 }$ evolve faster than all other variables, and on diferent time scales to one another. As a result, $\ell _ { 1 } , \ \ell _ { 2 }$ can be averaged out of the Hamiltonian up to arbitrarily high order and any splitting of separatrices in the $L _ { 1 } , L _ { 2 }$ directions is exponentially small. Moreover, recall that $\Psi _ { 2 }$ is the total angular momentum, which is a first integral. Since $\Gamma _ { 1 } , \Gamma _ { 2 } \ll \Gamma _ { 3 }$ this implies that $\Gamma _ { 3 } \sim \Psi _ { 2 }$ is almost constant. However in this case, as in [13], relatively small proportions of angular momentum can transfer from $\Gamma _ { 3 }$ to $\Gamma _ { 2 }$ to create a significant change in the orbital elements of the second planet. Indeed, $\Gamma _ { 3 }$ can drift from

$$
\Gamma_ {3} \sim \Psi_ {2} - \Psi_ {1} \qquad \mathrm{to} \qquad \Gamma_ {3} \sim \Psi_ {2} + \Psi_ {1}.
$$

This corresponds to having $C _ { 3 }$ and $C _ { 1 } + C _ { 2 }$ close to parallel and either with the same sign or with opposite sign. That is, this evolution in $\Gamma _ { 3 }$ implies a large drift in the inclination $i _ { 2 3 } \ ( \mathrm { s e e \ ( 1 3 ) } )$ , or equivalently in $\theta _ { 2 3 }$ (as defined in Section 1.2).

Since $\Gamma _ { 2 } \ \ll \ \Gamma _ { 3 } ,$ , this transfer of angular momentum between bodies can cause dramatic changes in $\Gamma _ { 2 } \in ( 0 , L _ { 2 } )$ . Indeed, we are able to show that it drifts from

$$
\Gamma_ {2} \sim L _ {2} \qquad \mathrm{to} \qquad \Gamma_ {2} \sim 0.
$$

Equivalently, the orbital ellipse of the second planet can swing from being near-circular $( e _ { 2 } \sim 0 )$ to being highly eccentric $( e _ { 2 } \sim 1 )$ .

Finally, note that $L _ { 3 }$ must satisfy $L _ { 3 } > \Gamma _ { 3 } \sim \Psi _ { 2 }$ . Moreover, by taking $L _ { 3 } \to + \infty$ while $\Psi _ { 2 }$ is fixed (recall that it is a first integral) one has that $e _ { 3 } \to 1$ . Since we are considering a hierarchical regime, where the orbits of the bodies are increasingly (and uniformly) separated, one has to constrain the possible growth of $L _ { 3 }$ . If one fixes $0 < \kappa \ll 1$ , then one can consider $L _ { 3 }$ transitioning from

$$
L _ {3} \sim (1 + \kappa) \Psi_ {2} \qquad \mathrm{to} \qquad L _ {3} \sim \frac {\Psi_ {2}}{\kappa}.\tag{16}
$$

Since $\Gamma _ { 3 }$ is almost constant, this is equivalent to changing at the same time the semimajor axis as above (i.e. transitioning from $\begin{array} { r } { a _ { 3 } \sim ( 1 + \kappa ) ^ { 2 } \Psi _ { 2 } ^ { 2 } \mathrm { ~ t o ~ } a _ { 3 } \sim \frac { \Psi _ { 2 } ^ { 2 } } { \kappa ^ { 2 } } ) } \end{array}$ and the eccentricity $e _ { 3 }$ as

$$
e _ {3} \sim \sqrt {\kappa} \qquad \mathrm{to} \qquad e _ {3} \sim \sqrt {1 - \kappa^ {2}}.
$$

The next theorem shows that such transitions are possible and that one can freely vary $\Gamma _ { 2 } , \Gamma _ { 3 }$ and $L _ { 3 }$ within their “allowed” ranges.

Theorem 2. Fix masses $m _ { 0 } , m _ { 1 } , m _ { 2 } , m _ { 3 } > 0$ such that

$$
m _ {0} \neq m _ {1}.\tag{17}
$$

There exists $\xi$ with $0 < \xi \ll 1$ and $\alpha _ { 1 } , \alpha _ { 2 } , \beta > 0$ such that the following is satisfied.

Fix $N \geq 1 \ a n y \ \{ \nu ^ { k } \} _ { k = 0 } ^ { N } \subset ( 0 , 1 ) , \ \{ \eta ^ { k } \} _ { k = 0 } ^ { N } \subset ( - 1 , 1 ) , \ \{ \zeta ^ { k } \} _ { k = 0 } ^ { N } \subset ( 1 , + \infty )$ and constants $L _ { 1 } ^ { 0 } , \ L _ { 2 } ^ { 0 }$ and $\Psi _ { 2 } ^ { 0 }$ satisfying

$$
L _ {1} ^ {0} \in [ 1 - \xi , 1 + \xi ], \qquad L _ {1} ^ {0} \ll L _ {2} ^ {0} \qquad (L _ {2} ^ {0}) ^ {3} \ll \Psi_ {2} ^ {0} \qquad a n d \qquad | \Psi_ {1} ^ {0} - \nu_ {0} L _ {2} ^ {0} | \leq \frac {L _ {1} ^ {0}}{\sqrt {3}} + \xi .
$$

Then, there exists an orbit of the Hamiltonian H in (8) expressed in Deprit coordinates and times $\{ t _ { k } \} _ { k = 0 } ^ { N }$ satisfying

$$
t _ {0} = 0 \qquad a n d \qquad | t _ {k} | \leq \left(L _ {2} ^ {0}\right) ^ {\alpha_ {1}} \left(\Psi_ {2} ^ {0}\right) ^ {\alpha_ {2}}, k \geq 1
$$

such that

$$
\begin{array}{r} | \Gamma_ {2} (t _ {k}) - \nu_ {k} L _ {2} ^ {0} | \leq (L _ {2} ^ {0}) ^ {- \beta} \\ | \Psi_ {2} ^ {0} - \Gamma_ {3} (t _ {k}) - \eta_ {k} \Psi_ {1} (t _ {k}) | \leq (L _ {2} ^ {0}) ^ {- \beta} \\ | L _ {3} (t _ {k}) - \zeta_ {k} \Psi_ {2} ^ {0} | \leq (L _ {2} ^ {0}) ^ {- \beta}. \end{array}
$$

Moreover,

$$
| \Gamma_ {1} (t _ {k}) - L _ {1} ^ {0} | \leq (L _ {2} ^ {0}) ^ {- \beta}, \quad | \Psi_ {1} (t _ {k}) - \Gamma_ {2} (t _ {k}) - M _ {k} | \leq (L _ {2} ^ {0}) ^ {- \beta}
$$

where $\begin{array} { r } { M _ { k } \in \left( 0 , \frac { L _ { 1 } ^ { 0 } } { \sqrt { 3 } } + \xi \right) } \end{array}$ is determined by

$$
\frac {M _ {k} ^ {2}}{(L _ {2} ^ {0} - \Gamma_ {2} (t _ {k})) ^ {3 / 2}} = \frac {M _ {0} ^ {2}}{(L _ {2} ^ {0} - \Gamma_ {2} ^ {0}) ^ {3 / 2}} \qquad a n d \qquad M _ {0} = \Psi_ {1} ^ {0} - \Gamma_ {2} ^ {0}
$$

whereas for all $t \in [ 0 , t _ { N } ]$ 2

$$
| \Gamma_ {3} (t) - \Gamma_ {3} ^ {0} | \leq 2 L _ {2} ^ {0}, \quad a n d \quad | L _ {j} (t) - L _ {j} ^ {0} | \leq (L _ {2} ^ {0}) ^ {- \beta} \quad f o r \quad j = 1, 2.
$$

Theorem 2 is proved in Sections 3-7. It pertains to fixed values of the masses, in the sense that the increasing separation of the semimajor axes depend on the mass choices. We now want to obtain an analogous statement in the planetary regime, namely when bodies 1, 2, and 3 are assumed to have small mass. More concretely, $m _ { 0 } \sim 1$ and $m _ { i } = \rho \tilde { m } _ { i }$ for $i = { 1 , 2 , 3 }$ with $\tilde { m } _ { i } \sim 1$ and $0 < \rho \ll 1$

To deal with the planetary regime we consider scaled Deprit coordinates. Indeed, for fixed semimajor axes, the Deprit actions all have size $\rho .$ Then, to be able to capture their drift along the difusing orbits, it is convenient to perform the conformally symplectic scaling

$$
L = \rho \check {L}, \quad \Gamma = \rho \check {\Gamma}, \quad \Psi = \rho \check {\Psi},\tag{18}
$$

Theorem 3. Fix $m _ { 0 } , \widetilde { m } _ { 1 } , \widetilde { m } _ { 2 } , \widetilde { m } _ { 3 } > 0$ and consider the Hamiltonian H in (8) expressed in Deprit coordinates with masses $m _ { 0 } , m _ { j } = \rho \widetilde { m } _ { j }$ ewith $j = 1 , 2 , 3$ . Then, there exists $0 < \kappa \ll 1 , \alpha _ { 1 } , \alpha _ { 2 } , \beta > 0$ , such that the following is satisfied.

Fix $N \geq 1$ any $\{ \nu ^ { k } \} _ { k = 0 } ^ { N } \subset ( 0 , 1 ) , \{ \eta ^ { k } \} _ { k = 0 } ^ { N } \subset ( - 1 , 1 ) , \{ \zeta ^ { k } \} _ { k = 0 } ^ { N } \subset ( 1 , + \infty )$ and constants $\check { L } _ { 1 } ^ { 0 } , \check { L } _ { 2 } ^ { 0 }$ and $\check { \Psi } _ { 2 } ^ { 0 }$ satisfying

$$
\check {L} _ {1} ^ {0} \in \left[ \frac {1}{2}, 2 \right], \qquad \check {L} _ {1} ^ {0} \ll \check {L} _ {2} ^ {0}, \qquad \check {\Psi} _ {2} ^ {0} \gg \rho^ {- 1 / 3} \qquad a n d \qquad | \check {\Psi} _ {1} ^ {0} - \nu_ {0} \check {L} _ {2} ^ {0} | \leq \kappa .
$$

Then, there exists an orbit of the Hamiltonian H in (8) expressed in scaled Deprit coordinates and times $\{ t _ { k } \} _ { k = 0 } ^ { N }$ satisfying

$$
t _ {0} = 0 \qquad a n d \qquad | t _ {k} | \leq C (\check {L} _ {2} ^ {0}) \rho^ {- 3 5 / 3}, k \geq 1,
$$

where $C ( \check { L } _ { 2 } ^ { 0 } )$ is a constant depending on ${ \check { L } } _ { 2 } ^ { 0 }$ but independent of $\rho ,$ such that

$$
\begin{array}{r} | \check {\Gamma} _ {2} (t _ {k}) - \nu_ {k} \check {L} _ {2} ^ {0} | \leq (\check {L} _ {2} ^ {0}) ^ {- \beta} \\ | \check {\Psi} _ {2} ^ {0} - \check {\Gamma} _ {3} (t _ {k}) - \eta_ {k} \check {\Psi} _ {1} (t _ {k}) | \leq (\check {L} _ {2} ^ {0}) ^ {- \beta} \\ | \check {L} _ {3} (t _ {k}) - \zeta_ {k} \check {\Psi} _ {2} ^ {0} | \leq (\check {L} _ {2} ^ {0}) ^ {- \beta}. \end{array}
$$

Moreover,

$$
| \check {\Gamma} _ {1} (t _ {k}) - \check {L} _ {1} ^ {0} | \leq (\check {L} _ {2} ^ {0}) ^ {- \beta}, \quad | \check {\Psi} _ {1} (t _ {k}) - \check {\Gamma} _ {2} (t _ {k}) - M _ {k} | \leq (\check {L} _ {2} ^ {0}) ^ {- \beta}
$$

where $M _ { k } \in ( 0 , \kappa )$ is determined by

$$
\frac {M _ {k} ^ {2}}{(\check {L} _ {2} ^ {0} - \check {\Gamma} _ {2} (t _ {k})) ^ {3 / 2}} = \frac {M _ {0} ^ {2}}{(\check {L} _ {2} ^ {0} - \check {\Gamma} _ {2} ^ {0}) ^ {3 / 2}} \qquad a n d \qquad M _ {0} = \check {\Psi} _ {1} ^ {0} - \check {\Gamma} _ {2} ^ {0}
$$

whereas for all $t \in [ 0 , t _ { N } ]$ 2

$$
| \check {\Gamma} _ {3} (t) - \check {\Gamma} _ {3} ^ {0} | \leq 2 \check {L} _ {2} ^ {0}, \quad a n d \quad | \check {L} _ {j} (t) - \check {L} _ {j} ^ {0} | \leq (\check {L} _ {2} ^ {0}) ^ {- \beta} \quad f o r \quad j = 1, 2.
$$

## 3 Computation of the secular Hamiltonian

In this section we compute the secular Hamiltonian in three steps: first, we expand the perturbing function (10) using the Legendre polynomials; next, we observe that the mean anomalies $\ell _ { 1 } , \ell _ { 2 }$ are faster than the other variables, and we use this fact to perform a near-identity symplectic coordinate transformation that averages the angles $\ell _ { 1 } , \ell _ { 2 }$ out of the perturbing function up to arbitrarily high order; finally, we make a further symplectic coordinate transformation so that the new action variables are all of order 1, and we use these variables to expand the Taylor series of the secular Hamiltonian.

This section has strong similarities with the computation of the secular Hamiltonian in [13]. We do include it for the convenience of the reader and because terms describing the motion of planet 3 difer significantly.

## 3.1 Expansion of the perturbing function in Legendre polynomials

Since $\| q _ { j } \| = O ( a _ { j } ) = O ( L _ { j } ^ { 2 } )$ , the assumption (14) implies that $\lVert q _ { 1 } \rVert \ll \lVert q _ { 2 } \rVert \ll \lVert q _ { 3 } \rVert$ . Denote by $\zeta _ { j }$ the angles between $q _ { j }$ and $q _ { j + 1 }$ for $j = 1 , 2$ , and denote by $P _ { n }$ the Legendre polynomial of degree n. Observe that we can write the perturbing function $F _ { \mathrm { p e r } } { \mathrm { . } }$ , defined by (10), as

$$
F _ {\mathrm{per}} = F _ {\mathrm{per}} ^ {1 2} + F _ {\mathrm{per}} ^ {2 3} + O \left(\frac {1}{a _ {3} ^ {3}}\right)
$$

where

$$
F _ {\text {per}} ^ {1 2} = \frac {\mu_ {2} M _ {2}}{\| q _ {2} \|} - \frac {m _ {0} m _ {2}}{\| q _ {2} + \sigma_ {1 1} q _ {1} \|} - \frac {m _ {1} m _ {2}}{\| q _ {2} - \sigma_ {0 1} q _ {1} \|} = - \frac {\mu_ {1} m _ {2}}{\| q _ {2} \|} \sum_ {n = 2} ^ {\infty} \tilde {\sigma} _ {1, n} P _ {n} (\cos \zeta_ {1}) \left(\frac {\| q _ {1} \|}{\| q _ {2} \|}\right) ^ {n}\tag{19}
$$

is the perturbing function of the inner 3-body problem, and where

$$
F _ {\mathrm{per}} ^ {2 3} = - \frac {\mu_ {2} m _ {3}}{\| q _ {3} \|} \sum_ {n = 2} ^ {\infty} \tilde {\sigma} _ {2, n} P _ {n} (\cos \zeta_ {2}) \left(\frac {\| q _ {2} \|}{\| q _ {3} \|}\right) ^ {n}
$$

describes the interactions between bodies 2 and 3, with

$$
\tilde {\sigma} _ {1, n} = \sigma_ {0 1} ^ {n - 1} + (- 1) ^ {n} \sigma_ {1 1} ^ {n - 1}, \quad \tilde {\sigma} _ {2, n} = (\sigma_ {0 2} + \sigma_ {1 2}) ^ {n - 1} + (- 1) ^ {n} \sigma_ {2 2} ^ {n - 1},
$$

and $\sigma _ { i j }$ are defined in (7).

## 3.2 Averaging of the mean anomalies $\ell _ { 1 }$ and $\ell _ { 2 }$

In Deprit coordinates the Kepler Hamiltonian $F _ { \mathrm { K e p } } { \mathrm { . } }$ defined by (9), is given by

$$
F _ {\mathrm{Kep}} = - \sum_ {j = 1} ^ {3} \frac {\mu_ {j} ^ {3} M _ {j} ^ {2}}{2 L _ {j} ^ {2}}.\tag{20}
$$

From Hamilton’s equations of motion we see that the first order of $\dot { \ell } _ { j }$ is $\begin{array} { r } { { \frac { \partial F _ { \mathrm { K e p } } } { \partial L _ { j } } } = { \frac { \mu _ { j } ^ { 3 } M _ { j } ^ { 2 } } { L _ { j } ^ { 3 } } } } \end{array}$ . Since the first order term in $F _ { \mathrm { p e r } }$ is of order $\frac { \| q _ { 1 } \| ^ { 2 } } { \| q _ { 2 } \| ^ { 3 } } = O \left( L _ { 2 } ^ { - 6 } \right)$ , it follows that the angles $\ell _ { 1 } , \ \ell _ { 2 }$ are faster than all other variables. Therefore standard averaging arguments imply that we can perform a near-identity coordinate transformation so that, in the new coordinates, the Hamiltonian does not depend on the angles $\ell _ { 1 } , \ell _ { 2 }$ up to arbitrarily (but finitely) high order terms. Efecting the coordinate transformation, the Hamiltonian $H = F _ { \mathrm { K e p } } + F _ { \mathrm { p e r } }$ becomes

$$
F = F _ {\mathrm{Kep}} + \tilde {F} _ {\mathrm{sec}} + \frac {1}{L _ {2} ^ {1 0}} R _ {1} + \frac {1}{L _ {3} ^ {6}} R _ {2},\tag{21}
$$

where $F _ { \mathrm { K e p } }$ is given by (20), the Hamiltonian $\tilde { F } _ { \mathrm { s e c } }$ is defined by

$$
\tilde {F} _ {\mathrm{sec}} = F _ {\mathrm{sec}} ^ {1 2} + F _ {\mathrm{sec}} ^ {2 3} + O \left(\frac {1}{L _ {3} ^ {6}}\right),\tag{22}
$$

with

$$
F _ {\mathrm{sec}} ^ {1 2} = \frac {1}{(2 \pi) ^ {2}} \int_ {\mathbb {T} ^ {2}} F _ {\mathrm{per}} ^ {1 2} d \ell_ {1} d \ell_ {2} = - \frac {1}{(2 \pi) ^ {2}} \frac {\mu_ {1} m _ {2}}{\| q _ {2} \|} \sum_ {n = 2} ^ {\infty} \tilde {\sigma} _ {1, n} \int_ {\mathbb {T} ^ {2}} P _ {n} (\cos \zeta_ {1}) \left(\frac {\| q _ {1} \|}{\| q _ {2} \|}\right) ^ {n} d \ell_ {1} d \ell_ {2}\tag{23}
$$

$$
F _ {\mathrm{sec}} ^ {2 3} = \frac {1}{2 \pi} \int_ {\mathbb {T}} F _ {\mathrm{per}} ^ {1 2} d \ell_ {2} = - \frac {1}{2 \pi} \frac {\mu_ {2} m _ {3}}{\| q _ {3} \|} \sum_ {n = 2} ^ {\infty} \tilde {\sigma} _ {2, n} \int_ {\mathbb {T}} P _ {n} (\cos \zeta_ {2}) \left(\frac {\| q _ {2} \|}{\| q _ {3} \|}\right) ^ {n} d \ell_ {2}.\tag{24}
$$

Moreover the remainder term $R _ { 1 }$ depends only on the variables on which $F _ { \mathrm { p e r } } ^ { 1 2 }$ depends.

Remark 4. We use the following terminology and notation.

1. Using the usual terminology from the literature, we refer to the terms in the expansion of $F _ { \mathrm { s e c } } ^ { 1 2 }$ obtained by setting $n = 2 , 3$ in (23) as the quadrupolar, octupolar (respectively) Hamiltonians of the interaction between bodies 1 and 2, and we write $F _ { \mathrm { q u a d } } ^ { 1 2 } , F _ { \mathrm { o c t } } ^ { 1 2 }$ (respectively) to denote these Hamiltonians.

2. In addition, we refer to the $n = 2$ term in the expansion (24) of $F _ { \mathrm { s e c } } ^ { 2 3 }$ as the quadrupolar Hamiltonian of the interaction between bodies 2 and 3, and we write $F _ { \mathrm { q u a d } } ^ { 2 3 }$ to denote this Hamiltonian. Note that this terminology is generally reserved in the literature for the term obtained $b y$ averaging both $\ell _ { 2 }$ and $\ell _ { 3 }$ (see for example [13]); however, in this paper, the angle $\ell _ { 3 }$ is slower than, for example $\gamma _ { 1 }$ (see Proposition 7 below), and so it cannot be averaged from the perturbing function. We therefore consider this terminology and notation to be appropriate in this instance.

In this paper we require only the Hamiltonians $F _ { \mathrm { q u a d } } ^ { 1 2 } , F _ { \mathrm { o c t } } ^ { 1 2 } , F _ { \mathrm { q u a d } } ^ { 2 3 }$ . Expanding the first two terms of (23) and (24) and using the notation of Remark 4 we obtain

$$
F _ {\mathrm{sec}} ^ {1 2} = - \frac {\mu_ {1} m _ {2}}{(2 \pi) ^ {2}} \left(F _ {\mathrm{quad}} ^ {1 2} + \tilde {\sigma} _ {1, 3} F _ {\mathrm{oct}} ^ {1 2} + O \left(\frac {a _ {1} ^ {4}}{a _ {2} ^ {5}}\right)\right), \quad F _ {\mathrm{sec}} ^ {2 3} = - \frac {\mu_ {2} m _ {3}}{2 \pi} \left(F _ {\mathrm{quad}} ^ {2 3} + O \left(\frac {a _ {2} ^ {3}}{a _ {3} ^ {4}}\right)\right),
$$

where

$$
\left\{ \begin{array}{l l} F _ {\text { quad }} ^ {1 2} = & \int_ {\mathbb {T} ^ {2}} P _ {2} \left(\cos \zeta_ {1}\right) \frac {\| q _ {1} \| ^ {2}}{\| q _ {2} \| ^ {3}}   d \ell_ {1}   d \ell_ {2}, \quad F _ {\text { oct }} ^ {1 2} = \int_ {\mathbb {T} ^ {2}} P _ {3} \left(\cos \zeta_ {1}\right) \frac {\| q _ {1} \| ^ {3}}{\| q _ {2} \| ^ {4}}   d \ell_ {1}   d \ell_ {2} \\ F _ {\text { quad }} ^ {2 3} = & \int_ {\mathbb {T}} P _ {2} \left(\cos \zeta_ {2}\right) \frac {\| q _ {2} \| ^ {2}}{\| q _ {3} \| ^ {3}}   d \ell_ {2} \end{array} \right.
$$

since $\tilde { \sigma } _ { j , 2 } = 1$ for $j = 1 , 2$ . In the following Lemma (proved in [13]), we compute $F _ { \mathrm { q u a d } } ^ { 1 2 }$ and $F _ { \mathrm { o c t } } ^ { 1 2 }$ explicitly in terms of Deprit coordinates; we could perform similar computations to compute $\bar { F } _ { \mathrm { q u a d } } ^ { 2 3 } ,$ but the resulting expression would be very long. Instead, we compute $F _ { \mathrm { q u a d } } ^ { 2 3 }$ in Section 3.3 via a Taylor expansion, after making a suitable linear symplectic coordinate transformation.

Lemma 5. The quadrupolar and octupolar Hamiltonians of bodies 1 and $\mathcal { Q }$ are given by

$$
F _ {\mathrm{quad}} ^ {1 2} = \frac {a _ {1} ^ {2}}{8 a _ {2} ^ {3} (1 - e _ {2} ^ {2}) ^ {\frac {3}{2}}} \left(\left(1 5 e _ {1} ^ {2} \cos^ {2} \gamma_ {1} - 1 2 e _ {1} ^ {2} - 3\right) \sin^ {2} i _ {1 2} + 3 e _ {1} ^ {2} + 2\right)\tag{25}
$$

and

$$
\begin{array}{r l} F _ {\mathrm{oct}} ^ {1 2} = - \frac {1 5}{6 4} \frac {a _ {1} ^ {3}}{a _ {2} ^ {4}} \frac {e _ {1} e _ {2}}{\left(1 - e _ {2} ^ {2}\right) ^ {\frac {5}{2}}} \\ & \times \left\{ \begin{array}{c} \cos \gamma_ {1} \cos \gamma_ {2} \left[ \begin{array}{c} \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}} \left(5 \sin^ {2} i _ {1 2} \left(6 - 7 \cos^ {2} \gamma_ {1}\right) - 3\right) \\ - 3 5 \sin^ {2} \gamma_ {1} \sin^ {2} i _ {1 2} + 7 \end{array} \right] \\ + \sin \gamma_ {1} \sin \gamma_ {2} \cos i _ {1 2} \left[ \begin{array}{c} \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}} \left(5 \sin^ {2} i _ {1 2} \left(4 - 7 \cos^ {2} \gamma_ {1}\right) - 3\right) \\ - 3 5 \sin^ {2} \gamma_ {1} \sin^ {2} i _ {1 2} + 7 \end{array} \right] \end{array} \right\} \end{array}\tag{26}
$$

respectively, where the eccentricity $e _ { j }$ of the $j ^ { \mathrm { t h } }$ Keplerian ellipse is defined by (11), and where $i _ { 1 2 }$ is the mutual inclination of Keplerian bodies 1 and 2, defined by

$$
\cos i _ {1 2} = \frac {\Psi_ {1} ^ {2} - \Gamma_ {1} ^ {2} - \Gamma_ {2} ^ {2}}{2 \Gamma_ {1} \Gamma_ {2}}.
$$

## 3.3 Taylor expansion of the secular Hamiltonian

In order to perform the subsequent analysis, we divide the phase space into strips where the actions live in some bounded region. In each strip we perform an afine coordinate transformation so that the new actions have order 1, thus allowing us to perform a further Taylor expansion of the secular Hamiltonian.

Recall we assume that the semimajor axes satisfy (14), which in Deprit coordinates corresponds to the assumption (15) (if the masses are assumed to be fixed). Now, the variables $\Gamma _ { 2 } , \Psi _ { 1 }$ are of order $L _ { 2 }$ , while $\Gamma _ { 3 } , \Psi _ { 2 }$ are of order $L _ { 3 }$ . Fix some large positive value $L _ { 3 } ^ { * }$ of $L _ { 3 }$ . The total angular momentum $\Psi _ { 2 }$ is conserved, so we write

$$
\Psi_ {2} = \delta_ {2} L _ {3} ^ {*}\tag{27}
$$

for some fixed $\delta _ { 2 } > 0$ . We make the symplectic change of variables:

$$
\left\{ \begin{array}{l l} L _ {3} = L _ {3} ^ {*} + \tilde {L} _ {3}, & \tilde {\ell} _ {3} = \ell_ {3} \\ \tilde {\Psi} _ {1} = \Psi_ {1} - \delta_ {1} L _ {2}, & \tilde {\psi} _ {1} = \psi_ {1} + \gamma_ {2} \\ \tilde {\Gamma} _ {2} = \Psi_ {1} - \Gamma_ {2}, & \tilde {\gamma} _ {2} = - \gamma_ {2} \\ \tilde {\Gamma} _ {3} = \Psi_ {2} - \Gamma_ {3} - \delta_ {3} L _ {2}, & \tilde {\gamma} _ {3} = - \gamma_ {3} \end{array} \right.\tag{28}
$$

where $\delta _ { 1 } , \delta _ { 3 } > 0$ are constant with respect to the Hamiltonian $\tilde { F } _ { \mathrm { s e c } } .$ . Note that this symplectic transformation does not modify the variables $\gamma _ { 1 } , \Gamma _ { 1 }$ (or indeed $\ell _ { 3 } )$ . We assume that $L _ { 3 } ^ { * }$ is chosen so that ${ \tilde { L } } _ { 3 } = O ( 1 )$ ).

Moreover, we assume that

$$
\tilde {\Gamma} _ {2} > 0\tag{29}
$$

as the case where $\tilde { \Gamma } _ { 2 }$ is negative can be treated analogously. Furthermore, we assume that the new actions $\Gamma _ { 1 } , \tilde { \Gamma } _ { 2 } , \tilde { \Gamma } _ { 3 } , \tilde { \Psi } _ { 1 }$ live in a compact set away from the origin which is independent of $L _ { 2 }$ and $L _ { 3 } ^ { * }$ .

Remark 6. We make the following remarks regarding this coordinate transformation and notation.

1. By choosing diferent values of the constants $\delta _ { 1 } , \delta _ { 2 } , \delta _ { 3 }$ (and adjusting $L _ { 3 } ^ { * }$ so that (27) still holds) we can focus on any relevant region of the phase space, in order to make the coordinate transformation (28). This fact will be of importance in Section 7.3, where we construct trajectories that drift through many of these diferent regions.

2. Observe that we could equally have used the total angular momentum $\Psi _ { 2 }$ as a parameter instead of $\delta _ { 2 }$ as $\Psi _ { 2 } , L _ { 3 } ^ { * }$ are constant, and (27) implies that $\begin{array} { r } { \delta _ { 2 } = \frac { \breve { \Psi } _ { 2 } } { L _ { 3 } ^ { * } } } \end{array}$ . The reason that we have used the notation $\delta _ { 2 }$ instead is to maintain consistency with $I 1 3 7 ;$ indeed, we use several results from $\it { 1 3 7 }$ and it is easier to compare the formulas $i f$ the notation is the same.

Using the coordinates (28), the Keplerian Hamiltonian $F _ { \mathrm { K e p } }$ takes the form

$$
F _ {\mathrm{Kep}} = \tilde {F} _ {\mathrm{Kep}} + \frac {1}{(L _ {3} ^ {*}) ^ {3}} \alpha_ {\mathrm{Kep}} \tilde {L} _ {3} - \frac {1}{(L _ {3} ^ {*}) ^ {4}} \frac {3}{2} \alpha_ {\mathrm{Kep}} \tilde {L} _ {3} ^ {2} + O \left(\frac {1}{(L _ {3} ^ {*}) ^ {5}}\right)\tag{30}
$$

where

$$
\tilde {F} _ {\mathrm{Kep}} = - \sum_ {j = 1} ^ {2} \frac {\mu_ {j} ^ {3} M _ {j} ^ {2}}{2 L _ {j} ^ {2}} - \frac {\mu_ {3} ^ {3} M _ {3} ^ {2}}{2 (L _ {3} ^ {*}) ^ {2}}, \quad \alpha_ {\mathrm{Kep}} = \mu_ {3} ^ {3} M _ {3} ^ {2}.\tag{31}
$$

Since the angle $\tilde { \ell } _ { 3 }$ evolves slower than some of the secular angles $( \mathrm { i . e . \ } \gamma _ { 1 } , \tilde { \gamma } _ { 2 } , \tilde { \psi } _ { 1 }$ ; see Proposition 7 below) we must consider it as a secular variable. Therefore, we include $F _ { \mathrm { K e p } } - \tilde { F } _ { \mathrm { K e p } }$ in the secular Hamiltonian $F _ { \mathrm { s e c } }$ which we define by

$$
F _ {\mathrm{sec}} = \tilde {F} _ {\mathrm{sec}} + \left(F _ {\mathrm{Kep}} - \tilde {F} _ {\mathrm{Kep}}\right)\tag{32}
$$

where $\tilde { F } _ { \mathrm { s e c } }$ is defined by (22).

In the following proposition, we identify the first appearance of each of the secular variables in the secular Hamiltonian $F _ { \mathrm { s e c } }$ . In addition, we identify the first appearance of products of trigonometric functions of $\tilde { \psi } _ { 1 }$ , $\tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 }$ with functions of $\gamma _ { 1 } , \Gamma _ { 1 } , { \tilde { \gamma } } _ { 2 } ;$ this is of significance as these are the terms that will contribute to the Poincar´e-Melnikov computation in Section 6.

Proposition 7. The secular Hamiltonian $F _ { \mathrm { s e c } }$ , defined by (32), can be expanded in the form

$$
F _ {\mathrm{sec}} = c + \sum_ {i, j = 0} ^ {\infty} \varepsilon^ {i} \mu^ {j} F _ {i j}
$$

where $\begin{array} { r } { \varepsilon = \frac { 1 } { L _ { 2 } } , \mu = \frac { L _ { 2 } } { L _ { 3 } } } \end{array}$ , and where the terms in the expansion satisfy the following properties.

1. The first two nontrivial terms in the expansion are $F _ { 6 , 0 } = \alpha _ { 0 } ^ { 1 2 } H _ { 0 } ^ { 1 2 } , F _ { 7 , 0 } = \alpha _ { 1 } ^ { 1 2 } H _ { 1 } ^ { 1 2 }$ where $\alpha _ { i } ^ { 1 2 }$ are nontrivial constants, and where the Hamiltonians $H _ { 0 } ^ { 1 2 } , H _ { 1 } ^ { 1 2 }$ are defined by (33) and (34) respectively, are integrable, and do not depend on the masses. The Hamiltonians $H _ { 0 } ^ { 1 2 } , H _ { 1 } ^ { 1 2 }$ are the first order terms from $F _ { \mathrm { q u a d } } ^ { \mathrm { i 2 } }$ (see (25)). The variables $\gamma _ { 1 } , \Gamma _ { 1 } , \tilde { \Gamma } _ { 2 }$ appear in $H _ { 0 } ^ { 1 2 }$ , and the action $\tilde { \Psi } _ { 1 }$ first appears in $H _ { 1 } ^ { 1 2 }$

2. The angle $\tilde { \gamma } _ { 2 }$ first appears in $H _ { 2 } ^ { 1 2 }$ , which is contained in $F _ { 8 , 0 }$ . The Hamiltonian $H _ { 2 } ^ { 1 2 }$ is defined by (35), and is the first order term in the expansion of $F _ { \mathrm { o c t } } ^ { 1 2 }$ (see (26)), up to a multiplicative constant.

3. The action ${ \tilde { L } } _ { 3 }$ first appears in $F _ { 3 , 3 } ^ { } ,$ , specifically in the term of order $\left( L _ { 3 } ^ { * } \right) ^ { - 3 }$ in the expansion of $F _ { \mathrm { K e p } } -$ $\tilde { F } _ { \mathrm { K e p } }$ (see (30), (31), and (32)).

4. Each of the angles $\tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 }$ first appears in the Hamiltonian $H _ { 0 } ^ { 2 3 }$ (see (38)) which is contained in $F _ { 2 , 6 }$

5. The action ${ \tilde { \Gamma } } _ { 3 }$ first appears in the Hamiltonian $\tilde { \Gamma } _ { 3 } \tilde { H } _ { 3 }$ (see (36) and (37)) which is contained in $F _ { 3 , 6 }$

6. The Hamiltonian $H _ { 1 } ^ { 2 3 }$ , contained in $F _ { 3 , 6 . }$ , presents the first products of functions of each of the angles $\tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 }$ with functions of $\gamma _ { 1 } , \Gamma _ { 1 } , \tilde { \gamma } _ { 2 }$

Proof. The proposition follows from Lemmas 10, 11, and 12 below, upon comparing the orders of the coeficients of each Hamiltonian using the assumptions (15). □

Notation 8. Throughout this paper, in order to simplify notation, we use ellipsis to mean the following. Fix some suficiently large integer $r \in \mathbb N$ . The notation $F = \epsilon ^ { i } \mu ^ { j } G + \cdot \cdot \cdot$ means that there are $\eta _ { 1 } , \eta _ { 2 } \in \mathbb { N } _ { 0 }$ ， not both 0, and a positive constant C such that

$$
\left\| F - \epsilon^ {i} \mu^ {j} G \right\| _ {C ^ {r}} \leq C \epsilon^ {i + \eta_ {1}} \mu^ {j + \eta_ {2}}.
$$

Moreover, we use the expression nontrivial constant to mean a constant depending only on the masses and the parameters $\delta _ { j }$ that is nonzero for all $m _ { 0 } , m _ { 1 } , m _ { 2 } , m _ { 3 } > 0$ satisfying (17), all $\delta _ { 1 } , \delta _ { 2 } \in ( 0 , 1 )$ , and all $\delta _ { 3 } \in ( - 1 , 1 )$

Remark 9. Although the secular Hamiltonian depends on the mean anomaly $\tilde { \ell } _ { 3 }$ , the most natural way to compute such Hamiltonians is by using the true anomaly, denoted by $v _ { 3 }$ . Throughout this paper, we will write the dependence of the Hamiltonian on the variable $\tilde { \ell } _ { 3 }$ (and indeed later on similar variables $\ell _ { 3 } ^ { \prime } , \hat { \ell } _ { 3 }$ obtained via near-identity coordinate transformations); however the dependence of the Hamiltonian on this variable will be seen only implicitly through the Hamiltonian’s dependence on the true anomaly $v _ { 3 } .$ . When we need to diferentiate such a Hamiltonian, say K, with respect to the mean anomaly $\tilde { \ell } _ { 3 }$ , we obtain $\begin{array} { r } { \frac { \partial K } { \partial \tilde { \ell } _ { 3 } } = \frac { \partial K } { \partial v _ { 3 } } \frac { \partial v _ { 3 } } { \partial \tilde { \ell } _ { 3 } } } \end{array}$ , and we notice that, due to Kepler’s second law, we have

$$
\frac {\partial v _ {3}}{\partial \tilde {\ell} _ {3}} = \frac {\partial v _ {3}}{\partial \ell_ {3}} = \left(1 - e _ {3} ^ {2}\right) ^ {- \frac {3}{2}} \left(1 + e _ {3} \cos v _ {3}\right) ^ {2} = \delta_ {2} ^ {- 3} \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}\right) ^ {2} + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}\right),
$$

where we have expanded the eccentricity $e _ { 3 }$ using (11) and (28).

The quadrupolar and octupolar Hamiltonians $F _ { \mathrm { q u a d } } ^ { 1 2 }$ and $F _ { \mathrm { o c t } } ^ { 1 2 }$ of bodies 1 and 2 take the same form as in [13], as described in the following two lemmas (see $[ 1 3 ]$ for the proofs).

Lemma 10. The Hamiltonian $F _ { \mathrm { q u a d } } ^ { 1 2 }$ can be written in the variables (28) as

$$
F _ {\mathrm{quad}} ^ {1 2} = \tilde {c} _ {0} ^ {1 2} + \frac {1}{L _ {2} ^ {6}} \alpha_ {0} ^ {1 2} H _ {0} ^ {1 2} + \frac {1}{L _ {2} ^ {7}} \alpha_ {1} ^ {1 2} H _ {1} ^ {1 2} + \frac {1}{L _ {2} ^ {8}} \tilde {\alpha} _ {2} \tilde {H} _ {2} + \dots
$$

where

$$
H _ {0} ^ {1 2} = \left(1 - \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}}\right) \left[ 2 - 5 \left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {2}}\right) \sin^ {2} \gamma_ {1} \right] + \frac {\tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}\tag{33}
$$

$$
H _ {1} ^ {1 2} = \left(3 H _ {0} ^ {1 2} \left(\gamma_ {1}, \Gamma_ {1}, \tilde {\Gamma} _ {2}\right) - 1\right) \tilde {\Psi} _ {1} - 4 \tilde {\Gamma} _ {2} H _ {0} ^ {1 2} \left(\gamma_ {1}, \Gamma_ {1}, \tilde {\Gamma} _ {2}\right) + 3 \tilde {\Gamma} _ {2} - \frac {\Gamma_ {1} ^ {2} \tilde {\Gamma} _ {2}}{L _ {1} ^ {2}}\tag{34}
$$

$$
\begin{array}{l} \tilde {H} _ {2} = \left(3 H _ {0} ^ {1 2} \left(\gamma_ {1}, \Gamma_ {1}, \tilde {\Gamma} _ {2}\right) - 1\right) \tilde {\Psi} _ {1} ^ {2} + \left(6 - 8 H _ {0} ^ {1 2} \left(\gamma_ {1}, \Gamma_ {1}, \tilde {\Gamma} _ {2}\right) - 2 \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}}\right) \tilde {\Gamma} _ {2} \tilde {\Psi} _ {1} \\ \qquad + \frac {1}{8} \Bigg [ \sin^ {2} \gamma_ {1} \left(5 \Gamma_ {1} ^ {2} - \frac {5 \Gamma_ {1} ^ {4}}{L _ {1} ^ {2}} + \frac {2 1 0 \Gamma_ {1} ^ {2} \tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}} - \frac {2 0 5 \tilde {\Gamma} _ {2} ^ {4}}{L _ {1} ^ {2}} + \frac {2 0 5 \tilde {\Gamma} _ {2} ^ {4}}{\Gamma_ {1} ^ {2}}\right) \\ \qquad + \frac {\Gamma_ {1} ^ {4}}{L _ {1} ^ {2}} - \frac {6 6 \Gamma_ {1} ^ {2} \tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}} + \frac {4 1 \tilde {\Gamma} _ {2} ^ {4}}{L _ {1} ^ {2}} + 4 0 \tilde {\Gamma} _ {2} ^ {2} \Bigg ] \end{array}
$$

and

$$
\alpha_ {0} ^ {1 2} = \frac {3   L _ {1} ^ {4}   M _ {2} ^ {3}   \mu_ {2} ^ {6}}{8   M _ {1} ^ {2}   \delta_ {1} ^ {3}   \mu_ {1} ^ {4}}, \quad \alpha_ {1} ^ {1 2} = - \frac {3   L _ {1} ^ {4}   M _ {2} ^ {3}   \mu_ {2} ^ {6}}{8   M _ {1} ^ {2}   \delta_ {1} ^ {4}   \mu_ {1} ^ {4}}, \quad \tilde {\alpha} _ {2} = \frac {3   L _ {1} ^ {4}   M _ {2} ^ {3}   \mu_ {2} ^ {6}}{4   M _ {1} ^ {2}   \delta_ {1} ^ {5}   \mu_ {1} ^ {4}}.
$$

Moreover $F _ { \mathrm { q u a d } } ^ { 1 2 }$ is integrable.

Lemma 11. The Hamiltonian $F _ { \mathrm { o c t } } ^ { 1 2 }$ can be written in the rescaled variables (28) as

$$
F _ {\mathrm{oct}} ^ {1 2} = \frac {1}{L _ {2} ^ {8}} \alpha_ {2} ^ {1 2} H _ {2} ^ {1 2} + \dots
$$

where

$$
H _ {2} ^ {1 2} = \sqrt {1 - \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}}} \left\{ \begin{array}{c} \cos \gamma_ {1} \cos \tilde {\gamma} _ {2} \left[ \begin{array}{c} \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}} \left(5 \left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {2}}\right) (6 - 7 \cos^ {2} \gamma_ {1}) - 3\right) \\ - 3 5 \sin^ {2} \gamma_ {1} \left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {2}}\right) + 7 \end{array} \right] \\ + \frac {\tilde {\Gamma} _ {2}}{\Gamma_ {1}} \sin \gamma_ {1} \sin \tilde {\gamma} _ {2} \left[ \begin{array}{c} \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}} \left(5 \left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {2}}\right) (4 - 7 \cos^ {2} \gamma_ {1}) - 3\right) \\ - 3 5 \sin^ {2} \gamma_ {1} \left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {2}}\right) + 7 \end{array} \right] \end{array} \right\}\tag{35}
$$

and

$$
\alpha_ {2} ^ {1 2} = - \frac {1 5}{6 4} \frac {L _ {1} ^ {6} \mu_ {2} ^ {8} M _ {2} ^ {4}}{\mu_ {1} ^ {6} M _ {1} ^ {3}} \frac {\sqrt {1 - \delta_ {1} ^ {2}}}{\delta_ {1} ^ {5}}.
$$

The quadrupolar Hamiltonian $F _ { \mathrm { q u a d } } ^ { 2 3 }$ of bodies 2 and 3 is expanded in the following lemma.

Lemma 12. We can write the Hamiltonian $F _ { \mathrm { q u a d } } ^ { 2 3 }$ as

$$
F _ {\mathrm{quad}} ^ {2 3} = \frac {L _ {2} ^ {4}}{\left(L _ {3} ^ {*}\right) ^ {6}} \alpha_ {0} ^ {2 3} K _ {0} + \frac {L _ {2} ^ {3}}{\left(L _ {3} ^ {*}\right) ^ {6}} \alpha_ {1} ^ {2 3} K _ {1} + \dots\tag{36}
$$

where the Hamiltonians $K _ { 0 } , K _ { 1 }$ are themselves defined via the expansions

$$
\left\{ \begin{array}{l} K _ {0} = H _ {0} ^ {2 3} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}\right) + \frac {1}{L _ {2}} \left[ \tilde {\Gamma} _ {3}   \tilde {H} _ {3} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}\right) + \tilde {H} _ {4} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}, \tilde {\Psi} _ {1}\right) \right] + \dots , \\ K _ {1} = H _ {1} ^ {2 3} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}, \Gamma_ {1}, \tilde {\Gamma} _ {2}\right) + \dots , \end{array} \right.\tag{37}
$$

and we have

$$
\left\{ \begin{array}{l} H _ {0} ^ {2 3} = \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}\right) ^ {3} \left[ A _ {0} \left(\tilde {\gamma} _ {3}, v _ {3}\right) \cos^ {2} \tilde {\psi} _ {1} + B _ {0} \left(\tilde {\gamma} _ {3}, v _ {3}\right) \cos \tilde {\psi} _ {1} \sin \tilde {\psi} _ {1} + C _ {0} \left(\tilde {\gamma} _ {3}, v _ {3}\right) \right], \\ H _ {1} ^ {2 3} = \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}\right) ^ {3} \sqrt {\Gamma_ {1} ^ {2} - \tilde {\Gamma} _ {2} ^ {2}} \left[ A _ {1} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}\right) \cos \tilde {\gamma} _ {2} + B _ {1} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}\right) \sin \tilde {\gamma} _ {2} \right] \end{array} \right.\tag{38}
$$

where the trigonometric polynomials $A _ { 0 } , B _ { 0 } , C _ { 0 }$ are given by

$$
A _ {0} \left(\tilde {\gamma} _ {3}, v _ {3}\right) = 1 5 \left[ \left(\delta_ {3} ^ {2} - \frac {\delta_ {3} ^ {2}}{\delta_ {1} ^ {2}} - \left(1 - \delta_ {1} ^ {2}\right)\right) \sin^ {2} \left(v _ {3} - \tilde {\gamma} _ {3}\right) + \left(1 - \delta_ {1} ^ {2}\right) \right]\tag{39}
$$

$$
B _ {0} (\tilde {\gamma} _ {3}, v _ {3}) = 3 0 \frac {\delta_ {3}}{\delta_ {1}} (1 - \delta_ {1} ^ {2}) \cos (v _ {3} - \tilde {\gamma} _ {3}) \sin (v _ {3} - \tilde {\gamma} _ {3})\tag{40}
$$

$$
C _ {0} (\tilde {\gamma} _ {3}, v _ {3}) = \left(1 5 \frac {\delta_ {3} ^ {2}}{\delta_ {1} ^ {2}} - 1 2 \delta_ {3} ^ {2} - 3 \delta_ {1} ^ {2}\right) \sin^ {2} (v _ {3} - \tilde {\gamma} _ {3}) + 6 \delta_ {1} ^ {2} - 5
$$

and the trigonometric polynomials $A _ { 1 } , B _ { 1 } , \tilde { H } _ { 3 }$ are given by

$$
A _ {1} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}\right) = \delta_ {1} \delta_ {3} \cos \tilde {\psi} _ {1} \sin^ {2} \left(v _ {3} - \tilde {\gamma} _ {3}\right) - \delta_ {1} ^ {2} \sin \tilde {\psi} _ {1} \cos \left(v _ {3} - \tilde {\gamma} _ {3}\right) \sin \left(v _ {3} - \tilde {\gamma} _ {3}\right)
$$

$$
B _ {1} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}\right) = \left(4 \delta_ {1} \delta_ {3} - 5 \frac {\delta_ {3}}{\delta_ {1}}\right) \sin \tilde {\psi} _ {1} \sin^ {2} (v _ {3} - \tilde {\gamma} _ {3}) + (4 \delta_ {1} ^ {2} - 5) \cos \tilde {\psi} _ {1} \cos (v _ {3} - \tilde {\gamma} _ {3}) \sin (v _ {3} - \tilde {\gamma} _ {3})
$$

$$
\begin{array}{r} \tilde {H} _ {3} (\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}) = (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}) ^ {3} [ (3 0 \delta_ {3} (1 - \frac {1}{\delta_ {1} ^ {2}}) \cos^ {2} \tilde {\psi} _ {1} + 3 0 \frac {\delta_ {3}}{\delta_ {1} ^ {2}} - 2 4 \delta_ {3}) \sin^ {2} (v _ {3} - \tilde {\gamma} _ {3}) \\ + 3 0 \frac {1}{\delta_ {1}} (1 - \delta_ {1} ^ {2}) \cos \tilde {\psi} _ {1} \sin \tilde {\psi} _ {1} \cos (v _ {3} - \tilde {\gamma} _ {3}) \sin (v _ {3} - \tilde {\gamma} _ {3}) ]. \end{array}
$$

Proof. By definition, we have

$$
F _ {\mathrm{quad}} ^ {2 3} = \int_ {\mathbb {T}} P _ {2} (\cos \zeta_ {2}) \frac {\| q _ {2} \| ^ {2}}{\| q _ {3} \| ^ {3}} d \ell_ {2}.\tag{41}
$$

Denote by $\mathcal { R } _ { 1 } ( \theta ) , \ \mathcal { R } _ { 3 } ( \theta )$ the rotation matrix by an angle θ around the x, z-axis respectively, and let $I _ { 3 } = \mathcal { R } _ { 3 } ( \pi )$ . Write $\bar { q } _ { j } = \| q _ { j } \| ^ { - 1 } q _ { j }$ , and $\bar { Q } _ { j } = ( \cos ( \gamma _ { j } + v _ { j } ) , \sin ( \gamma _ { j } + v _ { j } ) , 0 )$ where $v _ { j }$ is the true anomaly corresponding to the mean anomaly $\ell _ { j }$ . By Proposition 4.1 of [52], we have

$$
\begin{array}{r l} & {\bar {q} _ {2} = \mathcal {R} _ {3} (\psi_ {3}) \mathcal {R} _ {1} (i) \mathcal {R} _ {3} (\psi_ {2}) \mathcal {R} _ {1} (\tilde {i} _ {2}) \mathcal {R} _ {3} (\psi_ {1}) I _ {3} \mathcal {R} _ {1} (i _ {2}) \bar {Q} _ {2}} \\ & {\bar {q} _ {3} = \mathcal {R} _ {3} (\psi_ {3}) \mathcal {R} _ {1} (i) \mathcal {R} _ {3} (\psi_ {2}) I _ {3} \mathcal {R} _ {1} (i _ {3}) \bar {Q} _ {3}} \end{array}
$$

where

$$
\cos i = \frac {\Psi_ {3}}{\Psi_ {2}}, \qquad \cos \tilde {i} _ {2} = \frac {\Psi_ {2} ^ {2} + \Psi_ {1} ^ {2} - \Gamma_ {3} ^ {2}}{2 \Psi_ {1} \Psi_ {2}}, \qquad \cos i _ {2} = \frac {\Gamma_ {2} ^ {2} + \Psi_ {1} ^ {2} - \Gamma_ {1} ^ {2}}{2 \Psi_ {1} \Gamma_ {2}}, \qquad \cos i _ {3} = \frac {\Gamma_ {3} ^ {2} + \Psi_ {2} ^ {2} - \Psi_ {1} ^ {2}}{2 \Psi_ {2} \Gamma_ {3}}.
$$

Since the last 3 rotations performed in each expression $\bar { q } _ { 2 } , \bar { q } _ { 3 }$ are the same, they can be ignored in the computation of cos $\zeta _ { 2 } = \bar { q } _ { 2 } \cdot \bar { q } _ { 3 }$

First, we focus on the rotations by the angles $i _ { 2 } , i _ { 3 }$ . Observe that, in our rescaled variables,

$$
\cos i _ {2} = 1 - L _ {2} ^ {- 2} \frac {\Gamma_ {1} ^ {2} - \tilde {\Gamma} _ {2} ^ {2}}{2 \delta_ {1} ^ {2}} + O (L _ {2} ^ {- 3}), \sin i _ {2} = L _ {2} ^ {- 1} \frac {\sqrt {\Gamma_ {1} ^ {2} - \tilde {\Gamma} _ {2} ^ {2}}}{\delta_ {1}} + O (L _ {2} ^ {- 2}),
$$

$$
\cos i _ {3} = 1 + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}\right), \quad \sin i _ {3} = O \left(\frac {L _ {2}}{L _ {3} ^ {*}}\right).
$$

Therefore we can write

$$
\mathcal {R} _ {1} (i _ {2}) = \mathrm{Id} + L _ {2} ^ {- 1} M _ {1} + O \left(L _ {2} ^ {- 2}\right), \quad \mathcal {R} _ {1} (i _ {3}) = \mathrm{Id} + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}\right)
$$

where

$$
M _ {1} = \left( \begin{array}{c c c} 0 & 0 & 0 \\ 0 & 0 & - b _ {1} \\ 0 & b _ {1} & 0 \end{array} \right) \quad \text {with} \quad b _ {1} = \frac {\sqrt {\Gamma_ {1} ^ {2} - \tilde {\Gamma} _ {2} ^ {2}}}{\delta_ {1}}.
$$

We thus obtain the expression

$$
\cos \zeta_ {2} = \bar {q} _ {2} \cdot \bar {q} _ {3} = W _ {0} + \frac {1}{L _ {2}} W _ {1} + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}, \frac {1}{L _ {2} ^ {2}}\right)
$$

where

$$
\begin{array}{r l} & W _ {0} = \mathcal {R} _ {1} (\tilde {i} _ {2}) \mathcal {R} _ {3} (\psi_ {1}) I _ {3} \bar {Q} _ {2} \cdot I _ {3} \bar {Q} _ {3}, \\ & W _ {1} = \mathcal {R} _ {1} (\tilde {i} _ {2}) \mathcal {R} _ {3} (\psi_ {1}) I _ {3} M _ {1} \bar {Q} _ {2} \cdot I _ {3} \bar {Q} _ {3}. \end{array}
$$

Recall the Legendre polynomial of degree 2 is $P _ { 2 } ( x ) = \textstyle { \frac { 1 } { 2 } } \left( 3 x ^ { 2 } - 1 \right)$ . Thus

$$
P _ {2} (\cos \zeta_ {2}) = P _ {2} (W _ {0}) + 3 \frac {1}{L _ {2}} W _ {0} W _ {1} + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}\right).\tag{42}
$$

In what follows, we integrate the two terms on the right-hand side of (42) separately using the technique introduced in Appendix C of [25]. We have

$$
\left\{ \begin{array}{l} \| q _ {2} \| = a _ {2} \rho_ {2}, \quad \rho_ {2} = 1 - e _ {2} \cos u _ {2} \\ \| q _ {3} \| = a _ {3} (1 - e _ {3} ^ {2}) \varrho_ {3}, \quad \frac {1}{\varrho_ {3}} = 1 + e _ {3} \cos v _ {3} \end{array} \right.
$$

where $u _ { 2 }$ is the eccentric anomaly of body 2 and $v _ { 3 }$ is the true anomaly of body 3. By diferentiating the Kepler equation $\ell _ { 2 } = u _ { 2 } - e _ { 2 }$ sin u we obtain $d \ell _ { 2 } = \rho _ { 2 } d u _ { 2 }$ . Combining these formulas with (41) we see that

$$
F _ {\mathrm{quad}} ^ {2 3} = \frac {a _ {2} ^ {2}}{a _ {3} ^ {3} (1 - e _ {3} ^ {2}) ^ {3}} \left(K _ {0} + \frac {1}{L _ {2}} 3 K _ {1} + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}, \frac {1}{L _ {2} ^ {2}}\right)\right)
$$

where

$$
K _ {0} = \varrho_ {3} ^ {- 3} \int_ {\mathbb {T}} P _ {2} (W _ {0}) \rho_ {2} ^ {3} d u _ {2}, K _ {1} = \varrho_ {3} ^ {- 3} \int_ {\mathbb {T}} W _ {0} W _ {1} \rho_ {2} ^ {3} d u _ {2}.
$$

Using the expressions

$$
\rho_ {2} \cos v _ {2} = \cos u _ {2} - e _ {2}, \quad \rho_ {2} \sin v _ {2} = \sqrt {1 - e _ {2} ^ {2}} \sin u _ {2},
$$

we can eliminate the angle $v _ { 2 }$ from the integrands of $K _ { 0 }$ and $K _ { 1 }$ . The result is a trigonometric polynomial which can be computed by quadrature and combined with the expansions

$$
e _ {2} ^ {2} = \left(1 - \delta_ {1} ^ {2}\right) + \frac {1}{L _ {2}}   2 \delta_ {1} \left(\tilde {\Gamma} _ {2} - \tilde {\Psi} _ {1}\right) + O \left(L _ {2} ^ {- 2}\right), e _ {3} ^ {2} = 1 - \delta_ {2} ^ {2} + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}\right),
$$

and

$$
\cos \tilde {i} _ {2} = \frac {\delta_ {3}}{\delta_ {1}} + \frac {1}{L _ {2}} \frac {\delta_ {1} \tilde {\Gamma} _ {3} - \delta_ {3} \tilde {\Psi} _ {1}}{\delta_ {1} ^ {2}} + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}, \frac {1}{L _ {2} ^ {2}}\right), \quad \sin^ {2} \tilde {i} _ {2} = \left(1 - \frac {\delta_ {3} ^ {2}}{\delta_ {1} ^ {2}}\right) - \frac {1}{L _ {2}} \frac {2 \delta_ {3}}{\delta_ {1}} \frac {\delta_ {1} \tilde {\Gamma} _ {3} - \delta_ {3} \tilde {\Psi} _ {1}}{\delta_ {1} ^ {2}} + O \left(\frac {L _ {2}}{L _ {3} ^ {*}}, \frac {1}{L _ {2} ^ {2}}\right)
$$

to complete the proof of the lemma.

## 4 First-order integrable dynamics

The purpose of this section is to establish the existence of a normally hyperbolic invariant manifold for the first-order term $H _ { 0 } ^ { 1 2 }$ , defined by (33), in the expansion of the secular Hamiltonian.

This section is similar to the corresponding section in [13]. We include it for the sake of completeness.

The Deprit coordinates conveniently produce in the four-body problem the same Hamiltonian $F _ { \mathrm { q u a d } } ^ { 1 2 }$ (see (25)) as the quadrupolar Hamiltonian of the three-body problem, expressed in Delaunay coordinates (see for example [27]; see also Section 4 of [13]). Therefore we can use the analysis and results of [27] (up to some errata; see Appendix F of [13]). In summary, we will show that $H _ { 0 } ^ { 1 2 }$ has a hyperbolic periodic orbit with a homoclinic connection (in some system of coordinates); since $H _ { 0 } ^ { 1 2 }$ is integrable (notice that it does not depend on $\tilde { \gamma } _ { 2 } )$ , this homoclinic connection is a separatrix, lying in the non-transverse homoclinic intersection of the stable and unstable manifolds.

The Hamiltonian vector field of $H _ { 0 } ^ { 1 2 }$ in the $\gamma _ { 1 } , \Gamma _ { 1 }$ directions, obtained by diferentiating (33), is

$$
\left\{ \begin{array}{l} \dot {\gamma} _ {1} = \frac {\partial H _ {0} ^ {1 2}}{\partial \Gamma_ {1}} = \frac {2   \Gamma_ {1}}{L _ {1} ^ {2}} \left[ 5 \left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {2}}\right) \sin^ {2} \gamma_ {1} - 2 \right] - 1 0 \left(1 - \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}}\right) \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {3}} \sin^ {2} \gamma_ {1} \\ \dot {\Gamma} _ {1} = - \frac {\partial H _ {0} ^ {1 2}}{\partial \gamma_ {1}} = 5 \left(1 - \frac {\Gamma_ {1} ^ {2}}{L _ {1} ^ {2}}\right) \left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {2}}\right) \sin 2 \gamma_ {1}. \end{array} \right.\tag{43}
$$

This vector field has (among others) two equilibria whenever $\Gamma _ { 1 } = L _ { 1 }$ and

$$
\tilde {\Gamma} _ {2} <   L _ {1} \sqrt {\frac {3}{5}}.\tag{44}
$$

Indeed, whenever (44) holds there are two solutions $\gamma _ { 1 } ^ { \mathrm { m i n } } \in ( 0 , \pi )$ and $\gamma _ { 1 } ^ { \mathrm { m a x } } = \pi - \gamma _ { 1 } ^ { \mathrm { m i n } }$ to the equation

$$
\sin^ {2} \gamma_ {1} = \frac {2}{5 \left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}\right)}.
$$

Therefore $( \gamma _ { 1 } , \Gamma _ { 1 } ) = ( \gamma _ { 1 } ^ { \mathrm { m i n , m a x } } , L _ { 1 } )$ are equilibria of the Hamiltonian vector field (43). Moreover, these equilibria are hyperbolic; this can be seen clearly below when we pass to Poincar´e variables (46). The Hamiltonian $H _ { 0 } ^ { 1 2 }$ also depends on ${ \tilde { \Gamma } } _ { 2 } ;$ indeed, we have $\begin{array} { r } { \frac { d \tilde { \gamma } _ { 2 } } { d t } = \frac { \partial H _ { 0 } ^ { 1 2 } } { \partial \tilde { \Gamma } _ { 2 } } = \frac { 2 \tilde { \Gamma } _ { 2 } } { L _ { 1 } ^ { 2 } } } \end{array}$ . Therefore, lifting the equilibria to the full phase space of $H _ { 0 } ^ { 1 2 }$ by including the variables $\tilde { \gamma } _ { 2 } , \tilde { \gamma } _ { 2 } ,$ we obtain the periodic orbits

$$
Z _ {\mathrm{min,max}} ^ {0} (t, \tilde {\gamma} _ {2} ^ {0}) = (\gamma_ {1} ^ {\mathrm{min,max}}, L _ {1}, \tilde {\gamma} _ {2} ^ {0} + \tilde {\gamma} _ {2} ^ {1} (t), \tilde {\Gamma} _ {2})\tag{45}
$$

where $\tilde { \gamma } _ { 2 } ^ { 0 } \in \mathbb { T }$ is the initial condition, and where

$$
\tilde {\gamma} _ {2} ^ {1} (t) = \frac {2 \tilde {\Gamma} _ {2}}{L _ {1} ^ {2}} t.
$$

Remark 13. The assumptions we have discussed in the introduction regarding inclination are seen mathematically in (44) (see also Remark $\it { 2 4 }$ below for a refinement of this remark). Indeed, from (12) and the change of coordinates (28), we see that cos $\begin{array} { r } { i _ { 1 2 } = \frac { \tilde { \Gamma } _ { 2 } } { \Gamma _ { 1 } } + O \left( L _ { 2 } ^ { - 1 } \right) } \end{array}$ . Therefore on the circular ellipse $\{ \Gamma _ { 1 } = L _ { 1 } \}$ the assumptions (29) and (44) imply that $\vert \cos i _ { 1 2 } \vert < \sqrt { \frac { 3 } { 5 } } + O \left( L _ { 2 } ^ { - 1 } \right)$ . This implies that $i _ { 1 2 }$ is more than roughly $4 0 ^ { \circ }$

Suppose (44) holds, and recall moreover we have assumed in (29) that $\tilde { \Gamma } _ { 2 } ~ > ~ 0$ . Define the positive constants

$$
\chi = \sqrt {\frac {2}{3}} \frac {\tilde {\Gamma} _ {2}}{L _ {1}} \frac {1}{\sqrt {1 - \frac {5}{3} \frac {\tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}}}, A _ {2} = \frac {6}{L _ {1}} \sqrt {\frac {2}{3}} \sqrt {1 - \frac {5}{3} \frac {\tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}}.
$$

The proof of the following result is identical to the proof of Lemma 3.1 in [27] (see also Appendix F of [13]).

Lemma 14. There is a heteroclinic orbit of $H _ { 0 } ^ { 1 2 }$ joining $Z _ { \mathrm { m a x } } ^ { 0 }$ and $Z _ { \mathrm { m i n } } ^ { 0 }$ backward and forward in time respectively. It is defined by the equation

$$
\left(1 - \frac {\tilde {\Gamma} _ {2} ^ {2}}{\Gamma_ {1} ^ {2}}\right) \sin^ {2} \gamma_ {1} = \frac {2}{5}
$$

where $\gamma _ { 1 } \in ( \gamma _ { 1 } ^ { \operatorname* { m i n } } , \gamma _ { 1 } ^ { \operatorname* { m a x } } ) \subset ( 0 , \pi )$ , and its time parametrisation is given by

$$
Z ^ {0} (t, \tilde {\gamma} _ {2} ^ {0}) = \left(\gamma_ {1} (t), \Gamma_ {1} (t), \tilde {\gamma} _ {2} (t), \tilde {\Gamma} _ {2}\right)
$$

where

$$
\cos \gamma_ {1} (t) = \sqrt {\frac {3}{5}} \frac {\sinh (A _ {2} t)}{\sqrt {\chi^ {2} + (1 + \chi^ {2}) \sinh^ {2} (A _ {2} t)}},
$$

$$
\Gamma_ {1} (t) = \tilde {\Gamma} _ {2} \sqrt {\frac {5}{3}} \frac {\sqrt {1 + \frac {3}{5} \frac {L _ {1} ^ {2}}{\tilde {\Gamma} _ {2} ^ {2}} \sinh^ {2} (A _ {2} t)}}{\cosh (A _ {2} t)},
$$

and

$$
\tilde {\gamma} _ {2} (t) = \tilde {\gamma} _ {2} ^ {0} + \tilde {\gamma} _ {2} ^ {1} (t) + \tilde {\gamma} _ {2} ^ {2} (t), \quad \text {   with   } \quad \tilde {\gamma} _ {2} ^ {2} (t) = \arctan \left(\chi^ {- 1} \tanh (A _ {2} t)\right).
$$

Even though the Hamiltonian function $H _ { 0 } ^ { 1 2 }$ is analytic near $\{ \Gamma _ { 1 } = L _ { 1 } \}$ , the Deprit coordinates, as is the case with Delaunay coordinates, are singular on this hypersurface (what is the perihelion of a circle?). We therefore introduce the Poincar´e variables

$$
\xi = \sqrt {2 (L _ {1} - \Gamma_ {1})} \cos \gamma_ {1}, \quad \eta = - \sqrt {2 (L _ {1} - \Gamma_ {1})} \sin \gamma_ {1}.\tag{46}
$$

This is a symplectic change of variables, in the sense that $d \xi \wedge d \eta = d \Gamma _ { 1 } \wedge d \gamma _ { 1 }$ . In these variables, the Hamiltonian $H _ { 0 } ^ { 1 2 }$ becomes

$$
\tilde {H} _ {0} ^ {1 2} = \frac {1}{L _ {1}} \left[ 2 \xi^ {2} - \left(3 - 5 \frac {\tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}\right) \eta^ {2} \right] + \frac {\tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}} + O _ {2} (\xi^ {2} + \eta^ {2})\tag{47}
$$

and the entire hypersurface $\{ \Gamma _ { 1 } = L _ { 1 } \}$ becomes a single hyperbolic periodic orbit

$$
\left(\xi , \eta , \tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}\right) = \left(0, 0, \tilde {\gamma} _ {2} ^ {0} + \tilde {\gamma} _ {2} ^ {1} (t), \tilde {\Gamma} _ {2}\right).
$$

Moreover, the heteroclinic connection established in Lemma 14 becomes a homoclinic connection to this hyperbolic periodic orbit.

On the hyperbolic periodic orbit and the separatrix, the energy is given by $\frac { \tilde { \Gamma } _ { 2 } ^ { 2 } } { L _ { 1 } ^ { 2 } }$ . It follows that we have a hyperbolic periodic orbit and a homoclinic connection for each positive value of $\bar { \Gamma } _ { 2 }$ satisfying (44). In other words, the Hamiltonian $\tilde { H } _ { 0 } ^ { 1 2 }$ has a normally hyperbolic invariant manifold given by

$$
\Lambda_ {0} = \left\{\left(\xi , \eta , \tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}\right): (\xi , \eta) = (0, 0), \tilde {\gamma} _ {2} \in \mathbb {T}, \tilde {\Gamma} _ {2} \in [ \zeta_ {1}, \zeta_ {2} ] \right\}
$$

where $\zeta _ { 1 } , \zeta _ { 2 }$ satisfy

$$
0 <   \zeta_ {1} <   \zeta_ {2} <   L _ {1} \sqrt {\frac {3}{5}}.\tag{48}
$$

Moreover the stable and unstable manifolds of $\Lambda _ { 0 }$ coincide.

## 5 Analysis of the inner dynamics

We can lift the normally hyperbolic invariant manifold $\Lambda _ { 0 }$ to the full secular phase space by increasing its dimension to include the remaining secular variables $\tilde { \psi } _ { 1 } , \tilde { \Psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \Gamma } _ { 3 } , \tilde { \ell } _ { 3 } , \tilde { L } _ { 3 }$ , in order to obtain

$$
\tilde {\Lambda} _ {0} = \left\{\left(\xi , \eta , \tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right): \xi = \eta = 0, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3} \in \mathbb {T}, \tilde {\Gamma} _ {2} \in [ \zeta_ {1}, \zeta_ {2} ], \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3} \in [ - 1, 1 ] \right\}.
$$

It is clear that this set remains a normally hyperbolic invariant manifold for $H _ { 0 } ^ { 1 2 } ;$ : the variables $\tilde { \psi } _ { 1 } , \tilde { \Psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \Gamma } _ { 3 } , \tilde { \ell } _ { 3 } , \tilde { L } _ { 3 }$ are constant with respect to $\bar { H } _ { 0 } ^ { 1 2 }$ so invariance follows; and the hyperbolicity in the normal directions $\xi , \eta$ is preserved. In addition, the variables $\left( \tilde { \gamma } _ { 2 } , \tilde { \Gamma } _ { 2 } , \tilde { \psi } _ { 1 } , \tilde { \Psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \Gamma } _ { 3 } , \tilde { \ell } _ { 3 } , \tilde { L } _ { 3 } \right)$ define coordinates on $\tilde { \Lambda } _ { 0 }$

In a neighbourhood of the normally hyperbolic cylinder $\tilde { \Lambda } _ { 0 }$ the symplectic form is

$$
\Omega = d \xi \wedge d \eta + d \tilde {\Gamma} _ {2} \wedge d \tilde {\gamma} _ {2} + d \tilde {\Gamma} _ {3} \wedge d \tilde {\gamma} _ {3} + d \tilde {\Psi} _ {1} \wedge d \tilde {\psi} _ {1} + d \tilde {L} _ {3} \wedge d \tilde {\ell} _ {3},
$$

and so the restriction to $\tilde { \Lambda } _ { 0 }$ of Ω is

$$
\Omega_ {0} = \left. \Omega \right| _ {\tilde {\Lambda} _ {0}} = d \tilde {\Gamma} _ {2} \wedge d \tilde {\gamma} _ {2} + d \tilde {\Gamma} _ {3} \wedge d \tilde {\gamma} _ {3} + d \tilde {\Psi} _ {1} \wedge d \tilde {\psi} _ {1} + d \tilde {L} _ {3} \wedge d \tilde {\ell} _ {3}.\tag{49}
$$

The following theorem is the main result of this section.

Theorem 15. For any $r \geq 2$ there is $L _ { 2 } ^ { * } > 0$ such that for any $L _ { 2 } \ge L _ { 2 } ^ { * }$ and $L _ { 3 } \gg L _ { 2 } ^ { 3 }$ we have the following.

1. The flow of the secular Hamiltonian $F _ { \mathrm { s e c } }$ has a normally hyperbolic invariant manifold Λ that is $\begin{array} { r } { O \left( \frac { 1 } { L _ { 2 } } \right) } \end{array}$ close to $\tilde { \Lambda } _ { 0 }$ in the $C ^ { r }$ topology. The restriction to Λ of the symplectic form Ω is closed and nondegenerate. The variables $\left( \tilde { \gamma } _ { 2 } , \tilde { \Gamma } _ { 2 } , \tilde { \psi } _ { 1 } , \tilde { \Psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \Gamma } _ { 3 } , \tilde { \ell } _ { 3 } , \tilde { L } _ { 3 } \right)$ define coordinates on Λ, with respect to which $\Omega | _ { \Lambda }$ is not necessarily in Darboux form.

2. Choose $k _ { 1 } , k _ { 2 } \in \mathbb { N }$ . There is a coordinate transformation

$$
\Phi : \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) \longmapsto \left(\hat {\gamma} _ {2}, \hat {\Gamma} _ {2}, \hat {\psi} _ {1}, \hat {\Psi} _ {1}, \hat {\gamma} _ {3}, \hat {\Gamma} _ {3}, \hat {\ell} _ {3}, \hat {L} _ {3}\right)
$$

on Λ that is $O \left( \varepsilon ^ { 3 } \right)$ -close to the identity in the $C ^ { r }$ topology such that

$$
\Omega | _ {\Lambda} = d \hat {\Gamma} _ {2} \wedge d \hat {\gamma} _ {2} + d \hat {\Psi} _ {1} \wedge d \hat {\psi} _ {1} + d \hat {\Gamma} _ {3} \wedge d \hat {\gamma} _ {3} + d \hat {L} _ {3} \wedge d \hat {\ell} _ {3},
$$

and the restriction to Λ of the secular Hamiltonian $F _ { \mathrm { s e c } }$ is

$$
\hat {F} = \hat {F} _ {0} \left(\hat {\Gamma} _ {2}, \hat {\Psi} _ {1}, \hat {\Gamma} _ {3}, \hat {L} _ {3}; \varepsilon , \mu\right) + \varepsilon^ {k _ {1}} \mu^ {k _ {2}} \hat {F} _ {1} \left(\hat {\gamma} _ {2}, \hat {\Gamma} _ {2}, \hat {\psi} _ {1}, \hat {\Psi} _ {1}, \hat {\gamma} _ {3}, \hat {\Gamma} _ {3}, \hat {\ell} _ {3}, \hat {L} _ {3}; \varepsilon , \mu\right)
$$

where ${ \hat { F } } _ { 0 } = \varepsilon ^ { 6 } { \hat { c } } _ { 0 } { \hat { \Gamma } } _ { 2 } ^ { 2 } + \varepsilon ^ { 7 } { \hat { h } } _ { 0 } \left( { \hat { \Gamma } } _ { 2 } , { \hat { \Psi } } _ { 1 } , { \hat { \Gamma } } _ { 3 } , { \hat { L } } _ { 3 } ; \varepsilon , \mu \right)$ , where $\begin{array} { r } { \varepsilon = { \frac { 1 } { L _ { 2 } } } , \mu = { \frac { L _ { 2 } } { L _ { 3 } ^ { * } } } } \end{array}$ , and where $\hat { F } _ { j }$ are uniformly bounded in the $C ^ { r }$ topology as ε, $\mu  0 ~ f o r ~ j = 0 , 1$

The rest of the section is dedicated to the proof of Theorem 15. Fenichel theory guarantees the persistence of the normally hyperbolic manifold $\tilde { \Lambda } _ { 0 }$ for $F _ { \mathrm { s e c } } ~ [ 3 0 , 3 1 , 3 2 ]$ . In particular, the existence is guaranteed of a function $\rho : \tilde { \Lambda } _ { 0 } \to \mathbb { R } ^ { 2 }$ that is $O \left( L _ { 2 } ^ { - 1 } \right)$ small in the $C ^ { r }$ topology such that the set

$$
\Lambda = \operatorname{graph} (\rho) = \left\{\left(\rho (x), x\right): x \in \tilde {\Lambda} _ {0} \right\}\tag{50}
$$

is a normally hyperbolic invariant manifold for $F _ { \mathrm { s e c } }$ . The following lemma provides us with information regarding the order at which each secular variable appears in the Taylor expansion of $\rho .$

Lemma 16. The function ρ admits a Taylor expansion of the form

$$
\rho = \frac {1}{L _ {2}} \rho_ {0} + \frac {1}{L _ {2} ^ {2}} \rho_ {1} + \frac {L _ {2} ^ {1 0}}{\left(L _ {3} ^ {*}\right) ^ {6}} \rho_ {2} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \rho_ {3} + \frac {L _ {2} ^ {1 0}}{\left(L _ {3} ^ {*}\right) ^ {7}} \rho_ {4}
$$

with

$$
\left\{ \begin{array}{l l} \rho_ {0} = & \rho_ {0} (\tilde {\Gamma} _ {2}) \\ \rho_ {1} = & \rho_ {1} (\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}) \\ \rho_ {2} = & \rho_ {2} (\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}) \\ \rho_ {3} = & \rho_ {2} (\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}) \\ \rho_ {4} = & \rho_ {2} (\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}) \end{array} \right.
$$

where each $\rho _ { j }$ is uniformly bounded in the C<sup>r</sup> topology as $L _ { 2 } , L _ { 3 } \to \infty \ ( w i t h \ L _ { 3 } \gg L _ { 2 } ^ { 3 } )$

Proof. The proof is analogous to the proof of Lemma 21 in [13], and we do not repeat it here. □

Lemma 17. There is a coordinate transformation

$$
\Phi^ {(1)}: \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) \longmapsto (\gamma_ {2} ^ {\prime}, \Gamma_ {2} ^ {\prime}, \gamma_ {3} ^ {\prime}, \Gamma_ {3} ^ {\prime}, \psi_ {1} ^ {\prime}, \Psi_ {1} ^ {\prime}, \ell_ {3} ^ {\prime}, L _ {3} ^ {\prime})\tag{51}
$$

on Λ that is $\begin{array} { r } { O \left( \frac { 1 } { L _ { 2 } ^ { 3 } } \right) } \end{array}$ close to the identity satisfying

$$
\Gamma_ {2} ^ {\prime} = \tilde {\Gamma} _ {2} + \frac {1}{L _ {2} ^ {3}} P _ {0} ^ {\prime} (\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3})
$$

$$
\Psi_ {1} ^ {\prime} = \tilde {\Psi} _ {1} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} P _ {1} ^ {\prime} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right)
$$

$$
\Gamma_ {3} ^ {\prime} = \quad \tilde {\Gamma} _ {3} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} P _ {2} ^ {\prime} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right)
$$

$$
{L _ {3} ^ {\prime} =} {\tilde {L} _ {3} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} P _ {3} ^ {\prime} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right)}
$$

such that

$$
\Omega | _ {\Lambda} = d \Gamma_ {2} ^ {\prime} \wedge d \gamma_ {2} ^ {\prime} + d \Gamma_ {3} ^ {\prime} \wedge d \gamma_ {3} ^ {\prime} + d \Psi_ {1} ^ {\prime} \wedge d \psi_ {1} ^ {\prime} + d L _ {3} ^ {\prime} \wedge d \ell_ {3} ^ {\prime}.
$$

Proof. Denote by $U \subset \mathbb { R } ^ { 2 }$ the domain of the Poincar´e variables $( \xi , \eta )$ , and by $V \subset \mathbb { R } ^ { 4 }$ the domain of the actions $\left( \tilde { \Gamma } _ { 2 } , \tilde { \Psi } _ { 1 } , \tilde { \Gamma } _ { 3 } , \tilde { L } _ { 3 } \right)$ . Define the inclusion map $P : \mathbb { T } ^ { 4 } \times V  U \times ( \mathbb { T } ^ { 4 } \times V )$ by $P ( x ) = ( \rho ( x ) , x )$ where $\rho$ is the function that parametrises the normally hyperbolic cylinder Λ via (50). Then $\Omega _ { 1 } = P ^ { * } \Omega$ is the pullback to Λ of Ω in the coordinates (28).

The Liouville 1-form λ is given by $\dot { \lambda } = \xi d \eta + \tilde { \Gamma } _ { 2 } d \tilde { \gamma } _ { 2 } + \tilde { \Gamma } _ { 3 } d \tilde { \gamma } _ { 3 } + \tilde { \Psi } _ { 1 } d \tilde { \psi } _ { 1 } + \tilde { L } _ { 3 } d \tilde { \ell } _ { 3 }$ , and we have $\Omega = d \lambda$ Define $\lambda _ { 1 } = P ^ { * } \lambda$ . Then $\Omega _ { 1 }$ is exact, because $d \lambda _ { 1 } = d \left( P ^ { * } \lambda \right) = P ^ { * } d \lambda = P ^ { * } \Omega = \Omega _ { 1 }$

Denote by $\rho _ { \xi } , \rho _ { \eta }$ the $\xi , \eta$ components of $\rho$ respectively, and by $\rho _ { j , \xi } , \rho _ { j , \eta }$ the $\xi , \eta$ components of $\rho _ { j }$ respectively for each $j = 0 , 1 , 2 , 3 , 4$ . Using (49) we see that

$$
\Omega_ {1} = P ^ {*} \Omega = d \rho_ {\xi} \wedge d \rho_ {\eta} + \Omega_ {0} = \Omega_ {0} + R _ {1} + R _ {2}
$$

with

$$
R _ {1} = \frac {1}{L _ {2} ^ {2}} \left(d \rho_ {0, \xi} + \frac {1}{L _ {2}} d \rho_ {1, \xi}\right) \wedge \left(d \rho_ {0, \eta} + \frac {1}{L _ {2}} d \rho_ {1, \eta}\right) = \frac {1}{L _ {2} ^ {3}} \left[ d \rho_ {0, \xi} \wedge d \rho_ {1, \eta} + d \rho_ {1, \xi} \wedge d \rho_ {0, \eta} + \frac {1}{L _ {2}} d \rho_ {1, \xi} \wedge d \rho_ {1, \eta} \right],
$$

$$
R _ {2} = d \rho_ {\xi} \wedge d \rho_ {\eta} - R _ {1}
$$

where we have used the fact that $\rho _ { 0 }$ depends only on $\tilde { \Gamma } _ { 2 }$ . Then $R _ { 1 }$ is of order $\textstyle { \frac { 1 } { L _ { 2 } ^ { 3 } } }$ , and depends only on $\tilde { \gamma } _ { 2 } , \tilde { \Gamma } _ { 2 } , \tilde { \Psi } _ { 1 }$ , whereas $R _ { 2 }$ is of order $\frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ (i.e. the order of $\rho _ { 2 }$ times the order of $\rho _ { 1 } )$ ) and depends on all of the secular variables. In what follows, we construct the coordinate transformation (51) in two steps: the first one eliminates $R _ { 1 }$ from $\Omega _ { 1 }$ , and the second eliminates $R _ { 2 }$

Suppose there is a coordinate transformation

$$
h _ {0}: \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) \longmapsto \left(\gamma_ {2} ^ {*}, \Gamma_ {2} ^ {*}, \psi_ {1} ^ {*}, \tilde {\Psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right)\tag{52}
$$

that changes only the $\tilde { \gamma } _ { 2 } , \tilde { \Gamma } _ { 2 } , \tilde { \psi } _ { 1 }$ variables, such that

$$
h _ {0} ^ {*} \Omega^ {\prime} = \Omega_ {0} \quad \text { where } \quad \Omega^ {\prime} = \Omega_ {0} + R _ {1}.\tag{53}
$$

We use Moser’s trick from his proof of Darboux’s theorem: suppose $h _ { 0 } = \phi _ { \hat { \varepsilon } }$ where $\phi _ { t }$ is the time-t map of some nonautonomous vector field $X _ { t }$ and where $\hat { \varepsilon } = L _ { 2 } ^ { - 3 }$ . Upon diferentiating (53) with respect to $\hat { \varepsilon }$ and using Cartan’s magic formula we get

$$
0 = \frac {d}{d \hat {\varepsilon}} [ \phi_ {\hat {\varepsilon}} ^ {*} \Omega^ {\prime} ] = \phi_ {\hat {\varepsilon}} ^ {*} \left[ \frac {d}{d \hat {\varepsilon}} \Omega^ {\prime} + \mathcal {L} _ {X _ {\hat {\varepsilon}}} \Omega^ {\prime} \right] = \phi_ {\hat {\varepsilon}} ^ {*} \left[ \frac {d}{d \hat {\varepsilon}} \Omega^ {\prime} + i _ {X _ {\hat {\varepsilon}}} d \Omega^ {\prime} + d i _ {X _ {\hat {\varepsilon}}} \Omega^ {\prime} \right]
$$

where $\mathcal { L } _ { X _ { \hat { \varepsilon } } }$ is the Lie derivative with respect to $X _ { \hat { \varepsilon } }$ , and $i _ { X _ { \hat { \varepsilon } } }$ is the contraction operator of $X _ { \hat { \varepsilon } }$ . By the same argument as for $\Omega _ { 1 }$ above, $\Omega ^ { \prime } = d \lambda ^ { \prime }$ is exact, and $\mathrm { s o } ,$ since $d \Omega ^ { \prime } = 0$ , we obtain

$$
d i _ {X _ {\hat {\varepsilon}}} \Omega^ {\prime} = - \frac {d}{d \hat {\varepsilon}} \Omega^ {\prime} = - \frac {d}{d \hat {\varepsilon}} d \lambda^ {\prime} = - d \left(\frac {d}{d \hat {\varepsilon}} \lambda^ {\prime}\right).
$$

Observe that this equation is satisfied by vector fields $X _ { t }$ for which

$$
i _ {X _ {\hat {\varepsilon}}} \Omega^ {\prime} = - \frac {d}{d \hat {\varepsilon}} \lambda^ {\prime}.
$$

By inverting $\Omega ^ { \prime }$ this can be solved explicitly for $X _ { t }$ . Its flow exists at least for a time $\hat { \varepsilon } ,$ and its time-ˆε map gives the required map $h _ { 0 }$ as in (52). Indeed, the argument in Appendix A implies that this coordinate transformation does not afect $\tilde { \Psi } _ { 1 }$ , because $\rho _ { 0 } , \rho _ { 1 }$ do not depend on $\ddot { \psi } _ { 1 }$

In the new coordinates, the symplectic form $\Omega _ { 1 }$ becomes $\hat { \Omega } _ { 1 } = \Omega _ { 0 } + \hat { R } _ { 2 }$ where $\hat { R } _ { 2 } = h _ { 0 } ^ { * } R _ { 2 }$ . Since $R _ { 2 }$ is of order $\frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ , we may repeat the above procedure with $\begin{array} { r } { \hat { \varepsilon } = \frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } } } \end{array}$ to complete the proof of the lemma.

Lemma 18. Choose $k _ { 1 } , k _ { 2 } \in \mathbb { N }$ . There is a symplectic coordinate transformation

$$
\Phi^ {(2)}: (\gamma_ {2} ^ {\prime}, \Gamma_ {2} ^ {\prime}, \gamma_ {3} ^ {\prime}, \Gamma_ {3} ^ {\prime}, \psi_ {1} ^ {\prime}, \Psi_ {1} ^ {\prime}, \ell_ {3} ^ {\prime}, L _ {3} ^ {\prime}) \longmapsto \left(\hat {\gamma} _ {2}, \hat {\Gamma} _ {2}, \hat {\gamma} _ {3}, \hat {\Gamma} _ {3}, \hat {\psi} _ {1}, \hat {\Psi} _ {1}, \hat {\ell} _ {3}, \hat {L} _ {3}\right)
$$

on $\Lambda$ that is $O \left( \varepsilon ^ { 3 } \right)$ close to the identity, such that the restriction $\hat { F } = \left. F _ { \mathrm { s e c } } \right| _ { \Lambda }$ of the secular Hamiltonian to Λ becomes 7

$$
\hat {F} = \hat {F} _ {0} \left(\hat {\Gamma} _ {2}, \hat {\Gamma} _ {3}, \hat {\Psi} _ {1}, \hat {L} _ {3}; \varepsilon , \mu\right) + \varepsilon^ {k _ {1}} \mu^ {k _ {2}} F _ {1} \left(\hat {\gamma} _ {2}, \hat {\Gamma} _ {2}, \hat {\gamma} _ {3}, \hat {\Gamma} _ {3}, \hat {\psi} _ {1}, \hat {\Psi} _ {1}, \hat {\ell} _ {3}, \hat {L} _ {3}; \varepsilon , \mu\right)
$$

where ${ \hat { F } } _ { 0 } = \varepsilon ^ { 6 } c _ { 0 } { \hat { \Gamma } } _ { 2 } ^ { 2 } + \varepsilon ^ { 7 } { \hat { h } } _ { 0 } \left( { \hat { \Gamma } } _ { 2 } , { \hat { \Gamma } } _ { 3 } , { \hat { \Psi } } _ { 1 } , { \hat { L } } _ { 3 } ; \varepsilon , \mu \right)$ , where $\begin{array} { r } { \varepsilon = { \frac { 1 } { L _ { 2 } } } , \mu = { \frac { L _ { 2 } } { L _ { 3 } ^ { * } } } } \end{array}$ , and where the $C ^ { 2 }$ norm of $\hat { F }$ is uniformly bounded in $\varepsilon , \mu \ f o r \ j = 0 , \dot { . }$ 1. Moreover we can approximate the transformations of the actions at first order by

$$
\hat {\Gamma} _ {2} = \Gamma_ {2} ^ {\prime} + O \left(\frac {1}{L _ {2} ^ {3}}\right)\tag{54}
$$

$$
\hat {\Gamma} _ {3} = \Gamma_ {3} ^ {\prime} - \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {\mathrm{Kep}}} \frac {\beta_ {0} \delta_ {2} ^ {3}}{6} \left[ \sqrt {1 - \delta_ {2} ^ {2}} \left(\cos {(3 v _ {3} ^ {\prime} - 2 \gamma_ {3} ^ {\prime})} + 3 \cos {(v _ {3} ^ {\prime} - 2 \gamma_ {3} ^ {\prime})}\right) + 3 \cos {(2 v _ {3} ^ {\prime} - 2 \gamma_ {3} ^ {\prime})} \right] + \dots\tag{55}
$$

$$
\hat {\Psi} _ {1} = \Psi_ {1} ^ {\prime} - \frac {L _ {2} ^ {1 1}}{\left(L _ {3} ^ {*}\right) ^ {6}} \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {1} ^ {1 2}} \frac {\left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) ^ {3}}{2 \left(3 \frac {\left(\Gamma_ {2} ^ {\prime}\right) ^ {2}}{L _ {1} ^ {2}} - 1\right)} \left[ A _ {0} \left(\gamma_ {3} ^ {\prime}, v _ {3} ^ {\prime}\right) \cos 2 \psi_ {1} ^ {\prime} + B _ {0} \left(\gamma_ {3} ^ {\prime}, v _ {3} ^ {\prime}\right) \sin 2 \psi_ {1} ^ {\prime} \right] + \dots\tag{56}
$$

$$
\hat {L} _ {3} = L _ {3} ^ {\prime} - \frac {L _ {2} ^ {4}}{\left(L _ {3} ^ {*}\right) ^ {3}} \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {\mathrm{Kep}}} \left(\left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) ^ {3} \left[ \beta_ {0} \sin^ {2} \left(v _ {3} ^ {\prime} - \gamma_ {3} ^ {\prime}\right) + \beta_ {1} \right] - \delta_ {2} ^ {3} \left(\frac {\beta_ {0}}{2} + \beta_ {1}\right)\right) + \dots\tag{57}
$$

where the trigonometric polynomials $A _ { 0 } , B _ { 0 }$ are defined by (39), (40), the constants $\beta _ { j }$ are defined by

$$
\beta_ {0} = \frac {1}{2} \left(9 \delta_ {1} ^ {2} - 9 \delta_ {3} ^ {2} + 1 5 \frac {\delta_ {3} ^ {2}}{\delta_ {1} ^ {2}} - 1 5\right), \quad \beta_ {1} = \frac {1}{2} \left(5 - 3 \delta_ {1} ^ {2}\right),\tag{58}
$$

and where $v _ { 3 } ^ { \prime }$ is the true anomaly corresponding to the mean anomaly $\ell _ { 3 } ^ { \prime }$

Proof. Since the frequencies of the angles all have diferent size the averaging procedure is rather standar, since there are no small divisors. We explicitly compute the first order of the symplectic coordinate transformation $\Phi ^ { ( 2 ) }$ in the actions $\Gamma _ { 3 } ^ { \prime } , \Psi _ { 1 } ^ { \prime } , L _ { 3 } ^ { \prime }$ and approximate the order of the transformation in $\Gamma _ { 2 } ^ { \prime }$ . In order to do this we search for a Hamiltonian $J$ such that $\phi ^ { 1 } = \Phi ^ { ( 2 ) }$ where $\phi ^ { t }$ is the Hamiltonian flow of $J .$ . In this case $\Phi ^ { ( 2 ) }$ is necessarily symplectic. First of all, notice that since $F _ { \mathrm { q u a d } } ^ { 1 2 }$ does not depend on $\gamma _ { 2 }$ , and since the restriction to Λ of $F _ { \mathrm { o c t } } ^ { 1 2 }$ vanishes at first order, the first order term that could contain $\gamma _ { 2 } ^ { \prime }$ is the term of order $\varepsilon ^ { 9 }$ . Since the first order term in the expansion of $F _ { \mathrm { q u a d } } ^ { 1 2 }$ is $\varepsilon ^ { 6 } \left( { \Gamma _ { 2 } } \right) ^ { \prime 2 }$ times a nontrivial constant, we can easily find a Hamiltonian $J _ { 0 }$ of order $\varepsilon ^ { 3 }$ whose time-1 map gives a symplectic coordinate transformation that averages $\gamma _ { 2 } ^ { \prime }$ from the term of order $\varepsilon ^ { 9 }$ , hence (54).

Recall the first order terms containing $\tilde { \Psi } _ { 1 } , \tilde { \psi } _ { 1 }$ , respectively, are $H _ { 1 } ^ { 1 2 } , H _ { 0 } ^ { 2 3 }$ . Moreover the coeficients of $H _ { 1 } ^ { 1 2 } , H _ { 0 } ^ { 2 3 }$ respectively in the expansion of the secular Hamiltonian are $\varepsilon ^ { 7 } \alpha _ { 1 } ^ { \mathrm { 1 2 } } , \varepsilon ^ { 2 } \mu ^ { 6 } \alpha _ { 0 } ^ { 2 3 }$ . Notice that, up to higher-order terms (and a multiplicative constant equal to $L _ { 1 } ^ { 2 }$ in the case of $h _ { 0 } ^ { 1 2 } )$ , the restrictions $H _ { 0 } ^ { 1 2 } , \bar { H } _ { 1 } ^ { 1 2 }$ respectively, are equal to $h _ { 0 } ^ { 1 2 } , h _ { 1 } ^ { \bar { 1 } 2 }$ where

$$
h _ {0} ^ {1 2} = \left(\Gamma_ {2} ^ {\prime}\right) ^ {2}, \quad h _ {1} ^ {1 2} = H _ {1} ^ {1 2} | _ {\Lambda} = \left(3 \frac {\left(\Gamma_ {2} ^ {\prime}\right) ^ {2}}{L _ {1} ^ {2}} - 1\right) \Psi_ {1} ^ {\prime} + 2 \Gamma_ {2} ^ {\prime}.
$$

Moreover the restriction to Λ of $H _ { 0 } ^ { 2 3 }$ is equal to $H _ { 0 } ^ { 2 3 }$ , up to higher order terms. Let $c _ { 0 } = L _ { 1 } ^ { - 2 } \alpha _ { 2 } ^ { 2 3 }$ and define the Hamiltonian $\hat { H } _ { 0 } = \varepsilon ^ { 6 } c _ { 0 } h _ { 0 } ^ { 1 2 } + \varepsilon ^ { 7 } \alpha _ { 1 } ^ { 1 2 } h _ { 1 } ^ { 1 2 } + \varepsilon ^ { 2 } \mu ^ { 6 } \alpha _ { 0 } ^ { 2 3 } H _ { 0 } ^ { 2 3 }$ , a truncated version of $F _ { \mathrm { s e c } } | _ { \Lambda }$ . We now search for a Hamiltonian $\begin{array} { r } { J _ { 1 } = \varepsilon ^ { - 5 } \mu ^ { 6 } \frac { \alpha _ { 0 } ^ { 2 3 } } { \alpha _ { 1 } ^ { 1 2 } } \hat { J } _ { 1 } } \end{array}$ such that, denoting by $\phi _ { 1 } ^ { t }$ the Hamiltonian flow of $J _ { 1 }$ , the coordinate transformation $\phi _ { 1 } ^ { 1 }$ eliminates $\psi _ { 1 } ^ { \prime }$ from $H _ { 0 } ^ { 2 3 }$ . Assuming $J _ { 1 }$ does not depend on $\gamma _ { 2 } ^ { \prime } ,$ we have

$$
\begin{array}{r l} \hat {H} _ {0} \circ \phi_ {1} ^ {- 1} & = \varepsilon^ {6} c _ {0} h _ {0} ^ {1 2} \circ \phi_ {1} ^ {- 1} + \varepsilon^ {7} \alpha_ {1} ^ {1 2} h _ {1} ^ {1 2} \circ \phi_ {1} ^ {- 1} + \varepsilon^ {2} \mu^ {6} \alpha_ {0} ^ {2 3} H _ {0} ^ {2 3} \circ \phi_ {1} ^ {- 1} \\ & = \varepsilon^ {6} c _ {0} h _ {0} ^ {1 2} + \varepsilon^ {7} \alpha_ {1} ^ {1 2} (h _ {1} ^ {1 2} - \{h _ {1} ^ {1 2}, J _ {1} \}) + \varepsilon^ {2} \mu^ {6} \alpha_ {0} ^ {2 3} H _ {0} ^ {2 3} + \dots \\ & = \varepsilon^ {6} c _ {0} h _ {0} ^ {1 2} + \varepsilon^ {7} \alpha_ {1} ^ {1 2} h _ {1} ^ {1 2} + \varepsilon^ {2} \mu^ {6} \alpha_ {0} ^ {2 3} (H _ {0} ^ {2 3} - \{h _ {1} ^ {1 2}, \hat {J} _ {1} \}) + \dots \end{array}\tag{59}
$$

Integrating (38), we see that

$$
\left\langle H _ {0} ^ {2 3} \right\rangle_ {\psi_ {1} ^ {\prime}} = \frac {1}{2 \pi} \int_ {\mathbb {T}} H _ {0} ^ {2 3} d \psi_ {1} ^ {\prime} = \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) ^ {3} \left[ \frac {1}{2} A _ {0} (\gamma_ {3} ^ {\prime}, v _ {3} ^ {\prime}) + C _ {0} (\gamma_ {3} ^ {\prime}, v _ {3} ^ {\prime}) \right].\tag{60}
$$

We would like $\hat { J } _ { 1 }$ to satisfy

$$
\left\{h _ {1} ^ {1 2}, \hat {J} _ {1} \right\} = H _ {0} ^ {2 3} - \left\langle H _ {0} ^ {2 3} \right\rangle_ {\psi_ {1} ^ {\prime}} = \frac {1}{2} \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) ^ {3} \left[ A _ {0} (\gamma_ {3} ^ {\prime}, v _ {3} ^ {\prime}) \cos 2 \psi_ {1} ^ {\prime} + B _ {0} (\gamma_ {3} ^ {\prime}, v _ {3} ^ {\prime}) \sin 2 \psi_ {1} ^ {\prime} \right].\tag{61}
$$

Choose

$$
\hat {J} _ {1} = \frac {1}{4} \left(3 \frac {\left(\Gamma_ {2} ^ {\prime}\right) ^ {2}}{L _ {1} ^ {2}} - 1\right) ^ {- 1} \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) ^ {3} \left[ A _ {0} (\gamma_ {3} ^ {\prime}, v _ {3} ^ {\prime}) \sin 2 \psi_ {1} ^ {\prime} - B _ {0} (\gamma_ {3} ^ {\prime}, v _ {3} ^ {\prime}) \cos 2 \psi_ {1} ^ {\prime} \right].
$$

Since ${ \hat { J } } _ { 1 }$ does not depend on $\gamma _ { 2 } ^ { \prime }$ , neither does $J _ { 1 }$ , and so (59) is satisfied; moreover, it can easily be checked that this choice of $\hat { J } _ { 1 }$ solves (61). Hamilton’s equations of motion imply that

$$
\hat {\Psi} _ {1} = \Psi_ {1} ^ {\prime} - \frac {\partial J _ {1}}{\partial \psi_ {1} ^ {\prime}} + \dots = \Psi_ {1} ^ {\prime} - \frac {L _ {2} ^ {1 1}}{(L _ {3} ^ {*}) ^ {6}} \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {1} ^ {1 2}} \frac {\partial \hat {J} _ {1}}{\partial \psi_ {1} ^ {\prime}} + \dots
$$

Upon diferentiating $\hat { J } _ { 1 }$ with respect to $\psi _ { 1 } ^ { \prime }$ , we thus obtain (56).

The next step of the proof comprises the construction of a Hamiltonian $J _ { 2 }$ such that the time-1 map of its flow $\phi _ { 2 } ^ { t }$ averages the angle $\ell _ { 3 } ^ { \prime }$ from the secular Hamiltonian at first order by adjusting $L _ { 3 } ^ { \prime } .$ . The first appearance of $L _ { 3 } ^ { \prime }$ in the secular Hamiltonian is the term $\left( L _ { 3 } ^ { * } \right) ^ { - 3 } \alpha _ { \mathrm { K e p } } \tilde { L } _ { 3 }$ where the constant $\alpha _ { \mathrm { K e p } }$ is defined by (31), whereas $\ell _ { 3 } ^ { \prime }$ first appears via $v _ { 3 } ^ { \prime }$ in the term $\varepsilon ^ { 2 } \mu ^ { 6 } \alpha _ { 0 } ^ { 2 \dot { 3 } } \left. H _ { 0 } ^ { 2 3 } \right. _ { \psi _ { 1 } ^ { \prime } }$ , defined by (60). The average of $\left. H _ { 0 } ^ { 2 3 } \right. _ { \psi _ { 1 } ^ { \prime } }$ with respect to $\ell _ { 3 } ^ { \prime }$ is

$$
\begin{array}{l} \left\langle H _ {0} ^ {2 3} \right\rangle_ {\psi_ {1} ^ {\prime}, \ell_ {3} ^ {\prime}} = \frac {1}{2 \pi} \int_ {\mathbb {T}} \left\langle H _ {0} ^ {2 3} \right\rangle_ {\psi_ {1} ^ {\prime}} d \ell_ {3} ^ {\prime} = \frac {\delta_ {2} ^ {3}}{2 \pi} \int_ {\mathbb {T}} \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) \left[ \beta_ {0} \sin^ {2} (v _ {3} ^ {\prime} - \gamma_ {3} ^ {\prime}) + \beta_ {1} \right] d v _ {3} ^ {\prime} + \dots \\ = \delta_ {2} ^ {3} \left(\frac {\beta_ {0}}{2} + \beta_ {1}\right) + \dots \end{array}
$$

where the constants $\beta _ { j }$ are defined by (58), and where we have used the formula

$$
d \ell_ {3} ^ {\prime} = d \ell_ {3} + \dots = (1 + e _ {3} \cos v _ {3}) ^ {- 2} \left(\frac {\Gamma_ {3}}{L _ {3}}\right) ^ {3} d v _ {3} = \delta_ {2} ^ {3} \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) ^ {- 2} d v _ {3} ^ {\prime} + O \left(\frac {1}{L _ {3} ^ {*}}\right),\tag{62}
$$

which comes from Kepler’s second law. Therefore, writing $\begin{array} { r } { J _ { 2 } = \left( L _ { 3 } ^ { * } \right) ^ { 3 } \varepsilon ^ { 2 } \mu ^ { 6 } \frac { \alpha _ { 0 } ^ { 2 3 } } { \alpha _ { \mathrm { K e p } } } \hat { J } _ { 2 } } \end{array}$ , and assuming that $\hat { J } _ { 2 }$ does not depend on $\gamma _ { 2 } ^ { \prime } .$ , by similar reasoning to (59), we search for a function ${ \hat { J } } _ { 2 }$ satisfying

$$
\begin{array}{l} \frac {\partial \hat {J} _ {2}}{\partial \ell_ {3} ^ {\prime}} = \left\{L _ {3} ^ {\prime}, \hat {J} _ {2} \right\} = \left\langle H _ {0} ^ {2 3} \right\rangle_ {\psi_ {1} ^ {\prime}} - \left\langle H _ {0} ^ {2 3} \right\rangle_ {\psi_ {1} ^ {\prime}, \ell_ {3} ^ {\prime}} + \dots \\ = \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) ^ {3} \left[ \beta_ {0} \sin^ {2} (v _ {3} ^ {\prime} - \gamma_ {3} ^ {\prime}) + \beta_ {1} \right] - \delta_ {2} ^ {3} \left(\frac {\beta_ {0}}{2} + \beta_ {1}\right) + \dots \end{array}\tag{63}
$$

We could find $\hat { J } _ { 2 }$ explicitly by integration; however, since we only need to know

$$
\hat {L} _ {3} = L _ {3} ^ {\prime} - \frac {\partial J _ {2}}{\partial \ell_ {3} ^ {\prime}} + \dots = L _ {3} ^ {\prime} - \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {\mathrm{Kep}}} \frac {\partial \hat {J} _ {2}}{\partial \ell_ {3} ^ {\prime}} + \dots
$$

we have already established the approximation (57).

Finally, in order to average $\gamma _ { 3 } ^ { \prime }$ by adjusting $\Gamma _ { 3 } ^ { \prime }$ , we only have to notice that, after averaging the angles $\gamma _ { 2 } ^ { \prime } ,$ $\psi _ { 1 } ^ { \prime } , v _ { 3 } ^ { \prime }$ from $F _ { \mathrm { s e c } } | _ { \Lambda }$ , we have the same Hamiltonian as in [13] after averaging $\gamma _ { 2 } ^ { \prime } , \psi _ { 1 } ^ { \prime }$ from the restriction to $\Lambda$ of what is called the secular Hamiltonian in that paper. Therefore the Hamiltonian designed to average $\gamma _ { 3 } ^ { \prime }$ is of order $\frac { L _ { 2 } ^ { 1 3 } } { ( L _ { 3 } ) ^ { 8 } }$ (see Lemma 24 of [13]). However this does not imply that the first order of the coordinate transformation comes from this term; indeed, the first order of the coordinate transformation could come from the Hamiltonians $J _ { 1 } , \mathrm { o r } \ J _ { 2 } ,$ , as they both depend on $\gamma _ { 3 } ^ { \prime }$ , or from the first term averaging $\gamma _ { 2 } ^ { \prime }$ that depends also on $\gamma _ { 3 } ^ { \prime }$ . The latter is of order $\frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ , because the first term in the Hamiltonian depending on both $\gamma _ { 2 } ^ { \prime }$ and $\gamma _ { 3 } ^ { \prime }$ is $H _ { 1 } ^ { 2 3 }$ which is of order $\frac { L _ { 2 } ^ { 3 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ , and which we then average using the term of order $\textstyle { \frac { 1 } { L _ { 2 } ^ { 6 } } }$ . Now, comparing the orders of these two terms (i.e. $\frac { L _ { 2 } ^ { 1 3 } } { ( L _ { 3 } ) ^ { 8 } }$ and $\frac { L _ { 2 } ^ { 9 } } { ( L _ { 3 } ^ { * } ) ^ { 6 } } )$ with the orders $\frac { L _ { 2 } ^ { 1 1 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ and $\frac { L _ { 2 } ^ { 4 } } { \left( L _ { 3 } ^ { * } \right) ^ { 3 } }$ of $J _ { 1 }$ and $J _ { 2 }$ respectively, and using the assumption (14), we see in fact that the first order of the coordinate transformation in the variable $\Gamma _ { 3 } ^ { \prime }$ comes from $J _ { 2 }$ . Therefore

$$
\hat {\Gamma} _ {3} = \Gamma_ {3} ^ {\prime} - \frac {\partial J _ {2}}{\partial \gamma_ {3} ^ {\prime}} + \dots = \Gamma_ {3} ^ {\prime} - \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {\mathrm{Kep}}} \frac {\partial \hat {J} _ {2}}{\partial \gamma_ {3} ^ {\prime}} + \dots
$$

and we have

$$
\begin{array}{r l}&{\frac {\partial \hat {J _ {2}}}{\partial \gamma_ {3} ^ {\prime}} = \frac {\partial}{\partial \gamma_ {3} ^ {\prime}} \int \left(\left<   H _ {0} ^ {2 3} \right> _ {\psi_ {1} ^ {\prime}} - \left<   H _ {0} ^ {2 3} \right> _ {\psi_ {1} ^ {\prime}, \ell_ {3} ^ {\prime}}\right) d \ell_ {3} ^ {\prime} = - \beta_ {0} \int \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) ^ {3} \sin (2 (v _ {3} ^ {\prime} - g _ {3} ^ {\prime})) d \ell_ {3} ^ {\prime} + \dots}\\&{\quad = - \beta_ {0} \delta_ {2} ^ {3} \int \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3} ^ {\prime}\right) \sin (2 (v _ {3} ^ {\prime} - g _ {3} ^ {\prime})) d v _ {3} ^ {\prime} + \dots}\\&{\quad = \frac {\beta_ {0} \delta_ {2} ^ {3}}{6} \left[ \sqrt {1 - \delta_ {2} ^ {2}} (\cos (3 v _ {3} ^ {\prime} - 2 \gamma_ {3} ^ {\prime}) + 3 \cos (v _ {3} ^ {\prime} - 2 \gamma_ {3} ^ {\prime})) + 3 \cos (2 v _ {3} ^ {\prime} - 2 \gamma_ {3} ^ {\prime}) \right] + \dots}\end{array}
$$

where we have used (62) and (63), from which we obtain (55).

## 6 Computation of the scattering map

Now that we have analysed the inner dynamics on the normally hyperbolic invariant cylinder Λ, we must analyse its invariant manifolds, their transverse intersections and the corresponding dynamics. The next theorem, which describes the so-called outer dynamics associated to Λ and its invariant manifolds, is the main result of this section.

Theorem 19. The stable and unstable invariant manifolds of the normally hyperbolic invariant manifold Λ intersect transversely along two homoclinic channels, giving rise to two scattering maps $S _ { \pm } : \Lambda \to \Lambda ^ { \prime }$ such that

$$
S _ {\pm}: \left(\hat {\gamma} _ {2}, \hat {\Gamma} _ {2}, \hat {\gamma} _ {3}, \hat {\Gamma} _ {3}, \hat {\psi} _ {1}, \hat {\Psi} _ {1}, \hat {\ell} _ {3}, \hat {L} _ {3}\right) \longmapsto \left(\hat {\gamma} _ {2} ^ {*}, \hat {\Gamma} _ {2} ^ {*}, \hat {\gamma} _ {3} ^ {*}, \hat {\Gamma} _ {3} ^ {*}, \hat {\psi} _ {1} ^ {*}, \hat {\Psi} _ {1} ^ {*}, \hat {\ell} _ {3} ^ {*}, \hat {L} _ {3} ^ {*}\right)
$$

with

$$
\left\{ \begin{array}{l l} \hat {\Psi} _ {1} ^ {*} = & \hat {\Psi} _ {1} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \mathcal {S} _ {1} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) + \dots \\ \hat {\Gamma} _ {3} ^ {*} = & \hat {\Gamma} _ {3} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \mathcal {S} _ {2} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) + \dots \\ \hat {L} _ {3} ^ {*} = & \hat {L} _ {3} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \mathcal {S} _ {3} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) + \dots \end{array} \right.
$$

where

$$
\begin{array}{l} \mathcal {S} _ {1} ^ {\pm} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}) = \mp \alpha_ {1} ^ {2 3} (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \hat {v} _ {3}) ^ {3} \kappa \left(\frac {\pi \hat {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) \frac {\partial B _ {1}}{\partial \hat {\psi} _ {1}} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}) + \frac {\alpha_ {0} ^ {2 3} \alpha_ {2} ^ {1 2}}{\alpha_ {1} ^ {1 2}} \frac {L _ {1}}{6} \sqrt {\frac {3}{2}} \hat {\Gamma} _ {2} \\ \times \sqrt {1 - \frac {5}{3} \frac {\hat {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}} \frac {(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \hat {v} _ {3}) ^ {3}}{(3 \frac {\hat {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}} - 1)} [ A _ {0} (\hat {\gamma} _ {3}, \hat {\ell} _ {3}) \sin 2 \hat {\psi} _ {1} - B _ {0} (\hat {\gamma} _ {3}, \hat {\ell} _ {3}) \cos 2 \hat {\psi} _ {1} ] \\ \mathcal {S} _ {2} ^ {\pm} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}) = \mp \alpha_ {1} ^ {2 3} (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \hat {v} _ {3}) ^ {3} \kappa \left(\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) \frac {\partial B _ {1}}{\partial \hat {\gamma} _ {3}} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}) \\ \mathcal {S} _ {3} ^ {\pm} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}) = \mp \alpha_ {1} ^ {2 3} \delta_ {2} ^ {- 3} (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \hat {v} _ {3}) ^ {4} \kappa \left(\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) [ - 3 \sqrt {1 - \delta_ {2} ^ {2}} \sin \hat {v} _ {3} \\ \times B _ {1} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}) + (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \hat {v} _ {3}) \frac {\partial B _ {1}}{\partial \hat {v} _ {3}} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}) ] \end{array}\tag{64}
$$

(65)

(66)

where the function κ is defined $b y$

$$
\kappa (x) = \sqrt {\frac {2}{3}} \frac {L _ {1} ^ {2}}{\chi} \left[ 1 - \frac {x}{\sinh x} \right]\tag{67}
$$

and the trigonometric polynomials $A _ { 0 } , B _ { 0 } , B _ { 1 }$ were introduced in Lemma 12.

In Section 4 we established the existence of two hyperbolic periodic orbits $Z _ { \mathrm { m i n } } ^ { 0 } , Z _ { \mathrm { m a x } } ^ { 0 }$ for the Hamiltonian $H _ { 0 } ^ { 1 2 }$ (see (45)); moreover we found that the stable and unstable manifolds of these saddles coincide along a heteroclinic trajectory $Z ^ { 0 }$ introduced in Lemma 14. Furthermore, in the Poincar´e variables $\xi , \eta$ (see (46)), the two saddles are reduced to a single hyperbolic periodic orbit, which we denote by $Z _ { * } ^ { 0 }$ , and the heteroclinic connection becomes a homoclinic connection to $Z _ { * } ^ { 0 }$ ; for convenience we denote by $Z ^ { 0 }$ this homoclinic connection. Recall in Section 4 we considered the phase space of $H _ { 0 } ^ { 1 2 }$ to be of dimension 4, as the Hamiltonian $H _ { 0 } ^ { 1 2 }$ depends only on the variables $\gamma _ { 1 } , \Gamma _ { 1 } , \tilde { \Gamma } _ { 2 }$ (or equivalently on $\xi , \eta , \tilde { \Gamma } _ { 2 } )$ . However we can lift the dynamics to the full secular phase space in the obvious natural way, by setting all remaining secular variables $( \mathrm { i . e . } \tilde { \psi } _ { 1 } , \tilde { \Psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \Gamma } _ { 3 } , \tilde { \ell } _ { 3 } , \tilde { L } _ { 3 } )$ to be constant with respect to $H _ { 0 } ^ { 1 2 }$ . Considering $Z _ { * } ^ { 0 } , \ Z ^ { 0 }$ as functions of all variables in this way, we obtain a parametrisation of the normally hyperbolic invariant manifold $\tilde { \Lambda } _ { 0 }$ defined at the beginning of Section 5, and a parametrisation of the separatrix as in Lemma 14.

Write $\tilde { F } _ { \mathrm { q u a d } } ^ { 1 2 } \stackrel { } { = } L _ { 2 } ^ { 6 } { F } _ { \mathrm { q u a d } } ^ { \bar { 1 } 2 }$ . Then, the integrable Hamiltonian $\tilde { F } _ { \mathrm { q u a d } } ^ { 1 2 }$ possesses a hyperbolic periodic orbit $Z _ { * } ^ { \mathrm { q u a d } }$ that is $O ( L _ { 2 } ^ { - 1 } )$ close to $Z _ { * } ^ { 0 }$ ; moreover there is a homoclinic orbit Z<sup>quad</sup> to $Z _ { * } ^ { \mathrm { q u a d } }$ that is $O ( L _ { 2 } ^ { - 1 } )$ close to $Z ^ { 0 }$ . Since $\tilde { F } _ { \mathrm { q u a d } } ^ { 1 2 }$ is integrable (see Lemma 10), the homoclinic trajectory $Z ^ { \mathrm { q u a d } }$ corresponds to a non-transverse homoclinic intersection of the stable and unstable manifolds of $Z _ { * } ^ { \mathrm { q u a d } }$

Denote by $\bar { H } = L _ { 2 } ^ { 6 } F _ { \mathrm { s e c } } - \tilde { F } _ { \mathrm { q u a d } } ^ { 1 2 }$ the Hamiltonian of the perturbation, and define the Poincar´e-Melnikov potential by

$$
\begin{array}{r} \mathcal {L} \left(\tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) = \int_ {- \infty} ^ {\infty} \left[ \bar {H} \left(Z ^ {\mathrm{quad}} \left(t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right)\right) - \bar {H} \left(Z _ {*} ^ {\mathrm{quad}} \left(t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right)\right) \right] d t. \end{array}\tag{68}
$$

As with $\bar { H }$ itself, the Poincar´e-Melnikov potential can be expanded in ratios of powers of $L _ { 2 }$ and $L _ { 3 } ^ { * } .$ . The following result gives an expression for the first-order term at which each angle $\tilde { \gamma _ { 2 } } , \tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 }$ appears in the expansion of ${ \mathcal { L } } .$

Proposition 20. The expansion of the Poincar´e-Melnikov potential $\mathcal { L }$ satisfies the following properties, where the notation $\alpha _ { k } ^ { i j } , H _ { k } ^ { i j }$ is as in Proposition 7.

1. The first nontrivial term in the expansion of  is $\textstyle \frac { 1 } { L _ { 2 } ^ { 2 } } \alpha _ { 2 } ^ { 1 2 } \mathcal { L } _ { 2 } ^ { 1 2 }$ where

$$
\begin{array}{l} \mathcal {L} _ {2} ^ {1 2} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}\right) = \int_ {- \infty} ^ {\infty} \Big (H _ {2} ^ {1 2} \Big (Z ^ {0} \left(t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right) \Big) \\ \qquad - H _ {2} ^ {1 2} \left(Z _ {*} ^ {0} \left(t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right)\right) d t \\ = \tilde {\mathcal {L}} _ {2} ^ {1 2} \left(\tilde {\Gamma} _ {2}\right) \sin \tilde {\gamma} _ {2} \end{array}
$$

and where $\tilde { \mathcal { L } } _ { 2 } ^ { 1 2 }$ is an analytic function of $\tilde { \Gamma } _ { 2 }$ that is nonvanishing for $\tilde { \Gamma } _ { 2 } \in [ \zeta _ { 1 } , \zeta _ { 2 } ]$

2. The angles $\tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 }$ all appear for the first time in the expansion of  in the term $\begin{array} { r l r } {  { } } & { { } } & { \frac { L _ { 2 } ^ { 9 } } { ( L _ { 3 } ^ { * } ) ^ { 6 } } \alpha _ { 1 } ^ { 2 3 } \mathcal L _ { 1 } ^ { 2 3 } } \end{array}$ where

$$
\begin{array}{r l} & {\mathcal {L} _ {1} ^ {2 3} \left(\tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}\right) = \int_ {- \infty} ^ {\infty} \left(H _ {1} ^ {2 3} \left(Z ^ {0} (t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3})\right) \right.} \\ & {\qquad \left. - H _ {1} ^ {2 3} \left(Z _ {*} ^ {0} (t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3})\right)\right) d t} \\ & {\qquad = \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}\right) ^ {3} \kappa \left(\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right)} \\ & {\qquad \times \left[ A _ {1} (\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}) \cos \tilde {\gamma} _ {2} + B _ {1} (\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}) \sin \tilde {\gamma} _ {2} \right]} \end{array}
$$

where the function κ is defined by (67).

Proof. Part 1 of the proposition was proved in [27] (see also Proposition 27 and Appendix F of [13]). As for part 2, observe that, since $\tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 }$ are constant with respect to $H _ { 0 } ^ { 1 2 }$ , we can write

$$
\mathcal {L} _ {1} ^ {2 3} \left(\tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}\right) = \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}\right) ^ {3} \left[ A _ {1} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}\right) \mathcal {L} _ {1} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}\right) + B _ {1} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, v _ {3}\right) \mathcal {L} _ {2} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}\right) \right]\tag{69}
$$

where

$$
\mathcal {L} _ {j} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}\right) = \int_ {0} ^ {\infty} \left(\mathcal {F} _ {j} \circ Z ^ {0} \left(t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right) - \mathcal {F} _ {j} \circ Z _ {\min} ^ {0} \left(t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right)\right) d t +
$$

$$
+ \int_ {- \infty} ^ {0} \left(\mathcal {F} _ {j} \circ Z ^ {0} (t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}) - \mathcal {F} _ {j} \circ Z _ {\max} ^ {0} (t, \tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3})\right) d t,
$$

and where the functions

$$
\mathcal {F} _ {1} = \sqrt {\Gamma_ {1} ^ {2} - \tilde {\Gamma} _ {2} ^ {2}} \cos \tilde {\gamma} _ {2}, \quad \mathcal {F} _ {2} = \sqrt {\Gamma_ {1} ^ {2} - \tilde {\Gamma} _ {2} ^ {2}} \sin \tilde {\gamma} _ {2}
$$

do not depend on $\tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 }$ . It was shown in Section 6.2 of [13] that we have

$$
\mathcal {L} _ {1} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}\right) = \kappa \left(\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) \cos \tilde {\gamma} _ {2}, \quad \mathcal {L} _ {2} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}\right) = \kappa \left(\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) \sin \tilde {\gamma} _ {2}
$$

where κ is the function defined by (67). Combining these formulas with (69) completes the proof of the proposition. □

Lemma 21. The secular Hamiltonian has two homoclinic channels corresponding to the normally hyperbolic invariant manifold Λ, and there are two scattering maps defined globally on Λ by

$$
\tilde {S} _ {\pm}: \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) \longmapsto \left(\tilde {\gamma} _ {2} ^ {*}, \tilde {\Gamma} _ {2} ^ {*}, \tilde {\gamma} _ {3} ^ {*}, \tilde {\Gamma} _ {3} ^ {*}, \tilde {\psi} _ {1} ^ {*}, \tilde {\Psi} _ {1} ^ {*}, \tilde {\ell} _ {3} ^ {*}, \tilde {L} _ {3} ^ {*}\right)
$$

with

$$
\tilde {\gamma} _ {2} ^ {*} = \tilde {\gamma} _ {2} + \Delta_ {0} ^ {\pm} (\tilde {\Gamma} _ {2}; \dots), \quad \tilde {\psi} _ {1} ^ {*} = \tilde {\psi} _ {1} + \frac {1}{L _ {2} ^ {2}} \Delta_ {1} ^ {\pm} (\tilde {\Gamma} _ {2}; \dots),
$$

$$
\tilde {\gamma} _ {3} ^ {*} = \tilde {\gamma} _ {3} + \frac {L _ {2} ^ {8}}{(L _ {3} ^ {*}) ^ {6}} \Delta_ {2} ^ {\pm} (\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}), \quad \tilde {\ell} _ {3} ^ {*} = \tilde {\ell} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {7}} \Delta_ {3} ^ {\pm} (\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}),
$$

$$
\tilde {\Gamma} _ {2} ^ {*} = \tilde {\Gamma} _ {2} + \frac {1}{L _ {2} ^ {3}} \Theta_ {0} ^ {\pm} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right), \quad \tilde {\Psi} _ {1} ^ {*} = \tilde {\Psi} _ {1} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \Theta_ {1} ^ {\pm} \left(\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots\right),
$$

$$
\tilde {\Gamma} _ {3} ^ {*} = \tilde {\Gamma} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \Theta_ {2} ^ {\pm} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots), \quad \tilde {L} _ {3} ^ {*} = \tilde {L} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \Theta_ {3} ^ {\pm} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots)
$$

where the ellipsis after the semicolon denotes dependence on the remaining variables at higher order, and where

$$
\Delta_ {0} ^ {\pm} \left(\tilde {\Gamma} _ {2}; \dots\right) = 2 \arctan \chi^ {- 1} + \dots , \quad \Delta_ {1} ^ {\pm} \left(\tilde {\Gamma} _ {2}; \dots\right) = \frac {L _ {1}}{6} \sqrt {\frac {3}{2}} \alpha_ {2} ^ {1 2} \tilde {\Gamma} _ {2} \sqrt {1 - \frac {5}{3} \frac {\tilde {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}} + \dots
$$

$$
\Delta_ {2} ^ {\pm} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) = O (1), \quad \Delta_ {3} ^ {\pm} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) = O (1)
$$

and

$$
\Theta_ {0} ^ {\pm} \left(\tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) = O (1),
$$

$$
\Theta_ {1} ^ {\pm} \left(\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots\right) = \mp \alpha_ {1} ^ {2 3} \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}\right) ^ {3} \kappa \left(\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) \frac {\partial B _ {1}}{\partial \tilde {\psi} _ {1}} \left(\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}\right) + \dots
$$

$$
\Theta_ {2} ^ {\pm} \left(\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots\right) = \mp \alpha_ {1} ^ {2 3} \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}\right) ^ {3} \kappa \left(\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) \frac {\partial B _ {1}}{\partial \tilde {\gamma} _ {3}} \left(\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}\right) + \dots ,
$$

$$
\begin{array}{r} \Theta_ {3} ^ {\pm} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots) = \mp \alpha_ {1} ^ {2 3} \delta_ {2} ^ {- 3} (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}) ^ {4} \kappa (\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}) [ - 3 \sqrt {1 - \delta_ {2} ^ {2}} \sin v _ {3} \\ \times B _ {1} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}) + (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}) \frac {\partial B _ {1}}{\partial v _ {3}} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}) ] + \dots \end{array}
$$

Proof. Denote by $( \omega _ { 0 } , \omega _ { 1 } , \omega _ { 2 } , \omega _ { 3 } )$ the frequency vector of the angles $\left( \tilde { \gamma } _ { 2 } , \tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 } \right)$ on a torus on Λ corresponding to fixed values of the actions $\tilde { \Gamma } _ { 2 } , \tilde { \Psi } _ { 1 } , \tilde { \Gamma } _ { 3 } , \tilde { L } _ { 3 }$ for the Hamiltonian $\tilde { F } = L _ { 2 } ^ { 6 } \left( F _ { \mathrm { q u a d } } ^ { 1 2 } + F _ { \mathrm { K e p } } - \tilde { F } _ { \mathrm { K e p } } \right)$ The computations of Section 3 therefore imply that

$$
\omega_ {0} = 2 \alpha_ {0} ^ {1 2} \frac {\tilde {\Gamma} _ {2}}{L _ {1} ^ {2}} + O \left(\frac {1}{L _ {2}}\right), \quad \omega_ {1} = O \left(\frac {1}{L _ {2}}\right), \quad \omega_ {2} = 0, \quad \omega_ {3} = \frac {L _ {2} ^ {6}}{\left(L _ {3} ^ {*}\right) ^ {3}} \alpha_ {\mathrm{Kep}} + O \left(\frac {L _ {2} ^ {6}}{\left(L _ {3} ^ {*}\right) ^ {4}}\right).
$$

Consider the function

$$
\tau \longmapsto \mathcal {L} \left(\tilde {\gamma} _ {2} - \omega_ {0} \tau , \tilde {\psi} _ {1} - \omega_ {1} \tau , \tilde {\gamma} _ {3} - \omega_ {2} \tau , \tilde {\ell} _ {3} - \omega_ {3} \tau , \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right)\tag{70}
$$

where  is the Poincar´e-Melnikov potential defined by (68). Results of [18] imply that nondegenerate critical points of (70) correspond to transverse homoclinic intersections of the stable and unstable manifolds of Λ. Equation (68), Proposition 7, and Proposition 20 imply that

$$
\mathcal {L} = \frac {1}{L _ {2} ^ {2}} \alpha_ {2} ^ {1 2} \mathcal {L} _ {2} ^ {1 2} + \dots
$$

The function $\tau \mapsto \mathcal { L } _ { 2 } ^ { 1 2 } \left( \tilde { \gamma } _ { 2 } - \omega _ { 0 } \tau , \tilde { \Gamma } _ { 2 } \right)$ has nondegenerate critical points $\tau _ { \pm }$ where $\begin{array} { r } { \omega _ { 0 } \tau _ { \pm } = \tilde { \gamma } _ { 2 } \pm \frac { \pi } { 2 } } \end{array}$ . It follows that there are functions

$$
\tau_ {\pm} ^ {*} \left(\tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right) = \frac {1}{\omega_ {0}} \left(\tilde {\gamma} _ {2} \pm \frac {\pi}{2}\right) + \dots
$$

such that

$$
\left. \frac {d}{d \tau} \right| _ {\tau = \tau_ {\pm} ^ {*}} \mathcal {L} \left(\tilde {\gamma} _ {2} - \omega_ {0} \tau , \tilde {\psi} _ {1} - \omega_ {1} \tau , \tilde {\gamma} _ {3} - \omega_ {2} \tau , \tilde {\ell} _ {3} - \omega_ {3} \tau , \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right) = 0.
$$

We now introduce the reduced Poincar´e-Melnikov potentials

$$
\mathcal {L} _ {\pm} ^ {*} \left(\tilde {\gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right) = \mathcal {L} \left(\tilde {\gamma} _ {2} - \omega_ {0} \tau_ {\pm} ^ {*}, \tilde {\psi} _ {1} - \omega_ {1} \tau_ {\pm} ^ {*}, \tilde {\gamma} _ {3} - \omega_ {2} \tau_ {\pm} ^ {*}, \tilde {\ell} _ {3} - \omega_ {3} \tau_ {\pm} ^ {*}, \tilde {\Gamma} _ {2}, \tilde {\Psi} _ {1}, \tilde {\Gamma} _ {3}, \tilde {L} _ {3}\right).
$$

Now, following again [18], the changes in the actions coming from the scattering maps $\tilde { S } _ { \pm }$ are defined using the functions $\mathcal { L } _ { \pm } ^ { * }$ via

$$
\tilde {\Gamma} _ {2} ^ {*} = \tilde {\Gamma} _ {2} + \frac {\partial \mathcal {L} _ {\pm} ^ {*}}{\partial \tilde {\gamma} _ {2}} + \dots , \quad \tilde {\Psi} _ {1} ^ {*} = \tilde {\Psi} _ {1} + \frac {\partial \mathcal {L} _ {\pm} ^ {*}}{\partial \tilde {\psi} _ {1}} + \dots , \quad \tilde {\Gamma} _ {3} ^ {*} = \tilde {\Gamma} _ {3} + \frac {\partial \mathcal {L} _ {\pm} ^ {*}}{\partial \tilde {\gamma} _ {3}} + \dots , \quad \tilde {L} _ {3} ^ {*} = \tilde {L} _ {3} + \frac {\partial \mathcal {L} _ {\pm} ^ {*}}{\partial \tilde {\ell} _ {3}} + \dots
$$

Note that the cylinder frequencies in the model in [18] all have the same time scale and moreover the first order of the perturbation depends on all the angles. On the contrary, in our model there are multiple time scales and the angles $\tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 }$ , and $\tilde { \ell } _ { 3 }$ appear only at higher order terms (see Proposition 7). Still, one can easily check that the statements in [18] are still valid in the present setting. The only diference is that the first order of the scattering maps in the actions $\tilde { \Psi } _ { 1 } , \tilde { \Gamma } _ { 3 } , \tilde { L } _ { 3 }$ come from higher orders of the Melnikov potential.

By part 2 of Proposition 20, the first term in the expansion of the Poincar´e-Melnikov potential depending on any of the angles $\tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 }$ is $\begin{array} { r l r } {  { } } & { { } } & { \frac { L _ { 2 } ^ { 9 } } { ( L _ { 3 } ^ { * } ) ^ { 6 } } \alpha _ { 1 } ^ { 2 3 } \mathcal L _ { 1 } ^ { 2 3 } } \end{array}$ , and in fact all three of those angles appear in this term. It follows that the first term in the expansion of the reduced Poincar´e-Melnikov potentials depending on the angles $\begin{array} { r } { \tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 } \mathrm { ~ i s ~ } \frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } } \alpha _ { 1 } ^ { 2 3 } \left( \mathcal { L } _ { 1 } ^ { 2 3 } \right) _ { \pm } ^ { * } } \end{array}$ where

$$
\begin{array}{l} \left(\mathcal {L} _ {1} ^ {2 3}\right) _ {\pm} ^ {*} = \mathcal {L} _ {1} ^ {2 3} \left(\tilde {\gamma} _ {2} - \omega_ {0} \tau_ {\pm} ^ {*}, \tilde {\psi} _ {1} - \omega_ {1} \tau_ {\pm} ^ {*}, \tilde {\gamma} _ {3} - \omega_ {2} \tau_ {\pm} ^ {*}, \tilde {\ell} _ {3} - \omega_ {3} \tau_ {\pm} ^ {*}, \tilde {\Gamma} _ {2}\right) \\ = \mathcal {L} _ {1} ^ {2 3} \left(- \frac {\pi}{2}, \tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}\right) + \dots \\ = \mp \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}\right) ^ {3} \kappa \left(\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) B _ {1} \left(\tilde {\gamma} _ {3}, \tilde {\psi} _ {1}, \tilde {\ell} _ {3}\right) + \dots \end{array}
$$

It follows that

$$
\begin{array}{l} \frac {\partial \mathcal {L} _ {\pm} ^ {*}}{\partial \tilde {\psi} _ {1}} = \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \alpha_ {1} ^ {2 3} \frac {\partial (\mathcal {L} _ {1} ^ {2 3}) _ {\pm} ^ {*}}{\partial \tilde {\psi} _ {1}} + \dots = \mp \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \alpha_ {1} ^ {2 3} (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}) ^ {3} \kappa (\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}) \frac {\partial B _ {1}}{\partial \tilde {\psi} _ {1}} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}) + \dots , \\ \frac {\partial \mathcal {L} _ {\pm} ^ {*}}{\partial \tilde {\gamma} _ {3}} = \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \alpha_ {1} ^ {2 3} \frac {\partial (\mathcal {L} _ {1} ^ {2 3}) _ {\pm} ^ {*}}{\partial \tilde {\gamma} _ {3}} + \dots = \mp \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \alpha_ {1} ^ {2 3} (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}) ^ {3} \kappa (\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {2} ^ {2}}) \frac {\partial B _ {1}}{\partial \tilde {\gamma} _ {3}} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}) + \dots , \end{array}
$$

and

$$
\begin{array}{r l} & {\frac {\partial \mathcal {L} _ {\pm} ^ {*}}{\partial \tilde {\ell} _ {3}} = \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \alpha_ {1} ^ {2 3} \frac {\partial (\mathcal {L} _ {1} ^ {2 3}) _ {\pm} ^ {*}}{\partial \tilde {\ell} _ {3}} + \dots = \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \alpha_ {1} ^ {2 3} \frac {\partial (\mathcal {L} _ {1} ^ {2 3}) _ {\pm} ^ {*}}{\partial v _ {3}} \frac {\partial v _ {3}}{\partial \tilde {\ell} _ {3}} + \dots} \\ & {\quad = \mp \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \alpha_ {1} ^ {2 3} \delta_ {2} ^ {- 3} (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}) ^ {4} \kappa (\frac {\pi \tilde {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}})} \\ & {\qquad \times [ - 3 \sqrt {1 - \delta_ {2} ^ {2}} \sin v _ {3} B _ {1} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}) + (1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos v _ {3}) \frac {\partial B _ {1}}{\partial v _ {3}} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}) ] + \dots .} \end{array}
$$

where we have used (62).

For the angles $\tilde { \gamma } _ { 2 } , \tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 } .$ , the first-order term under application of the scattering map is a so-called phase shift. This is a change in the angle that comes from the integrable part of the Hamiltonian along the separatrix, and does not necessarily depend on the functions $\mathcal { L } _ { \pm } ^ { * }$ at first order. The phase shifts in the angles $\tilde { \gamma } _ { 2 } , \tilde { \psi } _ { 1 }$ come from $F _ { \mathrm { q u a d } } ^ { 1 2 } { \mathrm { . } }$ , and are therefore the same as in [13] (see Lemma 30 and Appendix D). For the angles $\tilde { \gamma } _ { 3 }$ and ${ \tilde { \ell } } _ { 3 } .$ , we simply estimate the order of the phase shift. Notice that the phase shift comes from the first appearance of the symplectic conjugate action in the Hamiltonian multiplying by functions of $\Gamma _ { 1 } , \gamma _ { 1 } , \tilde { \gamma } _ { 2 }$ , as these are the variables that behave diferently on the separatrix and on Λ. Since ${ \tilde { \Gamma } } _ { 3 }$ first appears in the secular Hamiltonian in the term of order $\frac { L _ { 2 } ^ { 3 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ , and since this term does not provide a phase shift in ${ \tilde { \gamma } } _ { 3 } .$ , the highest-order term that can potentially produce a phase shift has an additional factor of $\frac { 1 } { L _ { 2 } }$ . Since we normalise the entire secular Hamiltonian by $L _ { 2 } ^ { 6 }$ , we see that the phase shift in $\tilde { \gamma } _ { 3 }$ is of order $\begin{array} { r } { { \cal O } \left( \frac { L _ { 2 } ^ { 3 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } } \frac { 1 } { L _ { 2 } } L _ { 2 } ^ { 6 } \right) = { \cal O } \left( \frac { L _ { 2 } ^ { 8 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } } \right) } \end{array}$ . As for ${ \tilde { \ell } } _ { 3 } .$ , the phase shift comes from $H _ { 1 } ^ { 2 3 }$ upon expanding its coeficient

$$
\frac {L _ {2} ^ {3}}{L _ {3} ^ {6}} = \frac {L _ {2} ^ {3}}{\left(L _ {3} ^ {*} + \tilde {L} _ {3}\right) ^ {6}} = \frac {L _ {2} ^ {3}}{\left(L _ {3} ^ {*}\right) ^ {6}} - 6 \frac {L _ {2} ^ {3}}{\left(L _ {3} ^ {*}\right) ^ {7}} \tilde {L} _ {3} + \dots
$$

in powers of $\frac { 1 } { \tilde { L } _ { 3 } }$ . Upon scaling this by $L _ { 2 } ^ { 6 }$ , we see that the first term that can provide a phase shift is of order $\begin{array} { r } { O \left( \frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 7 } } \right) } \end{array}$ , as required. □

Lemma 22. In the ‘hat’ coordinates, the scattering maps $S _ { \pm } : \Lambda \to \Lambda ^ { \prime }$ , introduced in Lemma ${ \mathit { 2 1 } } ,$ are given by

$$
S _ {\pm}: \left(\hat {\gamma} _ {2}, \hat {\Gamma} _ {2}, \hat {\gamma} _ {3}, \hat {\Gamma} _ {3}, \hat {\psi} _ {1}, \hat {\Psi} _ {1}, \hat {\ell} _ {3}, \hat {L} _ {3}\right) \longmapsto \left(\hat {\gamma} _ {2} ^ {*}, \hat {\Gamma} _ {2} ^ {*}, \hat {\gamma} _ {3} ^ {*}, \hat {\Gamma} _ {3} ^ {*}, \hat {\psi} _ {1} ^ {*}, \hat {\Psi} _ {1} ^ {*}, \hat {\ell} _ {3} ^ {*}, \hat {L} _ {3} ^ {*}\right)
$$

with

$$
\left\{ \begin{array}{l l} \hat {\Psi} _ {1} ^ {*} = & \hat {\Psi} _ {1} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \mathcal {S} _ {1} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) + \dots \\ \hat {\Gamma} _ {3} ^ {*} = & \hat {\Gamma} _ {3} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \mathcal {S} _ {2} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) + \dots \\ \hat {L} _ {3} ^ {*} = & \hat {L} _ {3} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \mathcal {S} _ {3} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) + \dots \end{array} \right.
$$

where $S _ { j } ^ { \pm }$ are given by (64), (65), and (66) respectively.

Proof. Recall we denote by Φ the coordinate transformation on Λ from ‘tilde’ coordinates to ‘hat’ coordinates constructed in Theorem 15. Moreover, by Lemma 18, we can write

$$
\hat {\Psi} _ {1} = \tilde {\Psi} _ {1} + \frac {L _ {2} ^ {1 1}}{(L _ {3} ^ {*}) ^ {6}} \Phi_ {1} \left(\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots\right), \quad \hat {\Gamma} _ {3} = \tilde {\Gamma} _ {3} + \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \Phi_ {2} \left(\tilde {\gamma} _ {3}, \tilde {\ell} _ {3}; \dots\right) \quad \hat {L} _ {3} = \tilde {L} _ {3} + \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \Phi_ {3} \left(\tilde {\gamma} _ {3}, \tilde {\ell} _ {3}; \dots\right)
$$

with

$$
\begin{array}{r} \Phi_ {1} \left(\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots\right) = - \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {1} ^ {1 2}} \frac {\left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \tilde {v} _ {3}\right) ^ {3}}{2 \left(3 \frac {\left(\tilde {\Gamma} _ {2}\right) ^ {2}}{L _ {1} ^ {2}} - 1\right)} \left[ A _ {0} (\tilde {\gamma} _ {3}, \tilde {v} _ {3}) \cos 2 \tilde {\psi} _ {1} + B _ {0} (\tilde {\gamma} _ {3}, \tilde {v} _ {3}) \sin 2 \tilde {\psi} _ {1} \right] + \dots \\ \Phi_ {2} \left(\tilde {\gamma} _ {3}, \tilde {\ell} _ {3}; \dots\right) = - \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {\mathrm{Kep}}} \frac {\beta_ {0} \delta_ {2} ^ {3}}{6} \left[ \sqrt {1 - \delta_ {2} ^ {2}} (\cos (3 \tilde {v} _ {3} - 2 \tilde {\gamma} _ {3}) + 3 \cos (\tilde {v} _ {3} - 2 \tilde {\gamma} _ {3})) + 3 \cos (2 \tilde {v} _ {3} - 2 \tilde {\gamma} _ {3}) \right] + \dots \end{array}
$$

$$
\Phi_ {3} \left(\tilde {\gamma} _ {3}, \tilde {\ell} _ {3}; \dots\right) = - \frac {\alpha_ {0} ^ {2 3}}{\alpha_ {\mathrm{Kep}}} \left(\left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \tilde {v} _ {3}\right) ^ {3} \left[ \beta_ {0} \sin^ {2} \left(\tilde {v} _ {3} - \tilde {\gamma} _ {3}\right) + \beta_ {1} \right] - \delta_ {2} ^ {3} \left(\frac {\beta_ {0}}{2} + \beta_ {1}\right)\right) + \dots
$$

where the constants $\beta _ { j }$ are defined by (58). Therefore, using the notation of Lemma 21, we have

$$
\begin{array}{l} \hat {\Psi} _ {1} ^ {*} = \tilde {\Psi} _ {1} ^ {*} + \frac {L _ {2} ^ {1 1}}{(L _ {3} ^ {*}) ^ {6}} \Phi_ {1} \left(\tilde {\psi} _ {1} ^ {*}, \tilde {\gamma} _ {3} ^ {*}, \tilde {\ell} _ {3} ^ {*}, \tilde {\Gamma} _ {2} ^ {*}; \dots\right) \\ = \tilde {\Psi} _ {1} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \Theta_ {1} ^ {\pm} \left(\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots\right) \\ \qquad + \frac {L _ {2} ^ {1 1}}{(L _ {3} ^ {*}) ^ {6}} \Phi_ {1} \left(\tilde {\psi} _ {1} + \frac {1}{L _ {2} ^ {2}} \Delta_ {1} ^ {\pm} (\tilde {\Gamma} _ {2}; \dots), \tilde {\gamma} _ {3} + O \left(\frac {L _ {2} ^ {8}}{(L _ {3} ^ {*}) ^ {6}}\right), \tilde {\ell} _ {3} + O \left(\frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {7}}\right), \tilde {\Gamma} _ {2} + O \left(\frac {1}{L _ {2} ^ {3}}\right); \dots\right) \\ = \hat {\Psi} _ {1} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \left[ \Theta_ {1} ^ {\pm} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots) + \partial_ {\tilde {\psi} _ {1}} \Phi_ {1} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots) \Delta_ {1} ^ {\pm} (\tilde {\Gamma} _ {2}; \dots) \right] + \dots \\ = \hat {\Psi} _ {1} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \left[ \Theta_ {1} ^ {\pm} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}; \dots) + \partial_ {\hat {\psi} _ {1}} \Phi_ {1} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}; \dots) \Delta_ {1} ^ {\pm} (\hat {\Gamma} _ {2}; \dots) \right] + \dots , \end{array}\tag{71}
$$

$$
\begin{array}{l} \hat {\Gamma} _ {3} ^ {*} = \tilde {\Gamma} _ {3} ^ {*} + \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \Phi_ {2} (\tilde {\gamma} _ {3} ^ {*}, \tilde {\ell} _ {3} ^ {*}; \dots) \\ \qquad = \tilde {\Gamma} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \Theta_ {2} ^ {\pm} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots) + \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \Phi_ {2} (\tilde {\gamma} _ {3} + O (\frac {L _ {2} ^ {8}}{(L _ {3} ^ {*}) ^ {6}}), \tilde {\ell} _ {3} + O (\frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {7}}); \dots) \\ \qquad = \hat {\Gamma} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \Theta_ {2} ^ {\pm} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}; \dots) + \dots , \end{array}\tag{72}
$$

and

$$
\begin{array}{l} \hat {L} _ {3} ^ {*} = \tilde {L} _ {3} ^ {*} + \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \Phi_ {3} (\tilde {\gamma} _ {3} ^ {*}, \tilde {\ell} _ {3} ^ {*}; \dots) \\ \qquad = \tilde {L} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \Theta_ {3} ^ {\pm} (\tilde {\psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {\Gamma} _ {2}; \dots) + \frac {L _ {2} ^ {4}}{(L _ {3} ^ {*}) ^ {3}} \Phi_ {3} (\tilde {\gamma} _ {3} + O (\frac {L _ {2} ^ {8}}{(L _ {3} ^ {*}) ^ {6}}), \tilde {\ell} _ {3} + O (\frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {7}}); \dots) \\ \qquad = \hat {L} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \Theta_ {3} ^ {\pm} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}; \dots) + \dots \end{array}\tag{73}
$$

Combining (72) and (73) with the formulas given for $\Theta _ { 2 } ^ { \pm }$ and $\Theta _ { 3 } ^ { \pm }$ in Lemma 21 already gives the expressions (65) and (66). From (71), the formula for $\Theta _ { 1 } ^ { \pm }$ given in Lemma 21 and the formula above for $\Phi _ { 1 }$ we find that

$$
\begin{array}{l} \mathcal {S} _ {1} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) = \Theta_ {1} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) + \partial_ {\hat {\psi} _ {1}} \Phi_ {1} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) \Delta_ {1} ^ {\pm} \left(\hat {\Gamma} _ {2}\right) \\ = \mp \alpha_ {1} ^ {2 3} \left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \hat {v} _ {3}\right) ^ {3} \kappa \left(\frac {\pi \hat {\Gamma} _ {2}}{A _ {2} L _ {1} ^ {2}}\right) \frac {\partial B _ {1}}{\partial \hat {\psi} _ {1}} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}\right) + \frac {\alpha_ {0} ^ {2 3} \alpha_ {2} ^ {1 2}}{\alpha_ {1} ^ {1 2}} \frac {L _ {1}}{6} \sqrt {\frac {3}{2}} \hat {\Gamma} _ {2} \\ \times \sqrt {1 - \frac {5}{3} \frac {\hat {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}} \frac {\left(1 + \sqrt {1 - \delta_ {2} ^ {2}} \cos \hat {v} _ {3}\right) ^ {3}}{\left(3 \frac {\left(\hat {\Gamma} _ {2}\right) ^ {2}}{L _ {1} ^ {2}} - 1\right)} \left[ A _ {0} \left(\hat {\gamma} _ {3}, \hat {\ell} _ {3}\right) \sin 2 \hat {\psi} _ {1} - B _ {0} \left(\hat {\gamma} _ {3}, \hat {\ell} _ {3}\right) \cos 2 \hat {\psi} _ {1} \right], \end{array}
$$

which completes the proof of the lemma.

## 7 Shadowing in a Poincar´e Section

In this section we prove Theorem 2 by proving the existence of suitable transition chains of almost invariant tori, and applying the shadowing results of [14] (which are summarised in Appendix C) to obtain orbits of the full four-body problem that visit arbitrarily small neighbourhoods of these tori in the prescribed order.

As the shadowing results of $[ 1 4 ]$ are proved for mappings, we first choose a suitable Poincar´e section, and analyse the corresponding first return map; this is done is Section 7.1. In Section 7.2 we prove that we can find pseudo-orbits (that is orbits of the iterated function system consisting of the Poincar´e map and the scattering maps) that connect (up to small errors) any given sequence of almost invariant tori on the normally hyperbolic cylinder. Finally in Section 7.3 we apply the results of [14] to complete the proof of Theorem 2.

## 7.1 Reduction to a Poincar´e Map

Denote by $\tilde { \mathcal { D } }$ the region of the phase space where the coordinates $\left( \xi , \eta , \tilde { \gamma } _ { 2 } , \tilde { \Gamma } _ { 2 } , \tilde { \psi } _ { 1 } , \tilde { \Psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \Gamma } _ { 3 } , \tilde { \ell } _ { 3 } , \tilde { L } _ { 3 } \right)$ take the following values: $\xi , \eta$ live in the open ball in $\mathbb { R } ^ { 2 }$ centred at the origin of radius ${ \sqrt { 2 L _ { 1 } } } ;$ the angles $\tilde { \gamma } _ { 2 } , \tilde { \psi } _ { 1 } , \tilde { \gamma } _ { 3 } , \tilde { \ell } _ { 3 } \mathrm { ~ \bar { \varphi } ~ } \mathbb { T } ;$ and the actions satisfy $\tilde { \Gamma } _ { 2 } \in [ \zeta _ { 1 } , \zeta _ { 2 } ]$ and $\tilde { \Psi } _ { 1 } , \tilde { \Gamma } _ { 3 } , \tilde { L } _ { 3 } \in [ - 1 , 1 ]$ , where the constants $\zeta _ { 1 } , \zeta _ { 2 }$ were defined in (48). We now make the following further refinement to these constants:

$$
0 <   \zeta_ {1} <   \zeta_ {2} <   \frac {L _ {1}}{\sqrt {3}}.\tag{74}
$$

This refinement guarantees that our inner map satisfies a twist condition; see Lemma 25 below. By slightly shrinking the region $\tilde { \mathcal { D } }$ if necessary, we obtain a region $\mathcal { D }$ in which there is a (not necessarily symplectic) near-identity coordinate transformation

$$
\Upsilon : \left(\xi , \eta , \tilde {\gamma} _ {2}, \tilde {\Gamma} _ {2}, \tilde {\psi} _ {1}, \tilde {\Psi} _ {1}, \tilde {\gamma} _ {3}, \tilde {\Gamma} _ {3}, \tilde {\ell} _ {3}, \tilde {L} _ {3}\right) \longmapsto \left(\xi , \eta , \hat {\gamma} _ {2}, \hat {\Gamma} _ {2}, \hat {\psi} _ {1}, \hat {\Psi} _ {1}, \hat {\gamma} _ {3}, \hat {\Gamma} _ {3}, \hat {\ell} _ {3}, \hat {L} _ {3}\right)
$$

where $\left( \hat { \gamma } _ { 2 } , \hat { \Gamma } _ { 2 } , \hat { \psi } _ { 1 } , \hat { \Psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \Gamma } _ { 3 } , \hat { \ell } _ { 3 } , \hat { L } _ { 3 } \right)$ are the coordinates provided by Theorem 15. We consider the range of energies $\mathcal { E } = \{ F _ { \mathrm { s e c } } ( z ) : z \in \mathcal { D } \} \subset \mathbb { R }$

Theorem 23. Choose $E _ { 0 } \in \mathcal { E }$ and consider the Poincar´e section $M = \left\{ \hat { \gamma } _ { 2 } = 0 \right\} \cap \left\{ F _ { \mathrm { s e c } } = E _ { 0 } \right\} \cap \mathcal { D }$ . We have the following.

1. The flow of $F _ { \mathrm { s e c } }$ gives rise to a well-defined Poincar´e map $F : M \to M$ , and the set $\hat { \Lambda } = \Lambda \cap M$ is a normally hyperbolic invariant manifold for $F$ .

2. The variables $\left( \hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 } , \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 } \right)$ define coordinates on $\hat { \Lambda }$ and the inner map $f = F | _ { \hat { \Lambda } }$ is of the form

$$
f: \left\{ \begin{array}{l l} \left(\hat {\psi} _ {1} ^ {*}, \hat {\gamma} _ {3} ^ {*}, \hat {\ell} _ {3} ^ {*}\right) & = \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}\right) + g \left(\hat {\Psi} _ {1}, \hat {\Gamma} _ {3}, \hat {L} _ {3}\right) + O \left(\varepsilon^ {k _ {1} - 6} \mu^ {k _ {2}}\right) \\ \left(\hat {\Psi} _ {1} ^ {*}, \hat {\Gamma} _ {3} ^ {*}, \hat {L} _ {3} ^ {*}\right) & = \left(\hat {\Psi} _ {1}, \hat {\Gamma} _ {3}, \hat {L} _ {3}\right) + O \left(\varepsilon^ {k _ {1} - 6} \mu^ {k _ {2}}\right) \end{array} \right.\tag{75}
$$

where $\begin{array} { r } { \varepsilon = { \frac { 1 } { L _ { 2 } } } , \mu = { \frac { L _ { 2 } } { L _ { 3 } } } } \end{array}$ , where $k _ { 1 } , k _ { 2 }$ come from part 2 of Theorem $^ { 1 5 , }$ and where

$$
\det D g \left(\hat {\Psi} _ {1}, \hat {\Gamma} _ {3}, \hat {L} _ {3}\right) \neq 0.
$$

Moreover the bottom eigenvalue of Dg $\left( \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 } \right)$ is of order $\textstyle { \frac { \mu ^ { 6 } } { \varepsilon ^ { 2 } } }$ .

3. There are two scattering maps $\hat { S } _ { \pm } : \hat { \Lambda }  \hat { \Lambda } ^ { \prime }$ where $\hat { \Lambda } ^ { \prime }$ is an open cylinder in $\mathbb { T } ^ { 3 } \times \mathbb { R } ^ { 3 }$ containing $\hat { \Lambda }$ Moreover with $\Big ( \hat { \psi } _ { 1 } ^ { * } , \hat { \gamma } _ { 3 } ^ { * } , \hat { \ell } _ { 3 } ^ { * } , \hat { \Psi } _ { 1 } ^ { * } , \hat { \Gamma } _ { 3 } ^ { * } , \hat { L } _ { 3 } ^ { * } \Big ) = \hat { S } _ { \pm } \left( \hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 } , \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 } \right)$ we have

$$
\left\{ \begin{array}{l l} \hat {\Psi} _ {1} ^ {*} = & \hat {\Psi} _ {1} + \frac {L _ {2} ^ {9}}{\left(L _ {3} ^ {*}\right) ^ {6}} \mathcal {S} _ {1} ^ {\pm} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}\right) + \dots \end{array} \right.
$$

$$
\left\{ \begin{array}{l l} \hat {\Gamma} _ {3} ^ {*} = & \hat {\Gamma} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \mathcal {S} _ {2} ^ {\pm} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}) + \dots \end{array} \right.
$$

$$
\left\lfloor \hat {L} _ {3} ^ {*} = \hat {L} _ {3} + \frac {L _ {2} ^ {9}}{(L _ {3} ^ {*}) ^ {6}} \mathcal {S} _ {3} ^ {\pm} (\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Gamma} _ {2}) + \dots \right.
$$

where $S _ { j } ^ { \pm }$ are given by (64), (65), and (66) respectively.

Remark 24. The inequality (74) gives us the true range of values of the mutual inclination i along the difusive orbits we have found (see also Remark 13). Indeed, the computation cos $\begin{array} { r } { i _ { 1 2 } = \frac { \tilde { \Gamma } _ { 2 } } { \Gamma _ { 1 } } + O \left( L _ { 2 } ^ { - 1 } \right) } \end{array}$ that we made in Remark 13 combined with the fact that $\tilde { \Gamma } _ { 2 } \in [ \zeta _ { 1 } , \zeta _ { 2 } ]$ where $\zeta _ { 1 } , \zeta _ { 2 }$ satisfy (74) implies that, on the circular ellipse $\{ \Gamma _ { 1 } = L _ { 1 } \}$ , we have  cos $i _ { 1 2 } | < \sqrt { \frac { 1 } { 3 } } + O \left( L _ { 2 } ^ { - 1 } \right)$ , which means that $i _ { 1 2 }$ is more than roughly $5 5 ^ { \circ }$

The proof of parts 1 and 3 of Theorem 23 is equivalent to the proof of Lemmas 33 and 36 of [13], so we do not repeat it here. The proof of part 2 of the theorem is contained in Lemma 25 below.

Lemma 25. The inner map $f = F | _ { \hat { \Lambda } }$ has the form

$$
f: \left\{ \begin{array}{l l} \left(\hat {\psi} _ {1} ^ {*}, \hat {\gamma} _ {3} ^ {*}, \hat {\ell} _ {3} ^ {*}\right) & = \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}\right) + g \left(\hat {\Psi} _ {1}, \hat {\Gamma} _ {3}, \hat {L} _ {3}\right) + O \left(\varepsilon^ {k _ {1} - 6} \mu^ {k _ {2}}\right) \\ \left(\hat {\Psi} _ {1} ^ {*}, \hat {\Gamma} _ {3} ^ {*}, \hat {L} _ {3} ^ {*}\right) & = \left(\hat {\Psi} _ {1}, \hat {\Gamma} _ {3}, \hat {L} _ {3}\right) + O \left(\varepsilon^ {k _ {1} - 6} \mu^ {k _ {2}}\right) \end{array} \right.\tag{76}
$$

where $\begin{array} { r } { \varepsilon = { \frac { 1 } { L _ { 2 } } } , \mu = { \frac { L _ { 2 } } { L _ { 3 } } } } \end{array}$ , where $k _ { 1 } , k _ { 2 }$ come from part 2 of Theorem 15, and where

$$
\det D g \left(\hat {\Psi} _ {1}, \hat {\Gamma} _ {3}, \hat {L} _ {3}\right) \neq 0\tag{77}
$$

as long as

$$
\hat {\Gamma} _ {2} \notin \left\{0, \frac {L _ {1}}{\sqrt {3}} \right\}.\tag{78}
$$

Moreover the bottom eigenvalue of $D g \left( \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 } \right)$ is of order $\frac { \mu ^ { 6 } } { \varepsilon ^ { 2 } }$ .

Proof. The first order term of the normalised Hamiltonian $L _ { 2 } ^ { 6 } { \hat { F } }$ is $c _ { 0 } \hat { \Gamma } _ { 2 } ^ { 2 }$ by Theorem 15, so the frequency of $\hat { \gamma } _ { 2 }$ is $2 c _ { 0 } \hat { \Gamma } _ { 2 } + { \cal O } ( \varepsilon ) = { \cal O } ( 1 )$ . It follows that the return time to the Poincar´e section $\{ \hat { \gamma } _ { 2 } = 0 \}$ of the flow of the Hamiltonian function $\dot { L } _ { 2 } ^ { 6 } \hat { F }$ is of order 1. Since we have averaged the angles on the cylinder from the Hamiltonian $L _ { 2 } ^ { 6 } { \hat { F } }$ up to terms of order $O \left( \varepsilon ^ { k _ { 1 } - 6 } \mu ^ { k _ { 2 } } \right)$ (see Theorem 15), the Poincar´e map $f$ has the form (76).

Now, define

$$
\omega_ {i} (P _ {0}, P) = \frac {\partial \hat {F} _ {0}}{\partial P _ {i}}
$$

for $i = { 0 , 1 , 2 , 3 }$ where $P _ { 0 } = \hat { \Gamma } _ { 2 } , P _ { 1 } = \hat { \Psi } _ { 1 } , P _ { 2 } = \hat { \Gamma } _ { 3 } , P _ { 3 } = \hat { L } _ { 3 }$ , and $P = ( P _ { 1 } , P _ { 2 } , P _ { 3 } )$ . Restricting to an energy level $\{ \hat { F } _ { 0 } = E _ { 0 } \}$ with $E _ { 0 } \in \mathcal { E }$ , the implicit function theorem implies that we can write $P _ { 0 } = \alpha ( P )$ where

$$
\frac {\partial \alpha}{\partial P _ {j}} (P) = - \frac {\hat {\omega} _ {j} (P)}{\hat {\omega} _ {0} (P)}
$$

where we have defined $\hat { \omega } _ { i } ( P ) = \omega _ { i } ( \alpha ( P ) , P )$ . It is not hard to see that $g _ { i } ( P ) = \hat { \omega } _ { 0 } ( P ) ^ { - 1 } \hat { \omega } _ { i } ( P )$ . In the following computation, borrowed from Lemma 34 of [13], we suppress dependence of all functions on $P$ and $P _ { 0 } = \alpha ( P )$ for convenience of notation:

$$
\begin{array}{r l} & {\hat {\omega} _ {0} ^ {3} (D g) _ {i j} = \hat {\omega} _ {0} ^ {3} \frac {\partial g _ {i}}{\partial P _ {j}} = \hat {\omega} _ {0} ^ {2} \left(\frac {\partial \omega_ {i}}{\partial P _ {0}} \frac {\partial \alpha}{\partial P _ {j}} + \frac {\partial \omega_ {i}}{\partial P _ {j}}\right) - \hat {\omega} _ {0} \hat {\omega} _ {i} \left(\frac {\partial \omega_ {0}}{\partial P _ {0}} \frac {\partial \alpha}{\partial P _ {j}} + \frac {\partial \omega_ {0}}{\partial P _ {j}}\right)} \\ & {\quad = - \hat {\omega} _ {0} \hat {\omega} _ {j} \frac {\partial \omega_ {i}}{\partial P _ {0}} + \hat {\omega} _ {0} ^ {2} \frac {\partial \omega_ {i}}{\partial P _ {j}} + \hat {\omega} _ {i} \hat {\omega} _ {j} \frac {\partial \omega_ {0}}{\partial P _ {0}} - \hat {\omega} _ {0} \hat {\omega} _ {i} \frac {\partial \omega_ {0}}{\partial P _ {j}}} \\ & {\quad = - \frac {\partial \hat {F} _ {0}}{\partial P _ {0}} \frac {\partial \hat {F} _ {0}}{\partial P _ {j}} \frac {\partial^ {2} \hat {F} _ {0}}{\partial P _ {0} \partial P _ {i}} + \left(\frac {\partial \hat {F} _ {0}}{\partial P _ {0}}\right) ^ {2} \frac {\partial^ {2} \hat {F} _ {0}}{\partial P _ {j} \partial P _ {i}} + \frac {\partial \hat {F} _ {0}}{\partial P _ {i}} \frac {\partial \hat {F} _ {0}}{\partial P _ {j}} \frac {\partial^ {2} \hat {F} _ {0}}{\partial P _ {0} ^ {2}} - \frac {\partial \hat {F} _ {0}}{\partial P _ {0}} \frac {\partial \hat {F} _ {0}}{\partial P _ {i}} \frac {\partial^ {2} \hat {F} _ {0}}{\partial P _ {j} \partial P _ {0}}.} \end{array}
$$

Inserting the formulas for the derivatives of $\hat { F } _ { 0 }$ given in Appendix D into this formula, we see that

$$
\hat {\omega} _ {0} ^ {3} (D g) _ {1 1} = \varepsilon^ {2 0} \hat {A} _ {1 1}, \qquad \hat {\omega} _ {0} ^ {3} (D g) _ {1 2} = \varepsilon^ {1 6} \mu^ {6} \hat {A} _ {1 2}, \qquad \hat {\omega} _ {0} ^ {3} (D g) _ {2 1} = \varepsilon^ {1 6} \mu^ {6} \hat {A} _ {2 1},
$$

$$
\hat {\omega} _ {0} ^ {3} (D g) _ {2 2} = \varepsilon^ {1 6} \mu^ {6} \hat {A} _ {2 2}, \qquad \hat {\omega} _ {0} ^ {3} (D g) _ {1 3} = \varepsilon^ {1 6} \mu^ {3} \hat {A} _ {1 3}, \qquad \hat {\omega} _ {0} ^ {3} (D g) _ {2 3} = \varepsilon^ {1 6} \mu^ {7} \hat {A} _ {2 3},
$$

$$
\hat {\omega} _ {0} ^ {3} (D g) _ {3 1} = \varepsilon^ {1 6} \mu^ {3} \hat {A} _ {3 1}, \quad \omega_ {0} ^ {3} (D g) _ {3 2} = \varepsilon^ {1 6} \mu^ {7} \hat {A} _ {3 2}, \quad \omega_ {0} ^ {3} (D g) _ {3 3} = \varepsilon^ {1 6} \mu^ {4} \hat {A} _ {3 3}
$$

where $\hat { A } _ { i j } = O ( 1 )$ for each $i , j ,$ , and where

$$
\hat {A} _ {1 1} = C _ {1 2} ^ {3} \frac {5 4 \left(L _ {1} ^ {2} - 3 \hat {\Gamma} _ {2} ^ {2}\right) \left(L _ {1} ^ {2} + \hat {\Gamma} _ {2} ^ {2}\right)}{L _ {1} ^ {6} \delta_ {1} ^ {1 1}} + \dots
$$

$$
\hat {A} _ {2 2} = - C _ {1 2} ^ {2} C _ {2 3} \frac {3 6 \hat {\Gamma} _ {2} ^ {2} (1 2 \delta_ {1} ^ {2} - 2 0)}{L _ {1} ^ {4} \delta_ {1} ^ {8} \delta_ {2} ^ {3}} + \dots
$$

$$
\hat {A} _ {3 3} = - C _ {1 2} ^ {2} \alpha_ {\mathrm{Kep}} \frac {1 0 8 \hat {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {4} \delta_ {1} ^ {6}} + \dots
$$

Noticing that $\hat { \omega } _ { 0 } ^ { 3 } = O \left( \varepsilon ^ { 1 8 } \right)$ , we define $A _ { i j } = \varepsilon ^ { 1 8 } \hat { \omega } _ { 0 } ^ { - 3 } \hat { A } _ { i j }$ . We thus obtain

$$
D g = \left( \begin{array}{c c c} \varepsilon^ {2} A _ {1 1} & \frac {\mu^ {6}}{\varepsilon^ {2}} A _ {1 2} & \frac {\mu^ {3}}{\varepsilon^ {2}} A _ {1 3} \\ \frac {\mu^ {6}}{\varepsilon^ {2}} A _ {2 1} & \frac {\mu^ {6}}{\varepsilon^ {2}} A _ {2 2} & \frac {\mu^ {7}}{\varepsilon^ {2}} A _ {2 3} \\ \frac {\mu^ {3}}{\varepsilon^ {2}} A _ {3 1} & \frac {\mu^ {7}}{\varepsilon^ {2}} A _ {3 2} & \frac {\mu^ {4}}{\varepsilon^ {2}} A _ {3 3} \end{array} \right).
$$

We must find a condition under which the determinant of ${ \cal D } g$ is nonzero, and in addition we must estimate the order of its bottom eigenvalue. We compute

$$
\det D g = \frac {\mu^ {1 0}}{\varepsilon^ {2}} A _ {1 1} A _ {2 2} A _ {3 3} + \dots
$$

where we have used (15). It is not hard to see that the first-order approximations of the three eigenvalues of Dg are therefore given by the entries on the diagonal. Comparing their respective sizes using assumption (15), we thus see that the bottom eigenvalue is indeed of order $\frac { \mu ^ { 6 } } { \varepsilon ^ { 2 } }$ . In addition we see that the nondegeneracy condition (77) is satisfied as long as

$$
0 \neq \hat {A} _ {1 1} \hat {A} _ {2 2} \hat {A} _ {3 3} = 2 0 9 9 5 2   C _ {1 2} ^ {6}   C _ {2 3}   \alpha_ {\mathrm{Kep}}   \frac {\hat {\Gamma} _ {2} ^ {4}}{L _ {1} ^ {1 4}   \delta_ {1} ^ {2 5}   \delta_ {2} ^ {3}}   \left(L _ {1} ^ {2} - 3   \hat {\Gamma} _ {2} ^ {2}\right)   \left(L _ {1} ^ {2} + \hat {\Gamma} _ {2} ^ {2}\right)   \left(1 2   \delta_ {1} ^ {2} - 2 0\right) + \dots
$$

which yields (78).

## 7.2 Transition chains of almost invariant tori

We define a foliation of the normally hyperbolic manifold $\hat { \Lambda }$ via the leaves

$$
\mathcal {L} \left(\hat {\Psi} _ {1} ^ {*}, \hat {\Gamma} _ {3} ^ {*}, \hat {L} _ {3} ^ {*}\right) = \left\{\left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}, \hat {\Psi} _ {1}, \hat {\Gamma} _ {3}, \hat {L} _ {3}\right) \in \hat {\Lambda}: \hat {\Psi} _ {1} = \hat {\Psi} _ {1} ^ {*}, \hat {\Gamma} _ {3} = \hat {\Gamma} _ {3} ^ {*}, \hat {L} _ {3} = \hat {L} _ {3} ^ {*} \right\}\tag{79}
$$

for each $\left( \hat { \Psi } _ { 1 } ^ { * } , \hat { \Gamma } _ { 3 } ^ { * } , \hat { L } _ { 3 } ^ { * } \right) \in [ - 1 , 1 ] ^ { 3 }$ . Observe that each leaf $\mathcal { L } \left( \hat { \Psi } _ { 1 } ^ { * } , \hat { \Gamma } _ { 3 } ^ { * } , \hat { L } _ { 3 } ^ { * } \right)$ is almost invariant under the inner map $f ,$ as it takes the form (75). A transition chain is a sequence $\{ \mathcal { L } _ { j } \}$ of such leaves such that for each $j$ there is $\beta _ { j } \in \{ + , - \}$ and $z \in { \mathcal { L } } _ { j }$ such that $\hat { S } _ { \beta _ { j } } ( z ) \in \mathcal { L } _ { j + 1 }$ and

$$
T _ {\hat {S} _ {\beta_ {j}} (z)} \hat {\Lambda} = T _ {\hat {S} _ {\beta_ {j}} (z)} \left(\hat {S} _ {\beta_ {j}} (\mathcal {L} _ {j})\right) \oplus T _ {\hat {S} _ {\beta_ {j}} (z)} \mathcal {L} _ {j + 1}.
$$

This is an essential condition of the shadowing theorems of [14] (see Appendix C).

Recall that the first order terms $S _ { 1 } ^ { \pm } , S _ { 2 } ^ { \pm } , S _ { 3 } ^ { \pm }$ of the images of the actions of a point $\left( \hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 } , \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 } \right)$ under the scattering maps $\hat { S } _ { \pm } : \hat { \Lambda }  \hat { \Lambda } ^ { \prime }$ are given by (64), (65), (66) respectively as a result of Theorem 23. Let $z = \left( \hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 } \right) \in \mathbb { T } ^ { 3 }$ . In what follows we fix some values of the actions, and suppress the dependence of the functions $S _ { 1 } ^ { \pm } , S _ { 2 } ^ { \pm } , S _ { 3 } ^ { \pm }$ on these actions for convenience of notation. Define the matrices $A ^ { \pm } ( z )$ by

$$
A ^ {\pm} (z) = \left( \begin{array}{c c c} \partial_ {\hat {\psi} _ {1}} \mathcal {S} _ {1} ^ {\pm} (z) & \partial_ {\hat {\gamma} _ {3}} \mathcal {S} _ {1} ^ {\pm} (z) & \partial_ {\hat {\ell} _ {3}} \mathcal {S} _ {1} ^ {\pm} (z) \\ \partial_ {\hat {\psi} _ {1}} \mathcal {S} _ {2} ^ {\pm} (z) & \partial_ {\hat {\gamma} _ {3}} \mathcal {S} _ {2} ^ {\pm} (z) & \partial_ {\hat {\ell} _ {3}} \mathcal {S} _ {2} ^ {\pm} (z) \\ \partial_ {\hat {\psi} _ {1}} \mathcal {S} _ {3} ^ {\pm} (z) & \partial_ {\hat {\gamma} _ {3}} \mathcal {S} _ {3} ^ {\pm} (z) & \partial_ {\hat {\ell} _ {3}} \mathcal {S} _ {3} ^ {\pm} (z) \end{array} \right).\tag{80}
$$

Lemma 26. There are constants $\nu _ { j } > 0$ and $C > 0 f o r j = 1 , 2 , 3$ such that for suficiently large $L _ { 2 } \ll L _ { 3 } ^ { \frac 1 3 }$ and any leaf $\mathcal { L } ^ { * } = \mathcal { L } \left( \hat { \Psi } _ { 1 } ^ { 0 } , \hat { \Gamma } _ { 3 } ^ { 0 } , \hat { L } _ { 3 } ^ { 0 } \right)$ of the foliation $o f \hat { \Lambda }$ , there is $\sigma \in \{ + , - \}$ and there are open sets $U _ { j } \subset \mathcal { L } ^ { * } \simeq \mathbb { T } ^ { 3 }$ for $j = 1 , \dots , 8$ such that

$$
\det A ^ {\sigma} | _ {\overline {{U _ {j}}}} \neq 0
$$

where the matrices $A ^ { \pm }$ are defined by $( 8 0 ) , \mu ( U _ { j } ) > C$ where $\mu$ is the Lebesgue measure on $\mathbb { T } ^ { 3 }$ and moreover:

1. For all $z \in U _ { 1 }$ we have $S _ { 1 } ^ { \sigma } ( z ) > \nu _ { 1 } , S _ { 2 } ^ { \sigma } ( z ) > \nu _ { 2 }$ , and $S _ { 3 } ^ { \sigma } ( z ) > \nu _ { 3 }$

2. For $a l l z \in U _ { 2 }$ we have $S _ { 1 } ^ { \sigma } ( z ) > \nu _ { 1 } , S _ { 2 } ^ { \sigma } ( z ) > \nu _ { 2 } , a n d S _ { 3 } ^ { \sigma } ( z ) < - \nu _ { 3 }$

3. For $a l l z \in U _ { 3 }$ we have $S _ { 1 } ^ { \sigma } ( z ) > \nu _ { 1 } , S _ { 2 } ^ { \sigma } ( z ) < - \nu _ { 2 } , a n d S _ { 3 } ^ { \sigma } ( z ) > \nu _ { 3 }$

4. For $a l l z \in U _ { 4 }$ we have $S _ { 1 } ^ { \sigma } ( z ) > \nu _ { 1 } , S _ { 2 } ^ { \sigma } ( z ) < - \nu _ { 2 } , a n d S _ { 3 } ^ { \sigma } ( z ) < - \nu _ { 3 } .$

5. For $a l l z \in U _ { 5 }$ we have $S _ { 1 } ^ { \sigma } ( z ) < - \nu _ { 1 } , S _ { 2 } ^ { \sigma } ( z ) > \nu _ { 2 } , a n d S _ { 3 } ^ { \sigma } ( z ) > \nu _ { 3 }$

6. For $a l l z \in U _ { 6 }$ we have $S _ { 1 } ^ { \sigma } ( z ) < - \nu _ { 1 } , S _ { 2 } ^ { \sigma } ( z ) > \nu _ { 2 } , a n d S _ { 3 } ^ { \sigma } ( z ) < - \nu _ { 3 }$

7. For $a l l z \in U _ { 7 }$ we have $S _ { 1 } ^ { \sigma } ( z ) < - \nu _ { 1 } , S _ { 2 } ^ { \sigma } ( z ) < - \nu _ { 2 } , a n d S _ { 3 } ^ { \sigma } ( z ) > \nu _ { 3 }$

8. For all $z \in U _ { 8 }$ we have $S _ { 1 } ^ { \sigma } ( z ) < - \nu _ { 1 } , \ : S _ { 2 } ^ { \sigma } ( z ) < - \nu _ { 2 } , \ : a n d \ : S _ { 3 } ^ { \sigma } ( z ) < - \nu _ { 3 }$

Proof. Fix any leaf $\mathcal { L } ^ { * } = \mathcal { L } \left( \hat { \Psi } _ { 1 } ^ { 0 } , \hat { \Gamma } _ { 3 } ^ { 0 } , \hat { L } _ { 3 } ^ { 0 } \right)$ of the foliation of $\hat { \Lambda } .$ , and for $z = \left( \hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 } \right) \in \mathbb { T } ^ { 3 }$ , consider the map $S ^ { \pm } : \mathbb { T } ^ { 3 }  \mathbb { R } ^ { 3 }$ given by $S ^ { \pm } ( z ) = \overbar { ( S _ { 1 } ^ { \pm } ( z ) , S _ { 2 } ^ { \pm } ( z ) , S _ { 3 } ^ { \pm } ( z ) ) }$ . Observe that, if we can prove that there is some $z _ { 0 } \in \mathbb { T }$ and $\sigma \in \{ + , - \}$ such that $S ^ { \sigma } ( z _ { 0 } ) = 0$ and det $\overset { \cdot } { A } { } ^ { \sigma } ( z _ { 0 } ) \neq 0$ , then the inverse function theorem implies that $S ^ { \sigma }$ surjectively maps a neighbourhood of $z _ { 0 }$ in $\mathbb { T } ^ { 3 }$ onto a neighbourhood of the origin in $\mathbb { R } ^ { 3 }$ and this would complete the proof of the lemma. We search for such $\mathrm { ~ a ~ } z _ { 0 }$

Consider the point $\begin{array} { r } { z _ { 0 } = \left( \hat { \psi } _ { 1 } = \frac { \pi } { 2 } , \hat { \gamma } _ { 3 } = 0 , \hat { \ell } _ { 3 } = 0 \right) } \end{array}$ . Notice that the true anomaly $\hat { v } _ { 3 } = 0$ whenever the mean anomaly $\hat { \ell } _ { 3 } = 0$ . Using the formulas (64), (65), (66), it is not hard to see that $S ^ { \pm } ( z ) = 0$ . In addition, diferentiating these formulas with respect to the angles $\hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 }$ , and using the notation

$$
C _ {1} ^ {\pm} = \mp \alpha_ {1} ^ {2 3} \kappa \left(\frac {\pi \hat {\Gamma} _ {2} ^ {0}}{A _ {2} L _ {1} ^ {2}}\right), \quad c = \sqrt {1 - \delta_ {2} ^ {2}}, \quad \beta = 4 \delta_ {1} ^ {2} - 5,
$$

$$
C _ {2} = \frac {\alpha_ {0} ^ {2 3} \alpha_ {2} ^ {1 2}}{\alpha_ {1} ^ {1 2}} \frac {L _ {1}}{6} \sqrt {\frac {3}{2}} \hat {\Gamma} _ {2} \frac {\sqrt {1 - \frac {5}{3} \frac {\hat {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}}}}{3 \frac {\hat {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2}} - 1}
$$

and the relation

$$
\frac {\partial \hat {v} _ {3}}{\partial \hat {\ell} _ {3}} = \delta_ {2} ^ {- 3} \left(1 + c \cos \hat {v} _ {3}\right) ^ {2} + \dots
$$

we obtain (up to higher order terms)

$$
\partial_ {\hat {\psi} _ {1}} \mathcal {S} _ {1} ^ {\pm} (z _ {0}) = - 3 0   C _ {2} (1 + c) ^ {3}   (1 - \delta_ {1} ^ {2}),
$$

$$
\partial_ {\hat {\gamma} _ {3}} \mathcal {S} _ {1} ^ {\pm} (z _ {0}) = C _ {1} ^ {\pm} (1 + c) ^ {3} \beta - 3 0   C _ {2} (1 + c) ^ {3} (1 - \delta_ {1} ^ {2}),
$$

$$
\partial_ {\hat {\ell} _ {3}} \mathcal {S} _ {1} ^ {\pm} (z _ {0}) = - C _ {1} ^ {\pm} \delta_ {2} ^ {- 3} (1 + c) ^ {5} \beta + C _ {2} 3 0 (1 + c) ^ {5} \frac {\delta_ {3}}{\delta_ {1}} (1 - \delta_ {1} ^ {2}) \delta_ {2} ^ {- 3}
$$

and

$$
\partial_ {\hat {\psi} _ {1}} \mathcal {S} _ {2} ^ {\pm} (z _ {0}) = C _ {1} ^ {\pm} (1 + c) ^ {3} \beta ,
$$

$$
\partial_ {\hat {\gamma} _ {3}} \mathcal {S} _ {2} ^ {\pm} (z _ {0}) = - 2 C _ {1} ^ {\pm} (1 + c) ^ {3} \frac {\delta_ {3}}{\delta_ {1}} \beta ,
$$

$$
\partial_ {\hat {\ell} _ {3}} \mathcal {S} _ {2} ^ {\pm} (z _ {0}) = - 2   C _ {1} ^ {\pm}   (1 + c) ^ {5}   \frac {\delta_ {3}}{\delta_ {1}}   \delta_ {2} ^ {- 3}   \beta ,
$$

$$
\partial_ {\hat {\psi} _ {1}} \mathcal {S} _ {3} ^ {\pm} (z _ {0}) = - C _ {1} ^ {\pm} (1 + c) ^ {5} \delta_ {2} ^ {- 3} \beta ,
$$

$$
\partial_ {\hat {\gamma} _ {3}} \mathcal {S} _ {3} ^ {\pm} (z _ {0}) = - 2 C _ {1} ^ {\pm} (1 + c) ^ {5} \frac {\delta_ {3}}{\delta_ {1}} \delta_ {2} ^ {- 3} \beta ,
$$

$$
\partial_ {\hat {\ell} _ {3}} \mathcal {S} _ {3} ^ {\pm} (z _ {0}) = 2 C _ {1} ^ {\pm} (1 + c) ^ {7} \frac {\delta_ {3}}{\delta_ {1}} \delta_ {2} ^ {- 6} \beta .
$$

Since we only need to check that det $A ^ { \pm } ( z _ { 0 } ) \neq 0$ , we divide each row and each column of $A ^ { \pm } ( z _ { 0 } )$ by some common factors to simplify the computation. After dividing: the first row by $( 1 + c ) ^ { 3 } ;$ ; the second row by $C _ { 1 } ^ { \pm } \left( 1 + c \right) ^ { 3 } \beta ;$ the third row by $\hat { C } _ { 1 } ^ { \pm } ( 1 + c ) ^ { 5 } \delta _ { 2 } ^ { - 3 } \beta ;$ ; the second column by $\frac { \delta _ { 3 } } { \delta _ { 1 } }$ ; and the third column by $\begin{array} { r } { ( 1 + c ) ^ { 2 } \frac { \delta _ { 3 } } { \delta _ { 1 } } \delta _ { 2 } ^ { - 3 } } \end{array}$ , we are left with the matrix

$$
\hat {A} ^ {\pm} = \left( \begin{array}{c c c} - 3 0   C _ {2}   (1 - \delta_ {1} ^ {2}) & C _ {1} ^ {\pm}   \frac {\delta_ {1}}{\delta_ {3}}   \beta - 3 0   C _ {2}   (1 - \delta_ {1} ^ {2}) & - C _ {1} ^ {\pm}   \frac {\delta_ {1}}{\delta_ {3}} \beta + 3 0   C _ {2} (1 - \delta_ {1} ^ {2}) \\ 1 & - 2 & - 2 \\ - 1 & - 2 & 2 \end{array} \right).
$$

Therefore we have det $A ^ { \pm } ( z _ { 0 } ) \neq 0$ if and only if

$$
0 \neq \det \hat {A} ^ {\pm} = 4 C _ {1} ^ {\pm} \frac {\delta_ {1}}{\delta_ {3}} \beta - 2 4 0 C _ {2} (1 - \delta_ {1} ^ {2}).\tag{81}
$$

Recall that $\delta _ { 1 } \in ( 0 , 1 ) , \delta _ { 3 } > 0$ , and notice that $C _ { 1 } ^ { \pm } , C _ { 2 } , \beta \neq 0 ;$ moreover $C _ { 1 } ^ { + }$ and $C _ { 1 } ^ { - }$ have equal magnitude and opposite signs. It follows that (81) must hold for at least one value of $\sigma \in \{ + , - \}$ , so the lemma is proved. □

Lemma 27. Suppose $z \in \mathcal { L } _ { 0 } \cap U _ { j }$ and $z ^ { * } = \hat { S } _ { \sigma } ( z ) \in \mathcal { L } _ { 1 }$ where $\sigma \in \{ + , - \}$ and the open sets $U _ { j }$ were found in Lemma 26, and where $\mathcal { L } _ { 0 } , \mathcal { L } _ { 1 }$ are leaves of the foliation of Λ<sup>ˆ</sup>. Then $\hat { S } _ { \sigma }$ maps $\mathcal { L } _ { 0 }$ transversely across $\mathcal { L } _ { 1 }$ at the point $z ^ { * } = \hat { S } _ { \sigma } ( z )$ in the sense that

$$
T _ {z ^ {*}} \hat {\Lambda} = T _ {z ^ {*}} \left(\hat {S} _ {\sigma} \left(\mathcal {L} _ {0}\right)\right) \oplus T _ {z ^ {*}} \mathcal {L} _ {1}.
$$

Moreover the order of transversality (in the sense of Definition 35 in Appendix $\begin{array} { r } { C ) \ i s \ \frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } } } \end{array}$

Proof. Suppose $z \in U _ { j }$ for some $j = 1 , \dots , 8$ . The tangent space $T _ { z ^ { * } } \hat { \Lambda }$ is a real vector space of dimension $6 ,$ and its elements are of the form $v = ( Q , P )$ where $Q \in \mathbb { R } ^ { 3 }$ represents tangents in the $( \hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 } )$ directions, and $P \in \mathbb { R } ^ { 3 }$ represents tangents in the $( \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 } )$ directions. The scattering map $\hat { S } _ { \sigma }$ is smooth, and so $D _ { z } \hat { S } _ { \sigma } \left( T _ { z } \mathcal { L } _ { 0 } \right) = T _ { z ^ { * } } \hat { S } _ { \sigma } \left( \mathcal { L } _ { 0 } \right)$ . With $\boldsymbol { z } = \left( \hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 } , \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 } \right)$ and $z ^ { * } = \left( \hat { \psi } _ { 1 } ^ { * } , \hat { \gamma } _ { 3 } ^ { * } , \hat { \ell } _ { 3 } ^ { * } , \hat { \Psi } _ { 1 } ^ { * } , \hat { \Gamma } _ { 3 } ^ { * } , \hat { L } _ { 3 } ^ { * } \right)$ we can write

$$
D _ {z} \hat {S} _ {\sigma} = \left( \begin{array}{c c} A _ {1} & A _ {2} \\ A _ {3} & A _ {4} \end{array} \right)
$$

where

$$
A _ {1} = \frac {\partial (\hat {\psi} _ {1} ^ {*} , \hat {\gamma} _ {3} ^ {*} , \hat {\ell} _ {3} ^ {*})}{\partial (\hat {\psi} _ {1} , \hat {\gamma} _ {3} , \hat {\ell} _ {3})}, \quad A _ {2} = \frac {\partial (\hat {\psi} _ {1} ^ {*} , \hat {\gamma} _ {3} ^ {*} , \hat {\ell} _ {3} ^ {*})}{\partial (\hat {\Psi} _ {1} , \hat {\Gamma} _ {3} , \hat {L} _ {3})}, \quad A _ {3} = \frac {\partial (\hat {\Psi} _ {1} ^ {*} , \hat {\Gamma} _ {3} ^ {*} , \hat {L} _ {3} ^ {*})}{\partial (\hat {\psi} _ {1} , \hat {\gamma} _ {3} , \hat {\ell} _ {3})}, \quad A _ {4} = \frac {\partial (\hat {\Psi} _ {1} ^ {*} , \hat {\Gamma} _ {3} ^ {*} , \hat {L} _ {3} ^ {*})}{\partial (\hat {\Psi} _ {1} , \hat {\Gamma} _ {3} , \hat {L} _ {3})}.
$$

Therefore

$$
A _ {1} = \left( \begin{array}{c c c} 1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 1 \end{array} \right) + \dots , \quad A _ {3} = A ^ {\sigma} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}\right) + \dots
$$

where the matrices $A ^ { \pm }$ are defined by (80).

Let $v _ { 0 } \in T _ { z } \mathcal { L } _ { 0 }$ and $v _ { 1 } \in T _ { z ^ { * } } \mathcal { L } _ { 1 }$ . Since the leaves are defined as tori with constant actions, we have $v _ { j } = ( Q _ { j } , 0 )$ with $Q _ { j } \in \mathbb { R } ^ { 3 }$ for $j = 0 ,$ , 1. Therefore we have

$$
\binom{\bar {Q}}{\bar {P}} = D _ {z} \hat {S} _ {\sigma} (v _ {0}) + v _ {1} = \binom{Q _ {0} + Q _ {1}}{A ^ {\sigma} \left(\hat {\psi} _ {1}, \hat {\gamma} _ {3}, \hat {\ell} _ {3}\right) Q _ {0}} + \dots
$$

By Lemma ${ \mathrm { 2 6 } } ,$ the matrix $A ^ { \sigma } \left( \hat { \psi } _ { 1 } , \hat { \gamma } _ { 3 } , \hat { \ell } _ { 3 } \right)$ is nonsingular. Thus by varying $v _ { 0 } \in T _ { z } \mathcal { L } _ { 0 }$ and $v _ { 1 } \in T _ { z ^ { * } } \mathcal { L } _ { 1 }$ we can obtain any tangent vector in $T _ { z ^ { * } } \hat { \Lambda }$ , which is precisely the transversality we want to prove. The fact that the order of transversality is $\frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ follows from the fact that the order of the jumps in the scattering maps in the direction of each of the actions is $\frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ □

## 7.3 Orbits of the four-body problem shadowing the transition chains

In this section we apply the shadowing theorems of [14] (see also Appendix C) to the secular Hamiltonian and to the Hamiltonian of the full four-body problem in order to complete the proof of Theorem 2. In fact, our first observation is that we have already proved that the Poincar´e map $F : M \to M$ constructed in Theorem 23 satisfies assumptions [A1-3] of Theorem 36. Indeed, Theorem 23 implies that F has a normally hyperbolic invariant manifold $\hat { \Lambda } \simeq \mathbb { T } ^ { 3 } \times [ 0 , 1 ] ^ { 3 }$ , and that the inner map $f = F | _ { \hat { \Lambda } }$ is a near-integrable twist map satisfying a non-uniform twist condition of order $\frac { L _ { 2 } ^ { 8 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } }$ as per Definitions 33 and 34. In addition the stable and unstable manifolds of $\hat { \Lambda }$ have a transverse homoclinic intersection along (at least) two homoclinic channels, and the order of the transversality of the invariant manifolds is $\textstyle { \frac { 1 } { L _ { 2 } ^ { 2 } } }$ . These homoclinic channels give rise to two scattering maps $\hat { S } : \hat { \Lambda }  \hat { \Lambda } ^ { \prime }$ due to Theorems 19 and 23. In Section 7.2 we constructed a foliation of $\hat { \Lambda } ^ { \prime }$ , the leaves of which are given by constant values of the actions, and are almost invariant under the inner map. In addition Lemmas 26 and 27 imply that, by iterating one of the scattering maps in appropriate neighbourhoods in the leaves of the foliation, we may move in any direction, connecting leaves that are $\begin{array} { r } { O \left( \frac { L _ { 2 } ^ { 9 } } { \left( L _ { 3 } ^ { * } \right) ^ { 6 } } \right) } \end{array}$ apart, and mapping leaves transversely across leaves.

In Section 3.3 (see Remark 6 in particular) we made a symplectic change of coordinates (28) to the $\mathrm { \dot { \Omega } t i l d e } ^ { \prime }$ variables, which were the basis for all further analysis in the paper. However this coordinate transformation is local, whereas the drift in eccentricity, inclination, and the semimajor axis described in Theorem 1 is global. In order to define these coordinates we introduced constants $L _ { 3 } ^ { * }$ and $\delta _ { j }$ for $j = 1 , 2 , 3$ . Here $\delta _ { 2 }$ is the coeficient of total angular momentum, and is therefore fixed for the secular system. The constants $L _ { 3 } ^ { * } , \delta _ { 1 } , \delta _ { 3 }$ on the other hand are allowed to vary, and by varying them we simply obtain a diferent system of ‘tilde coordinates. It is not hard to see that the subsequent analysis of this paper holds equally for any value of the constants $L _ { 3 } ^ { * } \gg L _ { 2 } ^ { 3 } , \delta _ { 1 } \in ( 0 , 1 )$ , and $\delta _ { 3 } \in ( - 1 , 1 )$ . Denote by $\tilde { C } _ { L _ { 3 } ^ { * } , \delta _ { 1 } , \delta _ { 3 } }$ the system of ‘tilde’ coordinates corresponding to the values $L _ { 3 } ^ { * } , \delta _ { 1 } , \delta _ { 3 }$ . Then the results of Section 4 apply in $\tilde { C } _ { L _ { 3 } ^ { * } , \delta _ { 1 } , \delta _ { 3 } }$ coordinates for each relevant value of $L _ { 3 } ^ { * } , \delta _ { 1 } , \delta _ { 3 } .$ , so we have a normally hyperbolic invariant manifold $\Lambda _ { L _ { 3 } ^ { * } , \delta _ { 1 } , \delta _ { 3 } }$ in each such system of coordinates. Moreover, since the cylinder depends smoothly on the parameters $\bar { L _ { 3 } } , \delta _ { 1 } , \delta _ { 3 }$ , this construction allows us to obtain one large normally hyperbolic invariant cylinder $\Lambda ^ { * }$

Observe that the contents of Sections 7.1 and 7.2 apply equally in each system of coordinates $\tilde { C } _ { L _ { 3 } ^ { * } , \delta _ { 1 } , \delta _ { 3 } }$ Furthermore, since the $\hat { \gamma } _ { 2 }$ variable does not depend on $L _ { 3 } ^ { * } , \delta _ { 1 } , \delta _ { 3 }$ , the Poincar´e section is global, and so we obtain a large 6-dimensional cylinder $\hat { \Lambda } ^ { * }$ for the return map to the Poincar´e section. We now fix a global transition chain on the cylinder $\hat { \Lambda } ^ { * }$ such that the actions $\hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 }$ drift by an amount of order $L _ { 3 } ^ { * }$ along the chain (note that the values of $L _ { 3 }$ that we choose belong to some bounded set, as in (16)), and choose some sequence $\{ \tilde { C } _ { L _ { 3 } ^ { * , k } , \delta _ { 1 } ^ { k } , \delta _ { 3 } ^ { k } } \} _ { k = 1 , \dots , K }$ so that we have an appropriate system of coordinates to apply the analysis of the earlier sections near each torus in the chain. The analysis of Sections 7.1 and 7.2 applies in each coordinate system $\tilde { C } _ { L _ { 3 } ^ { * , k } , \delta _ { 1 } ^ { k } , \delta _ { 3 } ^ { k } }$ . Note that the shadowing results of [14] apply equally well using the many diferent coordinate systems, as the coordinates used in that paper are purely local. Thus the assumptions of Theorem 36 apply to the global transition chain on the cylinder $\hat { \Lambda } ^ { * }$

Denoting by $\{ \mathcal { L } _ { i } \}$ the global transition chain, Theorem 36 implies that, for any $\eta > 0$ and suficiently large $L _ { 2 } , L _ { 3 }$ , there is a sequence $\{ z _ { j } \} _ { j \in \mathbb { N } _ { 0 } }$ in the secular phase space and times $t _ { j } > 0$ such that

$$
z _ {j + 1} = \phi_ {\mathrm{sec}} ^ {t _ {j}} (z _ {j}), d (z _ {j}, \mathcal {L} _ {j}) <   \eta
$$

for each $j \in \mathbb N$ where $\phi _ { \mathrm { s e c } } ^ { t }$ is the flow of the secular Hamiltonian. Moreover, the time to move a distance of order ${ L } _ { 3 } ^ { * , 1 }$ in the $L _ { 3 }$ variable and a distance of order $L _ { 2 }$ in the $\hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 }$ directions is of order

$$
L _ {3} L _ {2} ^ {6} \frac {L _ {3} ^ {1 2}}{L _ {2} ^ {1 8}} \frac {L _ {3} ^ {6}}{L _ {2} ^ {8}} \frac {L _ {3} ^ {6}}{L _ {2} ^ {9}} = \frac {L _ {3} ^ {2 5}}{L _ {2} ^ {2 9}}.\tag{82}
$$

This follows from formula (93) and the following facts: we move a distance of order $L _ { 3 }$ in the actions $\hat { \Psi } _ { 1 }$ $\hat { \Gamma } _ { 3 } , \ \hat { L } _ { 3 } ;$ the return times to the Poincar´e section are themselves of order $L _ { 2 } ^ { 6 }$ as this is the reciprocal of the order of the frequency of ${ \hat { \gamma } } _ { 2 } ;$ the order of the splitting is $\frac { 1 } { L _ { 2 } ^ { 2 } } ;$ ; the size of the jumps in the scattering map are of order $\frac { L _ { 2 } ^ { 9 } } { L _ { 3 } ^ { 6 } }$ ; and the order of the twist condition is $\frac { L _ { 2 } ^ { 8 } } { L _ { 3 } ^ { 6 } }$

Now, consider the Hamiltonian $F$ of the full four-body problem after averaging the mean anomalies $\ell _ { 1 } , \ell _ { 2 }$ , defined by (21). Fix some $L _ { 1 } ^ { \pm } , L _ { 2 } ^ { \pm } \in \mathbb { R }$ with $0 < L _ { 1 } ^ { - } < L _ { 1 } ^ { + } \ll L _ { 2 } ^ { - } < \bar { L } _ { 2 } ^ { + }$ , so that if $( L _ { 1 } ^ { 0 } , L _ { 2 } ^ { 0 } ) \in$ $[ L _ { 1 } ^ { - } , L _ { 1 } ^ { + } ] \times [ L _ { 2 } ^ { - } , \dot { L } _ { 2 } ^ { + } ]$ ] then there exist initial conditions $L _ { 3 } ^ { 0 } \in \mathbb { R }$ such that $( L _ { 1 } ^ { 0 } , \bar { L } _ { 2 } ^ { 0 } , L _ { 3 } ^ { 0 } )$ satisfies our assumption (15). Let $\dot { \Sigma } = \bar { \mathbb { T } } ^ { 2 } \times [ L _ { 1 } ^ { - } , L _ { 1 } ^ { + } ] \times [ L _ { 2 } ^ { - } , L _ { 2 } ^ { + } ]$ , and recall from the beginning of Section 7.1 the definition of the subset  of the secular phase space. We consider the values of energy of the full four-body problem belonging to the set $\mathcal { E } _ { \mathrm { 4 b p } } = \{ F ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } ) : z \in \mathcal { D } , ( \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } ) \in \Sigma \}$ . Fix $E _ { 1 } \in \mathcal { E } _ { 4 \mathrm { b p } } ,$ , and denote by $\Psi$ the Poincar´e map of the flow of F to the section $\widehat { M } = ( \mathcal { D } \times \Sigma ) \cap \{ \hat { \gamma } _ { 2 } = 0 \} \cap \{ F = E _ { 1 } \}$ . Continuing to denote by $z \mathrm { ~ a ~ }$ point in $\mathcal { D } _ { : }$ , we write $( \bar { z } , \bar { \ell } _ { 1 } , \bar { \ell } _ { 2 } , \bar { L } _ { 1 } , \bar { L } _ { 2 } ) = \Psi ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } )$ with $\bar { z } = G ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } )$ and $( \bar { \ell } _ { 1 } , \bar { \ell } _ { 2 } , \bar { L } _ { 1 } , \bar { L } _ { 2 } ) = \phi ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } )$ . Since the Hamiltonian F is obtained by averaging the mean anomalies $\ell _ { 1 } , \ell _ { 2 }$ , there are $\hat { k } _ { 1 } , \hat { k } _ { 2 } \in \mathbb { N }$ such that the variables $\ell _ { 1 } , \ell _ { 2 }$ do not appear in $F$ until terms of order $\varepsilon ^ { \hat { k } _ { 1 } } \mu ^ { \hat { k } _ { 2 } }$ where $\begin{array} { r } { \varepsilon = \frac { 1 } { L _ { 2 } } } \end{array}$ and $\begin{array} { r } { \mu = \frac { L _ { 2 } } { L _ { 3 } } } \end{array}$ , and moreover we can choose $\hat { k } _ { 1 } , \hat { k } _ { 2 }$ to be as large as we like. Therefore the map $G$ takes the form $G ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } ) = \widetilde { G } ( z ; L _ { 1 } , L _ { 2 } ) + O \left( \varepsilon ^ { \hat { k } _ { 1 } - 6 } \mu ^ { \hat { k } _ { 2 } } \right)$ where the higher-order terms are uniformly bounded in the $C ^ { r }$ etopology for any $r \in \mathbb N$ , and where for any fixed values of $L _ { 1 } , L _ { 2 }$ , the map $z \mapsto \widetilde { G } ( z ; L _ { 1 } , L _ { 2 } )$ is a Poincar´e map of the type constructed in Theorem 23, and thus satisfies the assumptions $\left[ \mathrm { A 1 - 3 } \right]$ of Theorem 36. Consequently the map Ψ satisfies assumption [B1] of Theorem $3 7$ . In addition, if we write $\phi ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } ) = \left( \phi _ { 1 } ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } ) , \phi _ { 2 } ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } ) \right)$ so that $\left( \bar { \ell } _ { 1 } , \bar { \ell } _ { 2 } \right) = \phi _ { 1 } ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } )$ and $\left( \bar { L } _ { 1 } , \bar { L } _ { 2 } \right) = \phi _ { 2 } ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } )$ then we have $\phi _ { 2 } ( z , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } ) = ( L _ { 1 } , L _ { 2 } ) + O \left( \varepsilon ^ { \hat { k } _ { 1 } - 6 } \mu ^ { \hat { k } _ { 2 } } \right)$ with the higherorder terms uniformly C<sup>r</sup>-bounded, and so assumption [B2] of Theorem 37 is also satisfied. As explained in Appendix C, a consequence of results of [19] is that the map Ψ has a normally hyperbolic locally invariant manifold $\widetilde { \Lambda }$ that is close to $\hat { \boldsymbol { \Lambda } } \times \boldsymbol { \Sigma }$ . Therefore we can use the variables $( w , \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } , L _ { 2 } )$ as coordinates on $\widetilde { \Lambda }$ ewhere w are coordinates on $\hat { \Lambda }$ , and construct a foliation of $\widetilde { \Lambda }$ by the leaves

$$
\tilde {\mathcal {L}} \left(\hat {\Psi} _ {1} ^ {*}, \hat {\Gamma} _ {3} ^ {*}, \hat {L} _ {1} ^ {*}, \hat {L} _ {2} ^ {*}, \hat {L} _ {3} ^ {*}\right) = \left\{\left(w, \ell_ {1}, \ell_ {2}, L _ {1}, L _ {2}\right): w \in \mathcal {L} \left(\hat {\Psi} _ {1} ^ {*}, \hat {\Gamma} _ {3} ^ {*}, \hat {L} _ {3} ^ {*}\right), L _ {1} = \hat {L} _ {1} ^ {*}, L _ {2} = \hat {L} _ {2} ^ {*} \right\}
$$

where $\mathcal { L } \left( \hat { \Psi } _ { 1 } ^ { * } , \hat { \Gamma } _ { 3 } ^ { * } , \hat { L } _ { 3 } ^ { * } \right)$ is the leaf of the foliation of $\hat { \Lambda }$ defined by (79). Fix $\eta > 0$ and $K _ { 1 } , K _ { 2 } \in \mathbb { N }$ , and choose some initial values $\dot { L } _ { 1 } ^ { 1 } , \dot { L } _ { 2 } ^ { 1 }$ of the variables $L _ { 1 } , L _ { 2 }$ so that $( \ell _ { 1 } , \ell _ { 2 } , L _ { 1 } ^ { 1 } , L _ { 2 } ^ { 1 } ) \in$ Int Σ for any $( \ell _ { 1 } , \ell _ { 2 } ) \in \mathbb { T } ^ { 2 }$ . Choose $N \le \varepsilon ^ { - K _ { 1 } } \mu ^ { - K _ { 2 } }$ , and values $P _ { * } ^ { 1 } , \ldots , P _ { * } ^ { N }$ of the actions $\hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 } , \hat { L } _ { 3 }$ such that the leaves $\mathcal { L } \left( P _ { * } ^ { j } \right)$ of the foliation of $\hat { \Lambda }$ are connected by one of the scattering maps of the secular Hamiltonian with $L _ { 1 } = L _ { 1 } ^ { 1 } , L _ { 2 } = L _ { 2 } ^ { 1 }$ in the sense of Lemma 26. Then by Theorem $3 7$ , there are $( L _ { 1 } ^ { 2 } , L _ { 2 } ^ { 2 } ) , \ldots , ( L _ { 1 } ^ { N } , L _ { 2 } ^ { N } ) \in \left[ L _ { 1 } ^ { - } , L _ { 1 } ^ { + } \right] ^ { \div } \times \left[ L _ { 2 } ^ { - } , L _ { 2 } ^ { \mp } \right]$ such that, with $\tilde { \mathcal { L } } _ { j } = \tilde { \mathcal { L } } \left( P _ { * } ^ { j } , L _ { 1 } ^ { j } , L _ { 2 } ^ { j } \right)$ , there are points $( z ^ { 1 } , \ell _ { 1 } ^ { 1 } , \ell _ { 2 } ^ { 1 } , L _ { 1 } ^ { 1 } , L _ { 2 } ^ { 1 } ) , \dots , ( z ^ { N } , \ell _ { 1 } ^ { N } , \ell _ { 2 } ^ { N } , L _ { 1 } ^ { N } , L _ { 2 } ^ { N } )$ in the phase space of the full four-body problem and times $t _ { j } ^ { * } > 0$ such that

$$
(z ^ {i + 1}, \ell_ {1} ^ {i + 1}, \ell_ {2} ^ {i + 1}, L _ {1} ^ {i + 1}, L _ {2} ^ {i + 1}) = \phi_ {4 \mathrm{bp}} ^ {t _ {j} ^ {*}} (z ^ {i}, \ell_ {1} ^ {i}, \ell_ {2} ^ {i}, L _ {1} ^ {i}, L _ {2} ^ {i}), d ((z ^ {i}, \ell_ {1} ^ {i}, \ell_ {2} ^ {i}, L _ {1} ^ {i}, L _ {2} ^ {i}), \tilde {\mathcal {L}} _ {i}) <   \eta
$$

where $\phi _ { 4 \mathrm { b p } } ^ { t }$ is the flow of the full four-body problem. Moreover the time estimate (82) also holds in this case as the order of the time required to move a distance of order $L _ { 3 }$ in the $L _ { 3 }$ variable and a distance of order $L _ { 2 }$ in the $\hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 }$ directions. This completes the proof of Theorem 2.

## 8 Proof of Theorems 1 and 3

In Section 7 the proof of Theorem 2 was completed; the purpose of this section is to show that the analysis of Sections $3 \textrm { - } 7$ extends to a complete proof of Theorems 1 and 3.

## 8.1 The planetary regime: Proof of Theorem 3

We consider now the planetary regime where the masses of bodies 1,2, and 3 are small with respect to body 0. However, in order to make this work we will see that the semimajor axis $a _ { 3 }$ depends on the small mass parameter.

Up to now we have investigated what we have called the strongly hierarchical regime, where the semimajor axes satisfy

$$
O (1) = a _ {1} \ll a _ {2} \rightarrow \infty \qquad \mathrm{and} \qquad a _ {2} ^ {3} \ll a _ {3}
$$

(’strong’ meaning that the ratio between $a _ { 2 }$ and $a _ { 3 }$ has to be rather large).

Now we assume that

$$
m _ {1}, m _ {2}, m _ {3} \sim \rho \rightarrow 0.
$$

That is, three masses are small and of comparable size. We scale the Deprit actions via

$$
L = \rho \check {L}, \quad \Gamma = \rho \check {\Gamma}, \quad \Psi = \rho \check {\Psi}
$$

where $L = ( L _ { 1 } , L _ { 2 } , L _ { 3 } ) , \Gamma = ( \Gamma _ { 1 } , \Gamma _ { 2 } , \Gamma _ { 3 } )$ , and $\Psi = ( \Psi _ { 1 } , \Psi _ { 2 } )$

Proposition 28. The instability mechanism which we have shown to exist in the hierarchical regime in Sections $\mathcal { B } \mathrm { - } \mathcal { I }$ continues in the planetary regime (i.e. as $\rho$ tends to 0) as long as the scaled total angular momentum $\check { \Psi } _ { 2 }$ satisfies

$$
\check {\Psi} _ {2} \gtrsim \rho^ {- 1 / 3}.
$$

Moreover, the instability time is of the order of $\rho ^ { - 3 1 / 3 }$

Proof. Write $m _ { j } = \rho \bar { m } _ { j } , j = 1 , 2 , 3$ , so that, when $\rho \ll 1$

$$
M _ {j} \sim 1, \quad \sigma_ {0, j} \sim 1, \quad \sigma_ {i j} \sim \rho \quad \text { and } \quad \mu_ {j} \sim \rho \quad (i, j = 1, 2, 3).
$$

Consider the Keplerian Hamiltonian of the third planet (see (20)),

$$
F _ {\mathrm{Kep,3}} = - \frac {\mu_ {3} ^ {3} M _ {3} ^ {2}}{2 L _ {3} ^ {2}}.
$$

If we express it in term of the scaled actions (18), we obtain

$$
F _ {\mathrm{Kep,3}} \sim \frac {\rho}{\check {L} _ {3} ^ {2}}. \qquad \mathrm{and} \qquad \dot {\ell} _ {3} \sim \frac {1}{\check {L} _ {3} ^ {3}}\tag{83}
$$

Proceeding analogously for the perturbing function, one can see that it scales diferently in $\rho .$ Indeed, consider for instance the part of the perturbing function $F _ { \mathrm { p e r } } ^ { 1 2 }$ regarding planets 1 and 2 (first introduced in equation (19)), written in terms of Legendre polynomials. that is

$$
F _ {\mathrm{per}} ^ {1 2} = - \frac {\mu_ {1} m _ {2}}{\| q _ {2} \|} \sum_ {n = 2} ^ {\infty} \tilde {\sigma} _ {1, n} P _ {n} (\cos \zeta_ {1}) \left(\frac {\| q _ {1} \|}{\| q _ {2} \|}\right) ^ {n} \sim \rho^ {2} \frac {\check {L} _ {1} ^ {4}}{\check {L} _ {2} ^ {6}}
$$

where

$$
\tilde {\sigma} _ {1, n} = \sigma_ {0 1} ^ {n - 1} + (- 1) ^ {n} \sigma_ {1 1} ^ {n - 1} \sim 1.
$$

Note that if one considers $\left\| q _ { 1 } \right\| , \left\| q _ { 2 } \right\|$ independent of $\rho ,$ this Hamiltonian has size of order $\rho ^ { 2 }$ . One obtains the same behavior for $F _ { \mathrm { p e r } } ^ { 2 3 }$

Now, for ${ \check { L } } _ { 3 }$ independent of $\rho \colon$ if one lets $\rho \to 0$ , the frequency of ${ \dot { \ell } } _ { 3 }$ becomes much faster than the other secular variables. This alters the hierarchy of time scales considered in the proof of Theorem 2.

To keep the hierarchy it is enough to choose $\check { \Psi } _ { 2 } \sim \check { L } _ { 3 }$ large enough depending on $\rho .$ Indeed, note that in Theorem $2 ,$ the only condition on $\Psi _ { 2 }$ is a lower bound and therefore one can take $1 \sim \check { L } _ { 1 } ^ { 0 } \ll \check { L } _ { 2 } ^ { 0 }$ independent of $\rho$ and $\check { \Psi } _ { 2 } \gtrsim \rho ^ { - 1 / 3 }$ , where the exponent of $- \frac { 1 } { 3 }$ comes from (83). Scaling time by a factor $\rho ^ { 2 }$ and applying the change of coordinates (28), one obtains a secular Hamiltonian whose associated Keplerian (for planet 3), quadrupolar, octupolar Hamiltonians have first orders independent of $\rho .$ Then, the proof of Theorem 2 applies. For this scaled model, the estimate (82) implies the innstability time is

$$
\check {T} \lesssim \frac {\check {L} _ {3} ^ {2 5}}{\check {L} _ {2} ^ {2 9}} \lesssim \check {L} _ {3} ^ {2 5} \rho^ {- 2 9 / 3}.
$$

Scaling back time by the factor $\rho ^ { 2 }$ , one obtains

$$
T \sim \rho^ {- 3 5 / 3}.
$$

## 8.2 Proof of Theorem 1

Theorem 1 and the comments stated after it are a direct consequence of the proof of Theorems 2 and 3. Indeed, to prove Theorem 1 it is enough to deduce the evolution of the orbital elements and the normalised angular momentum vector from that of the Deprit variables in Theorem 2 and their definitions in Section 2.1 (see, in particular (11), (12) and (13)). The normalised angular momentum vector ${ \tilde { C } } _ { 2 }$ is determined by the eccentricity $e _ { 2 } .$ the mutual inclination $\theta _ { 2 3 }$ of bodies 2 and 3, and the longitude $h _ { 2 }$ of the node of planet 2. It can easily be checked that Theorems 2 and 3 imply that we can vary the eccentricity $e _ { 2 } .$ and the mutual inclination $\theta _ { 2 3 }$ in any way we like up to some small error term by varying $\Gamma _ { 2 } , \Gamma _ { 3 }$ (see (11) and (13)). The angle $h _ { 2 }$ is determined by angles on the normally hyperbolic cylinder. Although not stated explicitly in Theorems 2 and 3 or in Section 7, it is clear that the shadowing methods of [14] also allow us to shadow values of the angles on the cylinder by time shifts of the flow, and so we can control $h _ { 2 }$ in the same way that we control the actions. See Section 9 of [13] for an elaboration of this discussion. The time estimates in (3) are also provided by Theorem 2. Finally the analysis of the planetary regime and the time estimates in (4) are a consequence of Theorem 3.

## A A refinement of Moser’s trick

In Section 5 (see Lemma 17), we prove that there is a near-identity coordinate transformation that straightens the restriction to the normally hyperbolic invariant manifold of the symplectic form. If we were to proceed with this proof, for example, as in Lemma 23 of [13], we would see that the coordinate transformation in the action $\bar { \Psi } _ { 1 }$ would dominate the transformation coming from the averaging (i.e. Lemma 18). This would be problematic, as the computation of the coordinate transformation that straightens the symplectic form is significantly more complicated than that of the coordinate transformation that averages the inner angles. Instead, we notice that the first two terms in the Taylor expansion of the parametrisation of the normally hyperbolic manifold do not depend on the angle $\ddot { \psi } _ { 1 }$ (see Lemma 16); from a symplectic point of view, it seems natural therefore that the coordinate transformation straightening the symplectic form should not alter its symplectic conjugate $\tilde { \Psi } _ { 1 }$ . However, this coordinate transformation (provided by Moser’s trick from his proof of Darboux’s theorem) is obviously not symplectic, and so it is not clear a priori that this is the case. Below we provide a proof of this fact.

Denote by M a symplectic manifold of dimension $6 ,$ and by $\left( q _ { 0 } , q _ { 1 } , q _ { 2 } , p _ { 0 } , p _ { 1 } , p _ { 2 } \right)$ coordinates on M such that the symplectic form is

$$
\Omega = d \lambda = \sum_ {i = 0} ^ {2} d q _ {i} \wedge d p _ {i} \quad \text { where } \quad \lambda = - \sum_ {i = 0} ^ {2} p _ {i} d q _ {i}.
$$

Write $q = ( q _ { 1 } , q _ { 2 } ) , p = ( p _ { 1 } , p _ { 2 } )$ , and suppose $\Lambda \subset M$ is a submanifold of M that can be written as the graph of a function $\rho = ( \rho _ { q } , \rho _ { p } )$ in the sense that

$$
\Lambda = \{(q _ {0}, q, p _ {0}, p) \in M: q _ {0} = \rho_ {q} (q, p), p _ {0} = \rho_ {p} (q, p), (q, p) \in U \}
$$

for some domain U. Suppose moreover that $\rho = O ( \varepsilon )$ does not depend on $q _ { 2 } ;$ this can be expressed as $\rho = \varepsilon \rho ^ { \prime } ( q _ { 1 } , p )$ , where $\rho ^ { \prime } = ( \rho _ { q } ^ { \prime } , \rho _ { p } ^ { \prime } )$ . Let $\hat { \varepsilon } = \varepsilon ^ { 2 }$ , and write

$$
\Omega^ {\prime} = \left. \Omega \right| _ {\Lambda} = \hat {\varepsilon} d \rho_ {q} ^ {\prime} \wedge d \rho_ {p} ^ {\prime} + \Omega_ {0}, \quad \lambda^ {\prime} = \left. \lambda \right| _ {\Lambda} = - \hat {\varepsilon} \rho_ {p} ^ {\prime} d \rho_ {q} ^ {\prime} + \lambda_ {0}
$$

where

$$
\Omega_ {0} = \sum_ {i = 1} ^ {2} d q _ {i} \wedge d p _ {i}, \quad \lambda_ {0} = - \sum_ {i = 1} ^ {2} p _ {i} d q _ {i}.
$$

The goal is to find a coordinate transformation h on Λ that is $O ( \hat { \varepsilon } )$ -close to the identity such that $h ^ { * } \Omega ^ { \prime } = \Omega _ { 0 }$ Moser’s trick (see the proof of Lemma 17 for the precise construction) is to construct h as the time-ˆε map of a nonautonomous vector field $X _ { t }$ satisfying

$$
i _ {X _ {\hat {\varepsilon}}} \Omega^ {\prime} = - \frac {d}{d \hat {\varepsilon}} \lambda^ {\prime}.\tag{84}
$$

Lemma 29. Denote by h the time-εˆ map of the vector field $X _ { t }$ defined by (84). Then h has the form

$$
h: \left\{ \begin{array}{l l} \bar {q} _ {1} = & q _ {1} + \hat {\varepsilon}   f _ {1} (q _ {1}, p) \\ \bar {q} _ {2} = & q _ {2} + \hat {\varepsilon}   f _ {2} (q _ {1}, p) \\ \bar {p} _ {1} = & p _ {1} + \hat {\varepsilon}   f _ {3} (q _ {1}, p) \\ \bar {p} _ {2} = & p _ {2}. \end{array} \right.
$$

Proof. Notice we can write

$$
d \rho_ {q} ^ {\prime} \wedge d \rho_ {p} ^ {\prime} = A _ {1 3} d q _ {1} \wedge d p _ {1} + A _ {1 4} d q _ {1} \wedge d p _ {2} + A _ {3 4} d p _ {1} \wedge d p _ {2}
$$

where

$$
\left\{ \begin{array}{l l} A _ {1 3} = & \partial_ {q _ {1}} \rho_ {q} ^ {\prime} \partial_ {p _ {1}} \rho_ {p} ^ {\prime} - \partial_ {q _ {1}} \rho_ {p} ^ {\prime} \partial_ {p _ {1}} \rho_ {q} ^ {\prime} \\ A _ {1 4} = & \partial_ {q _ {1}} \rho_ {q} ^ {\prime} \partial_ {p _ {2}} \rho_ {p} ^ {\prime} - \partial_ {q _ {1}} \rho_ {p} ^ {\prime} \partial_ {p _ {2}} \rho_ {q} ^ {\prime} \\ A _ {3 4} = & \partial_ {p _ {1}} \rho_ {q} ^ {\prime} \partial_ {p _ {2}} \rho_ {p} ^ {\prime} - \partial_ {p _ {1}} \rho_ {p} ^ {\prime} \partial_ {p _ {2}} \rho_ {q} ^ {\prime}. \end{array} \right.
$$

Writing $\Omega ^ { \prime }$ in matrix form, we have

$$
\Omega^ {\prime} = \Omega_ {0} + \hat {\varepsilon}   A \quad \text { where } \quad \Omega_ {0} = \left( \begin{array}{c c} 0 & I \\ - I & 0 \end{array} \right), \quad I = \left( \begin{array}{c c} 1 & 0 \\ 0 & 1 \end{array} \right)\tag{85}
$$

and

$$
A = \left( \begin{array}{c c c c} 0 & 0 & A _ {1 3} & A _ {1 4} \\ 0 & 0 & 0 & 0 \\ - A _ {1 3} & 0 & 0 & A _ {3 4} \\ - A _ {1 4} & 0 & - A _ {3 4} & 0 \end{array} \right).\tag{86}
$$

On the other hand we can write

$$
\rho_ {p} ^ {\prime} d \rho_ {q} ^ {\prime} = a _ {1} d q _ {1} + a _ {3} d p _ {1} + a _ {4} d p _ {2}
$$

where

$$
\left\{ \begin{array}{l l} a _ {1} = & \rho_ {p} ^ {\prime} \partial_ {q _ {1}} \rho_ {q} ^ {\prime} \\ a _ {3} = & \rho_ {p} ^ {\prime} \partial_ {p _ {1}} \rho_ {q} ^ {\prime} \\ a _ {4} = & \rho_ {p} ^ {\prime} \partial_ {p _ {2}} \rho_ {q} ^ {\prime} \end{array} \right.
$$

so we can write $\lambda ^ { \prime }$ in vector form as

$$
\lambda^ {\prime} = \lambda_ {0} + \hat {\varepsilon}   a \quad \text { where } \quad \lambda_ {0} = - \left( \begin{array}{c} p _ {1} \\ p _ {2} \\ 0 \\ 0 \end{array} \right), \quad a = - \left( \begin{array}{c} a _ {1} \\ 0 \\ a _ {3} \\ a _ {4} \end{array} \right).\tag{87}
$$

Now, let $X _ { \hat { \varepsilon } } = ( \dot { q } , \dot { p } )$ . Then from (85) and (86), we see that the left-hand side of (84) is

$$
i _ {X _ {\hat {\varepsilon}}} \Omega^ {\prime} = X _ {\hat {\varepsilon}} ^ {T}   \Omega_ {0} + \hat {\varepsilon}   X _ {\hat {\varepsilon}} ^ {T}   A = \left( \begin{array}{c} - \dot {p} _ {1} \\ - \dot {p} _ {2} \\ \dot {q} _ {1} \\ \dot {q} _ {2} \end{array} \right) + \hat {\varepsilon} \left( \begin{array}{c} - A _ {1 3}   \dot {p} _ {1} - A _ {1 4}   \dot {p} _ {2} \\ 0 \\ A _ {1 3}   \dot {q} _ {1} - A _ {3 4}   \dot {p} _ {2} \\ A _ {1 4}   \dot {q} _ {1} + A _ {3 4}   \dot {p} _ {1} \end{array} \right).\tag{88}
$$

Meanwhile (87) implies that the right-hand side of (84) is

$$
- \frac {d}{d \hat {\varepsilon}} \lambda^ {\prime} = \left( \begin{array}{c} a _ {1} + \hat {\varepsilon} \partial_ {\hat {\varepsilon}} a _ {1} \\ 0 \\ a _ {3} + \hat {\varepsilon} \partial_ {\hat {\varepsilon}} a _ {3} \\ a _ {4} + \hat {\varepsilon} \partial_ {\hat {\varepsilon}} a _ {4} \end{array} \right).\tag{89}
$$

Combining (88) and (89) yields

$$
\left( \begin{array}{c} \dot {q} _ {1} \\ \dot {q} _ {2} \\ \dot {p} _ {1} \\ \dot {p} _ {2} \end{array} \right) = \left( \begin{array}{c} a _ {3} + \hat {\varepsilon} \partial_ {\hat {\varepsilon}} a _ {3} - \hat {\varepsilon} (A _ {1 3} \dot {q} _ {1} - A _ {3 4} \dot {p} _ {2}) \\ a _ {4} + \hat {\varepsilon} \partial_ {\hat {\varepsilon}} a _ {4} - \hat {\varepsilon} (A _ {1 4} \dot {q} _ {1} + A _ {3 4} \dot {p} _ {1}) \\ - a _ {1} - \hat {\varepsilon} \partial_ {\hat {\varepsilon}} a _ {1} + \hat {\varepsilon} (A _ {1 3} \dot {p} _ {1} + A _ {1 4} \dot {p} _ {2}) \\ 0 \end{array} \right)
$$

which completes the proof of the lemma.

## B The scattering map of a normally hyperbolic invariant manifold

In this section we denote by $M \mathrm { ~ a ~ } C ^ { r }$ smooth manifold, and by $\phi ^ { t } : M \to M$ a smooth flow with $\textstyle { \frac { d } { d t } } | _ { t = 0 } \phi ^ { t } = X$ where $X \in C ^ { r } ( M , T M )$ . Let $\Lambda \subset M$ be a compact $\phi ^ { t } .$ -invariant submanifold, possibly with boundary. By φ<sup>t</sup>-invariant we mean that X is tangent to Λ, but that orbits can escape through the boundary (a concept sometimes referred to as local invariance).

Definition 30. We call Λ a normally hyperbolic invariant manifold for φ<sup>t</sup> if there is $0 < \lambda < \mu ^ { - 1 }$ , a positive constant C and an invariant splitting of the tangent bundle

$$
T _ {\Lambda} M = T \Lambda \oplus E ^ {s} \oplus E ^ {u}
$$

such that:

$$
\| D \phi^ {t} | _ {E ^ {s}} \| \leq C \lambda^ {t} f o r a l l t \geq 0,
$$

$$
\left\| D \phi^ {t} \right| _ {E ^ {u}} \| \leq C \lambda^ {- t} f o r a l l t \leq 0,
$$

$$
\| D \phi^ {t} | _ {T \Lambda} \| \leq C \mu^ {| t |} f o r a l l t \in \mathbb {R}.
$$

Moreover, Λ is called an r-normally hyperbolic invariant manifold $i f$ it is $C ^ { r }$ smooth, and

$$
0 <   \lambda <   \mu^ {- r} <   1\tag{90}
$$

$f o r \ r \geq 1$ . This is called a large spectral gap condition.

This definition guarantees the existence of stable and unstable invariant manifolds $W ^ { s , u } ( \Lambda ) \subset M$ defined as follows. The local stable manifold $W _ { \mathrm { l o c } } ^ { s } ( \Lambda )$ is the set of points in a small neighbourhood of Λ whose forward orbits never leave the neighbourhood, and tend exponentially to Λ. The local unstable manifold $W _ { \mathrm { l o c } } ^ { u } ( \Lambda )$ is the set of points in the neighbourhood whose backward orbits stay in the neighbourhood and tend exponentially to Λ. We then define

$$
W ^ {s} (\Lambda) = \bigcup_ {t \geq 0} ^ {\infty} \phi^ {- t} \left(W _ {\mathrm{loc}} ^ {s} (\Lambda)\right), \quad W ^ {u} (\Lambda) = \bigcup_ {t \geq 0} ^ {\infty} \phi^ {t} \left(W _ {\mathrm{loc}} ^ {u} (\Lambda)\right).
$$

On the stable and unstable manifolds we have the strong stable and strong unstable foliations, the leaves of which we denote by $W ^ { s , u } ( x )$ for $x \in \Lambda$ . For each $x \in \Lambda$ , the leaf $W ^ { s } ( x )$ of the strong stable foliation is tangent at x to $E _ { x } ^ { s }$ , and the leaf $W ^ { u } ( x )$ of the strong unstable foliation is tangent at x to $E _ { x } ^ { u }$ . Moreover the foliations are invariant in the sense that $\phi ^ { t } \left( W ^ { s } ( x ) \right) = W ^ { s } \left( \phi ^ { t } ( x ) \right)$ and $\phi ^ { t } \left( W ^ { u } ( x ) \right) = W ^ { u } \left( \phi ^ { t } \tilde { ( x ) } \right)$ ) for each $x \in \Lambda$ and $t \in \mathbb { R }$ . We thus define the holonomy maps $\pi ^ { s , u } : W ^ { s , u } ( \Lambda ) \to \Lambda$ to be projections along leaves of the strong stable and strong unstable foliations. That is to say, if $x \in W ^ { s } ( \Lambda )$ then there is a unique $x _ { + } \in \Lambda$ such that $x \in W ^ { s } ( x _ { + } )$ , and so $\pi ^ { s } ( x ) = x _ { + }$ . Similarly, if $x \in W ^ { u } ( \Lambda )$ then there is a unique $x _ { - } \in \Lambda$ such that $x \in W ^ { u } ( x _ { - } )$ , in which case $\pi ^ { u } ( x ) = x _ { - }$

Now, suppose that $x \in ( W ^ { s } ( \Lambda )$ ⋔ $W ^ { u } ( \Lambda ) ) \setminus \Lambda$ is a transverse homoclinic point such that $x \in W ^ { s } ( x _ { + } ) \cap$ $W ^ { u } ( x _ { - } )$ . We say that the homoclinic intersection at x is strongly transverse if

$$
\begin{array}{c} T _ {x} W ^ {s} (x _ {+}) \oplus T _ {x} \left(W ^ {s} (\Lambda) \cap W ^ {u} (\Lambda)\right) = T _ {x} W ^ {s} (\Lambda), \\ T _ {x} W ^ {u} (x _ {-}) \oplus T _ {x} \left(W ^ {s} (\Lambda) \cap W ^ {u} (\Lambda)\right) = T _ {x} W ^ {u} (\Lambda). \end{array}\tag{91}
$$

In this case we can take a suficiently small neighbourhood Γ of x in $W ^ { s } ( \Lambda ) \cap W ^ { u } ( \Lambda )$ so that (91) holds at each point of $\Gamma ,$ and the restrictions to Γ of the holonomy maps are bijections onto their images. We call Γ a homoclinic channel (see Figure 1). We can then define the scattering map as follows [19].

Definition 31. Let $y _ { - } \in \pi ^ { u } \left( \Gamma \right)$ , let $y = ( \pi ^ { u } | _ { \Gamma } ) ^ { - 1 } ( y _ { - } )$ , and let $y _ { + } = \pi ^ { s } ( y )$ . The scattering map $S$ : $\pi ^ { u } ( \Gamma ) \to \pi ^ { s } ( \Gamma )$ is defined by

$$
S = \pi^ {s} \circ (\pi^ {u}) ^ {- 1}: y _ {-} \longmapsto y _ {+}.
$$

![](images/67005c936f395baee87584080077f33930565a048b1a307c19d0f0a7546ac7df.jpg)  
Figure 1: The scattering map $S$ takes a point $x _ { - } \in \Lambda$ , follows the unique leaf of the strong unstable foliation passing through $x _ { - }$ to the point x in the homoclinic channel Γ, and from there follows the unique leaf of the strong stable foliation passing through x to the point $x _ { + }$ on $\Lambda$

Suppose now that the smoothness r of M and X is at least 2, suppose the normally hyperbolic invariant manifold Λ is a $C ^ { r }$ submanifold of $M ,$ and suppose the large spectral gap condition (90) holds. This implies $C ^ { r - 1 }$ regularity of the strong stable and strong unstable foliations [42], which in turn implies that the scattering map S is $C ^ { r - 1 } \ \left\lceil 1 9 \right\rceil$

In general, the scattering map may be defined only locally, as the transverse homoclinic intersection of stable and unstable manifolds can be very complicated; however in the setting of the present paper, the scattering maps we study turn out to be globally defined.

## C A general shadowing argument

We follow the notation and exposition of [14]. Let M be a $C ^ { r }$ manifold of dimension $d = 2 ( m + n )$ where $r \geq 4$ . Let $F \in \operatorname { D i f f } ^ { 4 } ( M )$ , and assume F depends smoothly on a small parameter $\epsilon ,$ with uniformly bounded derivatives. Suppose $F$ has a normally hyperbolic invariant (or locally invariant) manifold $\Lambda \subset M$ of dimension 2n satisfying the large spectral gap condition (90); suppose moreover that Λ is difeomorphic to $\mathbb { T } ^ { n } \times [ 0 , 1 ] ^ { n }$ . Furthermore, we assume that dim $W ^ { s } ( \Lambda ) =$ dim $W ^ { u } ( \Lambda ) = m + 2 n$ . In order to state the remaining assumptions and the shadowing theorems, we must consider some definitions.

Suppose the scattering map S is defined relative to a homoclinic channel Γ for all suficiently small $\epsilon > 0$ We allow for the possibility that the angle between $W ^ { s , u } ( \Lambda )$ along the homoclinic channel Γ goes to 0 as $\epsilon  0$ . Denote by $\alpha ( v _ { 1 } , v _ { 2 } )$ the angle between two vectors $v _ { 1 } , v _ { 2 }$ in the direction that yields the smallest result $( \mathrm { i . e . ~ } \alpha ( v _ { 1 } , v _ { 2 } ) \in [ 0 , \pi ] )$ . For $x \in \Gamma$ , let

$$
\alpha_ {\Gamma} (x) = \inf \alpha (v _ {+}, v _ {-})
$$

where the infimum is over all $v _ { + } \in T _ { x } W ^ { s } ( \Lambda ) ^ { \perp }$ and $v _ { - } \in T _ { x } W ^ { u } ( \Lambda ) ^ { - }$ ⊥ such that $\| v _ { \pm } \| = 1$

Definition 32. For $\sigma \geq 0$ , we say that the angle of the splitting along Γ is of order $\epsilon ^ { \sigma } \textit { i f }$ there is a positive constant C (independent $o f \epsilon )$ such that

$$
\alpha_ {\Gamma} (x) \geq C \epsilon^ {\sigma} \quad \text {   for   all   } x \in \Gamma .
$$

Recall we have assumed that the normally hyperbolic invariant manifold Λ is difeomorphic to $\mathbb { T } ^ { n } \times [ 0 , 1 ] ^ { n }$ 2 and denote by $( q , p ) \in \mathbb { T } ^ { n } \times [ 0 , 1 ] ^ { n }$ smooth coordinates on Λ. Define $f : = F | _ { \Lambda }$ , which also depends on the small parameter ǫ.

Definition 33. We say that $f : \Lambda \to \Lambda$ is a near-integrable twist map if there is some $k \in \mathbb N$ such that

$$
f: \left\{ \begin{array}{l} \bar {q} = q + g (p) + O (\epsilon^ {k}) \\ \bar {p} = p + O (\epsilon^ {k}) \end{array} \right.
$$

where

$$
\det D g (p) \neq 0
$$

for all $p \in [ 0 , 1 ] ^ { n }$ , and where the higher order terms are uniformly bounded in the $C ^ { 1 }$ topology. If the higher order terms are 0 then f is an integrable twist map.

It follows from the definition that if $f : \Lambda \to \Lambda$ is a near-integrable twist map, then there exist twist parameters $T _ { + } > \widetilde { T } _ { - } > 0$ such that

$$
\widetilde {T} _ {-} \| v \| \leq \| D g (p) v \| \leq T _ {+} \| v \|
$$

for all $p \in [ 0 , 1 ] ^ { n }$ and all $v \in \mathbb { R } ^ { n }$ . We can always choose $T _ { + }$ to be independent of ǫ. Our formulation of the problem allows the parameter $\smash { \widetilde { T } _ { - } }$ to depend on ǫ: there is $\tau \in  { \mathbb { N } } _ { 0 }$ and a strictly positive constant $T _ { - }$ (independent of ǫ) such that $\tilde { T } _ { - } = \epsilon ^ { \tau } T _ { - }$ .

Definition 34. Suppose $f : \Lambda \to \Lambda$ is a near-integrable twist map. Denote by $T _ { + } > \widetilde { T } _ { - } = \epsilon ^ { \tau } T _ { - } > 0$ the twist parameters. We say that f satisfies:

• A uniform twist condition $i f \tau = 0 ;$

• A non-uniform twist condition (of order $\epsilon ^ { \tau } ) \ i f \ \tau > \ 0$ , and the order $\epsilon ^ { k }$ of the error terms in the definition of the near-integrable twist map f is such that $k > \tau$

In the coordinates $( q , p )$ , we may define a foliation of Λ, the leaves of which are given by

$$
\Lambda (p ^ {*}) = \{(q, p) \in \Lambda : p = p ^ {*} \}.\tag{92}
$$

If $f : \Lambda \to \Lambda$ is a near-integrable twist map in the sense of Definition 33, then each leaf of the foliation is almost invariant under $f ,$ up to terms of order $\epsilon ^ { k }$ . Denote by $U \subset \Lambda$ the domain of definition of the scattering map $S .$

Definition 35. We say that the scattering map S is transverse to leaves along leaves, and that the angle of transversality is of order $\epsilon ^ { v }$ (with respect to the leaves (92) of the foliation of Λ) if there are $c , C > 0$ such that for all $p _ { 0 } ^ { * } \in [ 0 , 1 ] ^ { n }$ and all $p ^ { * } \in [ 0 , 1 ] ^ { n }$ satisfying $\| p ^ { * } - p _ { 0 } ^ { * } \| < c \epsilon ^ { v }$ we have

$$
S \left(\Lambda (p _ {0} ^ {*}) \cap U\right) \pitchfork \Lambda (p ^ {*}) \neq \emptyset
$$

and there is $x \in S \left( \Lambda ( p _ { 0 } ^ { * } ) \cap U \right) \pitchfork \Lambda ( p ^ { * } )$ such that

$$
\inf \alpha (v _ {0}, v) \geq C \epsilon^ {v}
$$

where the infimum is taken over all v<sub>0</sub> $\in T _ { x } S \left( \Lambda ( p _ { 0 } ^ { * } ) \cap U \right)$ and $v \in T _ { x } \Lambda ( p ^ { * } )$ such that $\| v _ { 0 } \| = \| v \| = 1$

Using these definitions, we may now state the main assumptions of the first shadowing theorem, which will be applied to the secular Hamiltonian (32) to prove the existence of drifting orbits in the secular subsystem.

[A1] The stable and unstable manifolds $W ^ { s , u } ( \Lambda )$ have a strongly transverse homoclinic intersection along a homoclinic channel Γ, and so we have an open set $U \subseteq \Lambda$ and a scattering map $S : U \to \Lambda$ . The angle of the splitting along Γ is of order $\epsilon ^ { \sigma }$

[A2] The inner map $f = F | _ { \Lambda }$ is a near-integrable twist map with error terms of order $\epsilon ^ { k }$ satisfying a nonuniform (or uniform) twist condition of order $\epsilon ^ { \tau }$

[A3] The scattering map $S$ is transverse to leaves along leaves (with respect to the leaves (92) of the foliation of $\Lambda )$ , and the angle of transversality is of order $\epsilon ^ { v }$

Theorem 36. Fix $\eta \ > \ 0 _ { : }$ , let $\epsilon \ > \ 0$ be suficiently small, and suppose $k \ \geq \ 2 \left( \rho + \tau \right) + 1$ where $\rho = \operatorname* { m a x } \{ 2 \sigma , 2 v , \tau \}$ . Choose $\{ p _ { j } ^ { * } \} _ { j = 1 } ^ { \infty } \subset [ 0 , 1 ] ^ { n }$ such that

$$
S \left(\Lambda_ {j} \cap U\right) \cap \Lambda_ {j + 1} \neq \emptyset ,
$$

and $S \left( \Lambda _ { j } \cap U \right)$ is transverse to $\Lambda _ { j + 1 }$ , where $\Lambda _ { j } = \Lambda ( p _ { i } ^ { * } )$ . Suppose the distance between $\Lambda _ { j }$ and $\Lambda _ { j + 1 }$ is of order $\epsilon ^ { v }$ for each j. Then there are $\{ z _ { i } \} _ { i = 1 } ^ { \infty } \subset M$ and $\bar { n _ { i } } \in \mathbb { N }$ such that $z _ { i + 1 } = F ^ { n _ { i } } ( z _ { i } )$ and

$$
d (z _ {i}, \Lambda_ {i}) <   \eta .
$$

Moreover, the time to move a distance of order 1 in the p-direction is bounded from above by a term of order

$$
\epsilon^ {- \rho - \tau - v}.\tag{93}
$$

Observe that Theorem 36 cannot be applied to (21). Indeed, a crucial assumption in Theorem 36 is that the scattering map S is transverse to leaves along leaves. For (21), we have no information about the behaviour of the scattering map in the $L _ { i }$ directions, and so we cannot check assumption [A3] for the Hamiltonian (21). Theorem 37 below generalises Theorem 36 to settings where transversality is only known in some directions, and thus allows us to complete the proof of Theorem 2.

To state Theorem 37 we consider, as before, a $C ^ { r }$ manifold M of dimension $2 ( m + n )$ where $r \geq 4$ and $m , n \in \mathbb { N }$ . Let $\Sigma = \mathbb { T } ^ { \ell _ { 1 } } \times [ 0 , 1 ] ^ { \ell _ { 2 } }$ for some $\ell _ { 1 } , \ell _ { 2 } \in  { \mathbb { N } } _ { 0 }$ , and denote by $( \theta , \xi ) \in \mathbb { T } ^ { \ell _ { 1 } } \times [ 0 , 1 ] ^ { \ell _ { 2 } }$ coordinates on $\Sigma .$ . Write $\widetilde { M } = M \times \Sigma$ . Suppose $\Psi \in \operatorname { D i f f } ^ { 4 } \left( { \widetilde { M } } \right)$ such that

$$
\Psi (z, \theta , \xi) = (G (z, \theta , \xi), \phi (z, \theta , \xi))
$$

where $z \in M , G \in C ^ { 4 } \left( { \widetilde { M } } , M \right)$ , and $\phi \in C ^ { 4 } \left( { \widetilde { M } } , \Sigma \right)$ . Suppose Ψ depends on a small parameter ǫ. We make fthe following assumptions on Ψ.

[B1] There is some $L \in \mathbb { N }$ such that

$$
G (z, \theta , \xi) = \widetilde {G} (z; \xi) + O \left(\epsilon^ {L}\right)
$$

where the higher order terms are uniformly bounded in the $C ^ { 4 }$ topology, and for each $\xi \in [ 0 , 1 ] ^ { \ell _ { 2 } }$ the map

$$
\widetilde {G} (\cdot ; \xi): z \in M \longmapsto \widetilde {G} (z; \xi) \in M
$$

satisfies the assumptions [A1-3] of Theorem 36.

[B2] Moreover, the map φ has the form

$$
\phi : \left\{ \begin{array}{l} \bar {\theta} = \phi_ {1} (z, \theta , \xi) \\ \bar {\xi} = \phi_ {2} (z, \theta , \xi) = \xi + O \left(\epsilon^ {L}\right) \end{array} \right.
$$

where the higher order terms are uniformly bounded in the $C ^ { 4 }$ topology.

Results from [19] imply that Ψ has a normally hyperbolic invariant manifold $\widetilde { \Lambda }$ that is $O \left( \epsilon ^ { L } \right)$ close in the $C ^ { 4 }$ topology to $\Lambda \times \Sigma$ where $\Lambda \subset M$ eis the normally hyperbolic invariant manifold of $\widetilde G ( \cdot ; \xi )$ . Moreover there is an open set $\widetilde U \subset \widetilde \Lambda$ and a scattering map $\widetilde { S } : \widetilde { U } \to \widetilde { \Lambda }$ such that the z-component of $\widetilde { S } ( z , \theta , \xi )$ is $O \left( \epsilon ^ { L } \right)$ close in the $C ^ { 3 }$ e etopology to $S \left( z ; \xi \right)$ where $S ( \cdot ; \xi ) : U  \Lambda$ e e is the scattering map corresponding to $\widetilde G ( \cdot ; \xi )$

We use the coordinates $( q , p , \theta , \xi )$ on $\widetilde { \Lambda }$ where $( q , p )$ are the coordinates on Λ and $( \theta , \xi )$ eare the coordinates on Σ. Notice that the sets

$$
\widetilde {\Lambda} \left(p ^ {*}, \xi^ {*}\right) = \left\{\left(q, p, \theta , \xi\right) \in \widetilde {\Lambda}: p = p ^ {*}, \xi = \xi^ {*} \right\} = \Lambda \left(p ^ {*}\right) \times \mathbb {T} ^ {\ell_ {1}} \times \left\{\xi^ {*} \right\}
$$

for $p ^ { * } \in [ 0 , 1 ] ^ { n }$ and $\xi ^ { * } \in [ 0 , 1 ] ^ { \ell _ { 2 } }$ define the leaves of a foliation of $\widetilde { \Lambda } .$ , where $\Lambda ( p ^ { * } )$ are the leaves of the foliation of Λ defined by (92).

Theorem 37. Fix $\eta > 0$ and $K \in \mathbb N$ and let $\epsilon > 0$ be suficiently small. Choose $N \in \mathbb N$ satisfying

$$
N \leq \frac {1}{\epsilon^ {K}}
$$

$\xi _ { 1 } ^ { * } \in \mathrm { I n t } \left( [ 0 , 1 ] ^ { \ell _ { 2 } } \right)$ so that $\widetilde { G } ( \cdot ; \xi _ { 1 } ^ { * } )$ satisfies assumptions $[ A I - { \mathcal { B } } ] ,$ and $p _ { 1 } ^ { * } , . . . , p _ { N } ^ { * } \in [ 0 , 1 ] ^ { n }$ as in Theorem 36 such that

$$
S \left(\Lambda_ {j} \cap U; \xi_ {1} ^ {*}\right) \cap \Lambda_ {j + 1} \neq \emptyset
$$

and $S \left( \Lambda _ { j } \cap U ; \xi _ { 1 } ^ { * } \right)$ is transverse to $\Lambda _ { j + 1 }$ , where $\Lambda _ { j } = \Lambda ( p _ { j } ^ { * } )$ . Suppose the distance between $\Lambda _ { j }$ and $\Lambda _ { j + 1 }$ is of order $\epsilon ^ { v }$ for each $j ,$ and $L > 0$ is suficiently large, depending on $K$ . Then there are $\xi _ { 2 } ^ { * } , \ldots , \xi _ { N } ^ { * } \in [ 0 , 1 ] ^ { \ell _ { 2 } }$ such that, with $\widetilde { \Lambda } _ { j } = \widetilde { \Lambda } \left( p _ { j } ^ { * } , \xi _ { j } ^ { * } \right)$ , there are $w _ { 1 } , \ldots , w _ { N } \in \widetilde { M }$ and $n _ { i } \in \mathbb { N }$ such that the $\xi$ component of w<sub>1</sub> is $\xi _ { 1 } ^ { * }$

$$
w _ {i + 1} = \Psi^ {n _ {i}} (w _ {i}),
$$

and

$$
d \left(w _ {i}, \widetilde {\Lambda} _ {i}\right) <   \eta
$$

where $\rho , \sigma , \tau$ are as in the statement of Theorem 36. Moreover, the time to move a distance of order 1 in the p-direction is of order $\epsilon ^ { - \rho - \tau - \upsilon }$

Note that the transition chain obtained in Theorem 37 is only of finite length, while the one obtained in Theorem 36 may be infinite.

## D Derivatives of the inner Hamiltonian

Recall the definition of the integrable part $\hat { F } _ { 0 }$ of the inner secular Hamiltonian, after straightening the symplectic form and averaging the inner angles, as constructed in Theorem 15. In order to prove in Lemma 25 that the Poincar´e map satisfies a twist condition, we need to compute the first and second partial derivatives of $\hat { F } _ { 0 }$ with respect to the inner actions, or in some cases simply estimate the order. This information is provided in the following lemma.

Lemma 38. The first and second-order partial derivatives of $\hat { F } _ { 0 }$ with respect to the actions $\hat { \Gamma } _ { 2 } , \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 }$ , and ${ \hat { L } } _ { 3 }$ are as follows:

$$
\frac {\partial \hat {F} _ {0}}{\partial \hat {\Gamma} _ {2}} = \varepsilon^ {6} C _ {1 2} \frac {6 \hat {\Gamma} _ {2}}{L _ {1} ^ {2} \delta_ {1} ^ {3}} + \dots ,
$$

$$
\frac {\partial \hat {F} _ {0}}{\partial \hat {\Psi} _ {1}} = 3 \varepsilon^ {7} C _ {1 2} \frac {L _ {1} ^ {2} - 3 \hat {\Gamma} _ {2} ^ {2}}{L _ {1} ^ {2} \delta_ {1} ^ {4}} + \dots ,
$$

$$
\frac {\partial \hat {F} _ {0}}{\partial \hat {\Gamma} _ {3}} = \varepsilon^ {3} \mu^ {6} C _ {2 3} \frac {(2 0 - 1 2 \delta_ {1} ^ {2}) \delta_ {3}}{\delta_ {1} ^ {2} \delta_ {2} ^ {3}} + \dots ,
$$

$$
\frac {\partial \hat {F} _ {0}}{\partial \hat {L} _ {3}} = \varepsilon^ {3} \mu^ {3} \alpha_ {\mathrm{Kep}} + \dots ,
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {\Gamma} _ {2} ^ {2}} = \varepsilon^ {6} C _ {1 2} \frac {6}{L _ {1} ^ {2} \delta_ {1} ^ {3}} + \dots ,
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {\Gamma} _ {2} \partial \hat {\Psi} _ {1}} = - \varepsilon^ {7} C _ {1 2} \frac {1 8 \hat {\Gamma} _ {2}}{L _ {1} ^ {2} \delta_ {1} ^ {4}} + \dots ,
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {\Gamma} _ {2} \partial \hat {\Gamma} _ {3}} = \varepsilon^ {4} \mu^ {6} C _ {2 3} \frac {2 4 \delta_ {3}}{\delta_ {1} \delta_ {2} ^ {3}} + \dots ,
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {\Psi} _ {1} ^ {2}} = 1 2 \varepsilon^ {8} C _ {1 2} \frac {3 \hat {\Gamma} _ {2} ^ {2} - L _ {1} ^ {2}}{L _ {1} ^ {2} \delta_ {1} ^ {5}} + \dots ,
$$

$$
\frac {\partial^ {2} \hat {F _ {0}}}{\partial \hat {\Psi} _ {1} \partial \hat {\Gamma} _ {3}} = - \varepsilon^ {4} \mu^ {6} C _ {2 3} \frac {4 0 \delta_ {3}}{\delta_ {1} ^ {3} \delta_ {2} ^ {3}} + \dots ,
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {\Gamma} _ {3} ^ {2}} = \varepsilon^ {4} \mu^ {6} C _ {2 3} \frac {2 0 - 1 2 \delta_ {1} ^ {2}}{\delta_ {1} ^ {2} \delta_ {2} ^ {3}} + \dots ,
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {L} _ {3} ^ {2}} = - 3 \varepsilon^ {4} \mu^ {4} \alpha_ {\mathrm{Kep}} + \dots ,
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {L} _ {3} \partial \hat {\Gamma} _ {2}} = O (\varepsilon^ {4} \mu^ {7}),
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {L} _ {3} \partial \hat {\Psi} _ {1}} = O (\varepsilon^ {4} \mu^ {7}),
$$

$$
\frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {L} _ {3} \partial \hat {\Gamma} _ {3}} = O (\varepsilon^ {4} \mu^ {7}),
$$

where $\begin{array} { r } { \varepsilon = { \frac { 1 } { L _ { 2 } } } , \mu = { \frac { L _ { 2 } } { L _ { 3 } ^ { * } } } } \end{array}$ , where $C _ { 1 2 } , C _ { 2 3 }$ are nonzero constants independent of $L _ { 2 }$ and $L _ { 3 } ^ { * }$ coming from $F _ { \mathrm { q u a d } } ^ { 1 2 }$ $F _ { \mathrm { q u a d } } ^ { 2 3 }$ respectively, and where the nonzero constant $\alpha _ { \mathrm { K e p } }$ is defined by (31).

Proof. Observe that $\left. F _ { \mathrm { q u a d } } ^ { 1 2 } \right| _ { \Lambda }$ and $\left. F _ { \mathrm { q u a d } } ^ { 2 3 } \right| _ { \Lambda }$ are the same, after we average the inner angles, as the analogous objects in [13] up to higher order terms depending also on ${ \hat { L } } _ { 3 }$ . Therefore all of the derivatives taken with respect to the variables $\bar { \Gamma } _ { 2 } , \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 }$ are given at first order by Lemma 25 of [13].

From (30), (31), and (32), we see that

$$
\frac {\partial \hat {F} _ {0}}{\partial \hat {L} _ {3}} = \frac {\partial F _ {\mathrm{Kep}}}{\partial \hat {L} _ {3}} + \dots = \frac {1}{(L _ {3} ^ {*}) ^ {3}} \alpha_ {\mathrm{Kep}} + \dots , \quad \frac {\partial^ {2} \hat {F} _ {0}}{\partial \hat {L} _ {3} ^ {2}} = \frac {\partial^ {2} F _ {\mathrm{Kep}}}{\partial \hat {L} _ {3} ^ {2}} + \dots = - 3 \frac {1}{(L _ {3} ^ {*}) ^ {4}} \alpha_ {\mathrm{Kep}} + \dots .
$$

As for the mixed second partial derivatives with respect to ${ \hat { L } } _ { 3 }$ and the other actions, we estimate the order as follows. Products of ${ \hat { L } } _ { 3 }$ and the other actions come, at first order, in the expansion of $F _ { \mathrm { q u a d } } ^ { 2 3 }$ . We can find these by normalising $F _ { \mathrm { q u a d } } ^ { 2 3 }$ to obtain

$$
\tilde {F} _ {\mathrm{quad}} ^ {2 3} = \frac {L _ {3} ^ {6}}{L _ {2} ^ {4}} \frac {1}{(2 \pi) ^ {4}} \int_ {\mathbb {T} ^ {4}} F _ {\mathrm{quad}} ^ {2 3} d \tilde {\gamma} _ {2} d \tilde {\psi} _ {1} d \tilde {\gamma} _ {3} d \tilde {\ell} _ {3},
$$

expanding the coeficient

$$
\frac {L _ {2} ^ {4}}{L _ {3} ^ {6}} = \frac {L _ {2} ^ {4}}{\left(L _ {3} ^ {*} + \tilde {L} _ {3}\right) ^ {6}} = \frac {L _ {2} ^ {4}}{\left(L _ {3} ^ {*}\right) ^ {6}} - 6 \frac {L _ {2} ^ {4}}{\left(L _ {3} ^ {*}\right) ^ {7}} \tilde {L} _ {3} + O \left(\frac {L _ {2} ^ {4}}{\left(L _ {3} ^ {*}\right) ^ {8}}\right),\tag{94}
$$

and noticing that the first appearance of the actions $\tilde { \Gamma } _ { 2 } , ~ \tilde { \Psi } _ { 1 }$ , and ${ \tilde { \Gamma } } _ { 3 }$ in the expansion of $\tilde { F } _ { \mathrm { q u a d } } ^ { 2 3 }$ can be estimated by

$$
\frac {\partial \tilde {F} _ {\mathrm{quad}} ^ {2 3}}{\partial (\tilde {\Gamma} _ {2} , \tilde {\Psi} _ {1} , \tilde {\Gamma} _ {3})} = O \left(\frac {1}{L _ {2}}\right)\tag{95}
$$

because the first order term in the expansion of $F _ { \mathrm { q u a d } } ^ { 2 3 }$ (see $H _ { 0 } ^ { 2 3 }$ , defined by (38)) does not depend on any of the actions. Combining (94) and (95), and defining $\begin{array} { r } { \left. F _ { \mathrm { q u a d } } ^ { 2 3 } \right. = \frac { L _ { 2 } ^ { 4 } } { L _ { 3 } ^ { 6 } } \tilde { F } _ { \mathrm { q u a d } } ^ { 2 3 } } \end{array}$ yields

$$
\frac {\partial^ {2} \left<   F _ {\mathrm{quad}} ^ {2 3} \right > }{\partial \tilde {L} _ {3} \partial (\tilde {\Gamma} _ {2} , \tilde {\Psi} _ {1} , \tilde {\Gamma} _ {3})} = O \left(\frac {L _ {2} ^ {3}}{(L _ {3} ^ {*}) ^ {7}}\right) = O (\varepsilon^ {4} \mu^ {7}),
$$

and so

$$
\frac {\partial^ {2} \left<   F _ {\mathrm{quad}} ^ {2 3} \right > }{\partial \hat {L} _ {3} \partial (\hat {\Gamma} _ {2} , \hat {\Psi} _ {1} , \hat {\Gamma} _ {3})} = O \left(\frac {L _ {2} ^ {3}}{(L _ {3} ^ {*}) ^ {7}}\right) = O (\varepsilon^ {4} \mu^ {7})\tag{96}
$$

since the transformation from the $\mathrm { \dot { \Omega } t i l d e } ^ { \prime }$ to the ‘hat’ coordinates is close to the identity in $C ^ { r }$ . To see that this implies the estimates given in the statement of the lemma, it only remains to check that restricting $F _ { \mathrm { s e c } }$ to the cylinder Λ and then taking derivatives does not spoil the estimates. Indeed, recall the first order of the Hamiltonian that depends on the Poincar´e variables $\xi , \eta$ is of order $\frac { 1 } { L _ { 2 } ^ { 6 } } \ \mathrm { ( i . e }$ . the first order term $H _ { 0 } ^ { 1 2 }$ in the expansion of the secular Hamiltonian, defined by (47)). Moreover the first order term of the graph ρ defining Λ that depends on the variable ${ \tilde { L } } _ { 3 }$ is of order $\frac { L _ { 2 } ^ { 1 \mathrm { i } 0 } } { \left( L _ { 3 } ^ { * } \right) ^ { 7 } }$ (see Lemma (16)). Since $H _ { 0 } ^ { 1 2 }$ depends quadratically on ξ and η (see (47)), the term $H _ { 1 } ^ { 1 2 }$ is the lowest-order term that could contain products of the form ${ \tilde { L } } _ { 3 } P$ for $P \in \{ \tilde { \Gamma } _ { 3 } , \tilde { \Psi } _ { 1 } , \tilde { \Gamma } _ { 3 } \}$ ; since the coeficient of $H _ { 1 } ^ { 1 2 }$ is of order $\textstyle { \frac { 1 } { L _ { 2 } ^ { 7 } } }$ , the order of such terms is $\begin{array} { r } { \frac { 1 } { L _ { 2 } ^ { 7 } } \frac { L _ { 2 } ^ { 1 0 } } { \left( L _ { 3 } ^ { * } \right) ^ { 7 } } = \varepsilon ^ { 4 } \mu ^ { 7 } } \end{array}$ Therefore the estimates (96) imply the estimates on the mixed partial derivatives of $\hat { F } _ { 0 }$ with respect to ${ \hat { L } } _ { 3 }$ and $\hat { \Gamma } _ { 2 } , \hat { \Psi } _ { 1 } , \hat { \Gamma } _ { 3 }$ as required. □

## References

[1] V. I. Arnold. Small denominators and problems of stability of motion in classical and celestial mechanics. Uspehi Mat. Nauk, 18(6 (114)):91–192, 1963.

[2] V. I. Arnold. Instability of dynamical systems with many degrees of freedom. Dokl. Akad. Nauk SSSR, 156:9–12, 1964.

[3] V. I. Arnold, V. V. Kozlov, and A. I. Neishtadt. Mathematical aspects of classical and celestial mechanics, volume 3 of Encyclopaedia of Mathematical Sciences. Springer-Verlag, Berlin, third edition, 2006.

[4] P. Bernard. The dynamics of pseudographs in convex Hamiltonian systems. J. Amer. Math. Soc., 21(3):615–669, 2008.

[5] P. Bernard, V. Kaloshin, and K. Zhang. Arnold difusion in arbitrary degrees of freedom and normally hyperbolic invariant cylinders. Acta Math., 217(1):1–79, 2016.

[6] S. Bolotin and D. Treschev. Unbounded growth of energy in nonautonomous Hamiltonian systems. Nonlinearity, 12(2):365–388, 1999.

[7] M. J. Capi´nski and M. Gidea. Arnold difusion, quantitative estimates, and stochastic behavior in the three-body problem. Communications on Pure and Applied Mathematics, 2021.

[8] M. J. Capi´nski, M. Gidea, and R. de la Llave. Arnold difusion in the planar elliptic restricted three-body problem: mechanism and numerical verification. Nonlinearity, 30(1):329–360, 2017.

[9] C. Cheng. Dynamics around the double resonance. Camb. J. Math., 5(2):153–228, 2017.

[10] C. Cheng and J. Yan. Existence of difusion orbits in a priori unstable Hamiltonian systems. J. Diferential Geom., 67(3):457–517, 2004.

[11] L. Chierchia and G. Pinzari. Deprit’s reduction of the nodes revisited. Celestial Mechanics and Dynamical Astronomy, 109(3):285–301, 2011.

[12] L. Chierchia and G. Pinzari. The planetary N-body problem: symplectic foliation, reductions and invariant tori. Invent. Math., 186(1):1–77, 2011.

[13] A. Clarke, J. Fejoz, and M. Guardia. Why are inner planets not inclined? arXiv:2210.11311, 2022.

[14] A. Clarke, J. Fejoz, and M. Gu\`ardia. Topological shadowing methods in arnold difusion: weak torsion and multiple time scales. Nonlinearity, 36(1):426 – 457, 2023. Cited by: 0; All Open Access, Green Open Access.

[15] A. Clarke and D. Turaev. Arnold difusion in multi-dimensional convex billiards. Duke Mathematical Journal, to appear, 2022.

[16] A. Delshams, R. de la Llave, and T. Seara. A geometric approach to the existence of orbits with unbounded energy in generic periodic perturbations by a potential of generic geodesic flows of T<sup>2</sup>. Comm. Math. Phys., 209(2):353–392, 2000.

[17] A. Delshams, R. de la Llave, and T. Seara. Orbits of unbounded energy in quasi-periodic perturbations of geodesic flows. Adv. Math., 202(1):64–188, 2006.

[18] A. Delshams, R. de la Llave, and T. M. Seara. A geometric mechanism for difusion in Hamiltonian systems overcoming the large gap problem: heuristics and rigorous verification on a model. Mem. Amer. Math. Soc., 179(844):viii+141, 2006.

[19] A. Delshams, R. De La Llave, and T. M. Seara. Geometric properties of the scattering map of a normally hyperbolic invariant manifold. Advances in Mathematics, 217(3):1096–1153, 2008.

[20] A. Delshams, R. de la Llave, and T. M. Seara. Instability of high dimensional Hamiltonian systems: multiple resonances do not impede difusion. Adv. Math., 294:689–755, 2016.

[21] A. Delshams and G. Huguet. Geography of resonances and Arnold difusion in a priori unstable Hamiltonian systems. Nonlinearity, 22(8):1997–2077, 2009.

[22] A. Delshams, V. Kaloshin, A. de la Rosa, and T. M. Seara. Global instability in the restricted planar elliptic three body problem. Comm. Math. Phys., 366(3):1173–1228, 2019.

[23] A. Deprit. Elimination of the nodes in problems of n bodies. Celestial Mech., 30(2):181–195, 1983.

[24] M. Farhat, P. Auclair-Desrotour, G. Bou´e , and J. Laskar. The resonant tidal evolution of the earth-moon distance. Astronomy & Astrophysics, 2022.

[25] J. Fejoz. Quasiperiodic motions in the planar three-body problem. Journal of Diferential Equations, 183(2):303– 341, 2002.

[26] J. F´ejoz. D´emonstration du ‘th´eor\`eme d’Arnold’ sur la stabilit´e du syst\`eme plan´etaire (d’apr\`es Herman). Ergodic Theory Dynam. Systems, 24(5):1521–1582, 2004.

[27] J. Fejoz and M. Guardia. Secular instability in the three-body problem. Archive for rational mechanics and analysis, 221(1):335–362, 2016.

[28] J. F´ejoz, M. Gu\`ardia, V. Kaloshin, and P. Rold´an. Kirkwood gaps and difusion along mean motion resonances in the restricted planar three-body problem. J. Eur. Math. Soc. (JEMS), 18(10):2315–2403, 2016.

[29] J. F´ejoz and S. Serfaty. Deux cents ans apr\`es Lagrange. Journ´ee Annuelle, Paris, le 28 juin 2013. Soci´et´e Math´ematique de France, 2013.

[30] N. Fenichel. Persistence and smoothness of invariant manifolds for flows. Indiana University Mathematics Journal, 21(3):193–226, 1971.

[31] N. Fenichel. Asymptotic stability with rate conditions. Indiana University Mathematics Journal, 23(12):1109– 1137, 1974.

[32] N. Fenichel. Asymptotic stability with rate conditions, ii. Indiana University Mathematics Journal, 26(1):81–93, 1977.

[33] V. Gelfreich and D. Turaev. Unbounded energy growth in Hamiltonian systems with a slowly varying parameter. Comm. Math. Phys., 283(3):769–794, 2008.

[34] V. Gelfreich and D. Turaev. Arnold difusion in a priori chaotic symplectic maps. Comm. Math. Phys., 353(2):507–547, 2017.

[35] M. Gidea and R. de la Llave. Topological methods in the instability problem of hamiltonian systems. Discrete & Continuous Dynamical Systems, 14(2):295, 2006.

[36] M. Gidea, R. de la Llave, and T. M-Seara. A general mechanism of difusion in Hamiltonian systems: qualitative results. Comm. Pure Appl. Math., 73(1):150–209, 2020.

[37] R. Gomes, A. Morbidelli, and H. F. Levison. Planetary migration in a planetesimal disk: why did neptune stop at 30 au? Icarus, 170:492–507, 2004.

[38] M. Guardia, J. Paradela, and T. Seara. A degenerate Arnold difusion mechanism in the Restricted 3 Body Problem. Preprint, available at https://arxiv.org/abs/2302.06973, 2023.

[39] M. Guzzo, E. Lega, and C. Froeschl´e. First numerical investigation of a conjecture by N. N. Nekhoroshev about stability in quasi-integrable systems. Chaos, 21(3):033101, 12, 2011.

[40] R. S. Harrington. Dynamical evolution of triple stars. Astronom. J., pages 190–194, 1968.

[41] M. Herman. Some open problems in dynamical systems. In Proceedings of the International Congress of Mathematicians (Berlin, 1998), volume Extra Vol. II, pages 797–808 (electronic), 1998.

[42] M. W. Hirsch, C. C. Pugh, and M. Shub. Invariant manifolds. Bulletin of the American Mathematical Society, 76(5), 1970.

[43] V. Kaloshin and K. Zhang. Arnold difusion for smooth systems of two and a half degrees of freedom, volume 208 of Annals of Mathematics Studies. Princeton University Press, Princeton, NJ, 2020.

[44] J. Lagrange and J. Bertrand. M´ecanique analytique. Mallet-Bachelier, 1853.

[45] J.-L. Lagrange. M´emoire sur la th´eorie des variations des ´el´ements de plan\`etes et en particulier des variations des grands axes de leurs orbites. Œuvres, t. VI, pages 713–768, 1808.

[46] P.-S. Laplace. Sur le principe de la gravitation universelle et sur les in´egalit´es s´eculaires des plan\`etes qui en d´ependent. M´emoire de l’Acad´emie des sciences de Paris, Savants ´etrangers, ann´ee 1773. Œuvres, t. VIII, page 201, 1776.

[47] J. Laskar. Le syst\`eme solaire est-il stable? S´eminaire Poincar´e, pages 221–246, 2010.

[48] E. Mathieu. M´emoire sur les in´egalit´es s´eculaires des grands axes des orbites des plan\`etes. J. Reine Angew. Math., 80:97–127, 1875.

[49] R. Moeckel. Generic drift on Cantor sets of annuli. In Celestial mechanics (Evanston, IL, 1999), volume 292 of Contemp. Math., pages 163–171. Amer. Math. Soc., Providence, RI, 2002.

[50] N. N. Nehoroˇsev. An exponential estimate of the time of stability of nearly integrable Hamiltonian systems. Uspehi Mat. Nauk, 32(6(198)):5–66, 287, 1977.

[51] L. Niederman. Stability over exponentially long times in the planetary problem. Nonlinearity, 9(6):1703–1751, 1996.

[52] G. Pinzari. On the Kolmogorov set for many-body problems. PhD thesis, Universit\`a degli Studi di Roma Tre, 2009.

[53] S. Poisson. M´emoire sur les in´egalit´es s´eculaires des moyens mouvements des plan\`etes. J. Ecole Polytechnique <sup>´</sup> , 8:1–56, 1809.

Departament de Matematiques i Inform\` atica, Universitat de Barcelona, Gran Via, 585, 08007 Barcelo\` na, Spain

[54] D. Treschev. Evolution of slow variables in a priori unstable hamiltonian systems. Nonlinearity, 17(5):1803–1841, 2004.

[55] D. Treschev. Arnold difusion far from strong resonances in multidimensional a priori unstable Hamiltonian systems. Nonlinearity, 25(9):2717–2757, 2012.

[56] J. Xue. Arnold difusion in a restricted planar four-body problem. Nonlinearity, 27(12):2887–2908, 2014.

Departament de Matematiques i Inform\` atica, Universitat de Barcelona, Gran Via, 585, 08007 Barcelo\` na, Spain E-mail address: andrew.clarke@ub.edu Jacques Fejoz,

Universit´e Paris Dauphine PSL, CEREMADE, Place du Mar´echal de Lattre de Tassigny, 75016 Paris, France