# CaIRec: Calibrated Modality Imputation for Incomplete Multimodal Recommendation

Ruiyu Liu<sup>∗</sup> Southern University of Science and Technology Shenzhen, China 12310410@mail.sustech.edu.cn

Xiaohao Liu National University of Singapore Singapore, Singapore xiaohao.liu@u.nus.edu

Yunshan Ma Singapore Management University Singapore, Singapore ysma@smu.edu.sg

Miaomiao Cai<sup>†</sup> National University of Singapore Singapore, Singapore miaomiao.cai@nus.edu.sg

See-Kiong Ng National University of Singapore Singapore, Singapore seekiong@nus.edu.sg

## Abstract

Real-world multimodal recommender systems frequently sufer from incomplete modality observations, where items lack images, text, or other important content features. Such incompleteness weakens item representations and can substantially degrade rec ommendation performance. Existing modality imputation methods estimate missing representations from the available item content, but two key challenges remain. First, these methods mainly op timize the recovered representation itself, without explicitly con sidering how it should relate to the other modalities of the same item. The completed modalities may therefore form inconsistent cross-modal relations, causing Cross-modal Structural Distortion. Second, even when the completed modalities are structurally coherent, the recovered information may still be inefective for personalized ranking. Recovered representations receive limited ranking-oriented guidance, while modality missingness also dis rupts the item neighborhoods required for preference propagation, resulting in a Preference Adaptation Gap.

To address these challenges, we propose Calibrated Imputation for Incomplete Multimodal Recommendation (CaIRec), a twostage framework for incomplete multimodal recommendation. In the first stage, Structural Imputation Calibration (SIC) esti mates missing-modality representations from shared information inferred from the available modalities and calibrates their cross modal organization through structural regularization and correspondence supervision from genuinely observed modality pairs. In the second stage, Preference-oriented Representation Calibration (PRC) performs recommendation-specific adaptation at both the representation and relation levels. It constructs pseudo missing instances to align recovered representations with their observed counterparts shaped by ranking supervision in the recommendation space. It further builds completion-aware item graphs by integrating completed content relations with collaborative evi dence. Extensive experiments on three real-world datasets under diferent modality-missing settings demonstrate the efectiveness and robustness of CaIRec.

## 1 Introduction

Multimodal recommendation improves item understanding by using diferent types of content information, such as images and text [4, 10, 16, 40, 44, 46]. Diferent modalities describe an item from diferent views and provide useful information beyond user interactions [21, 25, 26, 43, 52, 54]. Such information is especially important when interactions are sparse [15, 46]. However, most existing methods assume that all items have complete modality information [17, 29, 42]. This assumption often does not hold in real-world applications, where some items may lack images, text descriptions, or other content features [7, 24]. Previous studies have shown that such modality incompleteness can substantially reduce the performance of multimodal recommendation models [7, 31, 42]. Therefore, incomplete multimodal recommendation aims to learn reliable item representations and user preferences from partial modality observations for accurate recommendation.

Existing studies mainly address incomplete multimodal recommendation through robust representation learning and modality imputation. Robust methods, such as MILK [2] and �<sup>3</sup>MRec [3], reduce the sensitivity of recommendation models to diferent missing patterns by extracting stable preference signals or modality-invariant information from the available modalities. However, their content evidence remains limited to the observed modalities, since they do not explicitly estimate the unavailable modality representations. In contrast, modality imputation directly estimates unavailable fea tures or representations [20, 24, 30]. For example, MoDiCF [19] generates missing modality features through a difusion process, while DGMRec [17] integrates shared semantics, modality-specific information, and user preferences for representation recovery. By estimating unavailable modality representations, they improve incomplete item representations and recommendation performance.

Despite these advances, existing imputation methods mainly recover representations from the available content of each item, while paying less attention to their cross-modal organization and efectiveness for personalized ranking. As illustrated in Figure 1, this limitation gives rise to two key challenges. First, Cross-modal Structural Distortion arises because a missing modality is commonly estimated from the observed modalities of the same item. Although such item-wise recovery can capture predictable information, the recovered representation is not explicitly constrained by its relations with the other modalities. It may therefore deviate from the cross-modal relation patterns exhibited by genuinely observed modality pairs, resulting in a distorted organization of the com pleted modalities. Second, the Preference Adaptation Gap arises because structurally reliable completion does not directly ensure efectiveness for recommendation. Existing imputation methods mainly optimize content recovery [17, 19, 20], while personalized ranking requires additional adaptation under interaction-based su pervision. At the representation level, recovered modalities follow a diferent generation pathway from genuine content and may de viate from their ranking-supervised observed counterparts in the recommendation space. At the relation level, modality missingness removes content-derived item connections, while item-wise recov ery does not necessarily reconstruct the neighborhoods required for preference propagation. These representation- and relation-level mismatches form the Preference Adaptation Gap. Together, these challenges require structurally calibrated modality completion fol lowed by recommendation-oriented adaptation.

![](images/8384064867e4d80ce24c062c0576f4c8967a7508229bf42886a12e8fa419faea.jpg)  
Figure 1: The two challenges in incomplete multimodal recommendation, Cross-modal Structural Distortion and the Preference Adaptation Gap.

To address these challenges, we propose Calibrated Imputation for Incomplete Multimodal Recommendation (CaIRec), a twostage framework for incomplete multimodal recommendation. Building on recent advances in multimodal completion [20, 28], CaIRec firs employs Structural Imputation Calibration (SIC) to establish a structurally calibrated completion foundation and then applies Preference-oriented Representation Calibration (PRC) to adapt completed representations and item relations to personalized rank ing. Specifically, SIC estimates missing-modality representations from available item content and calibrates their cross-modal orga nization. Its structural calibration regularizes within-item modal ity relations, while correspondence calibration anchors the completion space to cross-modal correspondence learned from genuinely observed modality pairs. More importantly, PRC performs recommendation-specific adaptation at both representation and relation levels. At the representation level, it constructs pseudo missing instances to align recovered representations with ranking supervised observed counterparts in the recommendation space. At the relation level, it combines completed content relations with col laborative evidence to supplement item neighborhoods disrupted by modality missingness. Through these two stages, CaIRec first improves the structural reliability of modality completion and then transforms completed information into recommendation-efective signals. Extensive experiments on three datasets under diferent modality-missing settings demonstrate the efectiveness and robustness of CaIRec. The main contributions of this work are summarized as follows:

• We identify two successive challenges in incomplete multimodal recommendation. Cross-modal Structural Distortion concerns the cross-modal organization of recovered modalities, while the Preference Adaptation Gap concerns their suitability for personalized ranking.

• We propose Calibrated Imputation for Incomplete Multimodal Recommendation (CaIRec), a two-stage framework connecting modality completion with recommendation. SIC calibrates the within-item cross-modal structure, while PRC adapts recovered representations and item relations to preference learning.

• Extensive experiments on three real-world datasets under diverse modality-missing settings demonstrate the efectiveness and robustness of CaIRec.

## 2 Preliminaries

Let $\mathcal { U } = \{ 1 , . . . , N _ { u } \}$ and $\textit { J } = \{ 1 , \ldots , N _ { i } \}$ denote the user and item sets, respectively. The training interactions are represented by $\mathbf { R } \in \{ 0 , 1 \} ^ { N _ { u } \times N _ { i } }$ , where $R _ { u i } = 1$ indicates an observed interaction and $R _ { u i } ~ = ~ 0$ denotes an unobserved interaction rather than an explicit negative preference [13, 37]. Multimodal recommendation further incorporates heterogeneous item content, such as visual and textual features, which may be incomplete in practice [10, 42]. Let $\boldsymbol { \mathcal { M } } = \{ 1 , \dots , N _ { m } \}$ denote the modality set. For each item $i , O _ { i } \subseteq { M }$ and $Q _ { i } = { \mathcal { M } } \backslash O _ { i }$ denote its observed and missing modality sets, respectively. We assume $O _ { i } \neq \emptyset$ . For each � ∈ $O _ { i }$ , item � has a pretrained feature $\mathbf { x } _ { i } ^ { m } \in \mathbb { R } ^ { d _ { m } }$ . When � ∈ $Q _ { i }$ , the corresponding feature is unavailable and is not replaced by a zero-filled observation.

Given R and the partially observed modality features $\chi ^ { \mathrm { o b s } } =$ $\{ \mathbf { x } _ { i } ^ { m } \mid i \in I , m \in O _ { i } \}$ , incomplete multimodal recommendation aims to learn user and item representations $\mathbf { h } _ { u } , \mathbf { h } _ { i } \in \mathbb { R } ^ { d } .$ The preference score is computed as [11]:

$$
\hat {y} _ {u i} = \mathbf {h} _ {u} ^ {\top} \mathbf {h} _ {i}.\tag{1}
$$

Candidate items are ranked based on ${ \hat { y } } _ { u i } .$ The key challenge is to learn efective user and item representations from partial modality observations for accurate personalized ranking.

## 3 Method

As illustrated in Figure 2, we propose Calibrated Imputation for Incomplete Multimodal Recommendation (CaIRec), a two-stage framework comprising Structural Imputation Calibration (SIC) and Preference-oriented Representation Calibration (PRC). Building on calibrated representation imputation, SIC first estimates missing-modality representations from shared information inferred from the available item content. It then calibrates the cross-modal organization ofthe completed modalities through structural regularization and correspondence supervision from genuinely observed modality pairs. The observed and recovered modality representations are retained as explicit completed item content for subsequent recommendation. PRC further performs recommendation-specific adaptation at both the representation and relation levels. It constructs pseudo-missing instances to reduce the discrepancy between recovered and observed representation pathways in the recommendation space, and builds completion-aware item graphs by inte grating completed content relations with collaborative evidence. Through these two stages, CaIRec first establishes a structurally calibrated completion space and then adapts the completed representations and item relations to personalized ranking.

## 3.1 Structural Imputation Calibration

To address Cross-modal Structural Distortion, SIC follows an impute-then-calibrate strategy. Existing imputation methods focus on recovering individual missing-modality representations from available content, while paying less attention to their relations with the other modalities of the same item. SIC first estimates missing modality representations through a shared-latent imputation back bone and then introduces structural and correspondence calibration to reduce the resulting cross-modal relation inconsistency.

3.1.1 Shared-latent imputation backbone. Since modality features difer in dimensions and distributions, we map them into a common completion space. For each modality �, we employ a modality specific projection $P _ { c } ^ { m } : \mathbb { R } ^ { d _ { m } }  \mathbb { R } ^ { d _ { c } }$ . For observed modality � ∈ $O _ { i }$ its projected representation is defined as:

$$
\mathbf {z} _ {i} ^ {m} = \frac {P _ {c} ^ {m} (\mathbf {x} _ {i} ^ {m})}{\| P _ {c} ^ {m} (\mathbf {x} _ {i} ^ {m}) \| _ {2} + \epsilon}, \qquad m \in \mathcal {O} _ {i},\tag{2}
$$

where $d _ { c }$ denotes completion dimension and $\epsilon >$ 0 ensures stability.

Building on representation imputation and probabilistic latent variable modeling [1, 8, 18, 28, 41], we instantiate an item-specific shared latent model for modality imputation. Each item � is associated with a shared latent variable $\boldsymbol { \beta } _ { i } \in \mathbb { R } ^ { d _ { \beta } }$ , with prior $\begin{array} { r l } { \operatorname { \mathcal { P } } ( \beta _ { i } ) = } & { { } } \end{array}$ ${ \cal N } ( 0 , { \bf { I } } )$ . Conditioned on $\beta _ { i } ,$ modality � is modeled as:

$$
p (\mathbf {z} _ {i} ^ {m} \mid \boldsymbol {\beta} _ {i}) = \mathcal {N} \left(\mathbf {W} ^ {m} \boldsymbol {\beta} _ {i} + \boldsymbol {\mu} ^ {m}, (\sigma_ {m}) ^ {2} \mathbf {I}\right),\tag{3}
$$

where $\mathbf { W } ^ { m }$ and $\pmb { \mu } ^ { m }$ map the shared latent information into modality $m ,$ and $\sigma _ { m }$ models the residual uncertainty. This model combines item-level shared information with modality-specific generation mappings, allowing missing representations to be conditionally estimated in their corresponding modality spaces.

To aggregate the information available for item �, SIC estimates the posterior of $\beta _ { i }$ conditioned on the observed projected repre sentations $\{ \mathbf { z } _ { i } ^ { m } \mid m \in O _ { i } \}$ and the generative parameters $\Theta _ { g } =$ $\{ \mathbf { W } ^ { m } , \pmb { \mu } ^ { m } , \sigma _ { m } \} _ { m \in \mathcal { M } }$ . The posterior combines evidence from all ob served modalities and has the following closed form [1, 8, 18]:

$$
q _ {i} (\boldsymbol {\beta} _ {i}) = p \left(\boldsymbol {\beta} _ {i} \mid \{\mathbf {z} _ {i} ^ {m} \} _ {m \in O _ {i}}, \Theta_ {g}\right) = \mathcal {N} \left(\mathbf {b} _ {i}, \Sigma_ {i}\right),\tag{4}
$$

where $\mathbf { b } _ { i }$ and $\Sigma _ { i }$ are the posterior mean and covariance. Because the posterior depends only on the observed modality set $O _ { i } ,$ the same inference process applies to diferent missing patterns. We use $\mathbf { b } _ { i }$ for missing-modality estimation and provide the closed-form expressions in Appendix $\mathrm { A . 1 }$

To learn the shared latent factors and modality-specific generation patterns from the available observations, we optimize the following representation objective [8]:

$$
\mathcal {L} _ {\mathrm{rep}} = - \frac {1}{| \mathcal {B} |} \sum_ {i \in \mathcal {B}} \left[ \mathbb {E} _ {q _ {i} (\boldsymbol {\beta} _ {i})} \left[ \sum_ {m \in \mathcal {O} _ {i}} \log p (\mathbf {z} _ {i} ^ {m} \mid \boldsymbol {\beta} _ {i}) \right] - D _ {\mathrm{KL}} \left(q _ {i} (\boldsymbol {\beta} _ {i}) \| p (\boldsymbol {\beta} _ {i})\right) \right]\tag{5}
$$

where B is the current item batch. The reconstruction term encourages the latent variable to explain the observed modality representations, while the KL term regularizes its posterior distribution. Only modalities in $O _ { i }$ participate in the objective, so missing modalities are never treated as zero-valued observations.

After estimating the item-specific latent information, we map the posterior mean $\mathbf { b } _ { i }$ into each missing modality space through the corresponding generative parameters [1, 8, 18]. For each $m \in { \mathcal { Q } } _ { i }$ the recovered representation is:

$$
\hat {\mathbf {z}} _ {i} ^ {m} = \frac {\mathbf {W} ^ {m} \mathbf {b} _ {i} + \pmb {\mu} ^ {m}}{\| \mathbf {W} ^ {m} \mathbf {b} _ {i} + \pmb {\mu} ^ {m} \| _ {2} + \epsilon}.\tag{6}
$$

This representation is a conditional estimate rather than an exact reconstruction of the unavailable content. The posterior mean b summarizes information predictable from the observed modalities, while $\mathbf { W } ^ { m }$ and $\pmb { \mu } ^ { m }$ transfer it into the target modality space through generation patterns learned across items. The imputation backbone therefore estimates only the target information supported by the available observations. Unlike related calibration-based approaches that use imputation to recalibrate the observed modalities, SIC treats the recovered representation as missing-modality content and calibrates its cross-modal organization to mitigate Cross-modal Structural Distortion. For unified notation, we define $\tilde { \mathbf { z } } _ { i } ^ { m } = \mathbf { z } _ { i } ^ { m }$ for $m \in O _ { i }$ and $\tilde { \mathbf { z } } _ { i } ^ { m } = \hat { \mathbf { z } } _ { i } ^ { m }$ for � $\in { \boldsymbol { Q } } _ { i }$

3.1.2 Cross-modal structural calibration. The shared-latent backbone estimates each missing representation from the available item content. However, individual recovery does not explicitly constrain how the recovered representation should relate to the other modalities of the same item. It may therefore deviate from the cross-modal relation patterns supported by valid modality observations, resulting in Cross-modal Structural Distortion. To address this issue, we introduce structural and correspondence calibration to regularize the cross-modal organization of the completed modalities.

For each item �, we stack its completed modality representations as $\tilde { \boldsymbol { \mathbf { Z } } } _ { i } = [ \tilde { \mathbf { z } } _ { i } ^ { 1 } , \boldsymbol { \mathbf { \ell } } , \boldsymbol { \mathbf { \cdot } } , \boldsymbol { \mathbf { \cdot } } , \tilde { \mathbf { z } } _ { i } ^ { N _ { m } } ] \in \mathbb { R } ^ { d _ { c } \times N _ { m } }$ and construct the modality-level Gram matrix $\mathbf { G } _ { i } = \tilde { \mathbf { Z } } _ { i } ^ { \top } \tilde { \mathbf { Z } } _ { i } .$ . Since all representations are normalized, each entry of $\mathbf { G } _ { i }$ measures the similarity between two modalities of the same item. We decompose the Gram matrix as $\mathbf { G } _ { i } = \mathbf { U } _ { i } \pmb { \Lambda } _ { i } \mathbf { U } _ { i } ^ { \top }$ where $\lambda _ { i , 1 } \ge \cdots \ge \lambda _ { i , N _ { m } }$ are the eigenvalues and $\mathbf { u } _ { i } = [ \mathbf { U } _ { i } ] _ { : , 1 }$ is the principal eigenvector. The leading eigenvalue measures the concentration of the within-item modality relations, while the principal eigenvector characterizes the relative contribution of each modality to the principal relation pattern.

Based on this spectral characterization [27], we regularize the completed representations from two perspectives. The leadingeigenvalue term reduces ambiguity in the within-item relation pattern, while the principal-direction term discourages identical structural configurations across items when the modality set admits nontrivial directional variation:

$$
\mathcal {L} _ {\mathrm{str}} = - \frac {1}{| \mathcal {B} |} \sum_ {i \in \mathcal {B}} \left[ \log \frac {\exp (\lambda_ {i , 1} / \tau)}{\sum_ {r = 1} ^ {N _ {m}} \exp (\lambda_ {i , r} / \tau)} + \log \frac {\exp (1 / \tau)}{\sum_ {j \in \mathcal {B}} \exp ((\mathbf {u} _ {i} ^ {\top} \mathbf {u} _ {j}) ^ {2} / \tau)} \right],\tag{7}
$$

where $\tau > 0$ is the temperature hyperparameter. The first term increases the relative prominence of the leading eigenvalue and encourages a more concentrated cross-modal organization. The second term regularizes structural variation across items, while the squared inner product removes the sign ambiguity of eigenvectors.

![](images/4976c19619cc1749a7a5191098cc0f6862aba0d8cbef9387a458cdeb4da1f6f0.jpg)  
Figure 2: Overview of the proposed CaIRec framework. SIC estimates missing-modality representations and calibrates their within-item cross-modal organization. PRC then adapts recovered representations in the recommendation space and supplements item relations for preference propagation and personalized ranking.

In the bimodal case, the principal-direction term introduces no additional continuous gradient within a fixed cross-modal similarity sign pattern. The leading-eigenvalue term therefore provides the main structural optimization signal in our setting. We provide a detailed analysis in Appendix A.4.

Structural calibration regularizes the overall relation pattern of each completed item, but it does not explicitly determine whether representations from diferent modalities correspond to the same item [5, 6, 27]. To provide more direct cross-modal correspondence supervision, we construct a set $\mathcal { P } _ { \mathcal { B } }$ of observed cross-modal pairs $\boldsymbol { p } = ( ( i , m ) , ( j , n ) )$ , where � ≠ �. A pair is labeled positive when � = � and negative otherwise. Positive pairs therefore contain two observed modalities of the same item, while negative pairs preserve the modality combination but replace one representation with that of another item. Based on these pairs, we introduce the following correspondence calibration objective:

$$
\mathcal {L} _ {\text { corr }} = - \frac {1}{| \mathcal {P} _ {\mathcal {B}} |} \sum_ {p \in \mathcal {P} _ {\mathcal {B}}} \left[ y _ {p} \log \hat {y} _ {p} + (1 - y _ {p}) \log (1 - \hat {y} _ {p}) \right],\tag{8}
$$

where $y _ { p }$ is the correspondence label and $\hat { y } _ { p } = \sigma ( g ^ { m , n } ( [ \mathbf { z } _ { i } ^ { m } \lVert \mathbf { z } _ { j } ^ { n } ] ) )$ ) is the predicted probability. Only genuinely observed modality pairs are used, which avoids treating uncertain imputed representations as supervision targets. Because the modality projections and gen erative model share a completion space, this objective provides correspondence supervision from genuinely observed modality pairs and anchors the space to cross-modal correspondence.

Finally, we combine the imputation and structural calibration objectives as:

$$
\mathcal {L} _ {\mathrm{SIC}} = \mathcal {L} _ {\mathrm{rep}} + \lambda_ {\mathrm{str}} \mathcal {L} _ {\mathrm{str}} + \lambda_ {\mathrm{corr}} \mathcal {L} _ {\mathrm{corr}},\tag{9}
$$

where $\lambda _ { \mathrm { s t r } }$ and $\lambda _ { \mathrm { c o r r } }$ control the two calibration objectives. The representation loss learns the shared-latent imputation backbone. The structural loss regularizes the spectral organization of the completed modalities, while the correspondence loss anchors the completion space to observed cross-modal correspondence.

## 3.2 Preference-oriented Representation Calibration

Although SIC produces structurally calibrated representations in the completion space, such representations are not necessarily well suited to personalized ranking. This limitation arises at both the representation and relation levels. At the representation level, recovered and directly observed representations follow diferent processing pathways and may therefore exhibit a pathway-specific discrepancy in the recommendation space. At the relation level, modality missingness removes content-derived item connections, while item-wise completion does not necessarily reconstruct the neighborhoods needed for preference propagation. To address these issues, we introduce Preference-oriented Representation Calibration (PRC) as the recommendation-specific stage of CaIRec. PRC adapts the recovery pathway through pseudo-missing instances and constructs completion-aware item graphs by integrating collaborative evidence with completed content relations.

3.2.1 Representation-level adaptation. Although recovered modality representations participate in the final ranking objective, ranking supervision alone provides no paired reference for correcting the pathway-specific discrepancy introduced by modality recovery. For the same item and modality, the recovered representation is inferred from the available modalities, whereas its observed counterpart is directly extracted from the original content. These diferent processing pathways may cause the recovered representation to deviate from its observed counterpart in the recommendation space, leaving it insuficiently adapted to personalized ranking. To provide direct adaptation guidance, we construct pseudo-missing instances from observed modalities. Specifically, we mask an ob served modality, recover it from the remaining modalities, and pair the resulting pseudo-recovered representation with its observed counterpart in the recommendation space. Since each pair shares the same item and modality, their discrepancy mainly reflects the deviation introduced by the recovery pathway.

For modality �, we map observed and recovered representations through separate branches. We employ a recommendation projection ${ P } _ { r } ^ { m } \ : \ \mathbb { R } ^ { d _ { c } } \  \ \mathbb { R } ^ { d }$ for observed representations and an adapter $A ^ { m } : \mathbb { R } ^ { d _ { c } }  \mathbb { R } ^ { d }$ for recovered representations. The recommendation-space representation is defined as:

$$
\mathbf {s} _ {i} ^ {m} = \left\{ \begin{array}{l l} P _ {r} ^ {m} (\mathbf {z} _ {i} ^ {m}), & m \in \mathcal {O} _ {i}, \\ A ^ {m} (\hat {\mathbf {z}} _ {i} ^ {m}), & m \in \mathcal {Q} _ {i}. \end{array} \right.\tag{10}
$$

The observed branch is derived from observed modality content and is directly shaped by ranking supervision, making it a suitable reference in the recommendation space. The recovered branch fol lows the imputation pathway and may exhibit a pathway-specific shift. We therefore use a separate adapter instead of forcing both branches to share the same transformation.

A genuinely missing modality has no observed representation that can serve as an alignment reference. We therefore construct pseudo-missing instances from items with at least two observed modalities. The eligible item–modality pairs are:

$$
\mathcal {E} _ {\mathrm{pm}} = \left\{(i, m) \mid i \in \mathcal {I}, m \in \mathcal {O} _ {i}, | \mathcal {O} _ {i} | \geq 2 \right\}\tag{11}
$$

For each $( i , m ) \in \mathcal { E } _ { \mathrm { p m } }$ modality � is temporarily masked and re covered from $O _ { i } \mid$ {�} using the same SIC imputation process. We denote the pseudo-recovered representation by $\hat { \mathbf { z } } _ { i } ^ { m , ( - \bar { m } ) }$ . Because the masked modality remains available as observed content during training, $\mathbf { z } _ { i } ^ { m }$ provides a paired observed reference. The correspondence and pseudo-missing objectives require a nonempty subset of items with at least two observed modalities. When such paired observations are unavailable, these objectives cannot be directly instantiated, and the framework reduces to the shared-latent impu tation and relation-level recommendation components.

We align the pseudo-recovered and observed representations after mapping them into the recommendation space:

$$
\mathcal {L} _ {\mathrm{align}} = \frac {1}{| \mathcal {E} _ {\mathrm{pm}} |} \sum_ {(i, m) \in \mathcal {E} _ {\mathrm{pm}}} \left[ 1 - \cos \left(A ^ {m} (\hat {\mathbf {z}} _ {i} ^ {m, (- m)}), \mathrm{sg} \left(P _ {r} ^ {m} (\mathbf {z} _ {i} ^ {m})\right)\right) \right],\tag{12}
$$

where $s \mathrm { g } ( \cdot )$ denotes stop-gradient. Because each pair shares the same item and modality identity, the objective mainly captures the discrepancy introduced by the recovery pathway. Minimizing $\mathcal { L } _ { \mathrm { a l i g n } }$ adapts the pseudo-recovered branch toward the ranking-supervised observed branch. Stop-gradient prevents the alignment loss from changing the observed reference, which remains optimized through personalized ranking. Pseudo-recovered and genuinely missing rep resentations share the same SIC imputation process and modality specific adapter. The learned pathway adaptation can therefore be applied to genuinely missing modalities.

3.2.2 Relation-level reconstruction. Representation-level adaptation calibrates recovered modalities for individual items, but recommendation also depends on relations among items. When modal ity � is missing, the corresponding content-derived connections cannot be obtained from the original observations. This leaves the modality-specific item neighborhood incomplete and weak ens the associated preference propagation paths. Moreover, recovering an individual representation does not by itself ensure that the resulting content neighborhood is consistent with collabora tive preference patterns. Motivated by modality-aware item-graph modeling [52] and graph-based feature propagation under missing modalities [30, 31], we construct a completion-aware item graph integrating completed content and collaborative similarities.

We model item relations from both interaction patterns and completed modality content. Let $\begin{array} { r } { d _ { i } = \sum _ { u \in \mathcal { U } } R _ { u i } } \end{array}$ denote the interaction degree of item �. For two distinct items � and $j ,$ the collaborative and modality-specific content similarities are:

$$
S _ {i j} ^ {\mathrm{cf}} = \frac {\sum_ {u \in \mathcal {U}} R _ {u i} R _ {u j}}{\sqrt {d _ {i} d _ {j}} + \epsilon}, \qquad S _ {i j} ^ {m} = \max \left(0, \cos \left(\tilde {\mathbf {z}} _ {i} ^ {m}, \tilde {\mathbf {z}} _ {j} ^ {m}\right)\right).\tag{13}
$$

Collaborative similarity measures normalized overlap between user interaction histories, while content similarity measures item proximity under modality �. Because $\tilde { \mathbf { z } } _ { i } ^ { m }$ may be either observed or recovered, all items can participate in modality-specific relation construction. We set $S _ { i i } ^ { \mathrm { c f } } = S _ { i i } ^ { m } = 0$ to exclude self-connections.

The two relation sources provide complementary evidence. Collaborative similarity introduces interaction-supported preference proximity but may be unreliable for items with sparse interactions. Completed content similarity supplements modality-specific relations but may contain uncertainty when recovered representations are involved. We therefore fuse them as:

$$
\mathbf {S} ^ {m, \mathrm{fuse}} = (1 - \eta) \mathbf {S} ^ {\mathrm{cf}} + \eta \mathbf {S} ^ {m},\tag{14}
$$

where $\eta \in \left[ 0 , 1 \right]$ balances the two relation sources. For each item, we select the Top-� entries in $\mathsf { S } ^ { m , \mathrm { f u s e } }$ as its neighbors and construct $\mathbf { G } _ { \mathrm { i t e m } } ^ { m }$ . The resulting graph combines completed content relations with interaction-supported evidence, supplementing item connections disrupted by modality missingness and providing additional paths for preference propagation.

3.2.3 Preference propagation and personalized ranking. For each modality $m ,$ we augment the user–item interaction graph with the completion-aware item graph $\mathbf { G } _ { \mathrm { i t e m } } ^ { m }$ . We then perform modalityspecific preference propagation following LightGCN [11] and existing multimodal graph recommendation methods [9, 46, 52]. The propagated representations are aggregated across layers and modalities to obtain user and item embeddings $\mathbf { h } _ { u }$ and $\mathbf { h } _ { i \cdot }$ . Their preference score is computed according to Equation (1). The propagation and aggregation equations are provided in Appendix $_ { \mathrm { ~ \tiny ~ A . 3 . } }$

We optimize the final representations using Bayesian Personalized Ranking (BPR) [37]. Let $\mathcal { D } _ { \mathrm { B P R } } = \{ ( u , i , j ) ~ | ~ R _ { u i } = 1 , R _ { u j } = 0 \}$ denote the training triplets, where user � has interacted with item � but not with item �. The recommendation loss is:

$$
\mathcal {L} _ {\mathrm{rec}} = - \frac {1}{| \mathcal {D} _ {\mathrm{BPR}} |} \sum_ {(u, i, j) \in \mathcal {D} _ {\mathrm{BPR}}} \log \sigma (\hat {y} _ {u i} - \hat {y} _ {u j}).\tag{15}
$$

The overall objective of PRC combines personalized ranking, recovery-pathway alignment, and parameter regularization:

$$
\mathcal {L} _ {\mathrm{PRC}} = \mathcal {L} _ {\mathrm{rec}} + \lambda_ {\mathrm{align}} \mathcal {L} _ {\mathrm{align}} + \lambda_ {\mathrm{reg}} \| \Theta_ {\mathrm{PRC}} \| _ {2} ^ {2},\tag{16}
$$

where $\lambda _ { \mathrm { a l i g n } }$ and $\lambda _ { \mathrm { r e g } }$ control alignment and regularization terms.

We optimize SIC and PRC sequentially to separate structurally calibrated modality completion from recommendation-oriented adaptation. SIC is first trained with $\mathcal { L } _ { \mathrm { S I C } }$ to learn the imputation backbone and organize the completed modalities in the completion space. We then fix the SIC parameters and optimize PRC with $\mathcal { L } _ { \mathrm { P R C } }$ . This stage adapts the recommendation-space mappings and supplements item relations without changing the learned imputation process. Accordingly, SIC addresses Cross-modal Structural

Table 1: Statistics of three datasets.

<table><tr><td>Dataset</td><td>#Users</td><td>#Items</td><td>#Interactions</td><td>Sparsity</td></tr><tr><td>Clothing</td><td>39,387</td><td>23,033</td><td>278,677</td><td>99.97%</td></tr><tr><td>Sports</td><td>35,598</td><td>18,357</td><td>296,337</td><td>99.95%</td></tr><tr><td>Beauty</td><td>21,752</td><td>11,161</td><td>165,325</td><td>99.93%</td></tr></table>

Distortion by calibrating cross-modal organization of conditionally imputed representations, while PRC addresses the Preference Adaptation Gap through representation-level pathway adaptation and relation-level neighborhood reconstruction. Further theoretical and empirical analyses of eficiency and scalability are in Appendix A.5.

## 4 Experiments

## 4.1 Experimental Settings

4.1.1 Datasets. We evaluate CaIRec on three Amazon recommendation datasets, namely Clothing, Sports, and Beauty [32]. Each dataset contains user–item ratings together with visual and textual item features. Following prior multimodal recommendation studies [54], we treat observed ratings as implicit feedback and adopt the same preprocessing and evaluation settings. We use the released 4,096-dimensional CNN visual features [32, 54] and 384- dimensional Sentence-Transformer textual features [36, 54]. The dataset statistics are reported in Table 1.

4.1.2 Modality-Missing Setings. Following previous studies on incomplete multimodal recommendation [3, 17, 20], we simulate modality incompleteness by randomly selecting 50% of the items as incomplete. For each selected item, either its visual or textual modality is uniformly sampled and removed, while the other modal ity remains observed. The remaining 50% of the items retain both modalities. The resulting item-level missing mask is fixed across training, validation, and testing, so that each item has the same modality availability throughout an experiment. The removed fea tures are unavailable to all methods, and all compared methods use the same missing mask for a fair comparison.

4.1.3 Baselines, Evaluation Protocol and Implementation Details. We compare CaIRec with representative methods from three categories. (1) Collaborative Filtering methods rely primarily on user– item interactions for preference modeling, including LightGCN [11] and SimGCL [49]. (2)General Multimodal Recommendation meth ods incorporate visual and textual item content to enhance preference modeling, including VBPR [10], BM3 [54], PGL [51], and MIG-GT [12]. (3) Incomplete Multimodal Recommendation methods explicitly address modality missingness. Robustness-oriented methods learn stable representations from the available modalities, including �<sup>3</sup>MRec [3] and MILK [2]. Completion-based methods estimate unavailable modality features or representations, including MoDiCF [19], DGMRec [17], and HEAT [30]. Detailed descriptions of all compared methods are provided in Appendix B.1.

We follow the data splitting and full-ranking evaluation protocol of prior multimodal recommendation studies [54]. Performance is measured by Recall@� (R@�) and NDCG@� (N@�) for � ∈ {10, 20}, with all non-interacted items treated as candidates. Each experiment is repeated five times with diferent random seeds while keeping the data split and modality-missing mask fixed, and average results are reported. All methods use the same split, mask, and hyperparameter search protocol, with significance assessed by a paired two-sided �-test. Detailed implementation settings and search ranges are provided in Appendix B.2.

## 4.2 Overall Performance

Table 2 reports the overall results on the three datasets. Across the evaluated datasets and metrics, CaIRec consistently achieves the strongest performance. The results show that CaIRec can efectively use partially observed multimodal content and adapt the completed representations and item relations to personalized ranking. We summarize the main observations as follows:

• Completion-based methods generally outperform robustnessoriented methods. �<sup>3</sup>MRec and MILK improve robustness by extracting stable or modality-invariant information from the available modalities, but they do not explicitly estimate the unavailable modality representations. Their content evidence therefore remains limited to the observed modalities. In comparison, completion-based methods such as DGMRec and HEAT generally achieve stronger results than the robustness-oriented baselines. This comparison suggests that robustness to missing patterns alone may be insuficient, while explicit completion can provide additional content evidence for recommendation.

• MIG-GT remains a strong baseline under modality missingness. Although MIG-GT is not specifically designed for in complete modalities, it models visual, textual, and collaborative signals through separate branches and captures global dependencies with a Transformer. When one content modality is missing, its remaining content and collaborative branches can still provide useful recommendation signals. This design helps MIG-GT outperform several missing-aware methods. However, MIG-GT does not explicitly estimate missing-modality representations or perform recommendation-specific adaptation for the recovered pathway, and it therefore remains behind CaIRec.

• CaIRec achieves the strongest overall performance. Across all dataset–metric combinations, CaIRec yields an average relative improvement of 3.77% over the strongest competing baseline. It also consistently surpasses leading completion-based methods, including DGMRec and HEAT. These results suggest that modality completion alone may not fully address incomplete multimodal recommendation. Individually recovered representations may still form distorted cross-modal relations and remain insuficiently adapted to personalized ranking. By combining Structural Imputation Calibration with Preference-oriented Representation Calibration, CaIRec more efectively transforms completed modality information into recommendation-oriented representations and item relations.

## 4.3 Ablation Study

To analyze the contribution of the components in SIC and PRC, we construct six variants of CaIRec. For SIC, w/o StrCal and w/o CorrCal remove the structural and correspondence calibration objectives, respectively, while w/o SIC removes the entire SIC stage and represents each missing modality with a zero vector. For PRC, w/o ItemGraph removes the completion-aware item graph, w/o PMA removes pseudo-missing alignment, and w/o PRC directly uses SIC outputs for recommendation without representation-level pathway adaptation or relation-level neighborhood reconstruction. Table 3 reports the results under a 50% modality-missing rate.

Table 2: Performance comparison under a 50% modality-missing rate. Results are averaged over five runs. The best and second best results are highlighted in bold and underlined, respectively. <sup>∗</sup> indicates a statistically significant improvement over the strongest baseline under a paired two-sided �-test with � < 0.005.

<table><tr><td rowspan="2">Methods</td><td colspan="4">Clothing</td><td colspan="4">Sports</td><td colspan="4">Beauty</td></tr><tr><td>R@10</td><td>N@10</td><td>R@20</td><td>N@20</td><td>R@10</td><td>N@10</td><td>R@20</td><td>N@20</td><td>R@10</td><td>N@10</td><td>R@20</td><td>N@20</td></tr><tr><td>LightGCN</td><td>0.0301</td><td>0.0163</td><td>0.0453</td><td>0.0201</td><td>0.0526</td><td>0.0290</td><td>0.0814</td><td>0.0364</td><td>0.0440</td><td>0.0216</td><td>0.0696</td><td>0.0280</td></tr><tr><td>SimGCL</td><td>0.0402</td><td>0.0219</td><td>0.0604</td><td>0.0270</td><td>0.0639</td><td>0.0351</td><td>0.0974</td><td>0.0439</td><td>0.0477</td><td>0.0245</td><td>0.0764</td><td>0.0320</td></tr><tr><td>VBPR</td><td>0.0332</td><td>0.0184</td><td>0.0491</td><td>0.0224</td><td>0.0550</td><td>0.0298</td><td>0.0840</td><td>0.0373</td><td>0.0478</td><td>0.0233</td><td>0.0776</td><td>0.0308</td></tr><tr><td>BM3</td><td>0.0405</td><td>0.0220</td><td>0.0602</td><td>0.0270</td><td>0.0634</td><td>0.0346</td><td>0.0959</td><td>0.0430</td><td>0.0475</td><td>0.0237</td><td>0.0747</td><td>0.0305</td></tr><tr><td>PGL</td><td>0.0413</td><td>0.0222</td><td>0.0615</td><td>0.0273</td><td>0.0571</td><td>0.0306</td><td>0.0895</td><td>0.0390</td><td>0.0422</td><td>0.0211</td><td>0.0675</td><td>0.0275</td></tr><tr><td>MIG-GT</td><td>0.0524</td><td>0.0286</td><td>0.0776</td><td>0.0350</td><td>0.0664</td><td>0.0366</td><td>0.1011</td><td>0.0455</td><td>0.0520</td><td>0.0254</td><td>0.0804</td><td>0.0325</td></tr><tr><td> $I^3$ -MRec</td><td>0.0416</td><td>0.0224</td><td>0.0647</td><td>0.0283</td><td>0.0620</td><td>0.0337</td><td>0.0951</td><td>0.0423</td><td>0.0474</td><td>0.0235</td><td>0.0768</td><td>0.0309</td></tr><tr><td>MILK</td><td>0.0284</td><td>0.0150</td><td>0.0433</td><td>0.0188</td><td>0.0298</td><td>0.0158</td><td>0.0475</td><td>0.0203</td><td>0.0340</td><td>0.0170</td><td>0.0543</td><td>0.0221</td></tr><tr><td>MoDiCF</td><td>0.0474</td><td>0.0266</td><td>0.0712</td><td>0.0329</td><td>0.0613</td><td>0.0346</td><td>0.0935</td><td>0.0432</td><td>0.0477</td><td>0.0237</td><td>0.0759</td><td>0.0308</td></tr><tr><td>DGMRec</td><td>0.0505</td><td>0.0273</td><td>0.0762</td><td>0.0339</td><td>0.0662</td><td>0.0361</td><td>0.1007</td><td>0.0450</td><td>0.0508</td><td>0.0247</td><td>0.0810</td><td>0.0323</td></tr><tr><td>HEAT</td><td>0.0504</td><td>0.0273</td><td>0.0767</td><td>0.0340</td><td>0.0655</td><td>0.0358</td><td>0.0982</td><td>0.0443</td><td>0.0500</td><td>0.0248</td><td>0.0788</td><td>0.0320</td></tr><tr><td>CAIREc (Ours)</td><td>0.0537*</td><td>0.0291*</td><td>0.0814*</td><td>0.0361*</td><td>0.0709*</td><td>0.0383*</td><td>0.1058*</td><td>0.0474*</td><td>0.0529*</td><td>0.0261*</td><td>0.0842*</td><td>0.0339*</td></tr><tr><td>Improv.</td><td>2.48%</td><td>1.75%</td><td>4.90%</td><td>3.14%</td><td>6.78%</td><td>4.64%</td><td>4.65%</td><td>4.18%</td><td>1.73%</td><td>2.76%</td><td>3.95%</td><td>4.31%</td></tr></table>

Table 3: Ablation study on three datasets, with relative drops from the full model shown in parentheses.

<table><tr><td rowspan="2">Variant</td><td colspan="2">Clothing</td><td colspan="2">Sports</td><td colspan="2">Beauty</td></tr><tr><td>R@20</td><td>N@20</td><td>R@20</td><td>N@20</td><td>R@20</td><td>N@20</td></tr><tr><td>CAIREc</td><td>0.0814</td><td>0.0361</td><td>0.1058</td><td>0.0474</td><td>0.0842</td><td>0.0339</td></tr><tr><td>w/o StrCal</td><td>0.0772(-5.16%)</td><td>0.0345(-4.43%)</td><td>0.1049(-0.85%)</td><td>0.0470(-0.84%)</td><td>0.0819(-2.73%)</td><td>0.0331(-2.36%)</td></tr><tr><td>w/o CorrCal</td><td>0.0803(-1.35%)</td><td>0.0358(-0.83%)</td><td>0.1050(-0.76%)</td><td>0.0470(-0.84%)</td><td>0.0833(-1.07%)</td><td>0.0334(-1.47%)</td></tr><tr><td>w/o SIC</td><td>0.0756(-7.13%)</td><td>0.0339(-6.09%)</td><td>0.1032(-2.46%)</td><td>0.0468(-1.27%)</td><td>0.0797(-5.34%)</td><td>0.0323(-4.72%)</td></tr><tr><td>w/o PMA</td><td>0.0792(-2.70%)</td><td>0.0354(-1.94%)</td><td>0.1044(-1.32%)</td><td>0.0467(-1.48%)</td><td>0.0828(-1.66%)</td><td>0.0331(-2.36%)</td></tr><tr><td>w/o ItemGraph</td><td>0.0752(-7.62%)</td><td>0.0334(-7.48%)</td><td>0.1017(-3.88%)</td><td>0.0450(-5.06%)</td><td>0.0802(-4.75%)</td><td>0.0322(-5.01%)</td></tr><tr><td>w/o PRC</td><td>0.0729(-10.44%)</td><td>0.0326(-9.70%)</td><td>0.1002(-5.29%)</td><td>0.0444(-6.33%)</td><td>0.0788(-6.41%)</td><td>0.0314(-7.37%)</td></tr></table>

Removing any component degrades performance, showing that the proposed designs provide complementary benefits. Within SIC, removing structural calibration causes a larger decrease than removing correspondence calibration, showing the importance of regularizing within-item cross-modal organization for reducing Cross-modal Structural Distortion. Correspondence calibration pro vides gains by anchoring the completion space to cross-modal correspondence learned from genuinely observed modality pairs.

Within PRC, removing the entire stage causes the largest degra dation among the major module-level variants, confirming that structurally calibrated modality completion alone is insuficient for personalized ranking. Removing pseudo-missing alignment weak ens representation-level adaptation of the recovered pathway, while removing the completion-aware item graph reduces connections available for preference propagation. These results support the representation- and relation-level design of PRC. The ablation results validate the sequential design of CaIRec, where SIC calibrates the within-item cross-modal organization and PRC adapts representations and item neighborhoods to personalized ranking.

![](images/f6e6cd84fddffc805a8aa3a9738e0cdbb5c524a6d099d279db68096ee3af7f67.jpg)

![](images/febce987f13855c28fcfaed40a743fa64bb729e42cf1ff9fde2a7c5f447436f0.jpg)  
Figure 3: Performance across item groups.

## 4.4 Performance on Incomplete Items

To directly evaluate the efectiveness of CaIRec on modalityincomplete items, we divide test items into modality-incomplete and modality-complete groups according to the fixed item-level missing mask and evaluate them separately under the same ranking protocol. We compare CaIRec with MIG-GT and DGMRec, the strongest general multimodal and missing-aware baselines, respectively. Figure 3 reveals two main findings. (1) CaIRec achieves substantially larger improvements on modality-incomplete items and consistently outperforms both baselines across datasets. On modality-complete items, the competing methods remain competitive, and CaIRec is slightly weaker in some settings. Nevertheless, its gains on incomplete items outweigh these diferences and yield the strongest overall performance, showing that the improvement of CaIRec is primarily concentrated on items directly afected by modality missingness. (2) The substantially larger gap over DGM Rec on modality-incomplete items suggests that modality comple tion alone does not necessarily produce recommendation-efective representations. By calibrating the cross-modal organization of completed modalities and further adapting the recovered pathway and item neighborhoods to personalized ranking, CaIRec provides more efective recommendation for incomplete items, supporting the need for recommendation-oriented adaptation after completion.

![](images/a79130c41c211678d689d8a3802a0329e6c4a877e51db01c0bda44c5c3fd56a8.jpg)  
Figure 4: Performance under varying modality-missing rates.

## 4.5 Robustness under Varying Missing Rates

To evaluate robustness under diferent degrees of modality incom pleteness, we vary the proportion of modality-incomplete items from 10% to 90% and compare CaIRec with MIG-GT, DGMRec, and HEAT. Figure 4 reports two main findings. (1) Completion based methods degrade more slowly as the missing rate increases. MIG-GT performs strongly under mild missingness but declines rapidly as more items lose one modality, whereas DGMRec, HEAT, and CaIRec show flatter trends. This suggests that estimating un available modality representations can partially compensate for lost content signals. (2) CaIRec achieves the strongest performance among completion-based methods, especially under moderate-tosevere missingness. Its advantage grows with the missing rate, in dicating lower sensitivity to severe modality incompleteness. This is consistent with the group-wise analysis, where its gains mainly arise from modality-incomplete items. The results support cali brating the cross-modal organization of completed modalities and adapting recovered representations and item relations to person alized ranking. Additional image-only and text-only missingness results in Appendix C.1 further demonstrate robustness across missing-modality types.

## 4.6 Hyperparameter Sensitivity

Figure 5 examines the objective weights in SIC and PRC. For SIC, moderate values of $\lambda _ { \mathrm { s t r } }$ and $\lambda _ { \mathrm { c o r r } }$ λcorr generally yield stronger performance. A weak structural constraint provides limited cross-modal regularization, whereas an excessively large value may over-constrain the completion space. The efect of correspondence calibration also depends on structural calibration, suggesting that relation-pattern regularization and observed-pair supervision provide complementary signals. A similar pattern appears for PRC. A small $\lambda _ { \mathrm { a l i g n } }$ provides limited guidance for adapting the recovered pathway, while a large value may overemphasize matching the observed branch. The regularization weight must balance model capacity and overfitting. Overall, the results highlight the need to balance structural calibration and recommendation-oriented adaptation. Additional hyperparameter analyses are provided in Appendix C.5.

(a) Beauty  
(b) Sports  
![](images/0f682620609aaa1385b6ded2c1b456237b183ca832c88d4de311b36eacbdbbd8.jpg)  
Figure 5: Hyperparameter sensitivity of CaIRec.

## 5 Related Work

## 5.1 Multimodal Recommendation

Multimodal recommendation incorporates item content such as images, text, and videos into collaborative preference modeling [10, 34, 46]. Early methods directly integrate modality features into recommendation objectives. VBPR [10] extends pairwise ranking with visual factors, while BM3 [54] and SLMRec [39] introduce selfsupervised learning across interaction and content views. Other methods construct modality-aware item graphs or propagate multimodal and collaborative signals, including LATTICE [52], MI-CRO [48], FREEDOM [53], PGL [51], MMGCN [46], GRCN [45], MGCN [50], and LGMRec [9]. Recent studies further improve modality fusion and global dependency modeling [12, 22, 23, 35, 47].

These studies demonstrate the value of multimodal content beyond interaction-only recommenders such as LightGCN [11] and SimGCL [49]. However, most assume that all items have complete modality features [17, 29, 42]. Missing content weakens semantic evidence and disrupts modality-derived item relations, motivating incomplete multimodal recommendation.

## 5.2 Incomplete Multimodal Recommendation

Existing methods mainly address modality incompleteness through robust representation learning or explicit completion [2, 3, 19]. Robust methods learn stable representations from available modalities. SiBraR [7] maps diferent modality combinations into a shared space, MILK [2] combines cross-modal alignment with invariant learning, and I<sup>3</sup>-MRec [3] employs invariant risk minimization and an information bottleneck. However, their content evidence remains limited to observed modalities.

Completion-based methods estimate unavailable modality representations [33, 38]. LRMM [42] combines modality dropout with a multimodal autoencoder, while CI<sup>2</sup>MG [24] models intra-modality relations and inter-modality generation. Recent methods use conditional difusion [19], disentangled generation [17], graph-context retrieval [20], or training-free feature propagation [30]. However, individual completion does not explicitly ensure coherent crossmodal organization or efectiveness for personalized ranking.

CalMRL [28] infers shared semantics from observed modalities and uses imputation to recalibrate observed encoders against anchor shift in generic multimodal alignment. In contrast, CaIRec preserves observed modalities as direct item content and uses their shared semantics to recover and calibrate the missing modality itself. SIC regularizes the recovered representation into a coherent within-item cross-modal structure, while PRC adapts only the re covery pathway to the ranking-supervised space and reconstructs completion-aware item relations for preference propagation.

## 6 Conclusion

In this work, we studied incomplete multimodal recommendation from the joint perspectives of modality completion and recom mendation adaptation. We identified two successive challenges, Cross-modal Structural Distortion and the Preference Adaptation Gap. The former arises when individually recovered representa tions form inconsistent relations with other modalities of the same item, while the latter concerns whether completed representations and item relations are efective for personalized ranking. To ad dress them, we proposed Calibrated Imputation for Incomplete Multimodal Recommendation (CaIRec), a two-stage framework connecting modality completion with personalized ranking. SIC calibrates the within-item cross-modal organization of estimated missing-modality representations, while PRC adapts them in the recommendation space and supplements item relations for pref erence propagation. Extensive experiments on three real-world datasets under diferent modality-missing settings demonstrated the efectiveness and robustness of CaIRec. Our evaluation is lim ited to Amazon benchmarks with visual and textual modalities and synthetically generated missingness. Extending CaIRec to other domains, naturally occurring missing patterns, and settings with more than two modalities remains important future work. Overall, the results show that efective incomplete multimodal recommendation requires both structurally calibrated completion and recommendation-oriented adaptation.

## References

[1] Francis R. Bach and Michael I. Jordan. 2005. A Probabilistic Interpretation of Canonical Correlation Analysis. Technical Report (2005).

[2] Haoyue Bai, Le Wu, Min Hou, Miaomiao Cai, Zhuangzhuang He, Yuyang Zhou, Richang Hong, and Meng Wang. 2024. Multimodality Invariant Learning for Multimedia-Based New Item Recommendation. SIGIR (2024), 677–686.

[3] Huilin Chen, Miaomiao Cai, Fan Liu, Zhiyong Cheng, Richang Hong, and Meng Wang. 2025. I<sup>3</sup>-MRec: Invariant Learning with Information Bottleneck for In complete Modality Recommendation. ACM MM (2025), 6133–6142.

[4] Jingyuan Chen, Hanwang Zhang, Xiangnan He, Liqiang Nie, Wei Liu, and Tat-Seng Chua. 2017. Attentive Collaborative Filtering: Multimedia Recommendation with Item- and Component-Level Attention. SIGIR (2017), 335–344.

[5] Sihan Chen, Handong Li, Qunbo Wang, Zijia Zhao, Mingzhen Sun, Xinxin Zhu, and Jing Liu. 2023. VAST: A Vision-Audio-Subtitle-Text Omni-Modality Founda tion Model and Dataset. NeurIPS (2023), 72842–72866.

[6] Giordano Cicchetti, Eleonora Grassucci, and Danilo Comminiello. 2025. A TRIAN-GLE Enables Multimodal Alignment Beyond Cosine Similarity. NeurIPS (2025).

[7] Christian Ganhör, Marta Moscati, Anna Hausberger, Shah Nawaz, and Markus Schedl. 2024. A Multimodal Single-Branch Embedding Network for Recommen dation in Cold-Start and Missing Modality Scenarios. arXiv:2409.17864 (2024).

[8] Benyamin Ghojogh, Ali Ghodsi, Fakhri Karray, and Mark Crowley. 2021. Factor Analysis, Probabilistic Principal Component Analysis, Variational Inference, and Variational Autoencoder: Tutorial and Survey. arXiv:2101.00734 (2021).

[9] Zhiqiang Guo, Jianjun Li, Guohui Li, Chaoyang Wang, Si Shi, and Bin Ruan. 2024. LGMRec: Local and Global Graph Learning for Multimodal Recommendation. AAAI (2024), 8454–8462.

[10] Ruining He and Julian McAuley. 2016. VBPR: Visual Bayesian Personalized Ranking from Implicit Feedback. AAAI (2016), 144–150

[11] Xiangnan He, Kuan Deng, Xiang Wang, Yan Li, Yongdong Zhang, and Meng Wang. 2020. LightGCN: Simplifying and Powering Graph Convolution Network for Recommendation. SIGIR (2020), 639–648.

[12] Jun Hu, Bryan Hooi, Bingsheng He, and Yinwei Wei. 2025. Modality-Independent Graph Neural Networks with Global Transformers for Multimodal Recommendation. AAAI (2025), 11790–11798.

[13] Yifan Hu, Yehuda Koren, and Chris Volinsky. 2008. Collaborative Filtering for Implicit Feedback Datasets. ICDM (2008), 263–272.

[14] Kalervo Järvelin and Jaana Kekäläinen. 2002. Cumulated Gain-Based Evaluation of IR Techniques. TOIS (2002), 422–446.

[15] Yangqin Jiang, Lianghao Xia, Wei Wei, Da Luo, Kangyi Lin, and Chao Huang. 2024. DifMM: Multi-Modal Difusion Model for Recommendation. ACM MM (2024), 7591–7599.

[16] Wang-Cheng Kang, Chen Fang, Zhaowen Wang, and Julian McAuley. 2017. Visually-Aware Fashion Recommendation and Design with Generative Image Models. ICDM (2017), 207–216.

[17] Jiwan Kim, Hongseok Kang, Sein Kim, Kibum Kim, and Chanyoung Park. 2025. Disentangling and Generating Modalities for Recommendation in Missing Modality Scenarios. SIGIR (2025), 1820–1829.

[18] Arto Klami, Seppo Virtanen, Eemeli Leppäaho, and Samuel Kaski. 2015. Group Factor Analysis. TNNLS (2015), 2136–2147.

[19] Jin Li, Shoujin Wang, Qi Zhang, Shui Yu, and Fang Chen. 2025. Generating with Fairness: A Modality-Difused Counterfactual Framework for Incomplete Multimodal Recommendations. WWW (2025), 2787–2798.

[20] Yuan Li, Jun Hu, Jiaxin Jiang, Bryan Hooi, and Bingsheng He. 2026. Robust Multimodal Recommendation via Graph Retrieval-Enhanced Modality Completion. arXiv:2605.00670 (2026).

[21] Zhenyang Li, Fan Liu, Yinwei Wei, Zhiyong Cheng, Liqiang Nie, and Mohan S. Kankanhalli. 2024. Attribute-Driven Disentangled Representation Learning for Multimodal Recommendation. ACM MM (2024), 9660–9669.

[22] Guojiao Lin, Zhen Meng, Dongjie Wang, Qingqing Long, Yuanchun Zhou, and Meng Xiao. 2024. GUME: Graphs and User Modalities Enhancement for Long-Tail Multimodal Recommendation. arXiv:2407.12338 (2024).

[23] Xixun Lin, Rui Liu, Yanan Cao, Lixin Zou, Qian Li, Yongxuan Wu, Yang Liu, Dawei Yin, and Guandong Xu. 2025. Contrastive Modality-Disentangled Learning for Multimodal Recommendation. TOIS (2025), 1–31.

[24] Zhenghong Lin, Yanchao Tan, Yunfei Zhan, Weiming Liu, Fan Wang, Chaochao Chen, Shiping Wang, and Carl Yang. 2023. Contrastive Intra- and Inter-Modality Generation for Enhancing Incomplete Multimedia Recommendation. ACM MM (2023), 6234–6242.

[25] Fan Liu, Huilin Chen, Zhiyong Cheng, Anan Liu, Liqiang Nie, and Mohan S. Kankanhalli. 2023. Disentangled Multimodal Representation Learning for Recommendation. TMM (2023), 7149–7159.

[26] Fan Liu, Huilin Chen, Zhiyong Cheng, Liqiang Nie, and Mohan S. Kankanhalli. 2023. Semantic-Guided Feature Distillation for Multimodal Recommendation. ACM MM (2023), 6567–6575.

[27] Xiaohao Liu, Xiaobo Xia, See-Kiong Ng, and Tat-Seng Chua. 2026. Principled Multimodal Representation Learning. TPAMI (2026), 9114–9128.

[28] Xiaohao Liu, Xiaobo Xia, Jiaheng Wei, Shuo Yang, Xiu Su, See-Kiong Ng, and Tat Seng Chua. 2026. Calibrated Multimodal Representation Learning with Missing Modalities. ICML (2026).

[29] Daniele Malitesta, Emanuele Rossi, Claudio Pomo, Tommaso Di Noia, and Fragkiskos D. Malliaros. 2024. Do We Really Need to Drop Items with Miss ing Modalities in Multimodal Recommendation? CIKM (2024), 3943–3948.

[30] Daniele Malitesta, Emanuele Rossi, Claudio Pomo, Tommaso Di Noia, and Fragkiskos D. Malliaros. 2026. Training-Free Graph-Based Imputation of Missing Modalities in Multimodal Recommendation. TKDE (2026), 3250–3263.

[31] Daniele Malitesta, Emanuele Rossi, Claudio Pomo, Fragkiskos D. Malliaros, and Tommaso Di Noia. 2024. Dealing with Missing Modalities in Multimodal Recom mendation: A Feature Propagation-Based Approach. arXiv:2403.19841 (2024).

[32] Julian McAuley, Christopher Targett, Qinfeng Shi, and Anton van den Hengel. 2015. Image-Based Recommendations on Styles and Substitutes. SIGIR (2015), 43–52.

[33] Jiquan Ngiam, Aditya Khosla, Mingyu Kim, Juhan Nam, Honglak Lee, and An drew Y. Ng. 2011. Multimodal Deep Learning. In ICML. 689–696.

[34] Yongxin Ni, Yu Cheng, Xiangyan Liu, Junchen Fu, Youhua Li, Xiangnan He, Yongfeng Zhang, and Fajie Yuan. 2023. A Content-Driven Micro-Video Recom mendation Dataset at Scale. arXiv:2309.15379 (2023).

[35] Rongqing Kenneth Ong and Andy W. H. Khong. 2025. Spectrum-Based Modality Representation Fusion Graph Convolutional Network for Multimodal Recom mendation. WSDM (2025), 773–781.

[36] Nils Reimers and Iryna Gurevych. 2019. Sentence-BERT: Sentence Embeddings Using Siamese BERT-Networks. EMNLP-IJCNLP (2019), 3982–3992.

[37] Stefen Rendle, Christoph Freudenthaler, Zeno Gantner, and Lars Schmidt-Thieme. 2009. BPR: Bayesian Personalized Ranking from Implicit Feedback. UAI (2009), 452–461.

[38] Nitish Srivastava and Ruslan Salakhutdinov. 2012. Multimodal Learning with Deep Boltzmann Machines In NeurIPS 2222-2230

[39] Zhulin Tao, Xiaohao Liu, Yewei Xia, Xiang Wang, Lifang Yang, Xianglin Huang, and Tat-Seng Chua. 2023. Self-Supervised Learning for Multimedia Recommen dation. TMM (2023), 5107–5116.

[40] Zhi Tao, Yinwei Wei, Xiang Wang, Xiangnan He, Xianglin Huang, and Tat-Seng Chua. 2020. MGAT: Multimodal Graph Attention Network for Recommendation. IPM (2020), 102277.

[41] Michael E. Tipping and Christopher M. Bishop. 1999. Probabilistic Principal Component Analysis. JRSS-B (1999), 611–622.

[42] Cheng Wang, Mathias Niepert, and Hui Li. 2018. LRMM: Learning to Recommend with Missing Modalities. EMNLP (2018), 3360–3370.

[43] Qifan Wang, Yinwei Wei, Jianhua Yin, Jianlong Wu, Xuemeng Song, and Liqiang Nie. 2023. DualGNN: Dual Graph Neural Network for Multimedia Recommenda tion. TMM (2023), 1074–1084.

[44] Yinwei Wei, Wenqi Liu, Fan Liu, Xiang Wang, Liqiang Nie, and Tat-Seng Chua. 2023. LightGT: A Light Graph Transformer for Multimedia Recommendation. SIGIR (2023), 1508–1517.

[45] Yinwei Wei, Xiang Wang, Liqiang Nie, Xiangnan He, and Tat-Seng Chua. 2020. GRCN: Graph-Refined Convolutional Network for Multimedia Recommendation with Implicit Feedback. ACM MM (2020), 3541–3549.

[46] Yinwei Wei, Xiang Wang, Liqiang Nie, Xiangnan He, Richang Hong, and Tat-Seng Chua. 2019. MMGCN: Multi-modal Graph Convolution Network for Personalized Recommendation of Micro-video. ACM MM (2019), 1437–1445.

[47] Jinfeng Xu, Zheyu Chen, Shuo Yang, Jinze Li, Hewei Wang, and Edith C.-H. Ngai. 2024. MENTOR: Multi-Level Self-Supervised Learning for Multimodal Recommendation. arXiv:2402.19407 (2024).

[48] Zixuan Yi, Xi Wang, Iadh Ounis, and Craig Macdonald. 2022. Multi-modal Graph Contrastive Learning for Micro-video Recommendation. SIGIR (2022), 1807–1811.

[49] Junliang Yu, Hongzhi Yin, Xin Xia, Tong Chen, Lizhen Cui, and Quoc Viet Hung Nguyen. 2022. Are Graph Augmentations Necessary? Simple Graph Contrastive Learning for Recommendation. SIGIR (2022), 1294–1303.

[50] Penghang Yu, Zhiyi Tan, Guanming Lu, and Bing-Kun Bao. 2023. Multi-View Graph Convolutional Network for Multimedia Recommendation. ACM MM (2023), 6576–6585.

[51] Penghang Yu, Zhiyi Tan, Guanming Lu, and Bing-Kun Bao. 2025. Mind Individual Information! Principal Graph Learning for Multimedia Recommendation. AAAI (2025), 13096–13105.

[52] Jinghao Zhang, Yanqiao Zhu, Qiang Liu, Shu Wu, Shuhui Wang, and Liang Wang. 2021. Mining Latent Structures for Multimedia Recommendation. ACM MM (2021), 3872–3880

[53] Xin Zhou and Zhiqi Shen. 2023. A Tale of Two Graphs: Freezing and Denoising Graph Structures for Multimodal Recommendation. ACM MM (2023), 935–943.

[54] Xin Zhou, Hongyu Zhou, Yong Liu, Zhiwei Zeng, Chunyan Miao, Pengwei Wang, Yuan You, and Feijun Jiang. 2023. Bootstrap Latent Representations for Multi Modal Recommendation. WWW (2023), 845–854.

## A Additional Method Details

The shared-latent imputation backbone in SIC follows conjugate Gaussian latent-variable modeling [1, 8, 18, 41]. This section provides the analytical posterior inference, pseudo-missing construction, graph propagation, and additional analysis omitted from the main text.

## A.1 SIC Posterior Inference

Given the observed completion-space representations $\{ \mathbf { z } _ { i } ^ { m } \} _ { m \in O _ { i } }$ and the generative parameters $\begin{array} { r } { \Theta _ { g } = \{ { \bf W } ^ { m } , { \pmb \mu } ^ { m } , \sigma _ { m } \} _ { m \in \mathcal { M } } , } \end{array}$ the posterior of the shared latent variable is:

$$
q _ {i} (\pmb {\beta} _ {i}) = p \left(\pmb {\beta} _ {i} \mid \{\mathbf {z} _ {i} ^ {m} \} _ {m \in O _ {i}}, \Theta_ {g}\right) = \mathcal {N} (\mathbf {b} _ {i}, \Sigma_ {i}),\tag{17}
$$

where

$$
\Sigma_ {i} = \left[ \mathbf {I} _ {d _ {\beta}} + \sum_ {m \in O _ {i}} \frac {(\mathbf {W} ^ {m}) ^ {\top} \mathbf {W} ^ {m}}{(\sigma_ {m}) ^ {2}} \right] ^ {- 1},\tag{18}
$$

and

$$
\mathbf {b} _ {i} = \Sigma_ {i} \sum_ {m \in O _ {i}} \frac {\left(\mathbf {W} ^ {m}\right) ^ {\top} \left(\mathbf {z} _ {i} ^ {m} - \boldsymbol {\mu} ^ {m}\right)}{\left(\sigma_ {m}\right) ^ {2}}.\tag{19}
$$

These expressions are obtained by collecting the quadratic terms in the log posterior and completing the square. Because the posterior depends only on the observed modality set $O _ { i } ,$ , the same inference applies to diferent missing patterns.

## A.2 Pseudo-Missing Inference

For each eligible pair $( i , m ) \in \mathcal { E } _ { \mathrm { p m } }$ , modality � is temporarily removed from the observed set:

$$
O _ {i} ^ {(- m)} = O _ {i} \setminus \{m \}.\tag{20}
$$

The corresponding posterior covariance and mean are:

$$
\Sigma_ {i} ^ {(- m)} = \left[ \mathbf {I} _ {d _ {\beta}} + \sum_ {n \in \mathcal {O} _ {i} ^ {(- m)}} \frac {(\mathbf {W} ^ {n}) ^ {\top} \mathbf {W} ^ {n}}{(\sigma_ {n}) ^ {2}} \right] ^ {- 1},\tag{21}
$$

and

$$
\mathbf {b} _ {i} ^ {(- m)} = \Sigma_ {i} ^ {(- m)} \sum_ {n \in \mathcal {O} _ {i} ^ {(- m)}} \frac {(\mathbf {W} ^ {n}) ^ {\top} (\mathbf {z} _ {i} ^ {n} - \boldsymbol {\mu} ^ {n})}{(\sigma_ {n}) ^ {2}}.\tag{22}
$$

The pseudo-recovered representation is:

$$
\widehat {\mathbf {z}} _ {i} ^ {m, (- m)} = \frac {\mathbf {W} ^ {m} \mathbf {b} _ {i} ^ {(- m)} + \boldsymbol {\mu} ^ {m}}{\left\| \mathbf {W} ^ {m} \mathbf {b} _ {i} ^ {(- m)} + \boldsymbol {\mu} ^ {m} \right\| _ {2} + \epsilon}.\tag{23}
$$

Pseudo-recovered and genuinely missing representations therefore follow the same posterior inference and target-modality generation process.

## A.3 Completion-Aware Graph Propagation

For modality �, collaborative and completed content similarities are first fused as:

$$
\mathbf {S} ^ {m, \mathrm{fuse}} = (1 - \eta) \mathbf {S} ^ {\mathrm{cf}} + \eta \mathbf {S} ^ {m}.\tag{24}
$$

We then retain the row-wise Top-� entries and symmetrize the resulting graph:

$$
\overline {{\mathbf {G}}} _ {\text { item }} ^ {m} = \mathcal {T} _ {k} \left(\mathsf {S} ^ {m, \text { fuse }}\right), \qquad \mathbf {G} _ {\text { item }} ^ {m} = \mathcal {S} \left(\overline {{\mathbf {G}}} _ {\text { item }} ^ {m}\right),\tag{25}
$$

where $\mathcal { T } _ { k } ( \cdot )$ denotes row-wise Top-� sparsification and $s ( \cdot )$ denotes graph symmetrization.

The modality-specific augmented adjacency matrix is:

$$
\mathbf {A} ^ {m} = \left[ \begin{array}{c c} \mathbf {0} & \mathbf {R} \\ \mathbf {R} ^ {\top} & \mathbf {G} _ {\text {item}} ^ {m} \end{array} \right].\tag{26}
$$

Following LightGCN [11], we apply symmetric normalization:

$$
\widehat {\mathbf {A}} ^ {m} = \left(\mathbf {D} ^ {m}\right) ^ {- \frac {1}{2}} \mathbf {A} ^ {m} \left(\mathbf {D} ^ {m}\right) ^ {- \frac {1}{2}}, \quad \mathbf {D} ^ {m} = \operatorname{Diag} \left(\mathbf {A} ^ {m} \mathbf {1}\right).\tag{27}
$$

The initial node representations are:

$$
\mathbf {H} ^ {m, (0)} = \left[ \begin{array}{c} \mathbf {E} _ {U} ^ {(0)} \\ \mathbf {E} _ {I} ^ {m, (0)} \end{array} \right], \qquad \mathbf {E} _ {I} ^ {m, (0)} = [ \mathbf {s} _ {1} ^ {m}, \ldots , \mathbf {s} _ {N _ {i}} ^ {m} ] ^ {\top}.\tag{28}
$$

Layer-wise propagation is performed as:

$$
\mathbf {H} ^ {m, (l + 1)} = \widehat {\mathbf {A}} ^ {m} \mathbf {H} ^ {m, (l)}.\tag{29}
$$

The representations from all layers are uniformly aggregated:

$$
\mathbf {H} ^ {m} = \frac {1}{L + 1} \sum_ {l = 0} ^ {L} \mathbf {H} ^ {m, (l)}.\tag{30}
$$

Let $\mathbf { p } _ { u } ^ { m }$ and $\mathsf { q } _ { i } ^ { m }$ denote the propagated user and item representations under modality �. The final representations are:

$$
\mathbf {h} _ {u} = \frac {1}{N _ {m}} \sum_ {m \in \mathcal {M}} \mathbf {p} _ {u} ^ {m}, \qquad \mathbf {h} _ {i} = \frac {1}{N _ {m}} \sum_ {m \in \mathcal {M}} \mathbf {q} _ {i} ^ {m}.\tag{31}
$$

During PRC training, the SIC parameters, completed modality rep resentations, and completion-aware item graphs remain fixed.

## A.4 Bimodal Interpretation of Structural Calibration

For two normalized modality representations, let $c _ { i } = ( \tilde { \mathbf { z } } _ { i } ^ { 1 } ) ^ { \top } \tilde { \mathbf { z } } _ { i } ^ { 2 }$ . Their Gram matrix is:

$$
\mathbf {G} _ {i} = \left[ \begin{array}{c c} 1 & c _ {i} \\ c _ {i} & 1 \end{array} \right],\tag{32}
$$

with eigenvalues $\lambda _ { i , 1 } = 1 + \left| c _ { i } \right|$ and $\lambda _ { i , 2 } = 1 - \vert c _ { i } \vert .$ . Consequently, the leading-eigenvalue component of $\mathcal { L } _ { \mathrm { s t r } }$ increases with $\left| { c _ { i } } \right|$ in the bimodal setting.

This component should not be interpreted as directly match ing the ground-truth cross-modal geometry or recovering a rich item-specific structural configuration. With two modalities, the within-item structure contains only one pairwise degree of free dom. The leading-eigenvalue component therefore acts as a relation concentration regularizer that discourages near-orthogonal config urations. It does not independently determine the sign or semantic correctness of the pairwise relation.

In the complete SIC objective, $\mathcal { L } _ { \mathrm { r e p } }$ constrains the conditional estimate using the observed representations, while ${ \mathcal { L } } _ { \mathrm { c o r r } }$ provides same-item correspondence supervision from genuinely observed modality pairs. The structural component is therefore optimized jointly with the imputation and correspondence objectives rather than used as an isolated recovery criterion.

When $N _ { m } = 2 ,$ the principal eigenvector is constant within each fixed similarity-sign region. The principal-direction component therefore provides no additional continuous gradient in our bimodal experiments, and the leading-eigenvalue component supplies the efective structural signal. The principal-direction formulation is retained for settings with more than two modalities, where nontrivial modality-wise directional configurations can arise. Its empirical benefit in such settings remains to be investigated.

## A.5 Model Analysis

A.5.1 Computational complexity. Let $| \mathcal { E } _ { R } | = \| \mathbf { R } \| _ { 0 } ,$ , and let $Q$ and � denote the numbers of distinct nonempty observed-modality patterns and propagation layers, respectively. The main costs of SIC are:

$$
\text { Projection: } \quad O \left(\sum_ {i \in \mathcal {I}} \sum_ {m \in O _ {i}} d _ {m} d _ {c}\right),
$$

$$
\text { Posterior   inference: } \quad O \left(N _ {m} d _ {c} d _ {\beta} ^ {2} + Q d _ {\beta} ^ {3} + \sum_ {i \in I} | O _ {i} | d _ {c} d _ {\beta} + N _ {i} d _ {\beta} ^ {2}\right),
$$

Structural calibration: $O \left( N _ { i } N _ { m } ^ { 2 } d _ { c } + N _ { i } N _ { m } ^ { 3 } + N _ { i } \vert \mathcal { B } \vert N _ { m } \right)$

(33)

Here, $( \mathbf { W } ^ { m } ) ^ { \top } \mathbf { W } ^ { m }$ is reused by items sharing the same observedmodality pattern, and the final structural-calibration term arises from batch-wise principal-direction comparison. Correspondence calibration is linear in the number of sampled observed cross-modal pairs.

Before PRC training, exact content-based neighbor construction and collaborative co-occurrence computation require:

$$
O \left(N _ {m} N _ {i} ^ {2} d _ {c} + \sum_ {u \in \mathcal {U}} \delta_ {u} ^ {2}\right), \qquad \delta_ {u} = \sum_ {i} R _ {u i}.\tag{34}
$$

In our implementation, R is stored sparsely, collaborative co-occurrence is computed by sparse matrix multiplication, and content similarities are evaluated in blocks. Only the Top-� neighbors are retained and the resulting graphs are symmetrized, so the full dense $N _ { i } \times N _ { i }$ similarity matrix is not stored simultaneously. Each modality-specific graph contains O (�<sub>�</sub>�) retained edges and is constructed once for reuse throughout PRC training.

After graph construction, the per-epoch PRC costs are:

Graph propagation:

Ranking and alignment:

$$
\begin{array}{l} O \left(L N _ {m} (| \mathcal {E} _ {R} | + k N _ {i}) d\right), \\ O \left(\left(| \mathcal {D} _ {\mathrm{BPR}} | + | \mathcal {E} _ {\mathrm{pm}} |\right) d\right). \end{array}\tag{35}
$$

Thus, the quadratic term is incurred only during exact contentneighbor construction, whereas repeated propagation is linear in the numbers of interaction and retained item-graph edges. Exact construction may still be expensive for million-scale item collections, for which approximate nearest-neighbor or distributed graph construction can be adopted.

A.5.2 Empirical eficiency. Table 4 reports per-epoch training time and full-ranking recommendation inference time under the same experimental setting. Because CaIRec is optimized sequentially, SIC and PRC are reported separately. SIC requires 5.9 seconds per training epoch. After the completed representations and item graphs are constructed, PRC requires 12.5 seconds per epoch and 5.6 seconds for full-ranking inference. The one-time missing-modality completion pass takes $3 . 9 \times 1 0 ^ { - 3 }$ seconds.

PRC has a slightly higher per-epoch training cost than DGMRec but is faster than HEAT and MoDiCF. Its full-ranking inference is faster than DGMRec and MoDiCF, while HEAT remains the fastest. These results show that recommendation-space adaptation and sparse graph propagation introduce moderate per-epoch overhead. The one-time exact item-graph construction cost is not included in the reported PRC per-epoch time and is discussed separately in the complexity analysis.

Table 4: Per-epoch training and inference/preprocessing time under the same experimental setting. The SIC entry denotes the one-time missing-modality completion pass, whereas the PRC entry denotes full-ranking recommendation inference.

<table><tr><td>Method or Stage</td><td>Train/Epoch (s)</td><td>Inference / Preprocessing (s)</td></tr><tr><td>DGMRec</td><td>10.1</td><td>10.8</td></tr><tr><td>HEAT</td><td>20.2</td><td>4.4</td></tr><tr><td>MoDiCF</td><td>761.0</td><td>33.2</td></tr><tr><td>CAIREc: SIC</td><td>5.9</td><td> $3.9 \times 10^{-3}$ </td></tr><tr><td>CAIREc: PRC</td><td>12.5</td><td>5.6</td></tr></table>

## A.6 Relation to CalMRL and Task-Specific Distinction

Although CaIRec builds on the calibrated representation recovery principle of CalMRL [28], the two methods difer fundamentally in the optimization role of the recovered modality. CalMRL studies missing modalities in generic multimodal representation learning, where anchor shift denotes the deviation between the alignment direction induced by the complete modality set and that induced by the observed subset. It estimates the missing representation to com pensate for its absent contribution to the virtual alignment anchor and thereby recalibrate the observed modality encoders. Recovery thus primarily serves as an auxiliary mechanism for improving the available modalities.

CaIRec shifts the role of recovery. It operates on pretrained item features and preserves genuinely observed modalities as di rect item content. Their shared semantics are instead used to estimate the unavailable modality, whose recovered representation is retained as explicit content and must itself become structurally reliable. Accordingly, Cross-modal Structural Distortion is related to but distinct from anchor shift: it concerns whether the recovered modality forms a coherent within-item organization with the observed modalities, rather than whether it restores an alignment direction for optimizing observed encoders. SIC therefore special izes calibrated recovery toward improving the recovered modality and organizing the completed item content.

This shift further exposes the Preference Adaptation Gap: structural reliability alone does not ensure that recovered content is com patible with the ranking-supervised representation space, while modality missingness also disrupts content-derived item neigh borhoods. PRC addresses this gap by aligning the recovery path way with its stop-gradient observed counterpart through same item, same-modality pseudo-missing supervision, and by combin ing completion-aware content relations with collaborative evidence for preference propagation. Removing PRC produces the largest module-level degradation, while removing either pseudo-missing alignment or the completion-aware item graph also consistently reduces performance. These results show that CaIRec’s contribu tion lies not in latent-variable imputation alone, but in redirecting calibrated recovery toward improving the missing modality itself and enabling its efective participation in personalized recommendation.

## A.7 Model Limitations

Our evaluation is limited to three Amazon datasets containing visual and textual modalities. Although these datasets are widely used in multimodal recommendation, they belong to the same platform and domain family. The current results therefore do not establish generalization to other domains or to settings involving audio, video, attributes, or more than two modalities.

This limitation is particularly relevant to the principal-direction component of structural calibration. In the bimodal setting, the within-item structure contains only one pairwise relation, and the principal-direction component provides no additional continuous gradient within a fixed similarity-sign region. Its role in settings with richer modality configurations remains to be empirically validated.

The main experiments also use synthetically generated modalitymissing masks. Real-world missingness may depend on item popularity, category, content quality, or interaction sparsity. Evaluating CaIRec under naturally occurring and non-random missing mechanisms is an important direction for future work.

Finally, correspondence calibration and pseudo-missing adaptation require training items with at least two genuinely observed modalities. When eligible paired observations are extremely scarce or unavailable, these objectives provide limited or no supervision. The efectiveness of CaIRec under such settings remains to be investigated.

## B Experimental Details

## B.1 Baselines and Evaluation

We compare CaIRec with eleven representative baselines covering collaborative filtering, general multimodal recommendation, and missing-aware multimodal recommendation.

• LightGCN [11] simplifies graph convolution to neighborhood aggregation and learns collaborative representations from user– item interactions.

• SimGCL [49] injects noise into node embeddings to construct contrastive views without explicit graph augmentation.

• VBPR [10] extends pairwise ranking by incorporating visual item features.

• BM3 [54] learns multimodal representations through bootstrap self-supervision over interactions and item content.

• PGL [51] uses principal subgraphs to model global co-occurrence and local personalized information.

• MIG-GT [12] combines modality-independent GNN receptive fields with a sampling-based global Transformer.

• I<sup>3</sup>-MRec [3] addresses modality incompleteness through invariant representation learning and an information bottleneck.

• MILK [2] learns modality-invariant preferences across heterogeneous missing environments.

• MoDiCF [19] combines difusion-based modality completion with counterfactual recommendation.

• DGMRec [17] disentangles modality-shared and modality-specific information before generating missing features.

• HEAT [30] performs training-free feature propagation over an item–item graph to impute unavailable modalities.

We use oficial implementations when available and reproduce the remaining baselines following their original papers. Hyperparameters are selected on the validation set, and all methods use the same data splits and modality-missing masks.

Following the full-ranking protocol commonly used in graph recommendation [11, 49], we report Recall@� and NDCG@� for $K \in \{ 1 0 , 2 0 \}$ . Recall@� measures the proportion of held-out interactions retrieved in the top-� list, while NDCG@� assigns greater weight to items ranked at higher positions [14]. For each user, all items except those observed during training are used as ranking candidates, and the results are averaged over test users.

Each method is run five times with diferent random seeds while keeping the data split and modality-missing mask fixed. Within each run, all methods use the same experimental setting. We report the mean performance over the five runs. Because the data split and missing mask remain fixed, diferences across runs arise from random initialization and stochastic optimization rather than dif ferent missing masks. Statistical significance between CaIRec and the strongest baseline is evaluated using a paired two-sided �-test.

## B.2 Hyperparameter Settings

The completion and recommendation dimensions are both set to 64, and the mini-batch size is fixed at 2,048. We tune the learning rate over $\{ 1 0 ^ { - 4 } , 5 \times 1 0 ^ { - 4 } , 1 0 ^ { - 3 } \}$ } and the $L _ { 2 }$ regularization coeficient over $\{ 1 0 ^ { - 5 } , 1 0 ^ { - 4 } , 1 0 ^ { - 3 } \}$ . The structural-calibration temperature � is selected from {0.05, 0.1, 0.2, 0.5}.

The SIC weights $\lambda _ { \mathrm { s t r } }$ and $\lambda _ { \mathrm { c o r r } }$ are selected according to validation performance from the candidate values examined in the sensitivity analysis. For PRC, we tune $\lambda _ { \mathrm { a l i g n } }$ over $\{ 1 0 ^ { - 4 } , 1 . 2 5 \times 1 0 ^ { - 3 } , 5 \times 1 0 ^ { - 3 }$ , 2× $1 0 ^ { - 2 } , 1 0 ^ { - 1 } \}$ and $\lambda _ { \mathrm { r e g } }$ over $\{ 1 0 ^ { - 3 } , 5 \times 1 0 ^ { - 3 } , 1 0 ^ { - 2 } , 2 \times 1 0 ^ { - 2 } \}$

The item-graph hyperparameters are selected from:

$$
k \in \{1, 3, 5, 1 0, 2 0 \}, \quad \eta \in \{0. 1, 0. 2 5, 0. 4, 0. 7, 0. 9 \}.\tag{36}
$$

All hyperparameters are selected according to validation Recall@20 under the same data split and modality-missing setting used for fi nal evaluation. We apply early stopping when validation Recall@20 does not improve for 30 consecutive epochs and use the best validation checkpoint for testing.

## C Further Analysis

## C.1 Performance under Single-Modality Missingness

The main experiments randomly select whether image or text is unavailable for each modality-incomplete item. We additionally consider two controlled missing directions. $T {  } I$ removes images and estimates them from text, while $I {  } T$ removes text and esti mates it from images. For each direction, we vary the missing rate from 10% to 90% and compare CaIRec with its w/o SIC variant.

Figure 6 shows that SIC consistently improves Recall@20 and NDCG@20 under both missing directions. The advantage generally increases at higher missing rates, particularly under �→� on Clothing and Beauty. This result shows that SIC remains beneficial when the missing modality type is fixed rather than randomly selected.

Table 5: Efect of stage-wise optimization on Clothing. Δ reports the relative change from the stage-wise strategy.

<table><tr><td>Training Strategy</td><td>Recall@20</td><td>NDCG@20</td><td> $\Delta$  Recall / NDCG</td></tr><tr><td>Stage-wise (Ours)</td><td>0.0814</td><td>0.0361</td><td>-</td></tr><tr><td>Warm-started Joint</td><td>0.0753</td><td>0.0337</td><td>-7.49% / -6.65%</td></tr><tr><td>From-scratch Joint (Rec-only)</td><td>0.0753</td><td>0.0336</td><td>-7.49% / -6.93%</td></tr><tr><td>From-scratch Joint (Rec+SIC)</td><td>0.0756</td><td>0.0339</td><td>-7.13% / -6.09%</td></tr></table>

Performance is generally lower under �→� than under $T {  } I ,$ especially at high missing rates. This diference may reflect the greater recommendation utility of textual content, the dificulty of estimating it from images, or both. The current experiment does not isolate these explanations. Overall, the results show that the efect of modality incompleteness depends on which modality is unavailable, while SIC provides consistent gains in both directions.

## C.2 Additional Results under Varying Missing Rates

Figure 7 reports additional results under varying modality-missing rates. Completion-based methods generally degrade more slowly than MIG-GT as the missing rate increases, indicating that explicit modality estimation can partially compensate for the loss oforiginal content. Among these methods, CaIRec maintains the strongest or near-strongest performance and shows clearer advantages under severe missingness. These observations are consistent with the robustness analysis in the main text.

## C.3 Stage-Wise Optimization

SIC and PRC optimize diferent representation spaces. SIC learns conditional modality imputation and within-item cross-modal organization, whereas PRC learns recommendation-space transformations and preference propagation. Under joint optimization, ranking gradients can update the SIC parameters through the recovered branch, causing the completion process and recommendation model to change simultaneously. Stage-wise optimization instead fixes the completion process before learning recommendation-oriented adaptation.

Table 5 shows that stage-wise optimization outperforms all three joint-training variants on Clothing. Warm-started joint training remains weaker despite using the same SIC initialization, suggesting that pretraining alone does not explain the improvement. The two from-scratch variants perform similarly, while retaining the SIC objectives yields only a modest gain over recommendation-only joint training.

These results are consistent with the rationale that fixing SIC provides a more stable input space for PRC and reduces coupling between completion and ranking objectives. However, this comparison does not establish gradient interference as the only cause of the performance diference.

![](images/4d1de2454fe6360fae38503d3bd0c9ad8fb348d7df78aa8c75547fabb2e4ef36.jpg)  
(a) Clothing

![](images/674a44e347ccc2d2a858258c24355d71e45c58c1bd529ea27642b204582ccad2.jpg)  
(b) Sports

![](images/dd2dc692e7f589836ad425dc2447f951e6fa9774b987454f3aa8463951b17d35.jpg)  
(c) Beauty

Figure 6: Performance of CaIRec and its w/o SIC variant under varying single-modality missing rates. �→� denotes image completion from text, while �→� denotes text completion from images.  
![](images/48506a3fd06d5f9e360dd6a09eddfdba74dd99880f218e2ee671d9e7c9cff157.jpg)  
(a) Clothing

![](images/c05e4b7e60ecf172b05db7bec3f8398f24b27bcfdc8187aac10be11e583b6ab1.jpg)  
(b) Clothing

![](images/339498b51f1859eedf5b8b8ad165cad26ac5920a55c8a24beaed5ff1bf627ba5.jpg)  
(c) Sports

![](images/c7da6c84ed46ec3ed7a7b434700fae4113b7a16c05a55df2073b4a2abb7a9cbc.jpg)  
(d) Beauty  
Figure 7: Additional recommendation results under varying modality-missing rates.

![](images/e1f7ed5ab83d2a1f92313bd0cd17e229602ff118e57627d92316684c39289760.jpg)

![](images/752d3cccaaff5034a7b94c47acce783c876b68e5e43bddadee574ebfd1b7cfdf.jpg)  
Figure 8: Performance of PGL and PGL+SIC on the three Amazon datasets under a 50% modality-missing rate.

## C.4 Plug-In Evaluation of SIC

We examine whether SIC can be incorporated into an existing multimodal recommender without modifying its recommendation backbone. We apply SIC to PGL and denote the resulting variant as PGL+SIC.

As shown in Figure 8, PGL+SIC consistently outperforms PGL on all three datasets in Recall@20 and NDCG@20. The gains sug gest that the completed representations produced by SIC can also support a recommendation backbone not specifically designed for modality missingness. This result provides additional evidence that SIC can serve as a plug-in completion component.

## C.5 Additional Hyperparameter Experiments

Figure 9 provides complementary NDCG@20 results for the SIC and PRC objective weights and examines the graph parameters � and � on Clothing. Here, � controls the number of neighbors retained in each modality-specific item graph, while � balances collaborative and completed content similarities. We vary one graph hyperparameter at a time while fixing the remaining settings.

Figures 9(a)–(b) show broad high-performing regions under moderate SIC and PRC objective weights. Figures 9(c)–(d) exhibit increase-then-decrease trends for the graph parameters. A very small � provides limited item neighborhoods, whereas a large value introduces less relevant neighbors. Similarly, a moderate � balances collaborative and completed content relations. These results show that CaIRec is stable around suitable settings but can be afected by excessively weak or strong calibration and graph signals.

## C.6 Additional Results on Modality-Incomplete Items

Figure 10 reports additional group-wise results under the same setting as the main text. Consistent with Figure 3, CaIRec achieves its clearest gains on modality-incomplete items, while competing methods remain competitive on modality-complete items. This shows that the overall improvement is primarily associated with items directly afected by modality missingness. The advantage over DGM-Rec on incomplete items further suggests that explicit modality completion alone may not be suficient to produce recommendationefective representations.

![](images/eb326c1e999ab5bb1da63ec8684805f31bac21ad44be5b3afbe34976bfb1fc5b.jpg)  
(a) NDCG@20

![](images/81eecf6ee24c17ad55f141033098f98755ff8040eacff08bf9851d66cbfb946a.jpg)  
(b) NDCG@20

![](images/3a2a297f264224d8cbb949c73e4b944edb1adff4d1d47c7dc96c80ad8fa4f40a.jpg)  
(c) Clothing

Figure 9: Additional hyperparameter sensitivity on Clothing.  
![](images/be6e4dbf6e0bbb5c4f25644f1323ffc5205d05f4a6993ad4e914f3e36f34c124.jpg)

![](images/fa669d3b721d09a7da02ea1c198db991626e34be3b7d000d62a382bcda7f71d7.jpg)

![](images/00e02acea1da62581ada02e43d56924b938ac5c0dd78d041c57844937d4f2c4a.jpg)

![](images/3ea611f68586eae8f26f39d958347685f940e49eb2ba0c049acc5690a8aecb35.jpg)

![](images/94a8f21cface16cab657e2d1fa7ea07c830f943babcc82479d4635884f668551.jpg)  
Figure 10: Additional performance comparison on modalityincomplete, modality-complete, and overall test-item groups.