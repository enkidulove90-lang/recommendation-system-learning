# RECLM: RECOMMENDATION INSTRUCTION TUNING

Yangqin Jiang<sup>1</sup>, Yuhao Yang<sup>1</sup>, Lianghao Xia<sup>1</sup>, Da Luo<sup>2</sup>, Kangyi Lin<sup>2</sup>, Chao Huang<sup>1∗</sup> University of Hong Kong<sup>1</sup>, Tencent<sup>2</sup>

{mrjiangyq99,chaohuang75}@gmail.com yuhao-yang@outlook.com aka\_xia@foxmail.com

## ABSTRACT

Modern recommender systems aim to deeply understand users’ complex prefer ences through their past interactions. While deep collaborative filtering approaches using Graph Neural Networks (GNNs) excel at capturing user-item relationships, their effectiveness is limited when handling sparse data or zero-shot scenarios, primarily due to constraints in ID-based embedding functions. To address these challenges, we propose a model-agnostic recommendation instruction-tuning paradigm that seamlessly integrates large language models with collaborative filtering. Our proposed Recommendation Language Model (RecLM) enhances the capture of user preference diversity through a carefully designed reinforcement learning reward function that facilitates self-augmentation of language models. Comprehensive evaluations demonstrate significant advantages of our approach across various settings, and its plug-and-play compatibility with state-of-the-art recommender systems results in notable performance enhancements. The implementation of our RecLM framework is publicly available at: https://github.com/HKUDS/RecLM.

## 1 INTRODUCTION

Recommendation systems serve as essential components of modern web applications, helping users navigate through the vast digital information landscape. These systems provide personalized suggestions across diverse platforms, including product recommendations on e-commerce platforms (Wang et al., 2020; Wu et al., 2018), content discovery on social networking sites (Jamali & Ester, 2010; Zhang et al., 2021), and viewer-tailored suggestions on video sharing platforms (Zhan et al., 2022; Jiang et al., 2024). At the core of these systems lies Collaborative Filtering (CF), a widely adopted approach that harnesses collective user preferences to generate personalized recommendations.

Current recommender systems predominantly operate within the user/item ID paradigm, where train ing data consists primarily of mapped user and item indices. While this approach has driven significant advancements in recommendation technology, particularly in data-rich scenarios (Yao et al., 2021; Yuan et al., 2023), it faces several fundamental limitations. Most notably, these systems encounter substantial challenges in cold-start scenarios and struggle to generalize effectively in zero-shot learning situations. The inherent dependency on ID-based representations becomes particularly problematic in completely cold-start settings, where systems fail to generate meaningful representations for new items, ultimately compromising their ability to deliver accurate recommendations.

Addressing the fundamental cold-start challenge in ID-based recommendation systems requires moving beyond traditional ID-based embeddings to leverage external features (e.g., textual or visual information) for generating user and item representations. However, this promising approach encounters significant practical challenges in real-world applications, primarily stemming from two critical issues: data incompleteness and quality concerns. On the incompleteness front, users frequently withhold personal information due to privacy concerns, leading to substantial gaps in external features. Simultaneously, existing data often suffers from quality issues, manifesting as misleading tags, irrelevant product specifications, or unreliable item descriptions. These challenges collectively underscore the critical need for robust methods to extract accurate, relevant, and highquality features from inherently noisy and incomplete side information—a prerequisite for achieving effective recommendation generalization in data-scarce scenarios.

Contribution. The exceptional generalization and reasoning capabilities of Large Language Models (LLMs) motivate a novel solution to cold-start recommendation challenges through specialized profiling systems based on external side information. This approach centers on developing effective language models customized for recommendation tasks, addressing two critical challenges: (i) designing robust mechanisms for LLMs to generate accurate profile representations that capture essential recommendation characteristics, especially for users or items lacking historical interactions, and (ii) developing techniques for LLMs to distill high-quality profiles from noisy feature sets while preserving the integrity of user-item interaction patterns and behavioral context.

To address these challenges, we propose RecLM, a novel recommendation instruction tuning paradigm that revolutionizes how LLMs understand behavioral contexts in recommender systems. While LLMs demonstrate superior natural language processing capabilities, they fundamentally lack the ability to model complex user-item interactions and behavioral preferences. Our approach tackles this limitation through two key technical innovations: (1) a seamless integration mechanism that fuses external user-item features with collaborative interaction patterns through specialized instruction tuning, enabling effective cold-start profiling without direct supervision signals, and (2) a reinforcement learning-based personalized feature enhancement framework that systematically reduces noise and mitigates over-smoothing effects inherent in collaborative filtering. This model-agnostic framework can be plugged into existing recommender systems to significantly enhance their generalization capacity, particularly in data-scarce scenarios. Our main contributions are as follows:

• Model-Agnostic Framework. We introduce a model-agnostic instruction tuning framework RecLM. It can be seamlessly integrated into existing recommender systems as a plug-and-play component, significantly enhancing their generalization capacity in scenarios with data scarcity.

• Enhancing Profiling System. We seamlessly integrate large language models with collaborative filtering to enhance user profiling and representation, particularly in cold-start scenarios, where current methods often struggle. Additionally, our approach employs reinforcement learning to refine profile quality, effectively addressing challenges associated with data noise and over-smoothing.

• Comprehensive Evaluation. We integrate RecLM with a range of state-of-the-art recommenders to assess the effectiveness of our approach across various settings. This includes conducting ablation studies and efficiency evaluations. Additionally, we carry out extensive experiments in real-world industrial recommendation scenarios, demonstrating the practicality and scalability of RecLM.

## 2 METHODOLOGY

## 2.1 ID-BASED COLLABORATIVE FILTERING

In the ID-based collaborative filtering (CF) paradigm, the primary goal is to optimize the ID embed dings of users and items. This optimization aims to accurately capture and represent user preferences for items, while considering the interaction patterns of users and items that are similar. Formally, we have a set of users denoted as $\mathcal { U } = \{ u _ { 1 } , \cdot \cdot \cdot , u _ { I } \}$ , and a set of items denoted as $\mathcal { V } = \{ v _ { 1 } , \cdots , v _ { J } \}$ Each user and item is assigned initial ID embeddings, represented as $\mathbf { x } _ { u }$ and $\mathbf { x } _ { v } \in \mathbb { R } ^ { d }$ respectively. The objective is to obtain optimized user and item representations, denoted as $\mathbf { e } _ { u } , \mathbf { e } _ { v } \in \mathbb { R } ^ { d }$ through a recommender model $\mathcal { R } ( \mathbf { x } _ { u } , \mathbf { x } _ { v } )$ . This model aims to maximize the posterior distribution $p ( \mathbf { e } | \bar { \mathcal { X } } ) \propto p ( \mathcal { X } | \mathbf { e } ) p ( \mathbf { e } )$ . The predicted likelihood of user-item interaction, denoted as $\hat { y } _ { u , v } ,$ is derived by performing a dot product between the user and item representations, as follows: $\hat { y } _ { u , v } = \mathbf { e } _ { u } ^ { \top } \cdot { \mathbf { e } _ { v } }$

While state-of-the-art recommender systems operating within the ID-based collaborative filtering paradigm have exhibited remarkable performance, they face significant challenges when tasked with handling cold-start recommendation scenarios, especially in situations where data scarcity is prevalent. The primary obstacle that ID-based recommenders encounter in these situations stems from the lack of past interaction history for newly introduced items. This absence of accumulated user engagement data disrupts the optimization paradigm that these systems typically rely upon, thereby making it considerably more difficult to generate accurate and meaningful representations for these items. Consequently, ID-based recommenders may encounter considerable difficulties in effectively modeling and understanding the inherent characteristics and preferences associated with these cold-start items, leading to a notable decline in the overall performance, particularly in zero-shot scenarios where no prior interaction data is available for certain items.

![](images/5ad40bb26f7c0b51ec7d77b7b73f00ab7636222de37eac545e1839c410610b4b.jpg)  
Figure 1: The Overall Framework of the Proposed RecLM.

## 2.2 TEXT-EMPOWERED USER/ITEM REPRESENTATIONS

To address the challenge of cold-start items in zero-shot recommendation scenarios, we propose a novel approach that leverages textual side features for generalized and adaptable user and item representation learning. Specifically, we seek to replace the traditional ID-based embeddings with the side information associated with the items, namely their text descriptions, represented as $\mathbf { F } \in \mathbb { R } ^ { | \nu | \times d _ { t } }$ To accomplish this, we utilize a project layer with a multi-layer perceptron $T _ { r a w }$ to map the raw textual features $\textbf { f } \in \mathbb { R } ^ { d _ { t } }$ into a lower-dimensional latent space ${ \underline { { \mathbb { R } } } } ^ { d }$ . The resulting representation $\hat { \mathbf { f } } \in \mathbb { R } ^ { d }$ is then used as the initial item representation in our model.

$$
\hat {\mathbf {f}} _ {v} = T _ {r a w} (\mathbf {f}).\tag{1}
$$

This text-driven approach enables a seamless fusion of collaborative signals with textual semantics, empowering our recommender to capture user preferences with unparalleled accuracy. Using rich textual features as initial item representations, we optimize user ID embeddings based on observed interactions. This injects valuable collaborative cues into the user and item representations, making them adaptable to evolving preferences. This synergistic learning equips our model to deeply comprehend users’ affinities for text-based items. Crucially, it also endows the system with zero-shot prediction capabilities for cold-start items lacking prior interaction data.

LLM-enhanced User/Item Profiling To further empower user representations with the rich textual semantics provided by large language models (LLMs), we propose generating user profile information that can reflect their interaction preferences. Specifically, item profiles can be derived from the profiles of users who frequently interact with them. This approach proves valuable in capturing user preferences and facilitating accurate recommendations for cold-start items.

On the user side, the ID embedding $\mathbf { x } _ { u } \in \mathbb { R } ^ { d }$ integrates with the user profile $\mathbf { p } _ { u } \in \mathbb { R } ^ { d _ { t } }$ , allowing the system to leverage the user’s ID-based embedding and their generated profile, which can capture more nuanced preferences. On the item side, the raw text $\mathbf { x } _ { v }$ combines with the item profile $\mathbf { p } _ { v } \in \mathbb { R } ^ { d _ { t } }$ enabling the system to understand the item’s characteristics and how they align with user preferences.

$$
\hat {\mathbf {f}} _ {u} ^ {a u g} = \Psi (\mathbf {x} _ {u} \mid T _ {p r o} (\mathbf {p} _ {u})), \quad \hat {\mathbf {f}} _ {v} ^ {a u g} = \Psi (\hat {\mathbf {f}} _ {v} \mid T _ {p r o} (\mathbf {p} _ {v})).\tag{2}
$$

Our framework employs a dual-MLP architecture for effective multi-modal fusion: an initial MLP encoder $\Psi ( \cdot )$ consolidates heterogeneous features, followed by a profile transformation network $T _ { p r o }$ that projects the unified embeddings into the model’s latent space. This hierarchical process generates enriched user and item representations $\hat { \pmb { \mathrm { f } } } _ { u } ^ { a u g } \in \mathbb { R } ^ { d }$ and $\hat { \pmb { \mathrm { f } } } _ { v } ^ { a u g } \in \mathbb { R } ^ { d }$ , capturing comprehensive behavioral patterns. To further enhance representation quality, we leverage state-of-the-art LLMs as profile augmentation engines, generating supplementary semantic information that significantly boosts our recommender system’s modeling capacity.

## 2.3 INSTRUCTION TUNING WITH COLLABORATIVE RELATIONSHIPS

Our RecLM framework seeks to align the collaborative relationships with the textual semantic repre sentation space through an innovative recommendation instruction tuning paradigm that seamlessly integrates user collaborative relationships into the LLM-based profiling process. The framework employs a two-phase approach: first, it utilizes knowledge distillation and dialogue-based instruction tuning to preserve high-order collaborative similarities between users and items, generating high-quality and informative user profiles. Subsequently, it leverages these refined user profiles to generate semantically aligned item profiles, resulting in a cohesive representation space that effectively captures both individual characteristics and collaborative patterns.

## 2.3.1 LLM FINE-TUNING WITH COLLABORATIVE SIGNALS

Our approach leverages llama2-7b-chat as the base model, augmented with a novel collaborative instruction tuning framework that captures both user-item interactions and profile generation capabilities. Specifically, we design specialized prompt templates incorporating collaborative signals, and construct input-output pairs using ChatGPT-3.5 to capture diverse user-item relationship patterns. Here, the ChatGPT-3.5 is utilized as a powerful LLM with strong text summary capacity to generate text profile to characterize the interaction patters among suers and items, and the collaborative relationships among them, and result in textual instructions used for collaborative instruction tuning.

## 2.3.2 COLLABORATIVE INSTRUCTION TUNING

In our recommendation instruction tuning paradigm, we propose to inject higher-order collaborative relational context through a novel two-turn collaborative instruction tuning paradigm. By incorporating collaborative signals that capture complex user-user and user-item relationships, this approach transcends the limitations of methods that rely solely on direct user-item interactions. Our framework serves a dual purpose: it empowers LLMs to generate richer and more nuanced user profiles by leveraging the collaborative network dynamics among users and items, while simultaneously addressing the fundamental challenge of insufficient direct supervision in profile generation tasks.

Profile Generation with Two-turn Dialogue. A fundamental challenge in LLM-based profile generation lies in the absence of ground truth data for direct evaluation, forcing practitioners to rely on indirect assessment through downstream recommendation performance. To address this limitation, we propose a novel two-turn collaborative instruction tuning paradigm that provides explicit supervision signals. Unlike conventional approaches that struggle with profile quality assessment, our framework leverages collaborative user relationships to guide LLMs in generating high-quality profiles through structured dialogue interactions.

• First Turn - Collaborative Profile Generation: The initial turn takes input query $\mathcal { Q }$ containing both the target user’s historical item interactions and those of similar users identified from their collaborative neighborhood. Here, user similarities are measured by the encoded user embeddings from LightGCN model (He et al., 2020). The LLM generates output response $\mathcal { R }$ consisting of user profiles that capture collaborative patterns.

$$
\mathcal {Q} _ {f i r.} = \text {Prompt} (u _ {t}, \{u _ {n} \}, \mathcal {V} _ {t}, \{\mathcal {V} _ {n} \}), \quad \mathcal {R} _ {f i r.} = \text {Prompt} (u _ {t}, \{u _ {n} \}, \mathcal {P} _ {t}, \{\mathcal {P} _ {n} \}).\tag{3}
$$

• Second Turn - Supervised Interaction Prediction: The second turn reformulates the instructiontuning task as an interaction prediction problem, aiming to enhance profile generation by incorporating explicit user-item preference signals. Specifically, the input query $\mathcal { Q }$ prompts whether target user $u _ { t }$ will interact with candidate item $v _ { t } .$ , while the output response $\mathcal { R }$ corresponds to the ground truth interaction status $( i . e .$ , yes or no) from the training dataset. To ensure balanced and informative training signals, we employ a systematic sampling strategy: For positive samples (50%), we select $v ^ { + }$ from the user’s interaction history $\nu _ { t }$ under the constraint that $v ^ { + }$ also appears in similar users’ history $\nu _ { n }$ , while removing it from $\nu _ { t }$ in first-turn instructions to prevent information leakage. For negative samples (50%), we select $v ^ { - }$ from similar users’ history $\bar { \mathcal { V } } _ { n }$ while ensuring no historical interaction exists between $u _ { t }$ and $v ^ { - }$ in the training data. This balanced sampling approach maintains unbiased training objectives while preserving crucial collaborative signals for effective profile generation.

$$
\mathcal {Q} _ {s e c.} = \left\{ \begin{array}{l l} P r o m p t (u _ {t}, v ^ {+}), & p o s. s a m p. \\ P r o m p t (u _ {t}, v ^ {-}), & n e g. s a m p. \end{array} \right. \quad \mathcal {R} _ {s e c.} = \left\{ \begin{array}{l l} \text {Yes,} & p o s. s a m p. \\ \text {No,} & n e g. s a m p. \end{array} \right.\tag{4}
$$

Tuning Strategy. For multi-turn dialogue instruction-tuning, our objective is to utilize LLM-generated responses R for weight updates while excluding queries $\bar { \mathcal { Q } } .$ . Traditional single-turn dialogue tuning, when applied to our paradigm, considers $\mathcal { Q } f i r . , \mathcal { R } _ { f i r . }$ , and $\mathcal { Q } _ { s e c . }$ as inputs, with only $\mathcal { R } _ { s e c . }$ <sub>.</sub> being predicted. This approach limits weight updates to losses from $\mathcal { R } _ { s e c }$ alone, failing to leverage the training data in multi-turn dialogues. Notably, $\mathcal { R } _ { f i r }$ contains rich textual information as multiple user profiles, which guides the generation of $\mathcal { R } _ { s e c }$ in subsequent turns. In contrast, $\mathcal { R } _ { s e c }$ consists of simpler binary responses (e.g., yes or no). Disregarding the valuable information in $\mathcal { R } _ { f i r }$ and relying on $\mathcal { R } _ { s e c }$ for fine-tuning would significantly limit the model’s learning capacity.

To address these limitations, we introduce a two-turn dialogue tuning approach. Specifically, we concatenate dialogues from both turns and apply masking techniques to differentiate between Q and $\mathcal { R }$ components. During training, the model computes losses exclusively from $\mathcal { R } .$ -marked segments, enabling both $\mathcal { R } _ { f i r }$ <sub>.</sub> and $\mathcal { R } _ { s e c }$ <sub>.</sub> to contribute to parameter optimization. This unified training strategy maximizes information utilization while effectively capturing collaborative relationships.

Inference Prompt. Following instruction-tuning, we design an inference prompt that integrates target user interactions $\nu _ { t }$ with neighbor histories $\nu _ { n }$ . This unified prompt guides LLMs to generate collaborative-aware user profiles by leveraging inter-user preference patterns.

$$
\mathcal {Q} _ {i n f.} = \text { Prompt } (u _ {t}, \{u _ {n} \}, \mathcal {V} _ {t}, \{\mathcal {V} _ {n} \}).\tag{5}
$$

## 2.4 REFINING PROFILE GENERATION THROUGH REINFORCEMENT LEARNING

We propose a reinforcement learning framework to enhance LLM-generated user profiles, focusing on improving accuracy and personalization. Our approach addresses two fundamental challenges: i) Prompt-Training Discrepancy—the inherent mismatch between inference (single-profile generation) and fine-tuning (multi-profile generation) phases that introduces potential inconsistencies in profile generation, and ii) Personalization-Collaboration Trade-off—while leveraging collaborative information enhances overall performance, it risks diluting individual user characteristics, analogous to the over-smoothing phenomenon observed in our collaborative instruction-tuning paradigm.

To address these challenges, we develop a reinforcement learning-based fine-tuning paradigm inspired by RLHF (Reinforcement Learning from Human Feedback)(Stiennon et al., 2020). Our approach consists of two key components: a reward model that evaluates LLM-generated profile quality, and an optimization procedure using Proximal Policy Optimization (PPO)(Schulman et al., 2017) that refines the LLM based on these reward signals. Through this iterative process, we progressively enhance the LLM’s ability to generate more accurate and personalized user profiles.

Reward Model. We design a reward model to evaluate the quality of LLM-generated outputs from a human perspective. Specifically, given an input pair [Q, R], the model produces a scalar value indicating the response quality. The reward model is optimized using the loss function $\mathcal { L } _ { r m }$

$$
\mathcal {L} _ {r m} = - \sum_ {i = 0} ^ {\mathcal {I}} \mathbb {E} _ {(\mathcal {Q} _ {i}, \mathcal {R} _ {i} ^ {+}, \mathcal {R} _ {i} ^ {-}) \sim D} [ \log (\sigma (r _ {\theta} (\mathcal {Q} _ {i}, \mathcal {R} _ {i} ^ {+}) - r _ {\theta} (\mathcal {Q} _ {i}, \mathcal {R} _ {i} ^ {-}))) ],\tag{6}
$$

where $r _ { \theta } ( \cdot )$ denotes the reward model, $\sigma ( \cdot )$ represents the sigmoid function, and $\mathcal { R } _ { i } ^ { + } / \mathcal { R } _ { i } ^ { - }$ indicate true/false responses respectively. For our profiling task, we maintain a consistent query $\mathcal { Q } _ { i n f }$ <sub>.</sub> while carefully constructing both positive responses $\mathcal { R } ^ { + }$ and negative responses $\mathcal { R } ^ { - }$ . We obtain $\mathcal { R } ^ { + }$ through ChatGPT and create $\mathcal { R } ^ { - }$ through two strategies:

• Diverse Negative Sampling: Multiple prompt templates generate varied low-quality responses, enabling the reward model to identify suboptimal outputs post instruction-tuning.

• Profile Substitution: Strategic replacement with similar users’ profiles helps the model discern subtle differences and prioritize personalized characteristics.

Proximal Policy Optimization. In our reinforcement learning framework, we treat the LLM M as the policy to be optimized, with the reward model approximating the true reward function. The core optimization objective is formulated as:

$$
\underset {\mathcal {M}} {\operatorname{argmax}} \mathbb {E} _ {x _ {i} \sim \mathcal {D}, y _ {i} \sim \mathcal {M}} [ R (y _ {i} | x _ {i}) ].\tag{7}
$$

To optimize M iteratively, we sample queries $\mathcal { Q } i$ from the dataset $\mathcal { D }$ and generate corresponding responses $\mathcal { R } i$ using $\mathcal { M } .$ We employ the Proximal Policy Optimization (PPO) algorithm and its associated loss function for optimization. Following Schulman et al. (2017), we enhance the reward function with a KL divergence penalty term between the original LLM $\mathcal { M } _ { 0 }$ and the optimized LLM M<sub>θ</sub>. This constraint effectively mitigates reward hacking—a phenomenon where models achieve high reward scores but poor human evaluation results. The final reward function R(·) for a given query-response pair $( \mathcal { Q } _ { i } , \mathcal { R } _ { i } )$ is defined as:

$$
R (\mathcal {R} _ {i} | \mathcal {Q} _ {i}) = \hat {r} (\mathcal {R} _ {i} | \mathcal {Q} _ {i}) - \beta D _ {K L} (\mathcal {M} _ {\theta} (\mathcal {Q} _ {i}) | | \mathcal {M} _ {0} (\mathcal {Q} _ {i}))\tag{8}
$$

The comprehensive details of our instruction design across all fine-tuning stages, together with our methodology for constructing positive and negative training samples for the reinforcement learning-based reward model, are thoroughly documented in Appendix 6.6.

## 3 EVALUATION

In this section, we verify the effectiveness of RecLM by answering the following several questions:

• RQ1: How does our proposed RecLM enhance the performance of existing recommender systems, particularly in item cold-start scenarios?

• RQ2: What contributions do the instruction-tuning techniques and reinforcement learning enhancements make to overall recommendation performance?

• RQ3: How effective is our LLM-empowered user/item profiling system as an embedding function?

• RQ4: How does our method perform in terms of efficiency?

• RQ5: What advantages does our method have compared to existing LLM-enhanced recommenders?

• RQ6: How does the reinforcement learning-based profile generation refinement enhance the performance of our LLM-empowered profiling system?

## 3.1 EXPERIMENTAL SETTINGS

To evaluate the effectiveness of our proposed method, we conduct extensive experiments using two public datasets: MIND<sup>1</sup> (Wu et al., 2020) and Netflix<sup>2</sup>, along with a large-scale dataset derived from real-world industrial data (referred to as Industrial for anonymity).

We assess the accuracy of the top-K recommendation results using two widely adopted metrics: Recall@K (R@K) and NDCG (N@K), with K set to 20 by default. To reduce bias, we employ an all-rank evaluation strategy, where positive items in the test set are ranked alongside all non-interacted items for each user. The final metric is reported as the average score across all users in the test set.

We evaluate the effectiveness of our RecLM approach by integrating it with state-of-the-art recommender systems, allowing us to assess performance improvements in a model-agnostic manner compared to baseline models. The selected CF recommenders include non-graph methods such as BiasMF (Koren et al., 2009) and NCF (He et al., 2017), the GNN-enhanced method LightGCN (He et al., 2020), and graph contrastive learning approaches SGL (Wu et al., 2021) and SimGCL (Yu et al., 2022). Details regarding the datasets and baseline methods are provided in Appendices 6.1 and 6.2.

## 3.2 PERFORMANCE COMPARISON (RQ1)

To demonstrate the effectiveness of our RecLM in enhancing performance, particularly in cold-start scenarios, we apply it to five common collaborative filtering methods. The "full-shot" setting corresponds to the complete dataset, while the "zero-shot" setting refers to the pure cold-start condition. The Base variant applies the cold-start recommendation paradigm to the baseline recommenders without any profiling enhancement via LLMs, whereas the Augment variant integrates RecLM into the base recommenders. Detailed settings and implementation information are provided in Appendices 6.3 and 6.5. The evaluation results in Table 1 reveal several interesting observations.

(i) Performance Improvement in Integrated Recommenders. We consistently find that integrating RecLM with backbone recommenders leads to enhanced performance compared to the base variant, which relies on raw external item features and ID-based user embeddings in both supervised and zero-shot settings. This provides compelling evidence for the effectiveness of RecLM. We attribute these improvements to two key factors: First, for supervised recommendation scenarios, RecLM leverages instruction-tuned LLMs to generate accurate user and item profiles as auxiliary information, effectively enhancing the semantic representation of user preference. Second, our tuning paradigm guides the LLMs in capturing user collaborative relationships, allowing for the generation of highquality, personalized profiles that demonstrate strong generalization in zero-shot scenarios.

Table 1: Performance comparison on MIND, Netflix and Industrial data in terms of Recall and NDCG. The superscript \* indicates the improvement is statistically significant where the p-value < 0.05.

<table><tr><td colspan="2">Dataset</td><td colspan="4">MIND</td><td colspan="4">Netflix</td><td colspan="4">Industrial</td></tr><tr><td>Backbone</td><td>Variants</td><td>R@20</td><td>R@40</td><td>N@20</td><td>N@40</td><td>R@20</td><td>R@40</td><td>N@20</td><td>N@40</td><td>R@20</td><td>R@40</td><td>N@20</td><td>N@40</td></tr><tr><td colspan="14">Full-Shot Setting</td></tr><tr><td rowspan="3">BiasMF</td><td>Base</td><td>0.0683</td><td>0.1039</td><td>0.0311</td><td>0.0399</td><td>0.0449</td><td>0.0790</td><td>0.1451</td><td>0.1375</td><td>0.0078</td><td>0.0143</td><td>0.0046</td><td>0.0066</td></tr><tr><td>Augment.</td><td>0.0719*</td><td>0.1353*</td><td>0.0272</td><td>0.0411*</td><td>0.0531*</td><td>0.0868*</td><td>0.1761*</td><td>0.1630*</td><td>0.0121*</td><td>0.0198*</td><td>0.0074*</td><td>0.0097*</td></tr><tr><td>Improve.</td><td>5.27%↑</td><td>30.22%↑</td><td>12.54%↓</td><td>3.01%↑</td><td>18.26%↑</td><td>9.87%↑</td><td>21.36%↑</td><td>18.55%↑</td><td>55.13%↑</td><td>38.46%↑</td><td>60.87%↑</td><td>46.97%↑</td></tr><tr><td rowspan="3">NCF</td><td>Base</td><td>0.0713</td><td>0.0985</td><td>0.0325</td><td>0.0445</td><td>0.0581</td><td>0.0936</td><td>0.1848</td><td>0.1721</td><td>0.0102</td><td>0.0076</td><td>0.0188</td><td>0.0091</td></tr><tr><td>Augment.</td><td>0.0760*</td><td>0.1233*</td><td>0.0288</td><td>0.0414</td><td>0.0591*</td><td>0.0968*</td><td>0.1903*</td><td>0.1785*</td><td>0.0133*</td><td>0.0087*</td><td>0.0206*</td><td>0.0108**</td></tr><tr><td>Improve.</td><td>6.59%↑</td><td>25.18%↑</td><td>11.38%↓</td><td>6.97%↓</td><td>1.72%↑</td><td>3.42%↑</td><td>2.98%↑</td><td>3.72%↑</td><td>30.39%↑</td><td>14.47%↑</td><td>9.57%↑</td><td>18.68%↑</td></tr><tr><td rowspan="3">LightGCN</td><td>Base</td><td>0.0389</td><td>0.0702</td><td>0.0150</td><td>0.0219</td><td>0.0467</td><td>0.0815</td><td>0.1488</td><td>0.1424</td><td>0.0096</td><td>0.0162</td><td>0.0059</td><td>0.0076</td></tr><tr><td>Augment.</td><td>0.0788*</td><td>0.0983*</td><td>0.0337*</td><td>0.0384*</td><td>0.0652*</td><td>0.1026*</td><td>0.1703*</td><td>0.1606*</td><td>0.0143*</td><td>0.0225*</td><td>0.0087*</td><td>0.0107*</td></tr><tr><td>Improve.</td><td>102.57%↑</td><td>40.03%↑</td><td>124.67%↑</td><td>75.34%↑</td><td>39.61%↑</td><td>25.89%↑</td><td>14.45%↑</td><td>12.78%↑</td><td>48.96%↑</td><td>38.89%↑</td><td>47.46%↑</td><td>40.79%↑</td></tr><tr><td rowspan="3">SGL</td><td>Base</td><td>0.0345</td><td>0.0708</td><td>0.0127</td><td>0.0210</td><td>0.0277</td><td>0.0416</td><td>0.0855</td><td>0.0762</td><td>0.0078</td><td>0.0138</td><td>0.0050</td><td>0.0068</td></tr><tr><td>Augment.</td><td>0.0732*</td><td>0.0967*</td><td>0.0367*</td><td>0.0421*</td><td>0.0788*</td><td>0.1204*</td><td>0.1958*</td><td>0.1831*</td><td>0.0133*</td><td>0.0221*</td><td>0.0080*</td><td>0.0106*</td></tr><tr><td>Improve.</td><td>112.17%↑</td><td>36.58%↑</td><td>188.98%↑</td><td>100.48%↑</td><td>184.48%↑</td><td>189.42%↑</td><td>129.01%↑</td><td>140.29%↑</td><td>70.51%↑</td><td>60.14%↑</td><td>60%↑</td><td>55.88%↑</td></tr><tr><td rowspan="3">SimGCL</td><td>Base</td><td>0.0421</td><td>0.0636</td><td>0.0155</td><td>0.0212</td><td>0.0231</td><td>0.0441</td><td>0.0810</td><td>0.0825</td><td>0.0042</td><td>0.0078</td><td>0.0026</td><td>0.0037</td></tr><tr><td>Augment.</td><td>0.0576*</td><td>0.0908*</td><td>0.0232*</td><td>0.0329*</td><td>0.0567*</td><td>0.0908*</td><td>0.1782*</td><td>0.1673*</td><td>0.0128*</td><td>0.0205*</td><td>0.0080*</td><td>0.0099*</td></tr><tr><td>Improve.</td><td>36.82%↑</td><td>42.77%↑</td><td>49.68%↑</td><td>55.19%↑</td><td>145.45%↑</td><td>105.90%↑</td><td>120.00%↑</td><td>102.79%↑</td><td>204.76%↑</td><td>162.82%↑</td><td>207.69%↑</td><td>167.57%↑</td></tr><tr><td colspan="14">Zero-Shot Setting</td></tr><tr><td rowspan="3">BiasMF</td><td>Base</td><td>0.0096</td><td>0.0165</td><td>0.0031</td><td>0.0041</td><td>0.0311</td><td>0.0769</td><td>0.0167</td><td>0.0292</td><td>0.0038</td><td>0.0068</td><td>0.0020</td><td>0.0029</td></tr><tr><td>Augment.</td><td>0.0246*</td><td>0.0373*</td><td>0.0107*</td><td>0.0135*</td><td>0.1381*</td><td>0.1490*</td><td>0.0828*</td><td>0.0584*</td><td>0.0056*</td><td>0.0103*</td><td>0.0026*</td><td>0.0040*</td></tr><tr><td>Improve.</td><td>156.25%↑</td><td>126.06%↑</td><td>245.16%↑</td><td>229.27%↑</td><td>344.05%↑</td><td>93.76%↑</td><td>395.81%↑</td><td>100.00%↑</td><td>47.37%↑</td><td>51.47%↑</td><td>30.00%↑</td><td>37.93%↑</td></tr><tr><td rowspan="3">NCF</td><td>Base</td><td>0.0301</td><td>0.0383</td><td>0.0080</td><td>0.0097</td><td>0.0480</td><td>0.1158</td><td>0.0196</td><td>0.0384</td><td>0.0044</td><td>0.0022</td><td>0.0056</td><td>0.0026</td></tr><tr><td>Augment.</td><td>0.0424*</td><td>0.0469*</td><td>0.0112*</td><td>0.0122*</td><td>0.1700*</td><td>0.1774*</td><td>0.0984*</td><td>0.0974*</td><td>0.0051*</td><td>0.0031*</td><td>0.0088*</td><td>0.0041*</td></tr><tr><td>Improve.</td><td>40.86%↑</td><td>22.45%↑</td><td>40.00%↑</td><td>25.77%↑</td><td>254.17%↑</td><td>53.20%↑</td><td>402.04%↑</td><td>153.65%↑</td><td>15.91%↑</td><td>40.91%↑</td><td>57.14%↑</td><td>57.69%↑</td></tr><tr><td rowspan="3">LightGCN</td><td>Base</td><td>0.0138</td><td>0.0292</td><td>0.0046</td><td>0.0078</td><td>0.0974</td><td>0.1256</td><td>0.0446</td><td>0.0415</td><td>0.0092</td><td>0.0160</td><td>0.0051</td><td>0.0070</td></tr><tr><td>Augment.</td><td>0.0196*</td><td>0.0389*</td><td>0.0064*</td><td>0.0086*</td><td>0.1371*</td><td>0.1453*</td><td>0.0697*</td><td>0.0459*</td><td>0.0133*</td><td>0.0188*</td><td>0.0090*</td><td>0.0106*</td></tr><tr><td>Improve.</td><td>42.03%↑</td><td>33.22%↑</td><td>39.13%↑</td><td>10.26%↑</td><td>40.76%↑</td><td>15.68%↑</td><td>56.28%↑</td><td>10.60%↑</td><td>44.57%↑</td><td>17.50%↑</td><td>76.47%↑</td><td>51.43%↑</td></tr><tr><td rowspan="3">SGL</td><td>Base</td><td>0.0162</td><td>0.0264</td><td>0.0062</td><td>0.0074</td><td>0.0385</td><td>0.1441</td><td>0.0274</td><td>0.0579</td><td>0.0065</td><td>0.0114</td><td>0.0036</td><td>0.0050</td></tr><tr><td>Augment.</td><td>0.0254*</td><td>0.0450*</td><td>0.0089*</td><td>0.0107*</td><td>0.1126*</td><td>0.1756*</td><td>0.0384*</td><td>0.1066*</td><td>0.0111*</td><td>0.0176*</td><td>0.0066*</td><td>0.0084*</td></tr><tr><td>Improve.</td><td>56.79%↑</td><td>70.45%↑</td><td>43.55%↑</td><td>44.59%↑</td><td>92.47%↑</td><td>21.86%↑</td><td>40.15%↑</td><td>84.11%↑</td><td>70.77%↑</td><td>54.39%↑</td><td>83.33%↑</td><td>68.00%↑</td></tr><tr><td rowspan="3">SimGCL</td><td>Base</td><td>0.0164</td><td>0.0300</td><td>0.0055</td><td>0.0084</td><td>0.0793</td><td>0.1259</td><td>0.0336</td><td>0.0460</td><td>0.0078</td><td>0.0140</td><td>0.0042</td><td>0.0059</td></tr><tr><td>Augment.</td><td>0.0312*</td><td>0.0388*</td><td>0.0098*</td><td>0.0115*</td><td>0.1508*</td><td>0.1895*</td><td>0.1550*</td><td>0.1647*</td><td>0.0084*</td><td>0.0137</td><td>0.0044*</td><td>0.0059</td></tr><tr><td>Improve.</td><td>90.24%↑</td><td>29.33%↑</td><td>78.18%↑</td><td>36.90%↑</td><td>90.16%↑</td><td>50.52%↑</td><td>361.31%↑</td><td>258.04%↑</td><td>7.69%↑</td><td>2.14%↓</td><td>4.76%↑</td><td></td></tr></table>

(ii) Outstanding Performance in Cold-Start Scenarios. This improvement arises from our innovative modifications to the ID-embedding paradigm employed in current recommenders. By incorporating external features specifically designed to address the challenges of interaction data scarcity, we have significantly enhanced the effectiveness of these systems. Remarkably, we observe substantial performance improvements even in the relatively sparser MIND and Industrial datasets, where data limitations traditionally pose significant hurdles. By leveraging our RecLM for user and item profiling, we significantly enhance the generalization capabilities of existing recommenders.

(iii) Practicality and Scalability for Real-World Deployment. The results from the Industrial dataset demonstrate that RecLM consistently enhances the performance of recommenders in largescale, highly sparse real-world scenarios. Furthermore, our user and item profile generation methods can be efficiently executed as an offline profiling system to support online applications, making them highly practical for real-world recommendations. To facilitate online recommendation systems, user and item profiles can be updated at regular intervals, such as daily or weekly. The performance improvements observed across various backbone models indicate that RecLM can easily adapt to a range of business models, significantly enhancing their overall effectiveness.

## 3.3 ABLATION STUDY (RQ2)

We conducted extensive experiments to validate the effectiveness of our proposed instruction tuning techniques by customizing three variants of RecLM: GPT\_KD, Naive, and Mask. Detailed descriptions of these variants can be found in Appendix 6.4. The results of our experiments are illustrated in Figure 2, allowing us to draw the following conclusions:

(i) Advantage of Collaborative Instruction Tuning. The results in Figure 2 show that using instruction tuning to capture collaborative relationships among users and items, along with the masking tuning strategy (Mask), significantly enhances performance compared to GPT\_KD. This improvement suggests that our tuning solution generates more precise, high-quality profiles by leveraging collaborative information effectively. In contrast, profiling based solely on user interaction history has limitations, as it lacks the guidance from collaborative insights. Consequently, this approach often results in less accurate profiles that may include noisy interaction records.

![](images/d726e245f5a0bba01d745135bdf3811e168599d08f0e16755b7f07508f113bd9.jpg)

![](images/0936f8ee38960487b648104ad7ebb73c24ec6d48f19e3b9f7b9c0ce2be6fa396.jpg)  
(a) MIND data

![](images/a5802759635884abd6ddd6cbb2e24d1e6902ce414e89578731e10608c0b93dd1.jpg)

![](images/8b25125408857c264257eb20c8893a6ac5d1aad690bcbf3beef7e3821fcb9569.jpg)  
(b) Netflix data  
Figure 2: Ablation study on the LLM tuning techniques in the RecLM framework.

(ii) Effectiveness of the Masking-Based Tuning Strategy. Although the Naive variant also employs a two-round dialogue-based instruction tuning technique similar to the Mask variant, its improvement over the GPT\_KD variant is limited. This underscores the advantages of the masking-based tuning strategy, which effectively utilizes responses from the two-round dialogue to update the weights of the LLM and guide its learning of collaborative relationships between users.

(iii) Benefits of Reinforcement Learning-Based Profile Generation Refinement. The results indicate that the Mask variant performs significantly worse than RecLM. This finding suggests that the proposed reinforcement learning (RL)-based profile generation refinement technique effectively addresses the noise issues and over-smoothing problems associated with the collaborative instruction tuning paradigm. As a result, it enables the LLM to generate more accurate and personalized profiles.

## 3.4 EFFECTIVENESS OF LLM-EMPOWERED PROFILING SYSTEM IN RECLM (RQ3)

To investigate the impact of our LLMempowered profiling system on user and item feature enhancements, we developed two variants of RecLM: one that excludes user feature enhancement (i.e., w/o User Aug.) and another that excludes item feature enhancement (i.e., w/o Item Aug.). The experiments were conducted on the MIND and Netflix datasets using the full-shot setting, with LightGCN and SGL as the backbone models. The evaluation results are presented in Table 2, allowing us to draw the following conclusions.

Table 2: Performance w.r.t. various aug. variants.

<table><tr><td colspan="2">Dataset</td><td colspan="2">MIND</td><td colspan="2">Netflix</td></tr><tr><td>Backbone</td><td>Variants</td><td>R@20</td><td>N@20</td><td>R@20</td><td>N@20</td></tr><tr><td rowspan="4">LightGCN</td><td>Base</td><td>0.0389</td><td>0.0150</td><td>0.0467</td><td>0.1488</td></tr><tr><td>w/o User Aug.</td><td>0.0302</td><td>0.0123</td><td>0.0384</td><td>0.1213</td></tr><tr><td>w/o Item Aug.</td><td>0.0719</td><td>0.0287</td><td>0.0505</td><td>0.1621</td></tr><tr><td>RecLM</td><td>0.0788</td><td>0.0337</td><td>0.0652</td><td>0.1703</td></tr><tr><td rowspan="4">SGL</td><td>Base</td><td>0.0345</td><td>0.0127</td><td>0.0277</td><td>0.0855</td></tr><tr><td>w/o User Aug.</td><td>0.0253</td><td>0.0093</td><td>0.0173</td><td>0.0578</td></tr><tr><td>w/o Item Aug.</td><td>0.0719</td><td>0.0289</td><td>0.0502</td><td>0.1546</td></tr><tr><td>RecLM</td><td>0.0732</td><td>0.0367</td><td>0.0788</td><td>0.1958</td></tr></table>

(i) User-Side Feature Enhancement. The exclusion of user-side feature enhancements (i.e., w/o User Aug.) results in a significant decline in performance across both evaluated datasets and backbone models. This underscores the critical role of our RecLM as the profiling system for improving performance. Relying solely on the original ID embedding for the user side is insufficient for effectively capturing and modeling user preferences. We attribute this outcome to both the effective extraction of text features and the successful integration of graph and textual information.

(ii) Item-Side Feature Enhancement. The exclusion of item-side feature enhancements (i.e., w/o Item Aug.) also leads to a noticeable decline in the recommender’s performance. Interestingly, when item-side feature enhancements are retained without incorporating any user-side feature enhancements (i.e., w/o User Aug.), the performance can drop even below that of the Base variant. This discrepancy can be attributed to the interplay between raw and enhanced features on the item side, which creates a complex dynamic. Relying solely on ID embedding for the user side proves inadequate for effectively modeling user preferences.

## 3.5 TRAINING EFFICIENCY ANALYSIS OF RECLM (RQ4)

To evaluate the efficiency of our RecLM approach, we conduct both a theoretical complexity analysis and an empirical running time test. Theoretical Analysis: The time complexity of the MLP used to transfer textual features $\mathbf { f } \in \mathbb { R } ^ { d _ { t } }$ of items into the model’s latent space $\mathbb { R } ^ { d }$ is $\mathcal { O } ( N \times ( d _ { t } \times d + d \times d ) )$ , where N represents the number of nodes, and $d _ { t }$ and d denote the dimensionalities of the original text features and the latent space, respectively. Empirical Evaluation: We present the per-epoch training time in Table 3. The evaluation was conducted on a server equipped with NVIDIA A100 GPUs (40 GB memory). The results indicate that for larger models (e.g., GNN-based methods), our RecLM requires relatively little

Table 3: Training efficiency w.r.t. integration with various recommenders.

<table><tr><td>Dataset</td><td>Recommender</td><td>Base</td><td>RecLM</td><td>Cost</td></tr><tr><td rowspan="5">MIND</td><td>BiasMF</td><td>0.72s</td><td>0.85s</td><td>+18.06%</td></tr><tr><td>NCF</td><td>0.76s</td><td>0.85s</td><td>+11.84%</td></tr><tr><td>LightGCN</td><td>0.79s</td><td>0.86s</td><td>+8.86%</td></tr><tr><td>SGL</td><td>1.93s</td><td>2.01s</td><td>+4.15%</td></tr><tr><td>SimGCL</td><td>2.63s</td><td>2.69s</td><td>+2.28%</td></tr><tr><td rowspan="5">Netflix</td><td>BiasMF</td><td>14.38s</td><td>16.42s</td><td>+14.19%</td></tr><tr><td>NCF</td><td>15.02s</td><td>17.17s</td><td>+14.31%</td></tr><tr><td>LightGCN</td><td>20.47s</td><td>20.95s</td><td>+2.34%</td></tr><tr><td>SGL</td><td>64.98s</td><td>65.08s</td><td>+0.15%</td></tr><tr><td>SimGCL</td><td>44.02s</td><td>44.61s</td><td>+1.34%</td></tr><tr><td rowspan="5">Industrial</td><td>BiasMF</td><td>7.07s</td><td>8.85s</td><td>+25.18%</td></tr><tr><td>NCF</td><td>7.58s</td><td>8.45s</td><td>+11.48%</td></tr><tr><td>LightGCN</td><td>9.33s</td><td>10.25s</td><td>+9.86%</td></tr><tr><td>SGL</td><td>32.34s</td><td>32.87s</td><td>+1.64%</td></tr><tr><td>SimGCL</td><td>85.41s</td><td>86.52s</td><td>+1.30%</td></tr></table>

additional time, often falling below 10%. In denser datasets like Netflix, this additional time can be reduced to under 5%. Even for smaller recommenders, the maximum additional time is approximately 25%. Given the substantial improvements in recommendation provided by our method, the incurred costs are considered acceptable.

## 3.6 COMPARISON WITH EXISTING LLM-ENHANCED METHODS(RQ5)

We further compare RecLM with the existing work LLMRec (Wei et al., 2024), which also enhances recommendation systems using LLMs, to highlight the superiority of our proposed instruction-tuning technique. The experimental results are presented in Figure 3. Specifically, LLMRec generates profiles for items and users by directly calling the LLM’s API without fine-tuning for the profile generation task. This approach fails to effectively leverage the collaborative relationships among users. As a result, RecLM demonstrates significant performance advantages across two public datasets, leading to notable improvements in the performance of the base models.

![](images/0ac7877d1028b2ad0cf68d62ca19822ab062edf0f433250601c4dff06f4de308.jpg)

![](images/33b4fa9565f1cd7c34a7bbb96b361b716fc2adec2a26f748bc857a8e98d90e08.jpg)  
(a) MIND data

![](images/4bc73399a1cfda9ab94efe452407f86e291f295ed49b3411b99b94ad06b3be12.jpg)

![](images/ebc29d009677a155e68061b9c88b06f9a1ea3056483c093f9ac91a8e14288d1a.jpg)  
(b) Netflix data

## 3.7 CASE STUDY(RQ6)

To intuitively explore the contribution of reinforcement learning to the personalization of generated profiles, we conducted a case study using the MIND dataset. In this study, as shown in Figure 4, the target user for whom the profile is being generated is User 49. This user has interacted with two items: Item 472 and Item 1572. Additionally, we identified three similar users who provide collaborative information: User 11451, User 20522, and User 341.

The user profile generated for User 49 after instruction tuning, but without reinforcement learning (RL) tuning, contains several irrelevant keywords related to the interacted items, such as "Foodie," "Food and drink," and "Horoscope."

Figure 3: Performance Comparison with LLMRec.  
![](images/ec96addd49c44e7b06bed0fc473ff30cd5078309f79055f04c31a0871c282395.jpg)  
Figure 4: Generated profiles w/ and w/o RL.

Notably, these terms also appear in the profiles of User 11451 and User 20522, suggesting that the generated profile is overly influenced by too many collaborative users. In contrast, the profile generated for User 49 after RL tuning effectively preserves the preferences indicated in the interaction history while incorporating relevant implicit keywords from collaborative users. For example, the term "pop culture" is derived from User 341’s profile. This approach provides precise and valuable additional information for modeling User 49’s preferences. We attribute this improvement to our proposed RL-based personalized feature enhancement techniques, which effectively address the noise and over-smoothing issues that can arise during the instruction-tuning process.

## 4 RELATED WORK

## 4.1 ID-BASED RECOMMENDER SYSTEMS

In recommender systems, numerous collaborative filtering models have been proposed to map users and items into latent representations based on user/item IDs (Koren et al., 2021; Su & Khoshgoftaar, 2009). These methods have evolved significantly, starting from early matrix factorization techniques, such as BiasMF (Koren et al., 2009), to the introduction of Neural Collaborative Filtering (NCF) with the advent of neural networks (He et al., 2017). Recently, advancements in Graph Neural Networks (GNNs) have opened promising avenues for constructing bipartite graphs based on useritem interaction history, allowing for the capture of high-order collaborative relationships. GNN-based methods, including NGCF (Wang et al., 2019), GCCF (Chen et al.), and LightGCN (He et al., 2020), have demonstrated state-of-the-art performance, enhancing the effectiveness of recommendation.

Additionally, researchers have incorporated self-supervised learning (SSL) techniques as supplementary learning objectives to improve the robustness of recommenders and address challenges related to data sparsity and noise (Yu et al., 2023). Contrastive learning (CL), a widely adopted SSL technique, has been effectively applied in CF research through approaches such as SGL (Wu et al., 2021), SimGCL (Yu et al., 2022), NCL (Lin et al., 2022), and AdaGCL (Jiang et al., 2023). Despite these advancements, ID-based recommenders still face significant limitations, particularly in completely cold-start scenarios and in terms of model transferability (Yuan et al., 2023).

## 4.2 LARGE LANGUAGE MODELS (LLMS) FOR RECOMMENDATION

The application of large language models (LLMs) in recommender systems has garnered significant attention (Fan et al., 2024; Lin et al., 2023; Liu et al., 2023). Current approaches can be categorized into two main types. The first category includes methods such as P5 (Geng et al., 2022) and Chat-REC (Gao et al., 2023), which emphasize designing prompts aligned with recommendation tasks, utilizing the LLM directly as the inference model. The second category enhances existing recommenders by integrating LLMs while still relying on traditional collaborative filtering methods (Wang et al., 2024). For instance, LLMRec (Wei et al., 2024) strengthens the user-item interaction graph through LLM-based graph augmentation, while RLMRec (Ren et al., 2024) combines LLM-enhanced text embeddings with GNN-based user/item representations. However, these approaches often lack fine-tuning tailored to specific recommendation tasks, primarily focusing on full-shot scenarios.

In contrast, our work introduces a novel instruction-tuning technique for an open-source LLM, allowing it to adapt to specific recommendation tasks and effectively capture collaborative information for profile generation. While methods like InstructRec (Zhang et al., 2023) and TALLRec (Bao et al., 2023) align LLM capabilities with recommendation tasks, they struggle with scalability due to instruction-question-answering prompts and exhibit poor generalization on sparse data. Our approach enhances the generalization ability of existing recommender systems in the face of data scarcity and noise, while maintaining efficiency in handling large-scale data in practical scenarios.

## 5 CONCLUSION

In this work, by seamlessly integrating large language models with collaborative filtering, we have introduced a novel instruction-tuning paradigm that equips language models with the critical ability to capture complex user-item interactions and behavioral preferences. This model-agnostic approach can be easily plugged into existing recommender systems, dramatically enhancing their generalization capacity, particularly in data-scarce scenarios where traditional ID-based methods often struggle. The two key innovations of RecLM - the fusion of external features with collaborative patterns through specialized instruction tuning, and the reinforcement learning-based personalized feature enhancement framework - address the fundamental challenges of cold-start profiling and data noise inherent in recommendation tasks. Comprehensive evaluations demonstrate the significant advantages and practical compatibility of our approach with state-of-the-art recommender systems.

## REFERENCES

Keqin Bao, Jizhi Zhang, Yang Zhang, Wenjie Wang, Fuli Feng, and Xiangnan He. Tallrec: An effective and efficient tuning framework to align large language model with recommendation. In RecSys, pp. 1007–1014, 2023.

Lei Chen, Le Wu, Richang Hong, Kun Zhang, and Meng Wang. Revisiting graph based collaborative filtering: A linear residual graph convolutional network approach. In AAAI’20.

Wenqi Fan, Zihuai Zhao, Jiatong Li, Yunqing Liu, Xiaowei Mei, Yiqi Wang, Jiliang Tang, and Qing Li. Recommender systems in the era of large language models (llms). TKDE, 2024.

Yunfan Gao, Tao Sheng, Youlin Xiang, Yun Xiong, Haofen Wang, and Jiawei Zhang. Chatrec: Towards interactive and explainable llms-augmented recommender system. arXiv preprint arXiv:2303.14524, 2023.

Shijie Geng, Shuchang Liu, Zuohui Fu, Yingqiang Ge, and Yongfeng Zhang. Recommendation as language processing (rlp): A unified pretrain, personalized prompt & predict paradigm (p5). In RecSys, pp. 299–315, 2022.

Xiangnan He, Lizi Liao, Hanwang Zhang, Liqiang Nie, Xia Hu, and Tat-Seng Chua. Neural collaborative filtering. In WWW, pp. 173–182, 2017.

Xiangnan He, Kuan Deng, Xiang Wang, Yan Li, Yongdong Zhang, and Meng Wang. Lightgcn: Simplifying and powering graph convolution network for recommendation. In SIGIR, pp. 639–648, 2020.

Edward J Hu, Yelong Shen, Phillip Wallis, Zeyuan Allen-Zhu, Yuanzhi Li, Shean Wang, Lu Wang, and Weizhu Chen. Lora: Low-rank adaptation of large language models. arXiv preprint arXiv:2106.09685, 2021.

Mohsen Jamali and Martin Ester. A matrix factorization technique with trust propagation for recommendation in social networks. In RecSys, pp. 135–142, 2010.

Yangqin Jiang, Chao Huang, and Lianghao Xia. Adaptive graph contrastive learning for recommendation. In KDD, pp. 4252–4261, 2023.

Yangqin Jiang, Lianghao Xia, Wei Wei, Da Luo, Kangyi Lin, and Chao Huang. Diffmm: Multi-modal diffusion model for recommendation. In ACM MM, pp. 7591–7599, 2024.

Yehuda Koren, Robert Bell, et al. Matrix factorization techniques for recommender systems. Computer, (8):30–37, 2009.

Yehuda Koren, Steffen Rendle, and Robert Bell. Advances in collaborative filtering. Recommender systems handbook, pp. 91–142, 2021.

Jianghao Lin, Xinyi Dai, Yunjia Xi, Weiwen Liu, Bo Chen, Hao Zhang, Yong Liu, Chuhan Wu, Xiangyang Li, Chenxu Zhu, et al. How can recommender systems benefit from large language models: A survey. TOIS, 2023.

Zihan Lin, Changxin Tian, Yupeng Hou, and Wayne Xin Zhao. Improving graph collaborative filtering with neighborhood-enriched contrastive learning. In WWW, pp. 2320–2329, 2022.

Peng Liu, Lemei Zhang, and Jon Atle Gulla. Pre-train, prompt, and recommendation: A comprehensive survey of language modeling paradigm adaptations in recommender systems. TACL, 11: 1553–1571, 2023.

Xubin Ren, Wei Wei, Lianghao Xia, Lixin Su, Suqi Cheng, Junfeng Wang, Dawei Yin, and Chao Huang. Representation learning with large language models for recommendation. In WWW, 2024.

John Schulman, Filip Wolski, Prafulla Dhariwal, Alec Radford, and Oleg Klimov. Proximal policy optimization algorithms. arXiv preprint arXiv:1707.06347, 2017.

Nisan Stiennon, Long Ouyang, Jeffrey Wu, Daniel Ziegler, Ryan Lowe, Chelsea Voss, Alec Radford, Dario Amodei, and Paul F Christiano. Learning to summarize with human feedback. NeurIPS, pp. 3008–3021, 2020.

Xiaoyuan Su and Taghi M Khoshgoftaar. A survey of collaborative filtering techniques. Advances in artificial intelligence, 2009, 2009.

Hugo Touvron, Louis Martin, Kevin Stone, Peter Albert, Amjad Almahairi, Yasmine Babaei, Nikolay Bashlykov, Soumya Batra, Prajjwal Bhargava, Shruti Bhosale, et al. Llama 2: Open foundation and fine-tuned chat models. arXiv preprint arXiv:2307.09288, 2023.

Jianling Wang, Raphael Louca, Diane Hu, Caitlin Cellier, James Caverlee, and Liangjie Hong. Time to shop for valentine’s day: Shopping occasions and sequential recommendation in e-commerce. In WSDM, pp. 645–653, 2020.

Jianling Wang, Haokai Lu, James Caverlee, Ed H Chi, and Minmin Chen. Large language models as data augmenters for cold-start item recommendation. In WWW, pp. 726–729, 2024.

Xiang Wang, Xiangnan He, Meng Wang, et al. Neural graph collaborative filtering. In SIGIR, 2019.

Wei Wei, Xubin Ren, Jiabin Tang, Qinyong Wang, Lixin Su, Suqi Cheng, Junfeng Wang, Dawei Yin, and Chao Huang. Llmrec: Large language models with graph augmentation for recommendation. In WSDM, pp. 806–815, 2024.

Fangzhao Wu, Ying Qiao, Jiun-Hung Chen, Chuhan Wu, Tao Qi, Jianxun Lian, Danyang Liu, Xing Xie, Jianfeng Gao, Winnie Wu, et al. Mind: A large-scale dataset for news recommendation. In ACL, pp. 3597–3606, 2020.

Jiancan Wu, Xiang Wang, Fuli Feng, Xiangnan He, Liang Chen, Jianxun Lian, and Xing Xie. Self-supervised graph learning for recommendation. In SIGIR, pp. 726–735, 2021.

Liang Wu, Diane Hu, Liangjie Hong, and Huan Liu. Turning clicks into purchases: Revenue optimization for product search in e-commerce. In SIGIR, pp. 365–374, 2018.

Tiansheng Yao, Xinyang Yi, Derek Zhiyuan Cheng, Felix Yu, Ting Chen, Aditya Menon, Lichan Hong, Ed H Chi, Steve Tjoa, Jieqi Kang, et al. Self-supervised learning for large-scale item recommendations. In CIKM, pp. 4321–4330, 2021.

Junliang Yu, Hongzhi Yin, Xin Xia, Tong Chen, Lizhen Cui, and Quoc Viet Hung Nguyen. Are graph augmentations necessary? simple graph contrastive learning for recommendation. In SIGIR, pp. 1294–1303, 2022.

Junliang Yu, Hongzhi Yin, Xin Xia, Tong Chen, Jundong Li, and Zi Huang. Self-supervised learning for recommender systems: A survey. TKDE, 2023.

Zheng Yuan, Fajie Yuan, Yu Song, Youhua Li, Junchen Fu, Fei Yang, Yunzhu Pan, and Yongxin Ni. Where to go next for recommender systems? id-vs. modality-based recommender models revisited. In SIGIR, pp. 2639–2649, 2023.

Ruohan Zhan, Changhua Pei, Qiang Su, Jianfeng Wen, Xueliang Wang, Guanyu Mu, Dong Zheng, Peng Jiang, and Kun Gai. Deconfounding duration bias in watch-time prediction for video recommendation. In KDD, pp. 4472–4481, 2022.

Fanjin Zhang, Jie Tang, Xueyi Liu, Zhenyu Hou, Yuxiao Dong, Jing Zhang, Xiao Liu, Ruobing Xie, Kai Zhuang, Xu Zhang, et al. Understanding wechat user preferences and “wow” diffusion. TKDE, pp. 6033–6046, 2021.

Junjie Zhang, Ruobing Xie, Yupeng Hou, Xin Zhao, Leyu Lin, and Ji-Rong Wen. Recommendation as instruction following: A large language model empowered recommendation approach. TOIS, 2023.

## 6 APPENDIX

## 6.1 DATASET DESCRIPTIONS

The statistical characteristics of the three datasets used in our experiments are summarized in Table 4. Below, we provide detailed descriptions of each dataset:

Table 4: Statistics of the experimental datasets.

<table><tr><td>Statistics</td><td>MIND</td><td>Netflix</td><td>Industrial</td></tr><tr><td># User</td><td>57128</td><td>16835</td><td>117433</td></tr><tr><td># Overlap. Item</td><td>1020</td><td>6232</td><td>72417</td></tr><tr><td># Snapshot</td><td>daily</td><td>yearly</td><td>daily</td></tr><tr><td colspan="4">Training Set</td></tr><tr><td># Item</td><td>2386</td><td>6532</td><td>152069</td></tr><tr><td># Interactions</td><td>89734</td><td>1655395</td><td>858087</td></tr><tr><td># Sparsity</td><td>99.934%</td><td>98.495%</td><td>99.995%</td></tr><tr><td colspan="4">Test Set</td></tr><tr><td># Item</td><td>2461</td><td>8413</td><td>158155</td></tr><tr><td># Interactions</td><td>87974</td><td>1307051</td><td>876415</td></tr><tr><td># Sparsity</td><td>99.937%</td><td>99.077%</td><td>99.995%</td></tr></table>

• MIND Data: A large-scale news recommendation benchmark dataset. We extracted data spanning two consecutive days, with one day allocated for training and the subsequent day for testing. Each news article contains rich textual features including category labels, titles, and abstract content.

• Netflix Data: This dataset is derived from the Netflix Prize Data competition on Kaggle, comprising implicit user-movie interactions. For our experiments, we extracted viewing histories spanning two consecutive years (2005-2006), with the first year’s data allocated for training and the subsequent year for testing. The textual features for each movie item are represented by its corresponding title.

• Industrial Data: A large-scale proprietary dataset collected from a major online content platform (anonymized for privacy). This comprehensive news article collection serves millions of daily active users and generates substantial user-article interactions. For our evaluation, we extracted interaction data from two consecutive days (Day N and Day N+1), utilizing them as training and testing sets respectively. Each article is represented by its title as the primary textual feature.

## 6.2 BASE MODEL DESCRIPTIONS

We provide detailed descriptions of the baseline methods employed in our comparative evaluation:

• BiasMF (Koren et al., 2009): A matrix factorization-based approach that enhances recommendation accuracy by incorporating user and item bias vectors to capture individual preference patterns.

• NCF (He et al., 2017): A neural collaborative filtering framework that replaces traditional matrix factorization’s dot-product operation with multi-layer neural networks, enabling the capture of complex user-item interactions. In our implementation, we specifically utilize the NeuMF variant.

• LightGCN (He et al., 2020): A graph-based recommendation model that leverages user-item interaction graphs through a simplified layer-wise propagation scheme, employing only linear transformations and element-wise operations to aggregate neighborhood information.

• SGL (Wu et al., 2021): An enhanced version of LightGCN that incorporates self-supervised contrastive learning. It employs various data augmentation techniques, including random walks and node/edge dropout, to generate diverse graph views for contrastive learning.

• SimGCL (Yu et al., 2022): A streamlined contrastive learning framework that generates contrastive views by directly injecting uniform noise into the embedding space, eliminating the need for explicit graph augmentation operations.

## 6.3 EXPERIMENTAL SETTINGS FOR PERFORMANCE COMPARISON

We conducted our performance evaluation (detailed in Sec. 3.2) under two distinct testing scenarios:

• Full-Shot Setting: Utilizes the complete test set, including items that appeared in the training phase, representing conventional recommendation scenarios.

• Zero-Shot Setting: Exclusively evaluates items absent from the training set, specifically designed to assess cold-start recommendation capability where items have no historical interaction data.

Our experimental framework compares two implementation variants:

• Base Variant: Implements our cold-start recommendation paradigm using only user ID embeddings and item text embeddings, without LLM-generated profiles.

• Augmented Variant: Fully integrates the proposed RecLM framework with traditional recommenders, incorporating LLM-generated item profiles.

This comparative setup enables systematic evaluation of how LLM-generated profiles enhance recommender performance, particularly in addressing cold-start challenges.

## 6.4 ABLATION STUDY CONFIGURATION

We evaluate four distinct variants of our model to assess the contribution of each component:

• GPT\_KD Variant: Implements basic large language model (LLM) fine-tuning using ChatGPT3.5- generated user profiles, as detailed in Sec. 2.3.1.

• Naive Variant: Builds upon GPT\_KD by incorporating instruction tuning, but restricts the dialogue to single-turn interactions, diverging from our proposed two-turn approach (Sec. 2.3.2).

• Mask Variant: Extends GPT\_KD with both two-turn instruction tuning and masking-based strategies, representing an intermediate step in our framework.

• Ours (RecLM): Represents our complete framework, enhancing the Mask variant with RL-based personalized feature optimization.

## 6.5 IMPLEMENTATION DETAILS

## 6.5.1 PARAMETER-EFFICIENT FINE-TUNING STRATEGY

To optimize LLM adaptation while preserving their core reasoning capabilities, we employ Parameter-Efficient Fine-Tuning (PEFT) methodology. Specifically, we utilize Low-Rank Adaptation (LoRA) (Hu et al., 2021) for fine-tuning Llama2-7b-chat (Touvron et al., 2023), enabling efficient task-specific adaptation while maintaining the model’s fundamental knowledge base.

## 6.5.2 BASE RECOMMENDER INTEGRATION AND HYPERPARAMETER CONFIGURATION

We systematically integrated RecLM into various base recommenders, conducting comprehensive hyperparameter optimization to ensure fair comparison. All models are implemented using PyTorch framework, utilizing Adam optimizer with default parameters and Xavier initialization. The training process employs a batch size of 4096, with embedding vectors dimensionality set to 32 and a learning rate of $1 e ^ { - 3 }$ . The $\mathcal { L } _ { 2 }$ regularization coefficient is optimized through a search space of $\{ 1 e ^ { - 3 } , 1 e ^ { - \tilde { 4 } }$ $1 e ^ { - 5 } , 1 e ^ { - 6 } , 1 e ^ { - 7 } \}$ . For GNN-based models (LightGCN, SGL, and SimGCL), we set the number of GCN layers to 2. Additionally, for self-supervised learning (SSL)-based models (SGL and SimGCL), the temperature coefficient is tuned within the range of {0.1, 0.5, 1.0}.

## 6.6 INSTRUCTION DESIGNS

In this section, we provide a comprehensive overview of the instructions utilized for fine-tuning at each stage of our process. We will also discuss the methodologies employed to construct both positive and negative training samples for the reinforcement learning reward model.

• Instruction Generation. As illustrated in Figure 5, our instruction generation is conducted based on the knowledge distillation process through leveraging ChatGPT’s capabilities by feeding it two key inputs: user-specific textual information and interaction-related item descriptions. The LLMs

![](images/e538e4f5b004fa1aa4b5f0eac311069e6946e338e011b20721615c28bfba8a6c.jpg)  
Figure 5: Instruction generation via ChatGPT knowledge distillation.

Info.]]... [Item ID, [Item Text Info.]]. Please provide the profile strictly in the following format: User identity: [Identity 1], [Identity 2], [Identity 3]; User interests: [Interest 1], [Interest 2], then synthesize this information to generate comprehensive user profiles that capture both personal identity characteristics and specific interest patterns.

<sup>User</sup> <sup>ID,</sup> <sup>profile:</sup> <sup>User</sup> <sup>identity:</sup> <sup>[Identity</sup> <sup>1],</sup> <sup>[Identity</sup> <sup>2],</sup> <sup>[Identity</sup> <sup>3];</sup> <sup>User</sup> <sup>interests:</sup> <sup>[Interest</sup> <sup>1],</sup> <sup>[Interest</sup> <sup>2],</sup> <sup>[Interest</sup> <sup>3].</sup>• Two-Turn Collaborative Instruction Design. Our instruction tuning framework implements a <sup>User</sup> <sup>ID,</sup> <sup>profile:</sup> <sup>User</sup> <sup>identity:</sup> <sup>[Identity</sup> <sup>1],</sup> <sup>[Identity</sup> <sup>2],</sup> <sup>[Identity</sup> <sup>3];</sup> <sup>User</sup> <sup>interests:</sup> <sup>[Interest</sup> <sup>1],</sup> <sup>[Interest</sup> <sup>2],</sup> <sup>[Interest</sup> <sup>3].</sup>carefully structured two-turn dialogue approach (Figure 6). Initial Setup: The system receives foundational instructions to establish LLMs’ understanding of collaborative filtering principles.

<sup>or</sup> <sup>No.</sup>First Turn: In the first turn, we provide input instructions containing interaction histories from <sub>Yes</sub> <sub>/</sub> <sub>No</sub>similar users and relevant item details. These similar users are identified through a graph collaborative filtering model, followed by embedding-based similarity calculations. The LLMs then process this information to generate comprehensive user profiles for each referenced user.

Second Turn: In the second turn, the LLMs perform prediction tasks by analyzing the previously generated user profiles in conjunction with specific item characteristics. Based on collaborative<sup>subcategory,</sup> <sup>title,</sup> <sup>and</sup> <sup>abstract.</sup> <sup>Based</sup> <sup>on</sup> <sup>this</sup> <sup>information,</sup> <sup>please</sup> <sup>generate</sup> <sup>the</sup> <sup>user's</sup> <sup>profile.</sup> <sup>Here</sup> <sup>is</sup> <sup>the</sup> <sup>list</sup> <sup>of</sup> <sup>previously</sup> <sup>clicked</sup> <sup>news</sup> <sup>articles::</sup> <sup>[Item</sup> <sup>Text</sup> <sup>Info.1],</sup> <sup>[Item</sup> <sup>Text</sup> <sup>Info.2],</sup> <sup>...,</sup> filtering principles, the model evaluates potential user-item interactions and outputs definitiveEmphasize that only the most likely three identities and interests should be provided, and strictly adhere to the above format. binary predictions (Yes/No) regarding interaction likelihood.<sub>User</sub> <sub>identity:</sub> <sub>[Identity</sub> <sub>1],</sub> <sub>[Identity</sub> <sub>2],</sub> <sub>[Identity</sub> <sub>3];</sub> <sub>User</sub> <sub>interests:</sub> <sub>[Interest</sub> <sub>1],</sub> <sub>[Interest</sub> <sub>2],</sub> <sub>[Interest</sub> <sub>3].</sub>

![](images/1f40306f8c8669c35eeb013d198b3bac7fdabf9daf924bdca4f511fc152931a6.jpg)  
Figure 6: Instruction designs for two-turn instruction tuning.

• User Profile Generation Instruction Design. Following the instruction tuning, the LLMs develop proficiency in profile generation with collaborative awareness. As illustrated in Figure 7, we implement a systematic instruction framework for user profile generation that consists of three key components. The process begins with system-level instructions that reinforce the LLMs understanding of collaborative filtering principles. The input layer then incorporates two essential elements: (1) interaction histories from multiple similar users, including the target user requiring profile generation, and (2) comprehensive textual descriptions of all relevant items. Based on this information, the LLMs synthesize and output a detailed profile for the target user.

![](images/d97709011f8f31ea3eae2e02bb6a9f2d01497160e775bb7d604199c31a748ce3.jpg)  
<sup>tor.</sup> <sup>I</sup> <sup>will</sup> <sup>provide</sup> <sup>you</sup> <sup>with</sup> <sup>textual</sup> <sup>information</sup> <sup>about</sup> <sup>one</sup> <sup>target</sup> <sup>item</sup> <sup>as</sup> <sup>well</sup> <sup>as</sup> <sup>a</sup> <sup>list</sup> <sup>of</sup> <sup>other</sup> <sup>items</sup> <sup>with</sup> <sup>their</sup> <sup>textua</sup><sub>ation,</sub> <sub>please</sub> <sub>generate</sub> <sub>the</sub> <sub>user</sub> <sub>profile</sub> <sub>of</sub> <sub>this</sub> <sub>target</sub> <sub>item.</sub> <sub>The</sub> <sub>target</sub> <sub>item</sub> <sub>text</sub> <sub>information:</sub> <sub>[Item</sub> <sub>Text</sub> <sub>Info.].</sub> <sub>Here</sub> <sub>is</sub> Figure 7: Instruction designs for user profile generation.

[Interest 4], [Interest 5].• Item Profile Generation Instruction Design. Following user profile generation, we develop item profiles to ensure semantic alignment between user and item features. The item profile represents a target user’s profile specific to a particular item, and we implement a dual-phase approach for comprehensive coverage: In the first phase, we generate profiles for items with existing user interactions by leveraging the profiles of their interacting users. This establishes direct user-item semantic connections. For cold-start items, the second phase employs similarity-based matching using raw item embeddings, followed by LLM-based profile inference. As illustrated in Figure 8,<sup>nstruction</sup> the instruction framework processes inputs comprising: (1) a target item and its similar items, (2)<sup>Each</sup> <sup>user's</sup> <sup>historical</sup> <sup>item</sup> <sup>interaction</sup> <sup>list</sup> <sup>is</sup> <sup>as</sup> <sup>follows:</sup> <sup>[Target</sup> <sup>User</sup> <sup>ID,</sup> <sup>item</sup> <sup>interaction</sup> <sup>list:[Item</sup> <sup>ID,</sup> <sup>Item</sup> <sup>ID,</sup> <sup>Item</sup> <sup>ID,</sup> <sup>...]];</sup> <sup>[User</sup> <sup>ID,</sup> <sup>item</sup> <sup>interaction</sup> <sup>list:[Item</sup> <sup>ID,</sup> <sup>Item</sup> <sup>ID,</sup> <sup>Item</sup> <sup>ID,</sup> <sup>...]]</sup> <sup>...</sup> detailed textual information for all items, and (3) existing profiles of similar items. The LLMs<sup>Text</sup> <sup>Info.]]...</sup> <sup>[Item</sup> <sup>ID,</sup> <sup>[Item</sup> <sup>Text</sup> <sup>Info.]].</sup> <sup>Please</sup> <sup>provide</sup> <sup>the</sup> <sup>profile</sup> <sup>of</sup> <sup>the</sup> <sup>target</sup> <sup>User</sup> <sup>ID</sup> <sup>strictly</sup> <sup>in</sup> <sup>the</sup> <sup>following</sup> <sup>format:</sup> <sup>User</sup> <sup>identity:</sup> <sup>[Identity</sup> <sup>1],</sup> <sup>[Identity</sup> <sup>2],</sup> <sup>[Identity</sup> <sup>3];</sup> <sup>User</sup> <sup>interests:</sup> then synthesize this information to generate the target item’s profile, thereby enhancing the overall semantic coherence of the recommendation system.

![](images/68330e118e22c7858c236ca69d3f15b252ee7d8c477d74aa048af37d4ee6c894.jpg)  
Figure 8: Instruction designs for item profile generation.

• Reward Model Training: Response Construction. The success of our personalized feature enhancement through reinforcement learning (Sec 2.4) depends critically on the quality of the reward model training data. This training data addresses two key challenges: instruction-tuning noise and collaborative feature over-smoothing. As illustrated in Figure 9, we construct positive samples through a combination of state-of-the-art LLMs (e.g., ChatGPT) and manual validation. For negative samples, we establish a complementary sampling strategy:

– Similar User Profiles: These samples train the reward model to identify subtle profile distinctions, thereby mitigating over-smoothing effects.

![](images/714451c581d5117adf299f3aa9552864d85c41775cebaa2e6eb95ea99e618be4.jpg)

– Low-Quality Responses: This category includes profiles with missing information or repetitive content, serving as explicit negative examples for model training.

Figure 9: Positive/Negative responses construction for reward model training.

## 6.7 FUTURE WORK EXPLORATION

Future research directions for RecLM could explore two promising avenues: First, extending the framework to multi-modal contexts, where user-item interactions involve diverse data types such as images, videos, and audio. This would require developing modal-specific instruction tuning strategies and designing cross-modal alignment mechanisms to maintain semantic consistency across different modalities. Second, investigating the potential of smaller, more efficient language models for profile generation. While our current implementation leverages Llama2-7b, exploring distilled or compressed models could significantly reduce computational overhead while maintaining profile quality. This could involve techniques like knowledge distillation from larger to smaller models specifically trained for recommendation tasks, or developing specialized lightweight architectures that focus exclusively on user/item profiling capabilities.