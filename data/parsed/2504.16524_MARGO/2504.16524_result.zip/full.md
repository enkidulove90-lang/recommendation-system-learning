# Modality Reliability Guided Multimodal Recommendation

Xue Dong, Xuemeng Song Senior Member, IEEE, Na Zheng, Sicheng Zhao Senior Member, IEEE, Guiguang Ding

Abstract—Multimodal recommendation faces an issue of the performance degradation that the uni-modal recommendation sometimes achieves the better performance. A possible reason is that the unreliable item modality data hurts the fusion result. Several existing studies have introduced weights for different modalities to reduce the contribution of the unreliable modality data in predicting the final user rating. However, they fail to provide appropriate supervisions for learning the modality weights, making the learned weights imprecise. Therefore, we propose a modality reliability guided multimodal recommendation framework that uniquely learns the modality weights supervised by the modality reliability. Considering that there is no explicit label provided for modality reliability, we resort to automatically identify it through the BPR recommendation objective. In particular, we define a modality reliability vector as the supervision label by the difference between modalityspecific user ratings to positive and negative items, where a larger difference indicates a higher reliability of the modality as the BPR objective is better satisfied. Furthermore, to enhance the effectiveness of the supervision, we calculate the confidence level for the modality reliability vector, which dynamically adjusts the supervision strength and eliminates the harmful supervision. Extensive experiments on three real-world datasets show the effectiveness of the proposed method.

Index Terms—Multimodal Recommendation, Multimodal Fusion, Modality Reliability.

## I. INTRODUCTION

RADITIONAL recommendation systems [1], [2] model the user interests based on the user-item behaviors on the web. Beyond the user behaviors, the item multimodal data, e.g., images and texts, provides a comprehensive manner for capturing the user interests. Accordingly, many researches have thus resorted to the multimodal recommendation systems [3], [4], [5], [6], [7], [8] that jointly exploit user behaviors and the item multimodal data to capture the user interests.

Although the multimodal data can be helpful, several studies [9], [10], [11] have found an crucial issue of the model performance degradation: the uni-modal recommendation framework sometimes achieves better performance than the multimodal one. One possible reason may be that certain modality data of an item is unreliable, which hurts the multimodal fusion result. For example, as shown in Figure 1, the first item is a “silicone chewing brush”, while its description contains some irrelevant information (see underlined sentenses). Besides, in the image of the second item, the mother that hugs a baby and a little girl that stands by are irrelevant to this “wrap baby bath towel”. Thus, the irrelevant information in the modality data could hinder the feature extraction and negatively affect the multimodal fusion.

![](images/cc7ac217fc90d69662d3ce1531b62ae90ccc8e81447628db3604d7ce6017dee2.jpg)  
Fig. 1. Examples of items with unreliable modality data.

Several research efforts [12], [10] have introduced weights for modalities of the item to reduce the contribution of the unreliable modality data in predicting the final user rating. They first calculate the modality-specific user ratings to one item in all modalities, and then fuse them based on the weights to predict the final user rating. The weights are randomly initialized and optimized with only the recommendation objective, e.g., Bayesian Personal Ranking (BPR) loss [13]. Despite their effectiveness, the modality weights learned by existing methods may be imprecise due to the lack of explicit supervisions for the weight learning. In other words, the modality weights may be not optimized as expected, but as additional parameters to increase the performance.

Therefore, in this paper, we present a novel modality reliability guided multimodal recommendation framework, termed as MARGO, shown in Figure 2. MARGO follows the standard multimodal recommendation framework that the modality-specific user ratings are fused with modality weights and the pair-wise BPR loss is adopted for model optimization. Differently, MARGO introduces the supervision of the modality reliability on the modality weight learning for a better fusion result. To infer the modality reliability, we draw inspiration from the BPR loss that the user ratings to positive items should be higher than negative items. Therefore, if a modality-specific user rating to the positive item is lager than that to a negative one, the corresponding modality of the two items tend to be reliable for predicting the final user rating. On the contrary, the modality of at least one in the two items is unreliable as it conflicts the BPR objective. Consequently, we define a modality reliability vector by the difference between the modality-specific user ratings to the positive and negative items, which can be used as the supervision of the modality weights of the two items. However, directly adding such supervision may be flawed, since the modality reliability vector is not always confident. To tackle this, inspired by that the loss value usually reflects the confidence of the result, we calculate the confidence for the modality reliability vector based on the BPR loss value, i.e., the difference between the final user ratings to the positive and negative items, where a smaller loss indicates a higher confidence. Thereafter, we design a weight calibration loss that pushes up the similarity between the modality reliability vector and the modality weights, where the supervision strength is dynamically adjusted by the confidence.

Besides, we design a two-stage training process to ensure the rationale of the modality reliability vector and the effectiveness of the supervision. The first stage discards the modality weights and pre-trains the model with only the BPR loss. After the model converge, the predicted modality-specific user ratings are meaningful and thus the modality reliability vector is rational. Then the second stage involves the modality weights and fine-tunes the model by incorporating the BPR loss and the weight calibration loss. We conduct extensive experiments on three public datasets, and the results have proven that MARGO obtains superior performances compared to state-of-the-art methods. The main contributions can be summarized as follows.

• We propose a modality reliability guided multimodal recommendation framework that learns the modality weights with the supervision of the modality reliability vector. It is the first attempt to add explicit supervisions to the weight learning during the multimodal fusion.

• We propose an automatic method to derive the supervision label for the modality weights, where we define a modality reliability vector through the BPR loss.

• We design a weight calibration loss, which dynamically adjusts the supervision strength of the modality reliability vector on the weights and eliminates the harmful supervision through a newly introduced confidence.

• Extensive experiments on the three public datasets have demonstrated the effectiveness of the proposed method. We will release our codes to facilitate other researchers in https://github.com/hello-dx/MARGO.

## II. RELATED WORK

Traditional recommendation methods [13], [1], [2] utilize the historical user-item interactions to learn user interests. Considering that the multimodal information reflects the item properties from different perspectives, some researches resort to the multimodal recommendation [14], [15], [3], [12], [16], [17], [18]. Several researches implicitly use the multimodal data as supervision signals, while other researches explicitly leverage it as the side information of items participating in the model training. This section will detail the implicit and explicit multimodal recommendation methods.

![](images/e987c37e1f64630057a78ab70fdc41f9e43d84fe9dcf0ba0dce1b1f2f56c1299.jpg)  
Fig. 2. Illustration of the proposed MARGO framework, which adds explicit supervisions to the modality weight learning. Specifically, we introduce a new modality reliability vector through the training objective to simulate the reliability of the modality data. We also involve the confidence for the modality reliability vector to ensure the effectiveness of the supervision.

## A. Implicit Multimodal Recommendation

These researches leverage the item multimodal information as the prior knowledge or supervisions to improve the recommendation performance [14], [16], [19], [20]. For example, AMCF [14] learns a projection between the item ID embedding and item attribute embeddings. The item attributes are adopted to distillate the semantic information into the item ID embedding, without directly participating in the user rating prediction. Zhang et al. [16] and Zhou et al. [19] adopt the item multimodal features to calculate the prior similarities between items. Based on the similarity, they construct a homogeneous graph between items and enhance the item embedding learning through the graph convolution in the graph. BM3 [20] introduces inter- and intra-modality contrastive learning to align item features in different modalities.

## B. Explicit Multimodal Recommendation

These researches [15], [3], [21], [22], [23], [24] explicitly extract the modality features from the item multimodal data and predict the user rating through the modality fusion result. According to the timing of the modality fusion, existing explicit multimodal recommendation methods could be roughly divided into the early and late fusion-based methods.

The early fusion-based methods [15], [25], [9], [26] first fuse the modality features of one item into a single embedding and then based on it predict the final user rating to the item. For example, VBPR [15] is the first attempt to leverage the item image into the recommendation, which concatenates the original item ID embedding and item visual features as the new item embedding. MGCN [9] introduces a behavior-aware feature fusion method to filter out the redundant information between modality features Nevertheless, this strategy cannot model the user’s specific interests on different modalities [3].

The late fusion-based methods [3], [12], [27], [4], [28], [29] learn the user rating towards each specific modality, and then predict the user final rating to the item by fusing all the modality-specific user ratings. For example, MMGCN [3] constructs the user-item graph in each modality and predicts the user ratings to the item in different modalities. It then utilizes the mean pooling of all modality-specific user ratings as the final user rating. Considering the different contributions of modalities during the modality fusion, several studies [7], [30] introduce the pre-defined a weight for each item modality. In particular, Dong et al. [7] set the weights for visual and textual modalities as hyper-parameters and tune the weights through validation set. Other studies [12], [10] learn the modality weights by a more flexible manner, which randomly assigns the weight for each modality in different items and updates the weight through the backward propagation.

Despite of their effectiveness, existing methods fail to add certain supervision signals when learning the modality weights. This may result in the learned modality weights failing to capture the modality reliability and becoming additional parameters used to improve the performance. Therefore, in this paper, we draw inspiration from the recommendation loss and derive a modality reliability vector from it. We then devise a weight calibration loss to supervise the learning of the modality weights.

## III. METHODOLOGY

In this section, we first provide the preliminaries of the multimodal recommendation in Subsection III-A. We then detail the proposed MARGO framework and its training algorithm in Subsection III-B and III-C, respectively. Subsection III-D provides the theoretical analysis of the model convergency.

## A. Preliminaries

We detail the preliminaries of the multimodal recommendations in this subsection, including the problem formulation, model architecture, and learning objective.

Problem Formulation. Suppose that there is a set of users $u ,$ a set of items I, and a set of item modalities M. Each user $u \in \mathcal { U }$ is associated with a set of interacted items $\mathcal { T } _ { u } .$ Each item $\textit { i } \in \textit { \textbf { Z } }$ has its multimodal features $\{ f _ { i } ^ { m } | m \ =$ $1 , . . . , | { \mathcal { M } } | \}$ , where $\pmb { f } _ { i } ^ { m }$ denotes the feature of the m-th modality. Multimodal recommendation aims to predict the user rating to an item according to the user interactions and item multimodal features. Ultimately, the candidate items can be ranked according to the predicted ratings and top items are recommended to the user. The main notations used in this work are detailed in Table I.

Model Architecture. In this paper, we focus on the late fusion based multimodal recommendation paradigm, owing to the fact that it allows straightforward and flexible weight adjustment for different modalities during the user rating prediction. Formally, as for a given user u and an item i, a late fusion based multimodal recommendation model $\mathcal { F }$ first learns an embedding of each modality for the user and item as follows,

TABLE I  
SUMMARY OF THE MAIN NOTATIONS.

<table><tr><td>Notation</td><td>Explanation</td></tr><tr><td> $\mathcal{U},\mathcal{I},\mathcal{M}$ </td><td>Sets of users, items and modalities, respectively.</td></tr><tr><td> $e_{u}\in\mathbb{R}^{d}$ </td><td>Embedding of the user u.</td></tr><tr><td> $e_{i}\in\mathbb{R}^{d}$ </td><td>Embedding of the item i.</td></tr><tr><td> $f_{i}^{m}$ </td><td>The m-th modality feature of the item i.</td></tr><tr><td> $w_{i}\in\mathbb{R}^{\left|\mathcal{M}\right|}$ </td><td>Weight vector of the item i.</td></tr><tr><td> $y_{ui}^{m}$ </td><td>The m-th modality-specific rating of user u to item i.</td></tr><tr><td> $y_{ui}$ </td><td>Final rating of the user u to the item i.</td></tr><tr><td>(u,i,k)</td><td>Training triplet of a user u, a positive item i, and a negative item k.</td></tr><tr><td> $z_{uik}\in\mathbb{R}^{\left|\mathcal{M}\right|}$ </td><td>Modality reliability vector of training triplet (u,i,k).</td></tr><tr><td> $\gamma_{uik}$ </td><td>Confidence of the modality reliability vector  $z_{uik}$ .</td></tr><tr><td> $\alpha,\beta$ </td><td>Trade-off hyper-parameters.</td></tr></table>

$$
\pmb {e} _ {u} ^ {m}, \pmb {e} _ {i} ^ {m} \leftarrow \mathcal {F} (u, i, \pmb {f} _ {i} ^ {m} | \Theta), m = 1, \dots , M,\tag{1}
$$

where $e _ { u } ^ { m } \in \mathbb { R } ^ { d }$ and $e _ { i } ^ { m } \in \mathbb { R } ^ { d }$ are the user and item embeddings of the m-th modality, which capture the user interests and item properties from the m-th modality, respectively. d is the embedding size. Θ is the model parameters.

Consequently, the modality-specific user rating $y _ { u i } ^ { m }$ can be predicted by the dot product of the learned user and item embeddings in the corresponding modality as follows,

$$
y _ {u i} ^ {m} = \pmb {e} _ {u} ^ {m} \cdot \pmb {e} _ {i} ^ {m}.\tag{2}
$$

Considering the different contributions of modalities, a randomly initialized weight vector ${ \pmb w } _ { i }$ is introduced for the item i to weighted fuse all the modality-specific user rating. Formally, the final user rating can be derived as follows,

$$
\boldsymbol {y} _ {u i} = \boldsymbol {w} _ {i} ^ {\mathsf {T}} \cdot [ y _ {u i} ^ {1}, y _ {u i} ^ {2}, \dots , y _ {u i} ^ {| \mathcal {M} |} ],\tag{3}
$$

where $y _ { u i }$ refers to the final rating of the user u to the item i, indicating how likely the user would be interested in the item. Note that the weight vector ${ \pmb w } _ { i }$ is outputted by a softmax function to ensure the summation of the weights in one item to be equal to 1.

Learning Objective. To optimize model parameters, the widely-used Bayesian Personalized Ranking (BPR) mechanism [13] is adopted to enforce the final user rating to a positive item to be higher than that to a negative item. Specifically, let $\mathcal { D } = \{ ( u , i , k ) _ { n } | n = 1 , 2 , . . . , N \}$ denote the training set of N training triplets. Each training triplet $( u , i , k )$ consists of a user $u \in \mathcal { U } ,$ a positive item $i \in \mathcal { Z } _ { u }$ that the user has historically interacted, and a negative item $k \in \mathcal { I } \setminus \mathcal { T } _ { u }$ that the user has not interacted, which indicates that the user u prefers item i compared with the item k. Then the recommendation loss can be defined as follows,

$$
\mathcal {L} _ {\mathrm{rec}} = - \sum_ {(u, i, k) \in \mathcal {D}} \log (\sigma (y _ {u i} - y _ {u k})),\tag{4}
$$

where $y _ { u i }$ and $y _ { u k }$ are the user ratings to the positive item i and negative item k, respectively. σ is the sigmoid function.

## B. The Proposed MARGO Framework

As a key novelty, we propose to leverage the modality reliability as the supervision signals to learn the modality weights, which makes the learned modality weights more precise and hence achieves a better multimodal fusion result. In particular, we first define a modality reliability vector through the difference between the predicted user ratings, and then introduce a weight calibration loss to supervise the weight learning process. We provide a detailed illustration of this weight calibration process in Figure 3.

Modality Reliability Inference. Suppose that we have a trained multimodal late fusion based recommendation model that can predict the modality-specific user ratings for all modalities in an item. Intuitively, according to BPR loss, if a modality-specific user rating to the positive item is larger than that to the negative one, we argue that the predictions in this modality are reliable and thus the modality of the two items tend to be reliable. On the contrary, this modality of at least one in the two items is unreliable as the predictions in the modality conflict with the BPR objective. Consequently, to a certain extent, the difference between the modality-specific user ratings to the positive and negative items could hid the information of the modality reliability, i.e., a larger difference indicates a higher reliability.

Formally, for a given training triplet $( u , i , k )$ , we calculate the following difference vector through the modality-specific user ratings to the positive and negative items,

$$
\pmb {d} _ {u i k} = [ y _ {u i} ^ {1} - y _ {u k} ^ {1}, y _ {u i} ^ {2} - y _ {u k} ^ {2}, \dots , y _ {u i} ^ {M} - y _ {u k} ^ {M} ],\tag{5}
$$

where $y _ { u i } ^ { m } \left( y _ { u k } ^ { m } \right)$ is the modality-specific user rating to the $m -$ th modality of the item i (k). Based on the difference vector, we define the modality reliability vector $z _ { u i k }$ of the training triplet $( u , i , k )$ as follows,

$$
\boldsymbol {z} _ {u i k} = \mathrm{softmax} _ {m} (g (\boldsymbol {d} _ {u i k})),\tag{6}
$$

where $g ( \ u )$ is a mapping function that maps the negative values to infinitesimal, i.e., $g ( x ) = x , { \mathrm { i f ~ } } x \geq 0 ; g ( x ) = - e ^ { 6 } , { \mathrm { i f ~ } } x < 0 .$ We add this mapping function to enforce the reliability of unreliable modality to be 0. Note that $\mathbf { { } } d _ { u i k }$ is affected by both items i and $k ,$ and thus the modality reliability vector $z _ { u i k }$ captures the modality reliability of both the two items.

Weight Calibration. Once the modality reliability vector is derived, it can be served as the supervision of the modality weight learning. However, it is non-trivial because that the modality reliability vector is automatically inferred through the training objective and is not always confident, where flawed cases will negatively affect the weight learning. Therefore, we further learn the confidence for the modality reliability vector to dynamically adjust its supervision strength on the weight learning and eliminate the negative cases.

In particular, the modality reliability vector $z _ { u i k }$ is ultimately affected by the user ratings $y _ { u i }$ and $y _ { u k }$ , and therefore its confidence can depend on the confidence of the final user rating. Inspired by studies [31], [32], [33] that identify the confidence of the predicted result through the corresponding loss value, we define the confidence of the modality reliability vector through the the confidence of the final user rating indicated by the BPR loss value. Specifically, in the training triplet $( u , i , k )$ , the BPR loss calculate the difference between user ratings to the positive item i and negative item k. A large difference $y _ { u i } - y _ { u k }$ indicates that $y _ { u i }$ is larger while $y _ { u k }$ is smaller. Therefore, the two predicted ratings $y _ { u i }$ and $y _ { u k }$ are more confident since they are in line with the objective of the BPR loss, and then the derived modality reliability vector will have a high confidence. Formally, we define the confidence $\gamma _ { u i k }$ of the modality reliability vector $z _ { u i k }$ as follows,

![](images/1876b378da8db61a45c7a180f23f153467451c3bd7c9d45ee2f95206825789f1.jpg)  
Fig. 3. Illustration of the weight calibration process.

$$
\gamma_ {u i k} = \left\{ \begin{array}{l l} \tanh ((y _ {u i} - y _ {u k}) / \tau), & y _ {u i} > y _ {u k}, \\ 0, & y _ {u i} \leq y _ {u k}, \end{array} \right.\tag{7}
$$

where tanh() is to map the positive confidence into (0, 1). τ is a linear scaling parameter to adjust the sensitivity. Note that when $y _ { u i } \le y _ { u k }$ , the predicted final user ratings are regarded as incorrect and thus the confidence is set to 0.

Accordingly, we combine the modality reliability vector and its confidence as the supervision signals for learning the modality weights. In particular, as aforementioned, $z _ { u i k }$ captures the modality reliability of both items i and k, and thus it should supervise the modality weights of both the two items. Formally, we design the weight calibration loss as follows,

$$
\mathcal {L} _ {\mathrm{cal}} = \sum_ {(u, i, k) \in \mathcal {D}} \operatorname{nograd} (\gamma_ {u i k}) \mathrm{KL} (\operatorname{nograd} (\boldsymbol {z} _ {u i k}) | | \boldsymbol {w} _ {i} \oplus \boldsymbol {w} _ {k}),\tag{8}
$$

where $\oplus$ refers to the element-wise summation of two vectors. Here we simply use the element-wise summation of the weight vectors ${ \pmb w } _ { i }$ and ${ \pmb w } _ { k }$ to indicate the joint weight vector of the item i and item k. $K L ( )$ is the Kullback-Leibler divergence. The subscript nograd() is a stop-gradient operator that prevents the supervision signals (i.e., the modality reliability vector and its confidence) from being updated. In this way, the gradients of this loss will only affect the modality weight learning as expected.

## C. Training Algorithm

Considering that at the previous training epochs, the model is still optimized and cannot provide reliable predictions yet. The derived modality reliability vector may be not meaningful for guiding the modality weight learning. Therefore, following the study [34], we adopt a two-stage learning strategy to facilitate the training process, where the first stage pre-trains the model to ensure the rational of the modality reliability vector for the modality weight learning in the second stage.

<div class="mineru-algorithm" style="white-space: pre-wrap; font-family:monospace;">
Algorithm 1 Training Algorithm of MARGO.

Input: The set of users U, set of items I, and the item multimodal features. The training set D.

Output: Model parameters  $\Theta$  and weight matrix W.

1: while not converged do

2:  $e_{u}^{m}, e_{i}^{m} \leftarrow \mathcal{F}(u, i, f_{i}^{m} | \Theta)$ .

3:  $y_{ui}^{m} = e_{u}^{m} \cdot e_{i}^{m}$ .

4:  $y_{ui} = \sum_{m=1}^{M} y_{ui}^{m}$ .

5: Update model parameters  $\Theta$  with  $L_{I}$  in Eqn. (9).

6: end while

7: while not converged do

8:  $e_{u}^{m}, e_{i}^{m} \leftarrow \mathcal{F}(u, i, f_{i}^{m} | \Theta)$ .

9:  $y_{ui}^{m} = e_{u}^{m} \cdot e_{i}^{m}$ .

10:  $z_{uik} = \text{softmax}_{m}(g(d_{uik}))$ .

11:  $y_{ui} = \sum_{m=1}^{M} w_{i}^{m} y_{ui}^{m}$ .

12: Fine-tune the model parameters  $\Theta$  and update the weight matrix W with  $L_{II}$  defined in Eqn. (10).

13: end while
</div>

At the first stage, in order to derive the modality-specific user ratings without the effects of modality weights, we discard the weights in Eqn. (3) and simply predict the final user rating with the summations of all modality-specific user ratings, i.e., $\begin{array} { r } { y _ { u i } \ = \ \sum _ { m = 1 } ^ { M } y _ { u i } ^ { m } } \end{array}$ . The first stage is trained with only the recommendation loss $\mathcal { L } _ { \mathrm { r e c } }$ defined in Eqn. (4) and its loss function is defined as follows,

$$
\mathcal {L} _ {\mathrm{I}} = \min _ {\boldsymbol {\Theta}} (\mathcal {L} _ {\mathrm{rec}} + \beta | | \boldsymbol {\Theta} | | _ {2}),\tag{9}
$$

where last term $| | \Theta | | _ { 2 }$ is the regularization of model parameters to avoid over-fitting. $\beta$ is to balance the two terms. After the model converges in the first stage, the model is able to predict the confident user ratings, and therefore we can derive the rational modality reliability vector for supervising the modality weight learning.

At the second stage, we calculate the final user rating by the weighted summation of all modality-specific user ratings defined in Eqn. (3). The model parameters and modality weights will be fine-tuned by jointly optimizing the recommendation loss and the weight calibration loss. Formally, the loss function of the second stage is defined as follows,

$$
\mathcal {L} _ {\mathrm{II}} = \min _ {\boldsymbol {\Theta}, \boldsymbol {W}} (\mathcal {L} _ {\mathrm{rec}} + \alpha \mathcal {L} _ {\mathrm{cal}} + \beta | | \boldsymbol {\Theta} | | _ {2}),\tag{10}
$$

where α and $\beta$ are to balance the three terms. W is the weight matrix that contain the weight vectors of all items. The detailed training algorithm is shown in Algorithm 1.

## D. Convergency Analysis

It is necessary to confirm the model convergency, since that we introduce a new weight calibration loss on the learning of the weight matrix W. To fulfill this, instead of justifying the convergency of the overall loss ${ \mathcal { L } } _ { \mathrm { I I } }$ , we turn to justify that the newly added weight calibration loss $\mathcal { L } _ { \mathrm { c a l } }$ does not conflict with the original recommendation loss $\mathcal { L } _ { \mathrm { r e c } }$ . In particular, two losses are non-conflict if the inner product of their gradients is non-negative [35]. Technically, to justify the model convergency, we can calculate the gradients of $\mathcal { L } _ { \mathrm { r e c } }$ and $\mathcal { L } _ { \mathrm { c a l } }$ on the weight matrix W and prove that their inner product is non-negative. The detailed proofs are as follows.

• Argument 1. $\begin{array} { r } { \frac { \partial \mathcal { L } _ { \mathrm { r e c } } } { \partial W } \cdot \frac { \partial \mathcal { L } _ { \mathrm { c a l } } } { \partial W } \geq 0 . } \end{array}$ • Proof 1. The partial derivative of the recommendation loss $\mathcal { L } _ { \mathrm { r e c } }$ with respect to the weight matrix W is,

$$
\begin{array}{l} \frac {\partial \mathcal {L} _ {\text {rec}}}{\partial \boldsymbol {W}} = \sum_ {i = 1} ^ {| \mathcal {I} |} \frac {\partial \mathcal {L} _ {\text {rec}}}{\partial \boldsymbol {w} _ {i}} \\ = \sum_ {i = 1} ^ {| \mathcal {I} |} \frac {\partial \left(- \log \left(\sigma (y _ {u i} - y _ {u k})\right)\right)}{\partial \boldsymbol {w} _ {i}} \\ = \sum_ {i = 1} ^ {| \mathcal {I} |} \frac {\partial \left(- \log \left(\sigma (\boldsymbol {w} _ {i} (\boldsymbol {e} _ {u} \odot \boldsymbol {e} _ {i}) - \boldsymbol {w} _ {k} (\boldsymbol {e} _ {u} \odot \boldsymbol {e} _ {k}))\right)\right)}{\partial \boldsymbol {w} _ {i}} \\ = \sum_ {i = 1} ^ {| \mathcal {I} |} \frac {\partial \left(- \log \left(\sigma (\boldsymbol {w} _ {i} A + B)\right)\right)}{\partial \boldsymbol {w} _ {i}} \\ = \sum_ {i = 1} ^ {| \mathcal {I} |} - A (1 - \sigma (\boldsymbol {w} _ {i} A + B)) \\ \leq 0, \end{array} \tag {11a}
$$

where we replace variables that are unrelated to the targeted parameter ${ \pmb w } _ { i }$ with constants in Eqn. (11a), i.e, $A = e _ { u } \odot e _ { i }$ and $\boldsymbol { B } = - \boldsymbol { w } _ { k } ( e _ { u } \odot \boldsymbol { e } _ { k } )$ . Eqn. (11b) is derived according to the derivative of the sigmoid function, $\mathrm { i . e . , }$ $\begin{array} { r } { \frac { \partial \sigma ( x ) } { \partial x } = \overline { { \sigma } } ( x ) \big ( 1 - \sigma ( x ) \big ) } \end{array}$ . Eqn. (11c) is satisfied as A refers to the summation of all modality-specific user ratings, which is almost non-negative, and $\left( 1 - \sigma ( \pmb { w } _ { i } A + B ) \right) > 0$

The partial derivative of the weight calibration loss $\mathcal { L } _ { \mathrm { c a l } }$ with respect to the weight matrix W is,

$$
\begin{array}{l} \frac {\partial \mathcal {L} _ {\mathrm{cal}}}{\partial \boldsymbol {W}} = \sum_ {i = 1} ^ {| \mathcal {I} |} \frac {\partial \mathcal {L} _ {\mathrm{cal}}}{\partial \boldsymbol {w} _ {i}} \\ = \sum_ {i = 1} ^ {| \mathcal {I} |} \frac {\partial (\operatorname{nograd} (\gamma_ {u i k}) \mathrm{KL} (\operatorname{nograd} (\boldsymbol {z} _ {u i k}) | | \boldsymbol {w} _ {i} \oplus \boldsymbol {w} _ {k}))}{\partial \boldsymbol {w} _ {i}} \\ = \sum_ {i = 1} ^ {| \mathcal {I} |} \frac {\partial (C \cdot \mathrm{KL} (D | | \boldsymbol {w} _ {i} \oplus \boldsymbol {w} _ {k}))}{\partial \boldsymbol {w} _ {i}} \\ = \sum_ {i = 1} ^ {| \mathcal {I} |} \frac {\partial (C (D \log D - D \log (\boldsymbol {w} _ {i} \oplus \boldsymbol {w} _ {k}))}{\partial \boldsymbol {w} _ {i}} \\ = \sum_ {i = 1} ^ {| \mathcal {I} |} - \frac {C D}{\boldsymbol {w} _ {i}} \leq 0, \end{array} \tag {12a}
$$

where variables nograd $( \gamma _ { u i k } )$ and $\mathrm { n o g r a d } ( z _ { u i k } )$ that have no gradient can be regarded as constants to the targeted parameter ${ \pmb w } _ { i }$ , which are replaced with $C$ and D in Eqn. (12a), respectively. Eqn. (12b) is derived according to the equation of the Kullback-Leibler divergence, i.e.,

KL $\begin{array} { r } { \iota ( p | | q ) = p \log p - p \log q . } \end{array}$ Eqn. (12c) is satisfied since that C, D and ${ \pmb w } _ { i }$ are non-negative.

Thereafter, the inner product between gradients of losses $\mathcal { L } _ { \mathrm { r e c } }$ and $\mathcal { L } _ { \mathrm { c a l } }$ can be calculated as follows,

$$
\begin{array}{l} \frac {\partial \mathcal {L} _ {\mathrm{rec}}}{\partial \boldsymbol {W}} \cdot \frac {\partial \mathcal {L} _ {\mathrm{cal}}}{\partial \boldsymbol {W}} \\ = \Big (\sum_ {i = 1} ^ {| \mathcal {I} |} - A \big (1 - \sigma (\boldsymbol {w} _ {i} A + B) \big) \Big) \cdot \Big (\sum_ {i = 1} ^ {| \mathcal {I} |} - \frac {C D}{\boldsymbol {w} _ {i}} \Big) \\ \geq 0. \end{array}
$$

## IV. EXPERIMENTS

We first give the experimental settings in Subsection IV-A, and then show the experiment results to answer the following research questions:

• RQ1. How effective is the proposed MARGO?

• RQ2. What is the contribution of each component?

• RQ3. How does MARGO perform with different hyperparameter settings?

• RQ4. How is the quality of learned modality weights?

• RQ5. What is the difference between reliable and unreliable modality data?

## A. Experimental Settings

In this subsection, we introduce the detailed experimental settings, including the datasets, evaluation protocols, and implementation details.

Datasets. Following the studies [9], [36], we conduct experiments on three categories in the widely-used Amazon dataset [37]: Baby, Sports, and Clothing. To keep the fair comparison, we closely follow the pre-processing of the datasets in the study [36], where only the users and items that have more than 5 interactions are remained. The statistics of the three datasets after pre-processing are listed in Table II. In the three datasets, each item is associated with its image and text. We directly adopt the released modality features in the studies [9], [36], where the image feature is a 4096- dimensional vector extracted by a CNN model [16] and the text feature is a 384-dimensional vector extracted by a pretrained sentence-transformers [38].

Evaluation Metrics. Following studies [9], [36], we randomly split each dataset with a ratio of 8 : 1 : 1 to derive the training, validation, and testing sets and evaluate our proposed MARGO method in the top- $. K$ recommendation task. To be more specific, we rank the positive items from all items in the dataset and adopt the widely-used evaluation metrics: Recall@K and NDCG@K, to evaluate the effectiveness of our proposed method. By default, we set K = 10, 20.

Implementation Details. We set the embedding size d to 64 following most studies [39], [40], [9]. We tune the trade-off parameters $\alpha$ and $\beta$ from [0.01, 0.1, 1], respectively, and the scaling parameter τ from [0.1, 1, 5, 10]. We adopt the stateof-the-art architecture in DRAGON [10] as the multimodal recommendation model $\mathcal { F }$ in Eqn. (1). We adopt the Adam optimizer [41] and use the learning rate of $1 e ^ { - 4 }$ . The minibatch sizes are 2, 048 for all the datasets, and the model is trained with 100 epochs using the early stop strategy. Note that

TABLE II  
STATISTICS OF THE EXPERIMENTAL DATASETS.

<table><tr><td>Dataset</td><td>#User</td><td>#Item</td><td>#Interaction</td><td>Sparsity</td></tr><tr><td>Baby</td><td>19,445</td><td>7,050</td><td>160,792</td><td>99.88%</td></tr><tr><td>Sports</td><td>35,598</td><td>18,357</td><td>296,337</td><td>99.95%</td></tr><tr><td>Clothing</td><td>39,387</td><td>23,033</td><td>278,677</td><td>99.97%</td></tr></table>

100 epochs are enough for the model to converge. As same as study [9], [36], the reported results are selected according to Recall@20 on the validation set.

## B. Performance Comparison (RQ1)

We select the following state-of-the-art methods to evaluate the effectiveness of the proposed method,

• VBPR [15] uses the item images to enrich the item embeddings and adopts the BPR loss for recommendation. For the fair comparison, we further incorporate the item texts.

• GRCN [4] constructs a user-item interaction graph for each modality and cuts off the false-positive edges in the graph to refine the graph learning.

• SLMRec [39] utilizes the self-supervised learning techniques in the graph-based models to uncover the hidden signals from the data with contrastive loss.

• BM3 [20] simplifies the self-supervised multimodal recommendation framework by removing the randomly sampled negative examples, while it directly perturbs the representation through a dropout mechanism.

• MICRO [42] utilizes the user-item interaction graph to learn the user and item embeddings. It then learns the itemitem graph from item multimodal data, and updates the item embeddings on the item-item graph.

• MGCN [9] uses the item behavior information to purify the item modality features. It designs a behavior-aware fusion method to filter out the redundant information between modality features.

• FREEDOM [19] introduces a new item-item graph for each modality and gets the latent item graphs by aggregating all the modalities. It also introduces the degree-sensitive edge pruning to denoise the user-item interaction graph.

• DRAGON [10] conducts graph learning on both heterogeneous graph and homogeneous graphs to obtain the user and item embeddings. Besides, it employs the attentive concatenation to fuse the multimodal ratings.

• LGMRec [8] introduces local graphs to learn collaborativerelated and modality-related embeddings. It further designs a global hyper-graph embedding module to capture the user’s global interests.

The results of the baselines and the proposed MARGO on three datasets are shown in Table III, where the best and second-best results are highlighted in bold and underlined, respectively. We also calculate the relative improvement of MARGO compared with the best baseline in the “impro.” row of Table III. As can be seen, the proposed MARGO method achieves the best performance compared with all baselines across all metrics. The average improvement is 3.26%, which demonstrates the effectiveness of the proposed method. This is because that we use the modality weights to decrease the negative effects of unreliable modalities in the multimodal fusion. Besides, although several studies, e.g., DRAGON, also adds the modality weights during the multimodal recommendation, they perform worse than the proposed MARGO. This is because that MARGO involves explicit supervisions on the modality weight learning, which makes the learned weights more precise.

TABLE III  
RESULTS OF THE PERFORMANCE COMPARISON ON THE THREE DATASETS. WE HIGHLIGHT THE BEST AND SECOND-BEST RESULTS IN BOLD AND UNDERLINED, RESPECTIVELY. “IMPRO.” IS THE RELATIVE IMPROVEMENT. THE RESULTS OF THE BASELINES ARE DERIVED FROM THEIR PAPERS.

<table><tr><td rowspan="2"></td><td colspan="4">Baby</td><td colspan="4">Sports</td><td colspan="4">Clothing</td><td rowspan="2">Average</td></tr><tr><td>R@10</td><td>R@20</td><td>N@10</td><td>N@20</td><td>R@10</td><td>R@20</td><td>N@10</td><td>N@20</td><td>R@10</td><td>R@20</td><td>N@10</td><td>N@20</td></tr><tr><td>VBPR (AAAI&#x27;16)</td><td>0.0423</td><td>0.0663</td><td>0.0223</td><td>0.0284</td><td>0.0558</td><td>0.0856</td><td>0.0307</td><td>0.0384</td><td>0.0280</td><td>0.0414</td><td>0.0159</td><td>0.0193</td><td>0.0395</td></tr><tr><td>GRCN (MM&#x27;20)</td><td>0.0532</td><td>0.0824</td><td>0.0282</td><td>0.0358</td><td>0.0559</td><td>0.0877</td><td>0.0306</td><td>0.0389</td><td>0.0424</td><td>0.0650</td><td>0.0225</td><td>0.0283</td><td>0.0476</td></tr><tr><td>SLMRec (TMM&#x27;22)</td><td>0.0540</td><td>0.0810</td><td>0.0285</td><td>0.0357</td><td>0.0676</td><td>0.1017</td><td>0.0374</td><td>0.0462</td><td>0.0452</td><td>0.0675</td><td>0.0247</td><td>0.0303</td><td>0.0517</td></tr><tr><td>MICRO (TKDE&#x27;22)</td><td>0.0584</td><td>0.0929</td><td>0.0318</td><td>0.0407</td><td>0.0679</td><td>0.1050</td><td>0.0367</td><td>0.0463</td><td>0.0521</td><td>0.0772</td><td>0.0283</td><td>0.0347</td><td>0.0560</td></tr><tr><td>BM3 (WWW&#x27;23)</td><td>0.0564</td><td>0.0883</td><td>0.0301</td><td>0.0383</td><td>0.0656</td><td>0.0980</td><td>0.0355</td><td>0.0438</td><td>0.0421</td><td>0.0625</td><td>0.0228</td><td>0.0280</td><td>0.0510</td></tr><tr><td>MGCN (MM&#x27;23)</td><td>0.0620</td><td>0.0964</td><td>0.0339</td><td>0.0427</td><td>0.0729</td><td>0.1106</td><td>0.0397</td><td>0.0496</td><td>0.0641</td><td>0.0945</td><td>0.0347</td><td>0.0428</td><td>0.0620</td></tr><tr><td>FREEDOM (MM&#x27;23)</td><td>0.0627</td><td>0.0992</td><td>0.0330</td><td>0.0424</td><td>0.0717</td><td>0.1089</td><td>0.0385</td><td>0.0481</td><td>0.0629</td><td>0.0941</td><td>0.0341</td><td>0.0420</td><td>0.0615</td></tr><tr><td>LGMRec (AAAI&#x27;24)</td><td>0.0644</td><td>0.1002</td><td>0.0349</td><td>0.0440</td><td>0.0720</td><td>0.1068</td><td>0.0390</td><td>0.0480</td><td>0.0555</td><td>0.0828</td><td>0.0302</td><td>0.0371</td><td>0.0596</td></tr><tr><td>DRAGON (ECAI&#x27;23)</td><td>0.0662</td><td>0.1021</td><td>0.0345</td><td>0.0435</td><td>0.0749</td><td>0.1124</td><td>0.0403</td><td>0.0500</td><td>0.0650</td><td>0.0957</td><td>0.0357</td><td>0.0435</td><td>0.0637</td></tr><tr><td>MARGO (ours)</td><td>0.0677</td><td>0.1032</td><td>0.0362</td><td>0.0452</td><td>0.0787</td><td>0.1175</td><td>0.0430</td><td>0.0530</td><td>0.0667</td><td>0.0969</td><td>0.0364</td><td>0.0440</td><td>0.0657</td></tr><tr><td>impro.</td><td>2.27%</td><td>1.08%</td><td>3.72%</td><td>2.73%</td><td>5.07%</td><td>4.54%</td><td>6.70%</td><td>6.00%</td><td>2.62%</td><td>1.25%</td><td>1.96%</td><td>1.15%</td><td>3.26%</td></tr></table>

## C. Ablation Study (RQ2)

To investigate the effects of various factors, we perform ablation studies on both key components of the proposed MARGO and different modality features.

1) Effect of Components: To evaluate the effects of the key components, we set up the following model variants:

• w/o weight. This variant removes the modality weights, where the final user rating is simply calculated by the summation of all ratings regarding different modalities and the model is trained with only the recommendation loss.

• w/o $\mathcal { L } _ { \mathrm { c a l } }$ . This variant discards the proposed weight calibration loss $\mathcal { L } _ { \mathrm { c a l } }$ where the modality weights are updated with only the recommendation loss.

• w/o two-stage. This variant only utilizes the second training stage of MARGO to optimize the model, where the first pre-training stage is discarded. In particular, in this variant, we adopt the same framework of the proposed method, but directly optimize the model by ${ \mathcal { L } } _ { \mathrm { I I } }$ in Eqn. (10).

• w/o nograd. This variant removes the stop-gradient operator in the weight calibration loss $\mathcal { L } _ { \mathrm { c a l } }$ in Eqn. (8).

The results of the ablation study on the components are shown in Table IV, where the best performance is highlighted in bold. We have the following observations.

1) w/o weight achieves the worst performance compared with others that involve the modality weights. This demonstrates that in multimodal recommendation, it is necessary to consider different contributions of different modalities on predicting the final user rating.

2) w/o $\mathcal { L } _ { \mathrm { c a l } }$ adds the modality weights but still achieves unsatisfied performance. This is because that in w/o $\mathcal { L } _ { \mathrm { c a l } }$ , the modality weights only updated with the recommendation loss, without explicit supervisions. Therefore, the learned modality weights may be imprecise.

3) w/o two-stage achieves worse performance than MARGO that adopts the two-stage training process. This may be because that without the first stage, the predicted user ratings at initial training epochs are irrational. Therefore, the derived modality reliability vector cannot provide correct supervisions to the weight learning, and hence harm the fusion results. This demonstrates the necessity of the two-stage training process.

4) w/o nograd results in a little performance drop compared with our proposed MARGO. Although the differences are not that obvious, we empirically find that w/o nograd will hurt the diversity of the learned modality weights, which will be discussed in RQ4 (Subsection IV-E).

2) Effect of Modalities: To explore the contribution of each modality to the recommendation performance, we compare the performance of the propose method under the uni-modal setting. $M A R G O _ { v }$ and MARGO denote the models that utilize visual and textual features, respectively. The results of the ablation study on the modalities are shown in Table IV. Comparing the results, we have the following observations.

1) The proposed MARGO that utilizes the multimodal data of items outperforms the other two variants that only utilize uni-modal data. This proves that the proposed MARGO could effectively use the item multimodal data to help improve the recommendation performance.

2) The variant $M A R G O _ { t }$ that utilizes the textual information achieves the better performance than $M A R G O _ { v }$ that uses the visual information. This indicates that it can better learn the user interests that using texts than images.

3) Comparing the results of the w/o weight variant, we find that although it uses both item texts and images, it still achieves the worse performance than $M A R G O _ { t }$ that only uses the item texts in Baby and Sports datasets. This indicates that the simple multimodal fusion method will lead to the performance degradation issue. Differently, the performance of MARGO is better than both $M A R G O _ { v }$ and $M A R G O _ { t } ,$ , which proves that MARGO is able to settle the performance degradation issue.

TABLE IV  
RESULTS OF THE ABLATION STUDY ON BOTH THE MODULES OF THE PROPOSED METHOD AND MODALITY FEATURES.

<table><tr><td rowspan="2"></td><td colspan="4">Baby</td><td colspan="4">Sports</td><td colspan="4">Clothing</td></tr><tr><td>R@10</td><td>R@20</td><td>N@10</td><td>N@20</td><td>R@10</td><td>R@20</td><td>N@10</td><td>N@20</td><td>R@10</td><td>R@20</td><td>N@10</td><td>N@20</td></tr><tr><td>w/o weight</td><td>0.0612</td><td>0.0935</td><td>0.0327</td><td>0.0410</td><td>0.0704</td><td>0.1045</td><td>0.0384</td><td>0.0472</td><td>0.0616</td><td>0.0908</td><td>0.0337</td><td>0.0411</td></tr><tr><td>w/o  $\mathcal{L}_{\text{cal}}$ </td><td>0.0654</td><td>0.1014</td><td>0.0357</td><td>0.0450</td><td>0.0760</td><td>0.1143</td><td>0.0413</td><td>0.0512</td><td>0.0652</td><td>0.0957</td><td>0.0360</td><td>0.0437</td></tr><tr><td>w/o two-stage</td><td>0.0659</td><td>0.1018</td><td>0.0354</td><td>0.0446</td><td>0.0762</td><td>0.1145</td><td>0.0419</td><td>0.0517</td><td>0.0655</td><td>0.0948</td><td>0.0358</td><td>0.0432</td></tr><tr><td>w/o nograd</td><td>0.0656</td><td>0.1023</td><td>0.0351</td><td>0.0446</td><td>0.0785</td><td>0.1152</td><td>0.0430</td><td>0.0525</td><td>0.0663</td><td>0.0976</td><td>0.0361</td><td>0.0440</td></tr><tr><td> $MARGO_v$ </td><td>0.0497</td><td>0.0798</td><td>0.0272</td><td>0.0350</td><td>0.0614</td><td>0.0910</td><td>0.0336</td><td>0.0413</td><td>0.0459</td><td>0.0669</td><td>0.0244</td><td>0.0297</td></tr><tr><td> $MARGO_t$ </td><td>0.0635</td><td>0.0985</td><td>0.0338</td><td>0.0428</td><td>0.0727</td><td>0.1089</td><td>0.0394</td><td>0.0488</td><td>0.0599</td><td>0.0895</td><td>0.0329</td><td>0.0405</td></tr><tr><td>MARGO</td><td>0.0677</td><td>0.1032</td><td>0.0362</td><td>0.0452</td><td>0.0787</td><td>0.1175</td><td>0.0430</td><td>0.0530</td><td>0.0667</td><td>0.0969</td><td>0.0364</td><td>0.0440</td></tr></table>

![](images/6226e227536fb9665cea68545877de904fb1c70cb08ed48360bb8cf549c375e1.jpg)

![](images/39e8d6afcdf0df46fb2f421fc664f1394dda0afdbc3676e691ce4f0a9a212e3d.jpg)

![](images/a22bf8c3f7cd21bd1f3570bd1938301119fe0d913eb0b8a06a5e6658acdf4d15.jpg)

![](images/d487fb69e1d787b1bf281e00551422cf9ebb4d64a775dd1054ac213f1a223142.jpg)

![](images/4426d6c1d6f093716ddcc2a2a26e02a1bf0bc76254e78594ce51e8b63ec43216.jpg)

![](images/ce9b7e18f4fd90f39e25e2097b56f8014630887c9daa42dc4e76292512c2becc.jpg)  
Fig. 4. Performance of the proposed MARGO with respect to different trade-off parameter α on three datasets. The x-axis refers to the values of α. The left and right y-axis refer to the Recall@20 and NDCG@20, respectively.

## D. Hyper-parameter Discussion (RQ3)

In this subsection, we evaluate the key hyper-parameters in MARGO, i.e., the trade-off parameter α defined in Eqn. (10) and sensitivity parameter τ defined in Eqn. (7).

1) Trade-off parameter α: It adjusts the balance between the original recommendation loss and weight calibration loss, where a larger α indicates the greater importance of the weight calibration loss in optimization. We tune α from $\{ 0 , 0 . 0 1 , 0 . 1 , 1 \}$ and report the Recall@20 and NDCG@20 results of MARGO in Figure 4. As can be seen, when we discard the weight calibration process, i.e., $\alpha = 0$ , the model achieves the worst performance. This demonstrates the effectiveness of our proposed the weight calibration loss. Besides, along with α increasing, the model performance first rises significantly until it achieves the best performance with the most suitable α and then decreases. This demonstrates the necessity of appropriately adjust the importance of the weight calibration to supervise the modality weight learning in the multimodal recommendation. However, when α becomes excessively large, the model focuses excessively on the weight learning, while overlooking the original and dominated recommendation objective, and hence the performance drops. Therefore, finding a suitable trade-off is crucial for ensuring the effectiveness of the recommendation.

2) Sensitivity parameter τ : It adjusts the sensitivity of the confidence $\gamma _ { u i k }$ affected by the prediction results $y _ { u i } - y _ { u k }$ during the weight calibration process. When τ becomes large, the confidence changes smoothly with the prediction results. We tune τ from {0.1, 1, 5, 10} and report the Recall@20 and NDCG@20 results of MARGO in Figure 4. As can be seen, along with the sensitivity parameter τ increasing, the performance first rises significantly until $\tau ~ = ~ 5$ and then decreases in all datasets. This suggests that a suitable sensitivity parameter is crucial for the weight calibration.

## E. Visualization of the Modality Weights (RQ4)

We visualize the weights of images learned by the best baseline (i.e., DRAGON) and our proposed MARGO in Figure 5. Besides, we also visualize the image weights learned by the w/o nograd variant to show it differences of the learned weights compared to our proposed MARGO. In Figure 5, the x-axis refers to the interval of weight values, while the y-axis refers to the number of items whose weights of the image fall within the corresponding weight interval. The histogram shows the distribution of the learned weights of images. Note that the distribution of the learned weights of texts is symmetrical with that of images, since that the summation of the weights of the text and image in one item is equal to 1. From Figure 5, we have the following observations.

1) The expectation of the weights learned by DRAGON is close to 0.5. This may be because that DRAGON does not have specific supervisions to distinguish whether the image is reliable, whereby the model provides a neutral prediction. Differently, the expectation of the weights learned by MARGO is smaller than 0.5. It shows that images are less reliable than texts as a whole. This phenomenon is in line with the result in Effect of Modalities (Subsection IV-C2), where $M A R G O _ { t }$ that utilizes the item texts outperforms MARGO that uses the item images.

![](images/9f1a49037347ecebfc4f8b4abee2faa44ac4b2823c985eb08eb3f67b9876d273.jpg)

![](images/fc15f2d0553d2df5ec10c161444cc70e8a83b9d8547d415574c273e44afefe12.jpg)

![](images/46bbefd0132db84c2fd3d71a9e5bd0442f49307f1a043ab1d6513ebb5722b309.jpg)

Fig. 5. Histogram of the weights of images learned by the best baseline DRAGON, variant w/o stopgrad, and our proposed method MARGO. The x-axis and y-axis refer to the weight value and item number, respectively.  
![](images/e0bf3681550db0aa0170b4ea734c0618e69ae57e60ce1b7b5a16e41a52a31ac0.jpg)  
Fig. 6. Examples of the five most reliable and unreliable item texts and images in the Baby dataset. The reliability of the modality data is determined by the learned modality weights learned by the proposed MARGO.

2) The weights learned by MARGO are more dispersed than those learned by DRAGON. Specifically, the weights of images learn by DRAGON are mainly concentrated in [0.4, 0.6], indicating that there is small difference in weights between images and texts. The result shows that the weights learned by DRAGON fails to meet the motivation of learning different weights for modalities. Differently, the weights learned by MARGO are more dispersed than DRAGON, which demonstrates that MARGO can better capture different contributions of modalities and hence achieve better performance.

3) Although w/o nograd adds the supervisions on the modality weight learning as same as MARGO, the learned weights are more concentrated than MARGO. This may be because that the modality weights learned without explicit supervisions tend to be learned concentrated, according to the results of DRAGON. Therefore, without the stopgradient operator in w/o nograd variant, the target modality reliability vector will be affected by the modality weights, causing the target to become concentrated and lose its original diversity. This further demonstrates that it is necessary to add the stop-gradient operator on the target modality reliability vector to avoid the negative gradients.

## F. Case Study (RQ5)

In this subsection, we conduct a case study to intuitively explore the similar and different patterns in the most reliable and unreliable modality data. In particular, without losing generality, we select most 3 reliable and unreliable modality data in Baby dataset based on their modality weights learned by our proposed MARGO in Figure 6. From Figure 6, we have the following observations.

1) The reliable and unreliable texts are different in contents. To be more specific, unreliable texts tend to have more unrelated descriptions or spend lots of space on describing the item usage. Reliable texts often begin with the item titles and utilize more concise phrase to introduce the item functions and attributes. For example, in unreliable texts, the phrases “just say no to” and “ there’s nothing else like it” are not necessary to describe the item. The third example details how to use an item that appears to be a children’s bath toy. Differently, it is clear from the first example in reliable texts that the item is a “Ergobaby Carrier”, which has “moisture-wicking mesh lining” and “durable synthetic exterior”, making it breathable, easy wash and quick dry.

2) The reliable and unreliable texts are different in language styles, where the unreliable texts contain more emotional expression such as “friendly” and “out for squirt-time fun”. These factors might mislead the model to focus on the emotion of texts, rather than the information of the item.

3) The reliability of images mainly depends on how much could the images describe the item. To be more specific, in unreliable images, it is difficult for us to recognize what the item is used for with only the image. For example, it can be seen that the first item is a pink boll with a pedestal from the image. However, it is hard to know that it is a pacifier sterilizer until we refer to its text. Besides, as for the second image, the persons are more prominent compared to the true item, i.e., the bath towel. Differently, in the reliable images, the item is dominant in the image and is easier to recognize based on the images. For example, the first item is a blanket that provides the baby a place to play, and the second item is a handbag.

## V. CONCLUSION AND FUTURE WORK

In this paper, we propose a modality reliability guided multimodal recommendation framework (MARGO) that leverage weights to model different contributions of item modalities in the rating prediction. Different from existing methods that optimize the weights with only the recommendation objective, we introduce a new supervision signals to enhance the weight learning process. In particular, we first derive a modality reliability vector by comparing the multimodal ratings of positive and negative items as the supervision label of the modality weights. We then calculate the confidence level for the supervision label for dynamically adjusting the supervision strength and eliminating the negative supervision. Extensive experiments on three public datasets have demonstrated the effectiveness of the proposed MARGO.

Through the experimental analysis, we have found that the reliable and unreliable modality data shares their specific patterns. For example, reliable texts mainly describe the item attributes and functions, while unreliable texts contain more emotional adjectives. It is benefit for the multimodal recommendation to discover and filter out such irrelevant information from the modality features, e.g., emotional factors in texts. Therefore, in the future, we plan to devise an automatic method for the feature enhancement for recommendation.

## REFERENCES

[1] X. He, K. Deng, X. Wang, Y. Li, Y. Zhang, and M. Wang, “Lightgcn: Simplifying and powering graph convolution network for recommendation,” in Conference on research and development in Information Retrieval. ACM, 2020, pp. 639–648.

[2] X. Zhou, D. Lin, Y. Liu, and C. Miao, “Layer-refined graph convolutional networks for recommendation,” CoRR, vol. abs/2207.11088, 2022.

[3] Y. Wei, X. Wang, L. Nie, X. He, R. Hong, and T. Chua, “MMGCN: multi-modal graph convolution network for personalized recommendation of micro-video,” in Conference on Multimedia. ACM, 2019, pp. 1437–1445.

[4] Y. Wei, X. Wang, L. Nie, X. He, and T. Chua, “Graph-refined convolutional network for multimedia recommendation with implicit feedback,” in Conference on Multimedia. ACM, 2020, pp. 3541–3549.

[5] W. Ji, X. Liu, A. Zhang, Y. Wei, Y. Ni, and X. Wang, “Online distillationenhanced multi-modal transformer for sequential recommendation,” in International Conference on Multimedia. ACM, 2023, pp. 955–965.

[6] Y. Wei, W. Liu, F. Liu, X. Wang, L. Nie, and T. Chua, “Lightgt: A light graph transformer for multimedia recommendation,” in Conference on Research and Development in Information Retrieval. ACM, 2023, pp. 1508–1517.

[7] X. Dong, X. Song, N. Zheng, Y. Wei, and Z. Zhao, “Dual preference distribution learning for item recommendation,” ACM Trans. Inf. Syst., vol. 41, no. 3, pp. 56:1–56:22, 2023.

[8] Z. Guo, J. Li, G. Li, C. Wang, S. Shi, and B. Ruan, “Lgmrec: Local and global graph learning for multimodal recommendation,” in Conference on Artificial Intelligence. AAAI, 2024, pp. 8454–8462.

[9] P. Yu, Z. Tan, G. Lu, and B. Bao, “Multi-view graph convolutional network for multimedia recommendation,” in International Conference on Multimedia. ACM, 2023, pp. 6576–6585.

[10] H. Zhou, X. Zhou, L. Zhang, and Z. Shen, “Enhancing dyadic relations with homogeneous graphs for multimodal recommendation,” in Conference on Prestigious Applications of Intelligent Systems, ser. Frontiers in Artificial Intelligence and Applications, vol. 372. IOS, 2023, pp. 3123–3130.

[11] J. Zhang, G. Liu, Q. Liu, S. Wu, and L. Wang, “Modality-balanced learning for multimedia recommendation,” in International Conference on Multimedia. ACM, 2024, pp. 7551–7560.

[12] Q. Wang, Y. Wei, J. Yin, J. Wu, X. Song, and L. Nie, “Dualgnn: Dual graph neural network for multimedia recommendation,” IEEE Trans. Multim., vol. 25, pp. 1074–1084, 2023.

[13] S. Rendle, C. Freudenthaler, Z. Gantner, and L. Schmidt-Thieme, “BPR: bayesian personalized ranking from implicit feedback,” in Conference on Uncertainty in Artificial Intelligence. AUAI, 2009, pp. 452–461.

[14] D. Pan, X. Li, X. Li, and D. Zhu, “Explainable recommendation via interpretable feature mapping and evaluation of explainability,” in International Joint Conference on Artificial Intelligence. IJCAI, 2020, pp. 2690–2696.

[15] R. He and J. J. McAuley, “VBPR: visual bayesian personalized ranking from implicit feedback,” in Conference on Artificial Intelligence. AAAI, 2016, pp. 144–150.

[16] J. Zhang, Y. Zhu, Q. Liu, S. Wu, S. Wang, and L. Wang, “Mining latent structures for multimedia recommendation,” in Conference on Multimedia. ACM, 2021, pp. 3872–3880.

[17] C. Chen, B. Song, J. Guo, and T. Zhang, “Multi-dimensional shared representation learning with graph fusion network for session-based recommendation,” Inf. Fusion, vol. 92, pp. 205–215, 2023.

[18] Z. Lin, Y. Tan, Y. Zhan, W. Liu, F. Wang, C. Chen, S. Wang, and C. Yang, “Contrastive intra- and inter-modality generation for enhancing incomplete multimedia recommendation,” in International Conference on Multimedia. ACM, 2023, pp. 6234–6242.

[19] X. Zhou and Z. Shen, “A tale of two graphs: Freezing and denoising graph structures for multimodal recommendation,” in International Conference on Multimedia. ACM, 2023, pp. 935–943.

[20] X. Zhou, H. Zhou, Y. Liu, Z. Zeng, C. Miao, P. Wang, Y. You, and F. Jiang, “Bootstrap latent representations for multi-modal recommendation,” in WWW. ACM, 2023, pp. 845–854.

[21] J. Guo, Y. Zhou, P. Zhang, B. Song, and C. Chen, “Trust-aware recommendation based on heterogeneous multi-relational graphs fusion,” Inf. Fusion, vol. 74, pp. 87–95, 2021.

[22] T. Kim, Y. Lee, K. Shin, and S. Kim, “MARIO: modality-aware attention and modality-preserving decoders for multimedia recommendation,” in Conference on Information & Knowledge Management. ACM, 2022, pp. 993–1002.

[23] X. Liu, Z. Tao, J. Shao, L. Yang, and X. Huang, “Elimrec: Eliminating single-modal bias in multimedia recommendation,” in Conference on Multimedia. ACM, 2022, pp. 687–695.

[24] Y. Li, C. Chen, X. Zheng, Y. Zhang, Z. Han, D. Meng, and J. Wang, “Making users indistinguishable: Attribute-wise unlearning in recommender systems,” in International Conference on Multimedia. ACM, 2023, pp. 984–994.

[25] S. Liu, Z. Chen, H. Liu, and X. Hu, “User-video co-attention network for personalized micro-video recommendation,” in WWW. ACM, 2019, pp. 3020–3026.

[26] X. Zhang, B. Xu, F. Ma, C. Li, L. Yang, and H. Lin, “Beyond cooccurrence: Multi-modal session-based recommendation,” IEEE Trans. Knowl. Data Eng., vol. 36, no. 4, pp. 1450–1462, 2024.

[27] X. Dong, J. Wu, X. Song, H. Dai, and L. Nie, “Fashion compatibility modeling through a multi-modal try-on-guided scheme,” in International conference on research and development in Information Retrieval. ACM, 2020, pp. 771–780.

[28] K. Liu, F. Xue, D. Guo, P. Sun, S. Qian, and R. Hong, “Multimodal graph contrastive learning for multimedia-based recommendation,” IEEE Trans. Multim., vol. 25, pp. 9343–9355, 2023.

[29] X. Song, C. Wang, C. Sun, S. Feng, M. Zhou, and L. Nie, “Mmfrec: Multi-modal enhanced fashion item recommendation,” IEEE Trans. Knowl. Data Eng., vol. 35, no. 10, pp. 10 072–10 084, 2023.

[30] F. Liu, H. Chen, Z. Cheng, A. Liu, L. Nie, and M. S. Kankanhalli, “Disentangled multimodal representation learning for recommendation,” IEEE Trans. Multim., vol. 25, pp. 7149–7159, 2023.

[31] L. Xiang, G. Ding, and J. Han, “Learning from multiple experts: Selfpaced knowledge distillation for long-tailed classification,” in European Conf. on Computer Vision, vol. 12350. Springer, 2020, pp. 247–263.

[32] Y. Shang, C. Gao, J. Chen, D. Jin, H. Ma, and Y. Li, “Enhancing adversarial robustness of multi-modal recommendation via modality balancing,” in Conference on Multimedia. ACM, 2023, pp. 6274–6282.

[33] X. Dong, X. Song, M. Tian, and L. Hu, “Prompt-based and weakmodality enhanced multimodal recommendation,” Inf. Fusion, vol. 101, p. 101989, 2024.

[34] C. Wang, Z. Wang, Y. Liu, Y. Ge, W. Ma, M. Zhang, Y. Liu, J. Feng, C. Deng, and S. Ma, “Target interest distillation for multiinterest recommendation,” in International Conference on Information & Knowledge Management. ACM, 2022, pp. 2007–2016.

[35] T. Yu, S. Kumar, A. Gupta, S. Levine, K. Hausman, and C. Finn, “Gradient surgery for multi-task learning,” in Conference on Neural Information Processing Systems, 2020.

[36] H. Zhou, X. Zhou, Z. Zeng, L. Zhang, and Z. Shen, “A comprehensive survey on multimodal recommender systems: Taxonomy, evaluation, and future directions,” CoRR, vol. abs/2302.04473, 2023.

[37] J. Ni, J. Li, and J. J. McAuley, “Justifying recommendations using distantly-labeled reviews and fine-grained aspects,” in Conference on Empirical Methods in Natural Language Processing and Natural Language Processing. ACL, 2019, pp. 188–197.

[38] N. Reimers and I. Gurevych, “Sentence-bert: Sentence embeddings using siamese bert-networks,” in Conference on Empirical Methods in Natural Language Processing. ACL, 2019, pp. 3980–3990.

[39] T. Zhulin, X. Liu, Y. Xia, X. Wang, L. Yang, X. Huang, and T.-S. Chua, “Self-supervised learning for multimedia recommendation,” IEEE Trans. Multim., 2023.

[40] X. Du, Z. Wu, F. Feng, X. He, and J. Tang, “Invariant representation learning for multimedia recommendation,” in Conference on Multimedia. ACM, 2022, pp. 619–628.

[41] D. P. Kingma and J. Ba, “Adam: A method for stochastic optimization,” in International Conf. on Learning Representations, 2015, pp. 1–15.

[42] J. Zhang, Y. Zhu, Q. Liu, M. Zhang, S. Wu, and L. Wang, “Latent structure mining with contrastive modality fusion for multimedia recommendation,” IEEE Trans. Knowl. Data Eng., vol. 35, no. 9, pp. 9154–9167, 2023.

![](images/5ed1126e5ec808a0b907ba58b914c9a56556435d2429992b39535627ed39588e.jpg)  
Xue Dong received the Ph.D. degree from the School of Software, Shandong University, in 2023. She is currently a research fellow with the School of Software, Tsinghua University, China. Her research interests contain multimedia computing, multimodal recommendation and multimodal prompt tuning. She has published several papers in the top venues, such as ACM SIGIR, MM, TOIS, IEEE TNNLS and Information Fusion.

![](images/02690a61b326667da6d154b04fd42d134191627d64d17f10e46fadf358a40af7.jpg)

Xuemeng Song received the B.E. degree from the University of Science and Technology of China, in 2012, and the Ph.D. degree from the School of Computing, National University of Singapore, in 2016. She is currently an Associate Professor with Shandong University, China. She has published several papers in the top venues, such as ACM SIGIR, MM, and TOIS. Her research interests include information retrieval and social network analysis. She has served as a reviewer for many top conferences and journals.

![](images/366412c6ebcf527dcd2877283118d9512bb8bd74cda0abd650727e30d3f084ff.jpg)

Na Zheng received the M.S. degree from the Central South University in 2018, and the Ph.D. degree from the Shandong University, in 2022. She is currently a research fellow with the National University of Singapore. She has published several papers in the top venues, such as ACM MM, TOIS, ToMM and IEEE TCVST. Her research interests include computer vision and food computing. She has served as a reviewer for many top conferences and journals.

![](images/bb60a26b4e2b008b12a2b2b9b3ff834552136b73df067428a3d5b580251cd382.jpg)

Sicheng Zhao received the Ph.D. degree from the Harbin Institute of Technology, Harbin, China, in 2016. He was a Visiting Scholar with the National University of Singapore, Singapore, from 2013 to 2014; a Research Fellow with Tsinghua University, Beijing, China, from 2016 to 2017; a Postdoctoral Research Fellow with the University of California at Berkeley, Berkeley, CA, USA, from 2017 to 2020; and a Postdoctoral Research Scientist with Columbia University, New York, NY, USA, from 2020 to 2022. He is currently a Research Associate Professor

with Tsinghua University. His research interests include affective computing, multimedia, and computer vision.

![](images/1edf9e7b30342746ec3c8477e6c040f76804b7044eb26ae7b293bf0f56b22864.jpg)

Guiguang Ding received the Ph.D. degree from Xidian University, Xi’an, China, in 2004. In 2006, he was a Postdoctoral Research Fellow with the Department of Automation, Tsinghua University, Beijing, China. He is currently a Professor with the School of Software, Tsinghua University. He has published over 100 scientific papers in major journals and conferences. His current research interests include multimedia information retrieval, computer vision, and machine learning. Dr. Ding served as a Leading Guest Editor for Neural Processing Letters (NPL)

and Multimedia Tools and Applications (MTAP), the Special Session Chair for IEEE International Conference on Acoustics, Speech, and Signal Processing (ICASSP) 2021, IEEE International Conference on Multimedia and Expo (ICME) 2019 and 2020, and Pacific Rim Conference on Multimedia (PCM) 2017, and a reviewer for over 20 prestigious international journals and conferences.