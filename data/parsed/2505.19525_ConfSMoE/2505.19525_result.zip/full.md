# Rethinking Gating Mechanism in Sparse MoE: Handling Arbitrary Modality Inputs with Confidence-Guided Gate

Liangwei Nathan Zheng <sup>1</sup> Wei Emma Zhang <sup>1</sup> Mingyu Guo <sup>1</sup> Olaf Maennel <sup>1</sup> Weitong Chen <sup>1</sup>

## Abstract

Effectively managing missing modalities is a fundamental challenge in real-world multimodal learning scenarios, where data incompleteness often results from systematic collection errors or sensor failures. Sparse Mixture-of-Experts (SMoE) architecture has shown the potential to naturally handle multimodal data, with experts specializing in different modalities. However, existing SMoE approaches often lack proper ability to handle missing modality, leading to performance degradation and poor generalization in real-world applications. We propose ConfSMoE to introduce a two-stage imputation module to handle the missing modality problem for the SMoE architecture by taking the opinion of experts and revealing the insight of expert collapse from gradient analysis with strong empirical evidence. Inspired by our gradient analysis, ConfSMoE proposed a novel expert gating mechanism by detaching the softmax routing score to task confidence score w.r.t ground truth signal. This naturally relieves expert collapse without introducing additional load balance loss function. We show that the insights of expert collapse empirically align with other gating mechanism such as Gaussian and Laplacian gate. The proposed method is evaluated on four different real-world datasets with three distinct experiment settings to conduct comprehensive analysis of ConfSMoE on resistance to missing modality and the impacts of proposed gating mechanism. We have released our code in: https://github.com/IcurasLW/ Official-Repository-of-ConfSMoE. git

## 1. Introduction

As modern applications increasingly involve data from multiple heterogeneous sources, multimodal learning has emerged as a critical paradigm to unlock complementary insights and enhance decision-making in complex tasks spanning medical decision support (Zheng et al., 2024a;c; Zhai et al., 2025), cross-modal inference (Wu et al., 2017; Cheng et al., 2024), temporal reasoning (Zheng et al., 2024b; Ni et al., 2024; Tan et al., 2026b), and natural language understanding (Fedus et al., 2022; Masoudnia & Ebrahimpour, 2014; Tan et al., 2026a). Sparse Mixture-of-Experts (SMoE) architectures (Yao et al., 2024; Yun et al., 2024; Mustafa et al., 2022) are widely used in multimodal learning for their ability to assign different experts to different input patterns through conditional computation. They are particularly effective when all input modalities are present, enabling diverse feature extraction and flexible expert routing. However, this assumption is often violated in practice. Incomplete modality observations are common in real-world scenarios due to sensor failures, privacy restrictions, or heterogeneous data collection pipelines (Yun et al., 2024; Sun et al., 2024; Shang et al., 2017; Wang et al., 2023). In addition, the use of softmax-based routing (Fedus et al., 2022) in typical SMoE tends to produce sharp routing distributions, leading to expert collapse problem, where only a few experts dominate the computation as shown in Figure 1a, resulting in poor diversity and limited generalization.

When one or more modalities are missing, many imputation approaches aim to reconstruct absent views through crossmodal information sharing (Ma et al., 2021; Wang et al., 2023; Yao et al., 2024) as shown in Figure 1b and overlook modality-specific information. We hypothesize that relying solely on available-modality imputation can misdirect the routing mechanism, leading to worse expert collapse; specifically, because the imputed features are dominated by the signal of available modality, the router becomes biased. For instance, if a text modality is imputed from vision, the router is likely to assign that ’pseudo-text’ to a vision expert rather than a text-specific one, exacerbating expert collapse and degrading gating reliability. Therefore, current modality imputation methods degrade the reliability of the gating mechanism and result in suboptimal expert selection. Although existing SMoE approaches attempt bypass imputation by assigning different modality combinations to designated experts (Han et al., 2024), this strategy becomes computationally intractable as the number of modalities grows. Another recent work leveraged a learnable modality bank (Yun et al., 2024) to impute missing modality by the missing pattern, and enforce load balance by load balance loss. However, the imputation bank is randomly initialized, similar to prompt tuning (Jia et al., 2022; Lester et al., 2021), and fails to capture modality-specific and fine-grained instance-specific structure, limiting the reliability of modality imputation and potentially misdirecting the router. Furthermore, enforcing load balancing via auxiliary loss functions can lead to ambiguous expert selection, as illustrated in Figure 3a.

To overcome the limited robustness of existing SMoE models under incomplete modality conditions, we propose a twostage imputation approach based on a core insight: a complete modality imputation should consist of modality- and instance-specific information, a property often overlooked in prior work. Firstly, we estimate missing modalities using intra-modality correlations, empowering modality-specific information, and then refines these estimates through tokenlevel cross-modal alignment to existing modality of the same sample, empowering instance-specific information. This refinement leverages the advantages of MoE that the data used to refine missing modality are from different opinions of experts. This approach is inspired by the modality gap phenomenon discussed by (Liang et al., 2022) and illustrated in Figure 1c, which suggests that a certain level of discrepancy between modalities is both expected and beneficial for downstream tasks. Thus, it is natural to first impute missing modalities using intra-modality information subsequently enhance them through token-level cross-modal refinement to add up instance-specific features from available modality.

We further uncover and formalize a critical cause of expert collapse in SMoE: the gradient concentration induced by softmax gating, which suppresses routing diversity and limits generalization (Fedus et al., 2022; Wang et al., 2024a; Yun et al., 2024; Han et al., 2024; Chi et al., 2022). Through gradient analysis, we show that conventional load-balancing losses exacerbate this issue by introducing gradient conflicts during optimization, reflected by the ”Sinusoidal Wave” pattern in expert selection plot shown in Figure 3a. To resolve this, we design a confidence-guided expert routing mechanism that replaces softmax gating with token-level confidence scores. This formulation not only avoids the adverse effects of entropy-based balancing but also enables stable, interpretable expert selection. The two mechanisms handling missing modality and Confidence-guided gating consist of our final proposed method: ConfSMoE. By decoupling routing score from the optimization bottlenecks of prior designs, ConfSMoE achieves both enhanced expert diversity and consistent performance across a wide range of incomplete modality scenarios. Our contributions are the following:

• A confidence-guided expert routing mechanism is proposed to mitigate expert collapse by decoupling gating from softmax-induced sharpness. Token-level confidence is used as an interpretable signal for expert selection.

• A two-stage imputation framework is developed, where missing modalities are first reconstructed using modality-specific patterns, then refined with instancelevel cross-modal context to preserve structural fidelity.

• Empirical results across three missing-modality settings demonstrate strong robustness and generalization. Performance improvements are further supported by ablation studies that align with theoretical analysis.

## 2. Preliminaries

## 2.1. Mixture-of-Expert Architecture

In this work, we build upon the SMoE framework by incorporating expert routing into the Transformer’s feedforward layers, enabling dynamic token-to-expert assignment based on learned routing scores. This architecture supports selective expert activation, where only the Top-K experts are engaged per token, and proves especially effective in the joint expert setting (Han et al., 2024), allowing tokens from different modalities to be routed to shared experts for enhanced cross-modal interaction. We begin with the standard Softmax SMoEs with N number of expert as a baseline configuration. Denote that input token embedding h $\in \mathbb { R } ^ { d }$ and the a learnable softmax router $\begin{array} { r } { G ( \mathbf { u } ) = \frac { \exp ( u _ { i } ) } { \sum _ { i } ^ { d } \exp ( u _ { j } ) } = \mathbf { g } = [ g _ { 1 } , g _ { 2 } , \dotsc , g _ { N } ] } \end{array}$ , where $\textbf { u } = \textbf { W }$ h and $\mathbf { \bar { W } } _ { r } ~ \in ~ \mathbb { R } ^ { N \times d }$ is the weight of router to linearly map h to gating logits $\mathbf { u } \in \mathbb { R } ^ { \bar { N } } . \quad G ( \mathbf { u } )$ produces routing score $g _ { i }$ for each expert $E _ { i }$ from expert pool $\mathbf { E } = [ E _ { 1 } , E _ { 2 } , \ldots , E _ { N } ] \in \mathbb { R } ^ { d \times d }$ . We consider the Top-K operation as a binary mask $\mathbf { m } \in \{ 0 , 1 \} ^ { N }$ to select the Top-K experts in forward as shown in Eq. 1. The final tokens/samples representation is weighted summation from Top-K experts with corresponding routing score $g _ { i }$ . Formally, we can represent the forward process of SMoE as in Eq. 2:

$$
\eta = \operatorname{sort} (\mathbf {g}) _ {K}, \quad m _ {i} = \left\{ \begin{array}{l l} 1 & \text { if } g _ {i} \geq \eta \\ 0 & \text { otherwise } \end{array} \right.\tag{1}
$$

$$
f (\mathbf {h}) = \mathbf {h} + \sum_ {i = 1} ^ {N} m _ {i} g _ {i} E _ {i} (\mathbf {h})\tag{2}
$$

![](images/aa8b61a353a84a14421108e36679bbd923dfe64d8f1076abbc38732fbcb3dd2d.jpg)  
Figure 1. Expert Collapse of MoE and Comparison with Two Different Modality Imputation

## 2.2. What Causes Expert Collapse?

Top-K operation can be considered as constant during the calculation of gradient. Thus, the Jacobian matrix of Eq. 2 w.r.t h can be analyzed to reveal the underlying cause of expert collapse in SMoE. Therefore,

$$
\mathbf {J} _ {M o E} = \sum_ {i = 1} ^ {N} m _ {i} \frac {\partial g _ {i}}{\partial \mathbf {h}} E _ {i} (\mathbf {h}) + \sum_ {i = 1} ^ {N} m _ {i} g _ {i} E _ {i} ^ {\prime} (\mathbf {h})\tag{3}
$$

Note that expert $E _ { i } ( h )$ and softmax gating $G ( \mathbf { u } )$ themselves are differentiable w.r.t h and the mask $\mathbf { m } = \mathrm { T o p } \mathrm { - K } ( \mathbf { g } , K )$ is a piecewise-constant mask that only changes when the ordering of routing score g changes. Conditioning on a fixed mask m, Eq. 2 reduces to a linear combination of differentiable functions (e.g. $E _ { i } ( h )$ and $G ( \mathbf { u } ) )$ , where the gradient will only propagate through the terms with $m _ { i } ~ = ~ 1$ , enabling parameter update for those activated experts. Consequently, during training, only the selected experts are differentiable. Therefore, we can denote the Jacobian of softmax as $\mathbf { J } _ { s o f t m a x } \in \mathbb { R } ^ { \dot { N } \times N }$ , where each entry $\mathbf { J } _ { s o f t m a x } ^ { i , j } = g _ { i } ( \delta _ { i j } - g _ { j } )$ and $\delta _ { i j }$ is Kronecker delta. In matrix form, Jacobian of softmax is $\mathbf { J } _ { s o f t m a x } = \mathbf { d i a g } ( \mathbf { g } ) - \mathbf { g } \mathbf { g } ^ { \top }$ and the Top-K $\mathbf { J } _ { s o f t m a x } = \mathbf { m } ( \mathbf { d i a g } ( \mathbf { g } ) - \mathbf { g } \mathbf { g } ^ { \top } )$ . Therefore, we can rewrite Eq. 3 to Eq. 4: In first term, only those experts with higher gating score will be chosen and the gradient is backward in $\mathbf { d i a g } ( \mathbf { g } ) \mathbf { \Sigma } - \mathbf { g } \mathbf { g } ^ { \top }$ to learn better routing score. In the second term, the gradient is backward to those selected experts $E _ { i }$ to learn better representation. During training, experts that receive more updates tend to be selected more frequently, as their improved representations attract higher gating scores. This creates a feedback loop which those experts with more expressive power will lead to higher gating score and thus more updates on weight for strong expressive power, resulting expert collapse based on token preference and produce rich-get-richer expert.

![](images/5dbbb126b991f45b8ece9ad2ac530ae821a2829a881e7e7bbbd1f3cbd9a587c4.jpg)

(4)

## 2.3. Gradient of Load Balance Loss

This expert collapse phenomenon restricts the model learning capacity since many other experts are wasted and can not reflect the actual expert diversity. One widely-used solutions to achieve balance expert usage is to introduce additional load balance loss (Yun et al., 2024; Han et al., 2024). However, such load balance loss approach is difficult to optimize since it produces gradient direction opposite to routing score term in Eq 4. To show this, we consider that any load balance loss $\mathcal { L } _ { l o a d }$ will eventually result a diverse softmax routing distribution, which encourages higher entropy on the routing score distribution. From Assumption C.1 defined in Appendix, we define that the objective of any $\mathcal { L } _ { l o a d } \mathrm { a s } \frac { 1 } { \mathcal { H } ( \mathbf { g } ) }$ over the softmax distribution, where $\begin{array} { r } { \mathcal { H } ( \mathbf { g } ) = - \sum _ { i } ^ { N } g _ { i } l o g } \end{array}$ g<sub>i</sub> represent the entropy of softmax distribution g. Taking the Jacobian over the $\mathcal { L } _ { l o a d }$ will give us (See detailed in Appendix. C.2):

$$
\mathbf {J} _ {\text { load }} = \left[ \frac {1}{\mathcal {H} (\mathbf {g}) ^ {2}} (l o g (\mathbf {g}) + 1) ^ {\top} \right] \cdot \left(\mathbf {d i a g} (\mathbf {g}) - \mathbf {g g} ^ {\top}\right)\tag{5}
$$

Recall that ${ \bf E } _ { K } ( { \bf h } )$ in Eq.4 is a set of expert with ReLU activation, we assume this network should not output negative value as the activation is located on positive side. We also know the fact that the Jacobian of softmax $\mathbf { J } _ { s o f t m a x }$ is symmetry and always Positive Semi-Definite (PSD) (Gao & Pavel, 2017), making the optimization direction of better routing score is always positive as the eigen-values are positive. In contrast, when sharp distribution appears, only one $g _ { j }$ is closed to 1 while other $g _ { i } , ( i \neq j )$ , approach to 0 in $\lfloor { \dot { o } } g ( \mathbf { g } ) + 1 = [ l o g ( g _ { 1 } ) + 1 , l o g ( g _ { 2 } ) + 1 , \dots , l o g ( g _ { N } ) + 1 ]$

Therefore, $\begin{array} { r } { \frac { 1 } { \mathcal { H } ( \mathbf { g } ) ^ { 2 } } ( l o g ( \mathbf { g } ) + 1 ) ^ { \top } } \end{array}$ is exponentially dominated by negative value, producing conflict gradient between $\mathbf { J } _ { l o a d }$ and the first term of $\mathbf { J } _ { M o E } .$ . Although recent works argue that Sparse MoE is not fully differentiable (Puigcerver et al., 2023; Wang et al., 2024b) since the experts are not fully activated, the Top-K operation does not change PSD property of the first term in Eq.4. In practice, we also do not observe any optimization problem caused by this discontinuity and this observation aligns with previous research (Fedus et al., 2022). Gradient will still be backward through the term where the activation mask is $m _ { i } = 1$ in $J _ { M o E }$ . In addition, we notice that first term gradient of Eq. 4 is only impacted by the Top-K $g _ { i }$ while the gradient in Eq. 5 is dominated by the Top-K $g _ { i }$ . The sharper the gating score distribution is, the more gradient conflict will be. It is also worthy to notice that gradient in $\operatorname { E q } . 5$ conflict occurs for any Top-K selection as the load balance loss consider all $g _ { i }$ regardless of number K expert selection. Taking an extreme example, Top-1 selection (Fedus et al., 2022) generates one $g _ { i }$ out of g for the second term of Eq.4 while Eq.5 still take all $g _ { i }$ to gradient computation in practice. Therefore, the opposite gradientfrom auxiliary load balance loss makes the training difficult to converge to global minimum and Expert selection becomes ambiguous, failing to reflect actual capacity of expert.

## 3. Proposed Method

## 3.1. ConfNet:Confidence-Guided Gating Network

From Eq. 5 and Eq. 4, we understand that load balance loss produces an opposite gradient to softmax router in typical SMoE. To avoid this gradient conflict and balance the load, the potential solution is to remove the association of sharp distribution from Eq. 4 and attempt to implicitly achieve load balance. One is to replace the routing function as illustrated in Figure. 2 (c) and one is to decouple the gating score with softmax router as illustrated in Figure. 2 (d). A typical example from a recent work, FuseMoE (Han et al., 2024), they replace the Softmax router to Laplacian router and calculate the routing score based on similarity of the expert embedding by $\mathcal { L } _ { 1 }$ distance. Then, the Top-K experts are selected with highest similarity to expert embedding and Laplacian router is not a sharp distribution so that the load shows implicit balance pattern as in Appendix Figure 8. The second approach is to decouple the connection of gating score and softmax distribution. One simple approach is to consider all expert equally important, then the final representation is averaged from all selected expert. However, this averaged approach does not emphasize the difference of expert and lose the specification of expert.

Therefore, we propose a Confidence-Guided Gating Network Pool (ConfNet), which introduces a novel routing strategy guided by task confidence. Specifically, instead of solely relying on conventional softmax-based gating, which often results in sharp distributions and entangled gradient contributions, ConfNet leverages the ground-truth label information to supervise the routing mechanism, encouraging expert selection aligned with task-relevant confidence rather than token or embedding similarity as in (Han et al., 2024; Fedus et al., 2022). For each expert $E _ { i } : \mathbb { R } ^ { d }  \mathbb { R } ^ { d }$ , we introduce an auxiliary confidence estimation network: a one-layer linear network $U _ { i } : \mathbb { R } ^ { d }  \mathbb { R } ^ { 1 }$ that maps token embedding h $\in \mathbb { R } ^ { d }$ to a single scalar logits $v _ { i } \in \mathbb { R } ^ { 1 }$ . v<sub>i</sub> is then mapped to a confidence score $c _ { i } \in ( 0 , 1 )$ as gating score by Sigmoid, representing the confidence of ground truth label $y _ { t }$ . To learn the ground true confidence $p _ { t }$ of downstream task w.r.t $y _ { t }$ , where $y _ { t }$ is ground truth label. We apply MSE loss as an auxiliary loss that minimize the difference between $c _ { i }$ and $p _ { t }$ . Formally, given any classification dataset $D$ with supervised signal $y _ { i }$ and number of instance $| D |$ , we consider the task loss $\mathcal { L } _ { t a s k }$ as Cross Entropy Loss and the final objective is to optimize:

$$
\mathcal {L} = \underbrace {\frac {1}{| D |} \sum_ {} ^ {| D |} y _ {t} l o g (p _ {t})} _ {\mathcal {L} _ {t a s k}} + \underbrace {\frac {1}{| D | K} \sum_ {} ^ {| D |} \sum_ {i = 1} ^ {N} m _ {i} (c _ {i} - p _ {t}) ^ {2}} _ {\mathcal {L} _ {c o n f}}\tag{6}
$$

Note that while the global optimization landscape of the deep neural network remains non-convex, the selected loss components (Cross-Entropy and MSE) are smooth and convex with respect to the network outputs. This ensures that the auxiliary confidence loss provides a stable, well-behaved gradient signal during backpropagation. During both training and inference, $c _ { i }$ serves as a proxy gating score for each expert to token fusion in Eq. 3. The $c _ { i }$ is Token-level confidence, which each token has one corresponding $c _ { i }$ for aggregation as in $\begin{array} { r } { \sum _ { i = 1 } ^ { N } m _ { i } g _ { i } E _ { i } ( \mathbf { h } ) } \end{array}$ as in Eq. 2, resulting in a variant of proposed method for fine-grained feature learning, denoted as ConfSMoE-T. Additionally, an expertlevel gating signal is also implemented for coarse-grained information retrieval. We aggregate token-level representations assigned to each expert and average them to compute expert-level gating signals as expert-level variant, denoted as ConfSMoE-E in experiment. The multimodal interaction is learned during the token assignment for all experts, which all modalities are shared one identical expert pool. This confidence-driven routing enables both fine-grained specialization and robust multimodal interaction, leading to improved generalization and interpretability.

## 3.2. Missing Modality Modeling: Two-Stage Imputation

Inspired by the modality gap phenomenon observed in contrastive learning (Liang et al., 2022), we hypothesize that a similar gap exists in our multimodal setting, and it may contribute positively to model performance, as illustrated in Appendix Figure 4. The presence of this modality gap suggests that imputing a missing modality using only shared information from the available modalities is inherently challenging, due to the distinct representational spaces each modality occupies. Ideally, the imputed modality should preserve the characteristics of its original distribution without being significantly biased by other modalities. To address this, we propose a Two-stage Imputation strategy to first reconstruct the representative feature from the missing modality distribution itself, and further refine the pre-imputed modality by adding instance-specific features from the available modalities.

![](images/d56d0e8be1fef43f751fdd5514a655a9d16eca954233a0b82cd66740f020dc80.jpg)  
Figure 2. The Framework of ConfSMoE: (a) ConfSMoE considers the confidence learned from ConfNet pool as the alternative gating score for expert aggregation. The ConfNet pool is a set of one-layer linear weight $\mathbb { R } ^ { d } \to \mathbb { R } ^ { 1 }$ . Missing modality imputation is achieved by taking the mean of random instances from the corresponding modality of training data as modality specific feature. The instance-specific feature are sparsely aggregated from existing modality. (b) Sharp gating score causes expert collapse. (c)(d) ”Fair” gating score distribution and decoupling gating score can alleviate the expert collapse without the helps of load balance loss.

Pre-Imputation: To retrieve modality-specific feature, given a sample $x _ { i }$ with missing modality $M _ { m } \in \mathbb { R } ^ { s \times d }$ and arbitrary available modality $M _ { a } \in \mathbb { R } ^ { s \times d }$ , where s is the sequence length. Pre-imputation aims to obtain the modality-specific feature from other instances of $M _ { m }$ distribution. One typical way is to take the mean feature distribution of $M _ { m }$ , but simply taking the mean may be overfitting to training set and all representation across different modality samples will be deterministic and uninformative. In contrast to mean representation, we wish to introduce some stochasticity during the pre-imputation as this stochasticity may prevent the representation from collapsing to the same representation. Specifically, we generate an preimputed modality embedding $\bar { M } _ { m }$ by sampling n number of instances out of b number of instances in modality pool $M _ { m , i } = [ M _ { m , 1 } , M _ { m , 2 } , \cdot \cdot \cdot , M _ { m , b } ]$ as follows:

$$
\bar {M} _ {m} = \frac {1}{n} \sum_ {i = 1} ^ {n} {\bf 1} M _ {m, i}\tag{7}
$$

Where $\mathbf { 1 } \ \in \ \{ 0 , 1 \} ^ { b }$ is the selection vector for $M _ { m }$ and $\mathbf { 1 } _ { i } = 1$ represents the i-th instance from the modality pool that is selected. $\bar { M } _ { m }$ will be sent to ConfSMoE to learn the interaction between different modalities. We denoted $M _ { m } ^ { * }$ as the pre-imputed modality representation after ConfSMoE and ${ \cal M } _ { a } ^ { k }$ as the available modality representation returned from k-th expert.

Post-Imputation: To refine $M _ { m } ^ { * }$ by available modality, we proposed a post-modality imputation to further capture the interactions between available and missing modality. Unlike conventional approaches that solely rely on the shared representation from an individual network, our method leverages information from various experts by selectively incorporating tokens. This allows the model to absorb nuanced, instance-specific features and interaction between modalities from different views of expert to available modality. We employ a sparse attention mechanism, under the assumption that only a subset of modality-specific information is meaningfully shared across $M _ { a } ^ { \dot { k } }$ . By enforcing sparsity, the model is encouraged to attend to the most relevant parts of the available modalities, thereby reducing the risk of injecting modality-irrelevant or noisy information into the imputed representation. Recall from Eq. 2, Top-K MoE generate K specialized representation from available modality $M _ { a } ^ { k } \in \mathbb { R } ^ { s \times d } , k = 0 , 1 , . . . K$ . Then, we concatenate all the ${ \cal M } _ { a } ^ { k }$ returned from K expert to form a representation of the opinion of different experts, denoted as $M _ { a } ^ { * } \in \mathbb { R } ^ { ( s \times K ) \times d }$ We apply a sparse cross-attention over $M _ { m } ^ { * }$ and $M _ { a } ^ { * }$ to select the most relevant tokens to refine $M _ { m } ^ { * } \in \mathbb { R } ^ { s \times d }$ The SparseCrossAttention takes $M _ { m } ^ { * }$ as Query modality ${ \bf Q } _ { m } = { \bf W } _ { q } M _ { m } ^ { * } , M _ { a } ^ { * }$ as Key modality ${ \bf K } _ { a } = { \bf W } _ { k } M _ { a } ^ { * }$ and Value modality ${ \bf V } _ { a } = { \bf W } _ { v } M _ { a } ^ { * }$ where $\mathbf { Q } _ { m } \in \mathbb { R } ^ { s \times d }$ and ${ \bf K } _ { a } , { \bf V } _ { a } \in \mathbb { R } ^ { ( s \times K ) \times d }$ . Note that $\mathbf { W } _ { q } , \mathbf { W } _ { k } , \mathbf { W } _ { v }$ are shared between all modalities. The crossattention scores $\mathbf { A } _ { a _ { } } ^ { } \in \mathbb { R } ^ { s \times ( s \times K ) }$ are first computed via the dot product of $\mathbf { Q } _ { m }$ and ${ \bf K } _ { a }$ . To induce sparsity, we apply a row-wise binary mask $\mathbf { t } \in \{ 0 , 1 \} ^ { s \times ( s \mathbf { \tilde { \cal K } } ) }$ , where an element $t _ { i , j }$ is set to 1 if the corresponding score $A _ { a , i , j }$ ranks within the Top-T values of the i-th row ${ \bf A } _ { a , i , \cdot } ,$ , and 0 otherwise. The selection threshold is defined as $\begin{array} { r } { \dot { T } = \frac { s ( | M | - 1 ) } { B } } \end{array}$ where |M| represents the number of modalities in the dataset and B is a sparsity hyperparameter, set to 4 by default. Finally, the sparse attention map $\mathbf { A } _ { a } ^ { * }$ is derived through the Hadamard product of the raw scores and the binary mask as in eq.9

$$
\gamma = \operatorname{sort} (\mathbf {A} _ {\mathbf {a}, \mathbf {i}, \cdot}) _ {T}, \quad t _ {i, j} = \left\{ \begin{array}{l l} 1 & \text { if } A _ {a, i, j} \geq \gamma \\ 0 & \text { otherwise } \end{array} \right.\tag{8}
$$

$$
\mathbf {A} _ {a} ^ {*} = \mathbf {t} \odot s o f t m a x (\frac {\mathbf {Q _ {m}} \mathbf {K _ {a}} ^ {\top}}{\sqrt {d}}) \in \mathbb {R} ^ {s \times (s \times K)}\tag{9}
$$

Thus, we aggregate the value matrix ${ \bf V } _ { a }$ using the sparse attention weights $\mathbf { A } ^ { * }$ to obtain the output of SparseCrossAttention (SCA). When multiple available modality $M _ { a } ^ { * }$ are presented in the dataset, we compute their contributions individually and sum them to refine $M _ { m } ^ { * }$

$$
\begin{array}{c} M _ {m} ^ {*} = \text {LayerNorm} \left(M _ {m} ^ {*} + \sum^ {| a |} S C A (M _ {m} ^ {*}, M _ {a} ^ {*}, M _ {a} ^ {*})\right) \\ = \text {LayerNorm} \left(M _ {m} ^ {*} + \sum^ {| a |} \mathbf {A} _ {a} ^ {*} \mathbf {V} _ {a}\right) \end{array}
$$

In addition, we expect this refinement to redistribute the representation of $M _ { m } ^ { * }$ instead of generating large-scale representation and lead to divergent training. A LayerNorm layer is applied to scale the feature map back to a consistent distribution as in other layers. With SCA, the post-imputation serves as a refinement module to add an instance-specific feature to $M _ { m } ^ { * }$ , so that each modality can contribute differently on different subsegment representations of $M _ { m } ^ { * }$ We visualize the attention weights after imputation in the Appendix Figures 14, 15, and 16, showing that the query modality can dynamically adjust the significance of information by leveraging both expert specialization and shared cross-modal cues, given that attention maps reveal distinct weight distributions across different modalities and experts.

## 4. Experiment

## 4.1. Experiment Setting

To ensure a fair comparison with baseline methods, we adopt the best-performing hyperparameter settings reported in their respective papers and official implementations. Additionally, we standardize the hidden dimension to 128 across all models. To eliminate confounding effects introduced by varying encoder architectures, we use the same modalityspecific encoders for all models, as differences in encoder design can significantly influence final performance. For the MIMIC-III and MIMIC-IV datasets, we employ a pretrained ClinicalBERT (Alsentzer et al., 2019) for textual data, a one-layer patch embedding module for both irregular time series and ECG signals, and a pretrained DenseNet (Cohen et al., 2022) from TorchXRayVision for chest X-ray (CXR) images. Experiment Setting I: Natural Missing Modality. This setting reflects real-world missingness patterns observed in clinical datasets. Experiment Setting II: Random Modality Dropout. A fixed percentage of modalities are randomly dropped for each instance, while ensuring that each instance retains at least one modality in both train and test set. Experiment Setting III: Asymmetric Modality Dropout. Half of the modalities are randomly dropped during training, while testing is performed with only one or two modalities present per instance, simulating domain shifts or deployment constraints. All experiments are 3-Fold cross-validate in different seeds and on the same computing device for fair comparison.

## 4.2. Primary Results

Experiment Setting I: In Table 1 and Appendix Table $^ { 6 , }$ we provide the experiments results on experiment setting I for three different ICU benchmarking tasks, where the modalities are natural missing instead of random. We obtain the following observations from the results: (1) In clinical benchmarking tasks 48-IHM, LOS, and 25-PHE, our proposed methods can significantly outperform the most recent baseline approaches such as FuseMoE and FlexMoE and other tradidtional multimodal learning methods in terms of F1 and AUC score. For MIMIC-III, the improvement on F1 and AUC is ranging from 1.81% to 3.91% and 0.92% to 1.22% respectively. (2) The improvement is even further when the size of dataset scale to bigger dataset but the same domain like MIMIC-IV. The improvement on F1 and AUC is ranging from 1.37% to 4.12% and 1.96% to 4.85%. The above empirical evidence roots and supports our claims that the model is strongly robust to missing modality and learn more comprehensive understanding on multimodal inputs.

Rethinking Gating Mechanism in Sparse MoE: Handling Arbitrary Modality Inputs with Confidence-Guided Gate  
Table 1. Experiment setting I: Main results on MIMIC-IV

<table><tr><td>Task</td><td>Metric</td><td>SMIL</td><td>ShaSpec</td><td>mmFormer</td><td>TF</td><td>LIMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-T</td><td>ConfSMoE-E</td></tr><tr><td rowspan="2">48-IHM</td><td>F1</td><td>39.58 ± 1.12</td><td>32.97 ± 1.08</td><td>45.39 ± 1.60</td><td>11.60 ± 0.54</td><td>43.76 ± 0.44</td><td>30.14 ± 1.15</td><td>40.21 ± 1.29</td><td>35.29 ± 0.30</td><td>49.18 ± 0.22</td><td>48.32 ± 0.30</td></tr><tr><td>AUC</td><td>76.60 ± 0.98</td><td>78.29 ± 0.25</td><td>80.43 ± 0.76</td><td>67.08 ± 0.77</td><td>82.97 ± 0.61</td><td>71.34 ± 0.88</td><td>78.05 ± 0.72</td><td>80.45 ± 0.44</td><td>85.24 ± 0.10</td><td>85.09 ± 0.17</td></tr><tr><td rowspan="2">LOS</td><td>F1</td><td>58.52 ± 0.44</td><td>56.22 ± 0.28</td><td>57.06 ± 0.32</td><td>42.01 ± 1.12</td><td>59.03 ± 0.39</td><td>57.59 ± 0.76</td><td>58.31 ± 0.46</td><td>56.96 ± 0.53</td><td>61.33 ± 0.39</td><td>61.35 ± 0.41</td></tr><tr><td>AUC</td><td>75.86 ± 0.66</td><td>72.22 ± 0.18</td><td>74.65 ± 0.32</td><td>64.11 ± 0.40</td><td>76.17 ± 0.17</td><td>72.59 ± 1.07</td><td>72.59 ± 0.61</td><td>74.81 ± 0.37</td><td>78.22 ± 0.15</td><td>77.85 ± 0.12</td></tr><tr><td rowspan="2">25-PHE</td><td>F1</td><td>27.77 ± 0.91</td><td>25.53 ± 0.11</td><td>26.15 ± 0.12</td><td>26.52 ± 0.29</td><td>25.38 ± 0.52</td><td>12.45 ± 0.54</td><td>12.25 ± 0.55</td><td>24.61 ± 0.71</td><td>28.67 ± 0.33</td><td>28.54 ± 0.25</td></tr><tr><td>AUC</td><td>63.90 ± 1.31</td><td>62.57 ± 0.23</td><td>70.33 ± 0.12</td><td>56.28 ± 0.16</td><td>72.50 ± 0.67</td><td>55.48 ± 0.39</td><td>58.52 ± 0.27</td><td>71.57 ± 0.47</td><td>74.56 ± 0.19</td><td>74.42 ± 0.34</td></tr></table>

Experiment Setting II: In Appendix Table 7 and Table 8, we implement Random Modality Dropout to study the sensitivity of model to missing modality. In this setting, we empirically find that those methods with missing modality imputation usually shows higher tenacity in high proportion of missingness such as FlexMoE and our propose method. Although ShaSpec has also imputed the missing modality by shared information, but it is weak on the backbone model and struggles to optimize with multi-task objectives. Our proposed method, on the other hand, shows superior performance across all settings in CMU-MOSEI and CMU-MOSI for all metrics.

biguous and difficulty on convergence. We also found that considering the uniform weight for all experts can achieve similar performance as sole softmax and generate similar sinusoidal pattern as softmax w/ $\mathcal { L } _ { l o a d } ,$ shown in Figure 9.

Experiment Setting III: In Appendix Table 9, Table 10, Table 11 and Table 12, we study which modality combination is significant and how is the tenacity of our proposed method to different distribution shift on missing modality. We find that single modality shows very similar performance during inference phrase in our proposed method and Flex-MoE across AUC and F1, indicating the effectiveness of missing modality imputation. In particular, our proposed also shows the highest resistance to missing modality across different combinations and remains competitive performance no matter what modality is missing. In addition, the modality combination Audio-Video is the worst modality combination for all implemented models. The potential reason may be that the data interaction between those two modalities are weak or even opposite. We show some visualization evidence in Figure 4 that the embedding of those two modalities are mostly symmetry.

In addition, Laplacian (Han et al., 2024) and Gaussian gating (Han et al., 2024; Xu et al., 1994) function can achieve comparable to softmax w/ $\mathcal { L } _ { l o a d }$ gating mechanism without helps of $\mathcal { L } _ { l o a d } .$ , providing further evidence to support the advantage of balanced expert selection. Our proposed ConfNet without helps of $\mathcal { L } _ { l o a d }$ is the best and significantly outperforms other gating function in CMU-MOSI and MIMIC-III. As illustrated in Figure 6 and supported by the quantitative results in Table 2, ConfNet not only preserves expert specialization but also achieves better load balancing than Laplacian, albeit slightly less balanced than softmax with $\mathcal { L } _ { \mathrm { l o a d } }$ and Gaussian gating as shown in Appendix H. This comparison provides two insights: First, optimization of $\mathcal { L } _ { l o a d }$ is simply against to optimization of softmax gating score but does not help to identify the best expert, reflecting the ”Sharp Sinusoidal $ { \mathrm { W a v e } } ^ { \prime }$ pattern in expert selection and ambiguous expert selection. Second, learning specialization of expert can also benefit to downstream performance. Notably, both ConfNet and Laplacian gates demonstrate a common pattern: they maintain the specialization ofdominant experts while redistributing some load to less active ones, which highlights that strict load balancing may suppress expert specialization and degrade performance, whereas maintaining a balance between specialization and load distribution leads to superior results. We provide further explanation in Appendix H for supporting our claims.

## 4.3. Why Does Confidence-Guided Gating Improve Performance?

We implemented experiment on switching different gating mechanisms in our propose method as shown in Table 2 and plot the expert selection heatmap in Appendix H. Figure 5 illustrates the softmax gating mechanism without load balance regularization, which exhibits severe expert collapse where only a few experts are consistently selected throughout training. Although load balance loss is adapted to distribute the load, it is hard to learn proper routing scores since the optimization is opposite as stated in Section 2, leading to suboptimal solution in this ablation. Softmax w/ $\mathcal { L } _ { l o a d }$ variant shows ”Sharp Sinusoidal Wave” expert selection pattern as shown in Figure 3a, indicating the selection is am-

## 4.4. How ConfNet and Modality Imputation integrate together?

We implement the experiment in Table 14 by removing ConfNet and the two-stage imputation module gradually. This experiment demonstrates that both novel modules, ConfNet and the two-stage imputation, are effective on their own, while their integration provides strong robustness against the missing modality challenge. Specifically, ConfNet captures informative features from the imputed modality, and the adaptive two-stage imputation operation reconstructs high-quality features, thereby complementing each other to achieve robust performance. Specifically, we dropped the entire imputation module and kept the missing modality as zeros (w/o impute), we can see that F1 and AUC dropped off by 3.85 and 0.74 on MIMIC-III, 1.88 and 1.97 on CMU-MOSI. This performance drop is even worse when imputation and ConfNet gating mechanism is removed from proposed method, providing strong empirical evidence for effectiveness of our design. We further remove the postimputation (w/o post-impute) and observe that ConfNet can still take advantage of modality-specific feature for their downstream task, showing robustness against missing modality.

![](images/9eacebdd3d093d147dacb5bfca26ce3f818e4438a8d4b4d1899b375e157a8458.jpg)  
(a) Expert selection of softmax w/ $\mathcal { L } _ { l o a d }$

![](images/08594c2977b99b74fb7616ef89aa3cce3c9c461415f8be79c3797651c13d67fd.jpg)  
(b) Expert selection of ConfNet  
Figure 3. Expert selection: X-axis represents epoch and Y-axis represents expert ID. The darker the color, the more selection will be for a particular expert. See detailed and more plots in Appendix H

Table 2. Ablation I: Different router. CMU-MOSI adopt 50% missing setting in Experiment III

<table><tr><td>Task</td><td>Metric</td><td>Mean</td><td>Softmax</td><td>Softmax w/  $\mathcal{L}_{load}$ </td><td>LFB</td><td>Gaussian</td><td>Laplacian</td><td>ConfNet</td></tr><tr><td rowspan="2">MIMIC-III</td><td>F1</td><td>48.34 ± 0.22</td><td>48.59 ± 1.97</td><td> $\underline{51.67 \pm 0.62}$ </td><td>48.36 ± 0.88</td><td>46.50 ± 1.62</td><td>50.10 ± 1.17</td><td>53.44 ± 0.27</td></tr><tr><td>AUC</td><td>85.13 ± 0.16</td><td>85.91 ± 0.84</td><td> $\underline{85.97 \pm 0.52}$ </td><td>85.05 ± 0.67</td><td> $\underline{86.70 \pm 0.33}$ </td><td>85.47 ± 1.05</td><td>87.05 ± 0.58</td></tr><tr><td rowspan="2">CMU-MOSI</td><td>F1</td><td>42.29 ± 0.87</td><td>41.47 ± 0.94</td><td>42.43 ± 1.34</td><td>43.86 ± 0.56</td><td>42.57 ± 1.81</td><td>43.15 ± 1.53</td><td>44.34 ± 0.77</td></tr><tr><td>AUC</td><td>68.01 ± 1.68</td><td> $\underline{68.77 \pm 1.66}$ </td><td>67.40 ± 0.54</td><td>66.60 ± 2.24</td><td>67.74 ± 0.45</td><td>67.60 ± 1.54</td><td>70.41 ± 1.31</td></tr></table>

## 4.5. Complexity Analysis

## 5. Related Works

In Table 13, we control the number of parameters in three different scales to compare performance. We aims to find the best model given similar parameter and computational costs. Although ShaSpec and TF achieve lower FLOPs given the same parameter amount, their performance remains less competitive than most Transformer- and MoE-based models. Among MoE-based models, ConfSMoE-T delivers the best performance while maintaining similar MFLOPs and parameter counts to the second-best baseline. Under comparable parameter settings, LIMoE and mmFormer fail to keep FLOPs as low as ConfSMoE-T and yield suboptimal results. Moreover, LIMoE is particularly inefficient, as its MFLOPs are substantially higher than those of other models with similar parameter sizes. By increasing the number of parameter to a larger scale, we can observed different amount of increment across the selected models while none of the baselines can achieve the same performance as ConfSMoE-T. Many baselines are still less competitive to small-scale ConfSMoE-T, demonstrating the scalability of ConfSMoE.

While many works consider that the interaction between multimodal data can bring a comprehensive understanding for downstream task. Initial multimodal fusion approach usually incorporates neural kernel fusion(Bucak et al., 2013; Poria et al., 2015), early/late network fusion (Xu et al., 2023; Baltrusaitis et al.ˇ , 2018; Guo et al., 2019). Approaches such as Tensor Fusion Network(Zadeh et al., 2017), Multimodal Transformer(Tsai et al., 2019) and Multimodal Adaption Gate(Rahman et al., 2020), LlMoE(Mustafa et al., 2022) all highlights the multimodal interactions are beneficial to downstream tasks. In medical domain, MedFuse (Hayat et al., 2022) incorporated CXR and EHR modality to jointly fuse modality with early and later fusion in a single fusion network. MISTS (Zhang et al., 2023) incorporated multi time attention mechanism to encode irregular time serires and adapts multimodal cross attention to fuse two different modality. (Yang & Wu, 2021) fused multimodal data in a attention gate and compute a replacement vector for modality fusion. However, these approaches are limited to full modality only and difficult to extend to increasing number of modality. Missing modality is realistic and practical problem in real life application such as medical diagnosis. SMIL (Ma et al., 2021) proposed a Bayesian meta-learning solution with reconstruction network to impute the missing modality from in hidden state during fusion. (Du et al., 2018; Shang et al., 2017) propose generative adversarial networks to impute the missing modality by semi-supervised learning. ShaSpec (Wang et al., 2023) and DrFuse (Yao et al., 2024) designed multiple loss functions to learn share and specific representation of different modality. However, the reconstruction network from SMIL and ShaSpec requires multiple additional auxiliary loss functions, which occupies the great amount of gradient in optimization process instead of task specific loss. (Sun et al., 2024) In addition, recent studies like FuseMoE (Han et al., 2024) respect the missingness of modalities and wish to assign each combination of multimodal data to different experts. Flex-MoE(Yun et al., 2024) further expand the advantages of FuseMoE and introduce a modality bank to impute the missing modality.

## 6. Conclusion

In this work, a novel ConfSMoE model, a confidence-guided sparse mixture-of-experts framework, is proposed to robustly handle multimodal learning with missing modalities. We proposed two key innovations: a two-stage imputation strategy that preserves modality-specific structure, and a novel confidence-driven gating mechanism that decouples expert selection from softmax-induced sharpness. These components jointly improve both expert specialization and routing stability without requiring entropy-based balancing losses.

## References

Alsentzer, E., Murphy, J. R., Boag, W., Weng, W.-H., Jin, D., Naumann, T., and McDermott, M. Publicly available clinical bert embeddings. arXiv preprint arXiv:1904.03323, 2019.

Bagher Zadeh, A., Liang, P. P., Poria, S., Cambria, E., and Morency, L.-P. Multimodal language analysis in the wild: CMU-MOSEI dataset and interpretable dynamic fusion graph. In Gurevych, I. and Miyao, Y. (eds.), Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers), pp. 2236–2246, Melbourne, Australia, July 2018. Association for Computational Linguistics. doi: 10.18653/v1/ P18-1208. URL https://aclanthology.org/ P18-1208/.

Baltrusaitis, T., Ahuja, C., and Morency, L.-P. Multimodalˇ machine learning: A survey and taxonomy. IEEE transactions on pattern analysis and machine intelligence, 41 (2):423–443, 2018.

Bucak, S. S., Jin, R., and Jain, A. K. Multiple kernel learning for visual object recognition: A review. IEEE Transactions on Pattern Analysis and Machine Intelligence, 36 (7):1354–1369, 2013.

Cheng, Y., Li, Y., He, J., and Feng, R. Mixtures of experts for audio-visual learning. Advances in Neural Information Processing Systems, 37:219–243, 2024.

Chi, Z., Dong, L., Huang, S., Dai, D., Ma, S., Patra, B., Singhal, S., Bajaj, P., Song, X., Mao, X.-L., et al. On the representation collapse of sparse mixture of experts. Advances in Neural Information Processing Systems, 35: 34600–34613, 2022.

Cohen, J. P., Viviano, J. D., Bertin, P., Morrison, P., Torabian, P., Guarrera, M., Lungren, M. P., Chaudhari, A., Brooks, R., Hashir, M., et al. Torchxrayvision: A library of chest x-ray datasets and models. In International Conference on Medical Imaging with Deep Learning, pp. 231–249. PMLR, 2022.

Du, C., Du, C., Wang, H., Li, J., Zheng, W.-L., Lu, B.-L., and He, H. Semi-supervised deep generative modelling of incomplete multi-modality emotional data. In Proceedings of the 26th ACM international conference on Multimedia, pp. 108–116, 2018.

Fedus, W., Zoph, B., and Shazeer, N. Switch transformers: Scaling to trillion parameter models with simple and efficient sparsity. Journal of Machine Learning Research, 23(120):1–39, 2022.

Gao, B. and Pavel, L. On the properties of the softmax function with application in game theory and reinforcement learning. arXiv preprint arXiv:1704.00805, 2017.

Guo, W., Wang, J., and Wang, S. Deep multimodal representation learning: A survey. Ieee Access, 7:63373–63394, 2019.

Han, X., Nguyen, H., Harris, C., Ho, N., and Saria, S. Fusemoe: Mixture-of-experts transformers for fleximodal fusion. arXiv preprint arXiv:2402.03226, 2024.

Harutyunyan, H., Khachatrian, H., Kale, D. C., Ver Steeg, G., and Galstyan, A. Multitask learning and benchmarking with clinical time series data. Scientific data, 6(1):96, 2019.

Hayat, N., Geras, K. J., and Shamout, F. E. Medfuse: Multimodal fusion with clinical time-series data and chest x-ray images. In Machine Learning for Healthcare Conference, pp. 479–503. PMLR, 2022.

Jia, M., Tang, L., Chen, B.-C., Cardie, C., Belongie, S., Hariharan, B., and Lim, S.-N. Visual prompt tuning. In European conference on computer vision, pp. 709–727. Springer, 2022.

Johnson, A. E., Pollard, T. J., Shen, L., Lehman, L.-w. H., Feng, M., Ghassemi, M., Moody, B., Szolovits, P., Anthony Celi, L., and Mark, R. G. Mimic-iii, a freely accessible critical care database. Scientific data, 3(1):1–9, 2016.

Johnson, A. E., Bulgarelli, L., Shen, L., Gayles, A., Shammout, A., Horng, S., Pollard, T. J., Hao, S., Moody, B., Gow, B., et al. Mimic-iv, a freely accessible electronic health record dataset. Scientific data, 10(1):1, 2023.

Lester, B., Al-Rfou, R., and Constant, N. The power of scale for parameter-efficient prompt tuning. arXiv preprint arXiv:2104.08691, 2021.

Liang, V. W., Zhang, Y., Kwon, Y., Yeung, S., and Zou, J. Y. Mind the gap: Understanding the modality gap in multi-modal contrastive representation learning. Advances in Neural Information Processing Systems, 35: 17612–17625, 2022.

Ma, M., Ren, J., Zhao, L., Tulyakov, S., Wu, C., and Peng, X. Smil: Multimodal learning with severely missing modality. In Proceedings of the AAAI Conference on Artificial Intelligence, volume 35, pp. 2302–2310, 2021.

Masoudnia, S. and Ebrahimpour, R. Mixture of experts: a literature survey. Artificial Intelligence Review, 42: 275–293, 2014.

Mustafa, B., Riquelme, C., Puigcerver, J., Jenatton, R., and Houlsby, N. Multimodal contrastive learning with limoe: the language-image mixture of experts. Advances in Neural Information Processing Systems, 35:9564–9576, 2022.

Ni, R., Lin, Z., Wang, S., and Fanti, G. Mixture-of-linearexperts for long-term time series forecasting. In International Conference on Artificial Intelligence and Statistics, pp. 4672–4680. PMLR, 2024.

Poria, S., Cambria, E., and Gelbukh, A. Deep convolutional neural network textual features and multiple kernel learning for utterance-level multimodal sentiment analysis. In Proceedings ofthe 2015 conference on empirical methods in natural language processing, pp. 2539–2544, 2015.

Puigcerver, J., Riquelme, C., Mustafa, B., and Houlsby, N. From sparse to soft mixtures of experts. arXiv preprint arXiv:2308.00951, 2023.

Rahman, W., Hasan, M. K., Lee, S., Zadeh, A., Mao, C., Morency, L.-P., and Hoque, E. Integrating multimodal information in large pretrained transformers. In Proceedings of the conference. Association for computational linguistics. Meeting, volume 2020, pp. 2359, 2020.

Shang, C., Palmer, A., Sun, J., Chen, K.-S., Lu, J., and Bi, J. Vigan: Missing view imputation with generative adversarial networks. In 2017 IEEE International conference on big data (Big Data), pp. 766–775. IEEE, 2017.

Shazeer, N., Mirhoseini, A., Maziarz, K., Davis, A., Le, Q., Hinton, G., and Dean, J. Outrageously large neural networks: The sparsely-gated mixture-of-experts layer. arXiv preprint arXiv:1701.06538, 2017.

Sun, Y., Liu, Z., Sheng, Q. Z., Chu, D., Yu, J., and Sun, H. Similar modality completion-based multimodal sentiment analysis under uncertain missing modalities. Information Fusion, 110:102454, 2024.

Tan, X., Wang, X., Liu, Q., Xu, X., Yuan, X., Zhu, L., and Zhang, W. Memotime: Memory-augmented temporal knowledge graph enhanced large language model reasoning. In Proceedings ofthe ACM Web Conference 2026, pp. 4220–4231, 2026a.

Tan, X., Wang, X., Liu, Q., Xu, X., Yuan, X., Zhu, L., and Zhang, W. Privgemo: Privacy-preserving dual-tower graph retrieval for empowering llm reasoning with memory augmentation. arXiv preprint arXiv:2601.08739, 2026b.

Tsai, Y.-H. H., Bai, S., Liang, P. P., Kolter, J. Z., Morency, L.-P., and Salakhutdinov, R. Multimodal transformer for unaligned multimodal language sequences. In Proceedings of the conference. Association for computational linguistics. Meeting, volume 2019, pp. 6558, 2019.

Wang, H., Chen, Y., Ma, C., Avery, J., Hull, L., and Carneiro, G. Multi-modal learning with missing modality via shared-specific feature modelling. In Proceedings ofthe IEEE/CVF Conference on Computer Vision and Pattern Recognition, pp. 15878–15887, 2023.

Wang, L., Gao, H., Zhao, C., Sun, X., and Dai, D. Auxiliaryloss-free load balancing strategy for mixture-of-experts. arXiv preprint arXiv:2408.15664, 2024a.

Wang, Z., Zhu, J., and Chen, J. Remoe: Fully differentiable mixture-of-experts with relu routing. arXiv preprint arXiv:2412.14711, 2024b.

Wu, Q., Teney, D., Wang, P., Shen, C., Dick, A., and Van Den Hengel, A. Visual question answering: A survey of methods and datasets. Computer Vision and Image Understanding, 163:21–40, 2017.

Xu, L., Jordan, M., and Hinton, G. E. An alternative model for mixtures of experts. Advances in neural information processing systems, 7, 1994.

Xu, P., Zhu, X., and Clifton, D. A. Multimodal learning with transformers: A survey. IEEE Transactions on Pattern Analysis and Machine Intelligence, 45(10):12113–12132, 2023.

Yang, B. and Wu, L. How to leverage multimodal ehr data for better medical predictions? arXiv preprint arXiv:2110.15763, 2021.

Yao, W., Yin, K., Cheung, W. K., Liu, J., and Qin, J. Drfuse: Learning disentangled representation for clinical multi-modal fusion with missing modality and modal inconsistency. In Proceedings of the AAAI conference on artificial intelligence, volume 38, pp. 16416–16424, 2024.

Yun, S., Choi, I., Peng, J., Wu, Y., Bao, J., Zhang, Q., Xin, J., Long, Q., and Chen, T. Flex-moe: Modeling arbitrary modality combination via the flexible mixture-of-experts. arXiv preprint arXiv:2410.08245, 2024.

Zadeh, A., Zellers, R., Pincus, E., and Morency, L.-P. Mosi: multimodal corpus of sentiment intensity and subjectivity analysis in online opinion videos. arXiv preprint arXiv:1606.06259, 2016.

Zadeh, A., Chen, M., Poria, S., Cambria, E., and Morency, L.-P. Tensor fusion network for multimodal sentiment analysis. arXiv preprint arXiv:1707.07250, 2017.

Zhai, Z., Li, F., Tan, X., Wang, X., and Zhang, W. Graph is a natural regularization: Revisiting vector quantization for graph representation learning. arXiv preprint arXiv:2508.06588, 2025.

Zhang, X., Li, S., Chen, Z., Yan, X., and Petzold, L. R. Improving medical predictions by irregular multimodal electronic health records modeling. In International Conference on Machine Learning, pp. 41300–41313. PMLR, 2023.

Zheng, L. N., Dong, C. G., Zhang, W. E., Chen, X., Yue, L., and Chen, W. Devil in the tail: A multi-modal framework for drug-drug interaction prediction in long tail distinction. In Proceedings ofthe 33rd ACM International Conference on Information and Knowledge Management, pp. 3395–3404, 2024a.

Zheng, L. N., Dong, C. G., Zhang, W. E., Yue, L., Xu, M., Maennel, O., and Chen, W. Revisited large language model for time series analysis through modality alignment. arXiv preprint arXiv:2410.12326, 2024b.

Zheng, L. N., Li, Z., Dong, C. G., Zhang, W. E., Yue, L., Xu, M., Maennel, O., and Chen, W. Irregularity-informed time series analysis: Adaptive modelling of spatial and temporal dynamics. In Proceedings of the 33rd ACM International Conference on Information and Knowledge Management, pp. 3405–3414, 2024c.

## A. Impact Statements

This paper presents work whose goal is to advance the field of machine learning. There are many potential societal consequences of our work, none of which we feel must be specifically highlighted here

## B. Notation

Table 3. Notation

<table><tr><td>Variable</td><td>Definition</td></tr><tr><td> $E_i$ </td><td>i-th expert function</td></tr><tr><td> $\mathbf{E}$ </td><td>Expert pool</td></tr><tr><td> $\mathbf{U}$ </td><td>ConfNet pool</td></tr><tr><td> $\mathbf{h}$ </td><td>Embedding of arbitrary data input</td></tr><tr><td> $K$ </td><td>Number of K selection</td></tr><tr><td> $T$ </td><td>Number of T selection in Post-Imputation</td></tr><tr><td> $N$ </td><td>Total number of expert</td></tr><tr><td> $n$ </td><td>Number of instances selected in Pre-Imputation</td></tr><tr><td> $G(\cdot)$ </td><td>Gating function</td></tr><tr><td> $\mathbf{g}$ </td><td>Gating score vector</td></tr><tr><td> $\mathcal{H}(\cdot)$ </td><td>Information entropy</td></tr><tr><td> $p_t$ </td><td>Confidence of ground truth</td></tr><tr><td> $\mathbf{A}_a^*$ </td><td>Sparse attention map</td></tr><tr><td> $M_m$ </td><td>Representation of Missing modality  $m$  before model backbone</td></tr><tr><td> $M_{m,b}$ </td><td>Modality pool with  $b$  instance for  $M_m$ </td></tr><tr><td> $\bar{M}_m$ </td><td>Imputed representation of  $M_m$  after pre-imputation</td></tr><tr><td> $M_m^*$ </td><td>Imputed representation of  $M_m$  after expert forward and Post-imputation</td></tr><tr><td> $M_a$ </td><td>Representation of available modality  $a$  before model backbone</td></tr><tr><td> $M_a^k$ </td><td>Representation of  $M_a$  returned from k-th expert</td></tr><tr><td> $M_a^*$ </td><td>Representation of  $M_a$  after expert forward</td></tr><tr><td> $B$ </td><td>Sparsity hyperparameter</td></tr><tr><td> $b$ </td><td>Number of instance in modality pool</td></tr><tr><td> $|M|$ </td><td>Number of modality</td></tr><tr><td> $diag(\cdot)$ </td><td>Diagonal matrix</td></tr><tr><td> $\delta_{ij}$ </td><td>Kronecker delta</td></tr><tr><td> $u_i$ </td><td>Softmax logits input at i-th entry</td></tr><tr><td> $c_i$ </td><td>Confidence score for expert  $E_i$ </td></tr><tr><td> $g_i$ </td><td>Gating score for expert  $E_i$ </td></tr></table>

To facilitate understanding of the model formulation and derivations, Table 3 outlines the notations used throughout this paper. These include variables associated with expert routing, gating mechanisms, modality assignments, and sparsity control, which are central to our proposed ConfSMoE framework.

## C. Derivation of Jacobian for MoE and Load Balance Loss

## C.1. Jacobian for Softmax

This section provides detailed mathematical derivations of the Jacobian matrix used in the gating function of ConfSMoE and its relation to the load balance loss. We first derive the Jacobian of the softmax operation applied to the gating logits, which is essential for analyzing expert selection dynamics. We then extend this analysis to derive gradients of the entropy-based load balance loss. These derivations provide theoretical insights into how sparse expert routing and balanced expert utilization can be jointly optimized.

We first derive the Jacobian of the softmax function as used in the MoE formulation Eq. 2.

$$
\mathbf {g} = G (\mathbf {u}) = \text { softmax } (\mathbf {u}) = \frac {e ^ {u _ {i}}}{\sum_ {j = 1} ^ {N} e ^ {u _ {j}}}\tag{10}
$$

where $u _ { i }$ is the i-th input value of gate logits.

$$
\frac {\partial \mathbf {g}}{\partial \mathbf {u}} = \left\{ \begin{array}{l l} \frac {e ^ {u _ {i}} (\sum_ {j = 1} ^ {N} e ^ {u _ {j}} - e ^ {u _ {i}})}{(\sum_ {j = 1} ^ {N} e ^ {u _ {j}}) ^ {2}} & \text { if } i = j \\ - \frac {e ^ {u _ {i}} e ^ {u _ {j}}}{(\sum_ {j = 1} ^ {N} e ^ {u _ {j}}) ^ {2}} & \text { if } i \neq j \end{array} \right.\tag{11}
$$

$$
\frac {\partial \mathbf {g}}{\partial \mathbf {u}} = \left\{ \begin{array}{c l} g _ {i} (1 - g _ {j}) & \text { if } i = j \\ - g _ {i} g _ {j} & \text { if } i \neq j \end{array} \right.\tag{12}
$$

Where $g _ { i }$ represent $\frac { e ^ { u _ { i } } } { \sum _ { j = 1 } ^ { N } e ^ { u _ { j } } }$ . This can be further compactly represent as:

$$
\frac {\partial \mathbf {g}}{\partial \mathbf {u}} = g _ {i} (\delta_ {i j} - g _ {j})\tag{13}
$$

Where $\delta _ { i j } = { \left\{ \begin{array} { l l } { 1 } & { { \mathrm { i f ~ } } i = j } \\ { 0 } & { { \mathrm { i f ~ } } i \neq j } \end{array} \right. }$ is Kronecker delta and the matrix form is:

$$
\mathbf {J} _ {\text { softmax }} = \frac {\partial \mathbf {g}}{\partial \mathbf {u}} = \mathbf {d i a g} (\mathbf {g}) - \mathbf {g g} ^ {\top}\tag{14}
$$

## C.2. Jacobian for Load Balance Loss

Assumption C.1. For any load balance loss $\mathcal { L } _ { \mathrm { l o a d } }$ applied to a Softmax-based MoE, the effect of $\mathcal { L } _ { \mathrm { l o a d } }$ is to encourage a flat expert selection distribution, which is equivalent to maximizing the entropy of the gating scores.

With Assumption C.1, We have load balance loss $\begin{array} { r } { \mathcal { L } _ { l o a d } = \frac { 1 } { \mathcal { H } ( \mathbf { g } ) } } \end{array}$ , where $\begin{array} { r } { \mathcal { H } ( \mathbf { g } ) = - \sum _ { i = 1 } ^ { N } g _ { i } l o g ( g _ { i } ) } \end{array}$ is the entropy of the gating distribution.

By applying the chain rule, we obtain:

$$
\frac {\partial \mathcal {L} _ {l o a d}}{\partial \mathbf {u}} = - \frac {1}{\mathcal {H} (\mathbf {u}) ^ {2}} \frac {\partial \mathcal {H}}{\partial \mathbf {u}} = - \frac {1}{\mathcal {H} (\mathbf {u}) ^ {2}} \frac {\partial \mathcal {H}}{\partial \mathbf {g}} \frac {\partial \mathbf {g}}{\partial \mathbf {u}}\tag{15}
$$

The intermediate gradients are given by:

$$
\frac {\partial \mathcal {H}}{\partial \mathbf {g}} = - l o g (\mathbf {g}) - \mathbf {g} \frac {1}{\mathbf {g}} = - l o g (\mathbf {g}) - 1, \quad \frac {\partial \mathbf {g}}{\partial \mathbf {u}} = \mathbf {d i a g} (\mathbf {g}) - \mathbf {g g} ^ {\top}\tag{16}
$$

Therefore, he final Jacobian of the load balance loss $J _ { l o a d }$ is:

$$
\mathbf {J} _ {\text { load }} = \frac {\partial \mathcal {L} _ {\text { load }}}{\partial \mathbf {g}} = \left[ \frac {1}{\mathcal {H} (\mathbf {g}) ^ {2}} (l o g \mathbf {g} + 1) ^ {\top} \right] \cdot (\mathbf {d i a g} (\mathbf {g}) - \mathbf {g g} ^ {\top})\tag{17}
$$

## D. Experiment Details

## D.1. Dataset

MIMIC-III (Johnson et al., 2016) is a public dataset contains irregular time series and clinical notes modality. We follow the preprocessing scripts from MMIMI-III benchmark (Harutyunyan et al., 2019) and (Zhang et al., 2023) to form multimodal patient instance. However, (Zhang et al., 2023) filter the instances with missing modality and we modified the scripts to preserve with instances with missing modality. MIMIC-IV (Johnson et al., 2023) is a public dataset that contains irregular time series, clinical notes, ECG signal and chest image. We follow the preprocessing scripts from MedFuse (Hayat et al., 2022) to preprocess irregular time series and further preprocess clinical notes, ECG signal and chest image by ourself. We follow the dataset split in MedFuse (Hayat et al., 2022) and form multimodal patient instances. CMU-MOSI (Zadeh et al., 2016) is a multimodal sentiment analysis dataset comprising audio, video, and text modalities. CMU-MOSEI (Bagher Zadeh et al., 2018) is an extension of the CMU-MOSI dataset, utilizing the same modalities—audio, text, and video from YouTube recordings. We follow preprocessing script of CMU-MOSI and CMU-MOSEI from MMML(Mustafa et al., 2022).

## D.2. Baselines

SMIL(Ma et al., 2021) impute missing modality with Bayesian meta-learning. ShaSpec(Wang et al., 2023) leverages multiple loss function to learn the modality-share and modality-specific information and impute the missing modality with modality-shared information. TF(Zadeh et al., 2017) extract the modality interaction by multimodal sub-networks and tensor fusion layer. mmFormer(Tsai et al., 2019) is a typical multimodal transformer with multihead attention mechanism. LlMoE(Mustafa et al., 2022) achieves the multimodal learning with contrastive learning. FuseMoE(Han et al., 2024) respect the missing modality and jointly learn single and missing modality combination data input and FuseMoE implement Laplacian gating mechanism for modality fusoin and expert selection. In experiment, we denote FuseMoE-S as softmax gating and FuseMoE-L as Laplacian gating. FlexMoE(Yun et al., 2024) assigns the combination of modality to different experts and impute the missing modality by modality bank. For our approach, we use ConfSMoE-T denotes Token-Level confidence fusion and ConfSMoE-E denotes Expert-level confidence fusion.

## D.3. Dataset and Task Description

Table 4. Dataset statistics

<table><tr><td>Dataset</td><td>Task</td><td>#Samples</td><td>Modality</td><td>#Classes</td><td>Is Imbalanced?</td><td>Missing Ratio</td></tr><tr><td rowspan="3">MIMIC-III</td><td>48-IHM</td><td>6621</td><td>Time Series, Text</td><td>2</td><td>Yes</td><td>24.21%</td></tr><tr><td>LOS</td><td>6621</td><td>Time Series, Text</td><td>2</td><td>Yes</td><td>24.21%</td></tr><tr><td>25-PHE</td><td>12,278</td><td>Time Series, Text</td><td>25</td><td>Yes</td><td>24.25%</td></tr><tr><td rowspan="3">MIMIC-IV</td><td>48-IHM</td><td>22,733</td><td>Image, ECG, Time Series, Text</td><td>2</td><td>Yes</td><td>47.10%</td></tr><tr><td>LOS</td><td>22,733</td><td>Image, ECG, Time Series, Text</td><td>2</td><td>Yes</td><td>47.10%</td></tr><tr><td>25-PHE</td><td>47,027</td><td>Image, ECG, Time Series, Text</td><td>25</td><td>Yes</td><td>50.32%</td></tr><tr><td>CMU-MOSI</td><td>Sentiment Analysis</td><td>1870</td><td>Audio, Video, Text</td><td>3</td><td>Yes</td><td>0% - 50%</td></tr><tr><td>CMU-MOSEI</td><td>Sentiment Analysis</td><td>20,985</td><td>Audio, Video, Text</td><td>3</td><td>Yes</td><td>0% - 50%</td></tr></table>

48-IHM is a binary classification task, where the time series is truncated to 48 hours readings and predict whether the patient in-hospital mortality in ICU.

LOS is also binary classification task. We formulate task similar to 48-IHM and those patients who spent at least 48 hours in the ICU are filtered to predict the remaining Length Of Stay.

25-PHE is a multilabel classification problem. We attempt to predict one 25 acute care conditions presented in a givem ICU stay record. The definition of those 25 acute care conditions are defined in MIMIC benchmark (Johnson et al., 2016)

CMU-MOSI and CMU-MOSEI are multimodal sentiment analysis benchmarks consisting of video clips annotated with sentiment scores. Each sample includes aligned audio, video, and text modalities. To simulate modality missingness, we introduce controlled random dropout during training.

All datasets are publicly available and widely adopted in multimodal research. Those datasets can be found and downloaded from the following links:

• CMU-MOSI and CMU-MOSEI download link: https://github.com/zehuiwu/MMML

• MIMIC-III download link: https://physionet.org/content/mimiciii/1.4/ and benchmark: https://github.com/YerevaNN/mimic3-benchmarks

• MIMIC-IV download link: https://physionet.org/content/mimiciv/2.2/ and benchmark: https://github.com/nyuadcai/MedFuse

## D.4. Hyperparameter and Hardware Setting

All experiments are conducted in a remote server with 4 × RTX4090 24 GB with 256 GB RAM and 96-cores CPU.

Table 5. Hyperparameter setting

<table><tr><td>Parameter</td><td>Value</td></tr><tr><td>#Expert</td><td>8 for MIMIC-III and MIMIC-IV, 4 for CMU-MOSI and CMU-MOSEI</td></tr><tr><td>#Top-K Expert</td><td>2</td></tr><tr><td>Learning Rate</td><td>3e-4</td></tr><tr><td>Hidden Size</td><td>128</td></tr><tr><td>#MoE layers</td><td>1</td></tr><tr><td>Training Epoch</td><td>50</td></tr><tr><td>Weight for  $\mathcal{L}_{conf}$ </td><td>1</td></tr><tr><td>#Instance for Pre-imputation</td><td>10</td></tr><tr><td>Random Seed</td><td>2023, 2024, 2025</td></tr><tr><td>Dropout</td><td>0.1</td></tr></table>

## E. Other Gating Mechanism and Load Balance Loss

## E.1. Mean Gating

The Mean Gate considers the gating score for all experts equally important. Given gating weight $\mathbf { W } _ { r }$ , and arbitrary representation h and gating score $\begin{array} { r } { g _ { i } = \frac { 1 } { N } } \end{array}$ produced by router $G ( \mathbf { u } )$ , where N is the number of expert.

## E.2. Softmax Gating

Given a token embedding h $\in \mathbb { R } ^ { d }$ and there are N expert $E _ { 1 } , E _ { 2 } , \cdots , E _ { N }$ with gating scores collected in ${ \bf g } = { \bf \pi }$ $\left[ g _ { 1 } , g _ { 2 } , \cdots , g _ { N } \right]$ . We introduce a linear weight ${ \mathbf W } _ { r }$ to map h to expert logits $\mathbf { u } = \mathbf { W } _ { r } \mathbf { h } \in \mathbb { R } ^ { N }$ . As in expert selection, we use softmax to convert the logits to probability distribution:

$$
g _ {i} = \frac {\exp (u _ {i})}{\sum_ {j = 1} ^ {N} \exp (u _ {j})}.
$$

## E.3. Loss-Free Balance Gating

As the Loss-Free Balance Gating (LFB) (Wang et al., 2024a) is not officially open-source, we found a github repository that reproduces the implementation: https://github.com/ambisinister/lossfreebalance. Formally, the number of instances assigned to each expert $z _ { i } = [ z _ { 1 } , z _ { 2 } , \cdot \cdot \cdot , z _ { i } ]$ and the average number of instance z¯. We introduce a expert-wise bias term $\{ b _ { i } \} _ { i = 1 } ^ { N }$ initialized as zeros and update iteratively in a rule-based manner. This bias term will be added to gating logits $\mathbf { u } = \bar { \mathbf { W } } _ { r } \bar { \mathbf { h } } \in \mathbf { \bar { \mathbb { R } } } ^ { N }$ of each expert to get a biased gating score $\boldsymbol { u } _ { i } ^ { * }$

$$
u _ {i} ^ {*} = u _ {i} + b _ {i}, \quad b _ {i} = b _ {i} + \alpha \times s i g n (e _ {i}), \quad e _ {i} = \bar {z} - z _ {i}\tag{18}
$$

Where, $e _ { i }$ is a load violation error and α is hyperparameter to control the strength of adjustment from violation error. Note that this $\boldsymbol { u } _ { i } ^ { * }$ is only used for expert selection in Top-K function instead of expert forward. The gating score $g _ { i }$ used to forward is generated as $g _ { i } = S i g m o i d ( u _ { i } )$ . The authors used sigmoid as they believe the sigmoid achieve slightly better performance than softmax.

## E.4. Gaussian Gating

We follow the implementation of FuseMoE (Han et al., 2024) for the Gaussian gate baseline. Given a token embedding h $\in \mathbb { R } ^ { d }$ and there are $N$ expert $E _ { 1 } , E _ { 2 } , \cdots , E _ { N }$ with gating scores collected in $\mathbf { g } ^ { - } = [ g _ { 1 } , g _ { 2 } , \cdots , g _ { N } ] \in \mathbb { R } ^ { N }$ . We introduce a matrix of Gaussian gate centers, a learnable parameter denoted as $\mathbf { c } = [ c _ { 1 } , c _ { 2 } , \cdots , c _ { N } ] \in \mathbb { R } ^ { d \times N }$ for each expert. For a single token, we define the gaussian logits as negative square Euclidean distance h and each gate center $c _ { i } { : }$

$$
u _ {i} = - \| \mathbf {h} - c _ {i} \| _ {2} ^ {2}, i = 1, \dots , N.
$$

As in expert selection we still use softmax to convert the logits to probability distribution:

$$
g _ {i} = \frac {\exp \left(- \| \mathbf {h} - c _ {i} \| _ {2} ^ {2}\right)}{\sum_ {j = 1} ^ {N} \exp (- \| \mathbf {h} - c _ {j} \| _ {2} ^ {2})}.
$$

## E.5. Laplacian Gating

We follow the implementation of FuseMoE (Han et al., 2024) for the Laplacian gate baseline. Given a token embedding $\mathbf { \pmb { \mathrm { \mathbf { \mathbf { \imath } } } } } _ { \mathbf { \pmb { \mathbf { \imath } } } } \in \mathbb { R } ^ { d }$ and $N$ experts $E _ { 1 } , E _ { 2 } , \cdots , E _ { N }$ with gating scores collected in $\mathbf { g } = [ g _ { 1 } , g _ { 2 } , \cdots , g _ { N } ] \in \mathbb { R } ^ { N }$ , we introduce a matrix of Laplacian gate centers, a learnable parameter denoted as $\mathbf { c } = [ \mathbf { c } _ { 1 } , \mathbf { c } _ { 2 } , \cdot \cdot \cdot , \mathbf { c } _ { N } ] \in \mathbb { R } ^ { d \times N }$ for each expert. For a single token, we define the Laplacian logits as the negative Euclidean distance between h and each gate center ${ \bf { c } } _ { i } \mathbf { : }$

$$
u _ {i} = - \left\| \mathbf {h} - \mathbf {c} _ {i} \right\| _ {2}, i = 1, \dots , N.
$$

As in expert selection, we still use softmax to convert the logits into a probability distribution:

$$
g _ {i} s = \frac {\exp (- \| \mathbf {h} - c _ {i} \| _ {2})}{\sum_ {j = 1} ^ {N} \exp (- \| \mathbf {h} - c _ {j} \| _ {2})}.
$$

## E.6. Load Balance Loss

We follow (Shazeer et al., 2017) to implement load balance loss used in our experiment.

$$
\begin{array}{l} \mathcal {L} _ {b a l a n c e} = \mathbf {C V} ^ {2} \left(\sum_ {j} ^ {N} i m p o r t a n c e _ {j}\right) + \mathbf {C V} ^ {2} \left(\sum_ {j} ^ {N} l o a d _ {j}\right) \\ i m p o r t a n c e _ {j} = \sum_ {i} ^ {| D |} g _ {i, j}, \quad l o a d _ {j} = \sum_ {i} ^ {| D |} \delta (g _ {i, j} > 0) \end{array}
$$

where $\begin{array} { r } { C V ^ { 2 } ( x ) = \Big ( \frac { \sigma ( x ) } { \mu ( x ) } \Big ) ^ { 2 } , \sigma ( x ) } \end{array}$ is the standard deviation of $x ,$ importance is the expert importance of expert $j$ and $l o a d _ { j }$ is load of expert $j , \delta ( \cdot > 0 )$ is an indicator function that is 1 when the inner value is greater than 0.

Now we show that the load balance function used in the experiment encourages flat gating score distribution, which is equivalent to having the same mathematical behaviour as the general load balance loss in gradient analysis. The denominator is the average across all expert, then we have:

$$
\mu = \frac {1}{N} \sum_ {j} ^ {N} i m p o r t a n c e _ {j} = \frac {1}{N} \sum_ {j} ^ {N} \left(\sum_ {i} ^ {| D |} g _ {i, j}\right) = \frac {1}{N} \sum_ {i} ^ {| D |} \left(\sum_ {j} ^ {N} g _ {i, j}\right) = \frac {| D |}{N}\tag{19}
$$

Note that $\begin{array} { r } { \sum _ { j } ^ { N } g _ { i , j } = 1 } \end{array}$ is the summation of gating score out of softmax router. From above, the denominator is a constant only impacted by the number of instances $| D |$ and the number of experts N. Thus, the applied load balance loss will minimize the variance of importance for each expert, which encourages flat gating score distribution. This is equivalent to minimizing the reverse of gating score entropy $\displaystyle \frac { \mathbf { \bar { \sigma } } _ { 1 } } { \mathcal { H } ( \mathbf { \mathbf { g } } ) }$ as we show in gradient analysis.

## F. Limitation

This work may be limited to expert discontinuity as it is build upon on sparse MoE backbone. A key limitation lies in the dichotomy between fully differentiable MoE and sparse MoE architectures. These two paradigms embody opposite design philosophies, one prioritizing differentiability and comprehensive training, the other emphasizing efficiency through sparsity, making it difficult to simultaneously leverage the benefits of both within a single unified framework.

## G. Additional Results

These experiments extend the main results presented in Section Experiment and highlight the scalability of our method to real-world multimodal challenges.

Table 6. Experiment setting I: Main results on MIMIC-III

<table><tr><td>Task</td><td>Metric</td><td>SMIL</td><td>ShaSpec</td><td>mmFormer</td><td>TF</td><td>LiMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-T</td><td>ConfSMoE-E</td></tr><tr><td rowspan="2">48-IHM</td><td>F1</td><td> $48.56 \pm 0.35$ </td><td> $34.36 \pm 0.73$ </td><td> $43.80 \pm 0.67$ </td><td> $23.09 \pm 1.13$ </td><td> $47.62 \pm 0.21$ </td><td> $48.62 \pm 0.27$ </td><td> $\underline{51.63} \pm 0.39$ </td><td> $47.81 \pm 0.31$ </td><td> $\underline{53.44} \pm \underline{0.27}$ </td><td> $50.00 \pm 2.17$ </td></tr><tr><td>AUC</td><td> $84.00 \pm 1.10$ </td><td> $79.86 \pm 0.53$ </td><td> $81.27 \pm 0.76$ </td><td> $78.47 \pm 0.65$ </td><td> $83.30 \pm 0.64$ </td><td> $85.81 \pm 0.13$ </td><td> $86.22 \pm 0.15$ </td><td> $85.10 \pm 0.61$ </td><td> $87.05 \pm 0.58$ </td><td> $\underline{87.14} \pm \underline{0.21}$ </td></tr><tr><td rowspan="2">LOS</td><td>F1</td><td> $62.01 \pm 0.54$ </td><td> $57.27 \pm 0.36$ </td><td> $61.10 \pm 0.65$ </td><td> $56.23 \pm 0.79$ </td><td> $62.75 \pm 0.10$ </td><td> $62.26 \pm 0.36$ </td><td> $62.27 \pm 1.61$ </td><td> $64.18 \pm 0.34$ </td><td> $\underline{66.27} \pm 0.40$ </td><td> $\underline{66.39} \pm \underline{0.23}$ </td></tr><tr><td>AUC</td><td> $80.08 \pm 0.35$ </td><td> $74.71 \pm 0.07$ </td><td> $77.94 \pm 0.12$ </td><td> $72.60 \pm 0.79$ </td><td> $79.80 \pm 0.27$ </td><td> $80.05 \pm 0.51$ </td><td> $79.70 \pm 0.43$ </td><td> $80.49 \pm 0.48$ </td><td> $\underline{81.66} \pm \underline{0.26}$ </td><td> $\underline{81.71} \pm \underline{0.18}$ </td></tr><tr><td rowspan="2">25-PHE</td><td>F1</td><td> $33.01 \pm 0.30$ </td><td> $19.52 \pm 0.39$ </td><td> $35.10 \pm 0.38$ </td><td> $30.38 \pm 0.38$ </td><td> $36.22 \pm 0.39$ </td><td> $33.48 \pm 0.22$ </td><td> $34.07 \pm 0.51$ </td><td> $35.31 \pm 0.57$ </td><td> $\underline{37.40} \pm 0.13$ </td><td> $\underline{40.13} \pm \underline{0.40}$ </td></tr><tr><td>AUC</td><td> $75.17 \pm 1.84$ </td><td> $64.61 \pm 0.25$ </td><td> $71.79 \pm 0.26$ </td><td> $66.56 \pm 0.17$ </td><td> $77.93 \pm 0.44$ </td><td> $77.22 \pm 0.29$ </td><td> $77.19 \pm 0.33$ </td><td> $77.37 \pm 0.10$ </td><td> $\underline{78.93} \pm \underline{0.38}$ </td><td> $\underline{78.28} \pm \underline{0.73}$ </td></tr></table>

Table 7. Experiment setting II: Main results on CMU-MOSI

<table><tr><td>Missing Rate</td><td>Metric</td><td>ShaSpec</td><td>TF</td><td>mmFormer</td><td>LIMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-T</td><td>ConfSMoE-E</td></tr><tr><td rowspan="2">0%</td><td>F1</td><td>41.78 ± 0.64</td><td>43.28 ± 0.36</td><td>50.22 ± 0.20</td><td>50.91 ± 0.19</td><td>47.69 ± 0.39</td><td>48.15 ± 0.57</td><td>51.50 ± 0.55</td><td>51.83 ± 0.27</td><td>51.70 ± 0.29</td></tr><tr><td>AUC</td><td>65.08 ± 0.39</td><td>64.48 ± 0.51</td><td>74.62 ± 0.49</td><td>78.12 ± 0.31</td><td>75.26 ± 0.20</td><td>75.96 ± 0.29</td><td>79.38 ± 0.23</td><td>80.56 ± 0.10</td><td>80.62 ± 0.07</td></tr><tr><td rowspan="2">10%</td><td>F1</td><td>43.40 ± 0.74</td><td>40.14 ± 0.13</td><td>48.66 ± 1.20</td><td>49.91 ± 0.33</td><td>46.81 ± 0.45</td><td>48.81 ± 0.42</td><td>49.92 ± 0.28</td><td>49.99 ± 0.85</td><td>50.89 ± 0.07</td></tr><tr><td>AUC</td><td>65.45 ± 0.56</td><td>61.54 ± 0.66</td><td>77.21 ± 0.76</td><td>77.12 ± 0.14</td><td>70.25 ± 0.93</td><td>72.36 ± 0.50</td><td>77.07 ± 0.21</td><td>78.06 ± 0.64</td><td>78.03 ± 0.21</td></tr><tr><td rowspan="2">20%</td><td>F1</td><td>39.15 ± 0.13</td><td>42.64 ± 0.30</td><td>48.51 ± 1.15</td><td>48.84 ± 0.61</td><td>47.92 ± 0.58</td><td>45.00 ± 0.44</td><td>49.16 ± 0.24</td><td>50.58 ± 0.73</td><td>50.17 ± 0.31</td></tr><tr><td>AUC</td><td>60.87 ± 0.29</td><td>65.52 ± 0.98</td><td>74.16 ± 0.71</td><td>76.64 ± 0.23</td><td>71.05 ± 0.36</td><td>72.15 ± 0.37</td><td>73.80 ± 1.43</td><td>77.17 ± 0.55</td><td>77.18 ± 0.11</td></tr><tr><td rowspan="2">30%</td><td>F1</td><td>39.54 ± 0.17</td><td>40.42 ± 0.75</td><td>46.66 ± 1.24</td><td>46.13 ± 0.55</td><td>43.78 ± 0.51</td><td>44.48 ± 0.63</td><td>45.49 ± 0.44</td><td>47.57 ± 0.10</td><td>47.52 ± 0.77</td></tr><tr><td>AUC</td><td>60.80 ± 0.44</td><td>60.57 ± 0.99</td><td>71.25 ± 0.57</td><td>74.33 ± 0.49</td><td>70.38 ± 0.56</td><td>72.25 ± 0.48</td><td>72.54 ± 0.92</td><td>75.59 ± 0.18</td><td>75.42 ± 0.49</td></tr><tr><td rowspan="2">40%</td><td>F1</td><td>35.32 ± 0.32</td><td>38.69 ± 0.42</td><td>42.22 ± 0.44</td><td>43.31 ± 0.38</td><td>41.88 ± 0.42</td><td>43.20 ± 0.20</td><td>43.13 ± 0.61</td><td>45.12 ± 0.27</td><td>44.18 ± 0.10</td></tr><tr><td>AUC</td><td>59.58 ± 0.13</td><td>61.62 ± 0.07</td><td>68.44 ± 0.14</td><td>67.21 ± 0.43</td><td>64.61 ± 0.63</td><td>66.14 ± 0.11</td><td>68.12 ± 0.34</td><td>71.65 ± 0.47</td><td>69.55 ± 0.49</td></tr><tr><td rowspan="2">50%</td><td>F1</td><td>36.39 ± 0.97</td><td>38.46 ± 1.09</td><td>41.14 ± 0.31</td><td>41.54 ± 0.77</td><td>38.55 ± 0.34</td><td>40.90 ± 0.49</td><td>41.95 ± 0.48</td><td>44.34 ± 0.77</td><td>42.48 ± 0.12</td></tr><tr><td>AUC</td><td>55.60 ± 0.12</td><td>60.49 ± 0.80</td><td>61.87 ± 0.67</td><td>67.43 ± 0.34</td><td>62.28 ± 0.28</td><td>65.73 ± 0.30</td><td>66.47 ± 0.49</td><td>70.41 ± 1.31</td><td>69.04 ± 0.32</td></tr></table>

Table 8. Experiment setting II: Main results on CMU-MOSEI

<table><tr><td>Missing Rate</td><td>Metric</td><td>ShaSpec</td><td>TF</td><td>mmFormer</td><td>LiMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-T</td><td>ConfSMoE-E</td></tr><tr><td rowspan="2">0%</td><td>F1</td><td>47.48 ± 0.27</td><td>38.89 ± 0.54</td><td>56.75 ± 0.47</td><td>59.13 ± 0.52</td><td>57.04 ± 0.15</td><td>58.71 ± 0.23</td><td>60.62 ± 0.96</td><td>61.31 ± 0.14</td><td>62.35 ± 0.12</td></tr><tr><td>AUC</td><td>67.93 ± 0.56</td><td>64.26 ± 0.61</td><td>76.42 ± 0.24</td><td>80.29 ± 0.31</td><td>78.54 ± 0.42</td><td>78.13 ± 0.34</td><td>81.34 ± 0.20</td><td>82.87 ± 0.10</td><td>82.75 ± 0.44</td></tr><tr><td rowspan="2">10%</td><td>F1</td><td>47.41 ± 0.18</td><td>34.94 ± 1.10</td><td>55.37 ± 0.47</td><td>57.46 ± 1.10</td><td>55.90 ± 0.55</td><td>56.68 ± 0.31</td><td>58.66 ± 1.10</td><td>59.81 ± 0.34</td><td>60.22 ± 0.31</td></tr><tr><td>AUC</td><td>69.26 ± 0.22</td><td>61.05 ± 0.34</td><td>75.36 ± 0.53</td><td>79.38 ± 0.94</td><td>76.38 ± 0.39</td><td>76.44 ± 0.12</td><td>79.48 ± 0.23</td><td>81.00 ± 0.10</td><td>81.05 ± 0.17</td></tr><tr><td rowspan="2">20%</td><td>F1</td><td>46.54 ± 1.04</td><td>35.37 ± 0.94</td><td>52.91 ± 0.75</td><td>55.35 ± 0.88</td><td>54.44 ± 0.27</td><td>54.60 ± 0.19</td><td>55.96 ± 1.67</td><td>58.06 ± 0.21</td><td>57.66 ± 0.20</td></tr><tr><td>AUC</td><td>68.05 ± 0.56</td><td>59.54 ± 0.22</td><td>73.02 ± 0.65</td><td>77.29 ± 0.47</td><td>74.32 ± 0.16</td><td>74.92 ± 0.64</td><td>78.05 ± 0.10</td><td>78.85 ± 0.28</td><td>78.83 ± 0.22</td></tr><tr><td rowspan="2">30%</td><td>F1</td><td>45.05 ± 0.90</td><td>35.36 ± 0.84</td><td>49.71 ± 0.30</td><td>53.93 ± 1.13</td><td>52.27 ± 0.35</td><td>49.92 ± 0.36</td><td>52.00 ± 0.47</td><td>54.16 ± 0.49</td><td>54.83 ± 0.15</td></tr><tr><td>AUC</td><td>66.89 ± 0.31</td><td>60.23 ± 0.31</td><td>71.28 ± 0.10</td><td>76.50 ± 0.31</td><td>72.22 ± 0.52</td><td>72.52 ± 0.29</td><td>76.14 ± 0.38</td><td>76.91 ± 0.41</td><td>77.10 ± 0.30</td></tr><tr><td rowspan="2">40%</td><td>F1</td><td>43.49 ± 0.95</td><td>32.23 ± 0.61</td><td>48.06 ± 0.54</td><td>50.95 ± 0.99</td><td>49.32 ± 0.17</td><td>49.36 ± 0.60</td><td>49.29 ± 0.28</td><td>50.72 ± 0.37</td><td>50.66 ± 0.18</td></tr><tr><td>AUC</td><td>65.32 ± 0.59</td><td>60.09 ± 0.35</td><td>69.31 ± 0.10</td><td>73.24 ± 0.76</td><td>69.85 ± 0.11</td><td>70.05 ± 0.46</td><td>72.08 ± 1.27</td><td>73.63 ± 0.48</td><td>73.88 ± 0.25</td></tr><tr><td rowspan="2">50%</td><td>F1</td><td>42.75 ± 1.22</td><td>33.01 ± 0.51</td><td>47.39 ± 0.16</td><td>46.69 ± 0.63</td><td>43.08 ± 0.47</td><td>44.44 ± 0.36</td><td>46.19 ± 0.34</td><td>47.31 ± 0.20</td><td>48.13 ± 0.33</td></tr><tr><td>AUC</td><td>62.32 ± 0.42</td><td>58.20 ± 0.17</td><td>66.61 ± 0.22</td><td>70.90 ± 0.82</td><td>67.63 ± 0.55</td><td>67.44 ± 0.16</td><td>70.15 ± 1.10</td><td>71.74 ± 0.14</td><td>70.48 ± 0.11</td></tr></table>

Table 9. Experiment setting III: Main results on CMU-MOSI

<table><tr><td colspan="3">Test Modality</td><td colspan="9">Dataset: CMU-MOSI / Evaluation Metric: AUC</td></tr><tr><td>Video</td><td>Text</td><td>Audio</td><td>ShaSpec</td><td>mmFormer</td><td>TF</td><td>LIMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-T</td><td>ConfSMoE-E</td></tr><tr><td>√</td><td>√</td><td></td><td> $62.18 \pm 0.88$ </td><td> $72.72 \pm 0.08$ </td><td> $59.37 \pm 1.12$ </td><td> $74.63 \pm 0.13$ </td><td> $55.35 \pm 1.11$ </td><td> $56.44 \pm 1.48$ </td><td> $74.59 \pm 1.50$ </td><td> $75.57 \pm 0.55$ </td><td> $75.56 \pm 0.33$ </td></tr><tr><td>√</td><td></td><td>√</td><td> $55.79 \pm 2.53$ </td><td> $52.21 \pm 0.31$ </td><td> $57.87 \pm 0.32$ </td><td> $56.84 \pm 0.34$ </td><td> $56.24 \pm 1.96$ </td><td> $55.11 \pm 0.77$ </td><td> $52.28 \pm 1.23$ </td><td> $58.42 \pm 0.14$ </td><td> $58.66 \pm 0.20$ </td></tr><tr><td></td><td>√</td><td>√</td><td> $65.22 \pm 1.01$ </td><td> $71.96 \pm 0.47$ </td><td> $57.89 \pm 0.65$ </td><td> $75.59 \pm 0.39$ </td><td> $54.36 \pm 1.67$ </td><td> $56.10 \pm 1.76$ </td><td> $75.55 \pm 1.64$ </td><td> $77.02 \pm 0.63$ </td><td> $76.96 \pm 0.64$ </td></tr><tr><td>√</td><td></td><td></td><td> $55.10 \pm 1.59$ </td><td> $71.01 \pm 0.53$ </td><td> $58.57 \pm 0.44$ </td><td> $74.73 \pm 0.51$ </td><td> $55.94 \pm 1.51$ </td><td> $55.66 \pm 1.66$ </td><td> $74.35 \pm 1.60$ </td><td> $75.07 \pm 0.70$ </td><td> $75.11 \pm 0.54$ </td></tr><tr><td></td><td>√</td><td></td><td> $61.60 \pm 4.80$ </td><td> $73.77 \pm 0.44$ </td><td> $60.28 \pm 1.42$ </td><td> $75.73 \pm 0.33$ </td><td> $55.45 \pm 0.95$ </td><td> $56.58 \pm 1.29$ </td><td> $74.42 \pm 1.39$ </td><td> $75.58 \pm 0.55$ </td><td> $75.50 \pm 0.41$ </td></tr><tr><td></td><td></td><td>√</td><td> $66.85 \pm 3.01$ </td><td> $69.04 \pm 0.94$ </td><td> $57.19 \pm 0.72$ </td><td> $73.29 \pm 0.53$ </td><td> $56.04 \pm 1.91$ </td><td> $57.85 \pm 0.74$ </td><td> $75.34 \pm 1.46$ </td><td> $77.02 \pm 0.63$ </td><td> $76.47 \pm 0.63$ </td></tr></table>

Table 10. Experiment setting III: Main results on CMU-MOSI

<table><tr><td colspan="3">Test Modality</td><td colspan="9">Dataset: CMU-MOSI / Evaluation Metric: F1</td></tr><tr><td>Video</td><td>Text</td><td>Audio</td><td>ShaSpec</td><td>mmFormer</td><td>TF</td><td>LiMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-T</td><td>ConfSMoE-E</td></tr><tr><td>√</td><td>√</td><td></td><td>41.27 ± 0.81</td><td>48.25 ± 0.11</td><td>34.96 ± 0.72</td><td>44.45 ± 0.33</td><td>30.51 ± 2.53</td><td>29.90 ± 2.58</td><td>50.54 ± 0.73</td><td>54.07 ± 0.29</td><td>54.04 ± 0.36</td></tr><tr><td>√</td><td></td><td>√</td><td>36.99 ± 2.03</td><td>35.79 ± 0.55</td><td>34.83 ± 0.54</td><td>35.20 ± 0.64</td><td>24.29 ± 4.23</td><td>27.89 ± 6.23</td><td>30.02 ± 7.82</td><td>37.40 ± 0.16</td><td>38.17 ± 0.13</td></tr><tr><td></td><td>√</td><td>√</td><td>43.72 ± 1.64</td><td>45.53 ± 0.33</td><td>37.25 ± 0.53</td><td>47.79 ± 0.46</td><td>20.68 ± 2.14</td><td>29.88 ± 4.55</td><td>50.41 ± 1.55</td><td>52.86 ± 0.75</td><td>51.13 ± 0.15</td></tr><tr><td>√</td><td></td><td></td><td>42.98 ± 0.21</td><td>46.49 ± 0.91</td><td>38.11 ± 0.35</td><td>44.86 ± 0.94</td><td>25.67 ± 2.82</td><td>27.34 ± 2.94</td><td>50.39 ± 0.87</td><td>53.76 ± 0.43</td><td>54.57 ± 0.35</td></tr><tr><td></td><td>√</td><td></td><td>41.36 ± 2.27</td><td>47.13 ± 0.54</td><td>37.99 ± 0.40</td><td>43.81 ± 0.42</td><td>25.70 ± 2.82</td><td>27.30 ± 2.95</td><td>50.65 ± 0.90</td><td>53.77 ± 0.45</td><td>49.93 ± 0.06</td></tr><tr><td></td><td></td><td>√</td><td>45.45 ± 2.73</td><td>46.02 ± 1.21</td><td>38.79 ± 0.56</td><td>45.50 ± 0.47</td><td>25.23 ± 4.59</td><td>29.73 ± 3.51</td><td>50.57 ± 1.35</td><td>53.72 ± 0.94</td><td>50.69 ± 0.47</td></tr></table>

Table 11. Experiment setting III: Main results on CMU-MOSEI

<table><tr><td colspan="3">Test Modality</td><td colspan="9">Dataset: CMU-MOSEI / Evaluation Metric: AUC</td></tr><tr><td>Video</td><td>Text</td><td>Audio</td><td>ShaSpec</td><td>mmFormer</td><td>TF</td><td>LiMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-T</td><td>ConfSMoE-E</td></tr><tr><td>√</td><td>√</td><td></td><td>64.47 ± 0.10</td><td>76.60 ± 0.39</td><td>56.98 ± 0.20</td><td>81.23 ± 0.07</td><td>75.81 ± 0.82</td><td>76.62 ± 0.37</td><td>80.63 ± 0.41</td><td>81.45 ± 0.02</td><td>81.52 ± 0.07</td></tr><tr><td>√</td><td></td><td>√</td><td>58.41 ± 0.10</td><td>56.72 ± 0.84</td><td>58.41 ± 0.17</td><td>59.64 ± 0.56</td><td>57.32 ± 0.62</td><td>57.22 ± 0.12</td><td>58.28 ± 1.51</td><td>60.33 ± 0.03</td><td>60.00 ± 0.23</td></tr><tr><td></td><td>√</td><td>√</td><td>64.46 ± 0.14</td><td>75.91 ± 0.04</td><td>58.64 ± 0.13</td><td>80.00 ± 0.29</td><td>77.24 ± 0.60</td><td>77.31 ± 0.16</td><td>80.00 ± 0.10</td><td>81.26 ± 0.10</td><td>81.23 ± 0.14</td></tr><tr><td>√</td><td></td><td></td><td>63.52 ± 0.19</td><td>75.82 ± 0.28</td><td>58.71 ± 0.35</td><td>80.69 ± 0.34</td><td>76.84 ± 0.14</td><td>76.27 ± 0.70</td><td>81.06 ± 0.20</td><td>81.60 ± 0.13</td><td>81.53 ± 0.22</td></tr><tr><td></td><td>√</td><td></td><td>64.40 ± 0.24</td><td>75.83 ± 0.28</td><td>58.89 ± 0.40</td><td>80.96 ± 0.26</td><td>76.85 ± 0.14</td><td>76.51 ± 0.50</td><td>80.48 ± 0.21</td><td>81.49 ± 0.13</td><td>81.65 ± 0.17</td></tr><tr><td></td><td></td><td>√</td><td>65.16 ± 0.04</td><td>75.85 ± 0.09</td><td>58.32 ± 0.04</td><td>80.19 ± 0.11</td><td>77.13 ± 0.75</td><td>77.23 ± 0.24</td><td>80.21 ± 0.11</td><td>81.25 ± 0.10</td><td>81.23 ± 0.14</td></tr></table>

Table 12. Experiment setting III: Main results on CMU-MOSEI

<table><tr><td colspan="3">Test Modality</td><td colspan="9">Dataset: CMU-MOSEI / Evaluation Metric: F1</td></tr><tr><td>Video</td><td>Text</td><td>Audio</td><td>ShaSpec</td><td>mmFormer</td><td>TF</td><td>LiMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-T</td><td>ConfSMoE-E</td></tr><tr><td>√</td><td>√</td><td></td><td>40.75 ± 0.14</td><td>56.02 ± 0.56</td><td>31.38 ± 0.61</td><td>58.97 ± 0.53</td><td>55.85 ± 0.69</td><td>53.59 ± 1.07</td><td>60.10 ± 0.76</td><td>61.56 ± 0.22</td><td>61.78 ± 0.58</td></tr><tr><td>√</td><td></td><td>√</td><td>38.15 ± 0.92</td><td>37.12 ± 0.66</td><td>31.73 ± 0.16</td><td>38.26 ± 2.40</td><td>29.40 ± 1.67</td><td>33.29 ± 2.89</td><td>36.28 ± 3.51</td><td>39.76 ± 0.23</td><td>39.36 ± 1.45</td></tr><tr><td></td><td>√</td><td>√</td><td>40.82 ± 0.12</td><td>56.06 ± 0.29</td><td>31.86 ± 0.23</td><td>58.58 ± 0.31</td><td>57.02 ± 1.60</td><td>53.38 ± 0.65</td><td>58.70 ± 2.10</td><td>61.37 ± 0.28</td><td>61.15 ± 0.39</td></tr><tr><td>√</td><td></td><td></td><td>40.37 ± 0.46</td><td>55.70 ± 0.35</td><td>31.59 ± 0.23</td><td>61.20 ± 0.46</td><td>54.02 ± 2.88</td><td>53.08 ± 0.40</td><td>58.58 ± 0.71</td><td>61.84 ± 0.70</td><td>61.78 ± 0.58</td></tr><tr><td></td><td>√</td><td></td><td>42.16 ± 0.22</td><td>55.89 ± 0.37</td><td>30.84 ± 0.26</td><td>59.35 ± 0.12</td><td>55.87 ± 0.68</td><td>54.11 ± 0.49</td><td>58.42 ± 0.27</td><td>61.56 ± 0.61</td><td>61.94 ± 0.37</td></tr><tr><td></td><td></td><td>√</td><td>42.45 ± 0.85</td><td>56.06 ± 0.29</td><td>30.71 ± 0.71</td><td>60.00 ± 0.85</td><td>56.64 ± 1.65</td><td>52.92 ± 1.11</td><td>59.50 ± 0.80</td><td>61.10 ± 0.10</td><td>61.00 ± 0.76</td></tr></table>

## G.1. Additional Ablation Study

Table 13. Control Complexity Study: We control the complexity of model to evaluate performance

<table><tr><td>Scale</td><td>Metrics</td><td>ShaSpec</td><td>TF</td><td>LiMoE</td><td>mmFormer</td><td>FuseMoE</td><td>FlexMoE</td><td>ConfSMoE-T</td></tr><tr><td rowspan="3">Small</td><td>MFLOPs</td><td>21,73</td><td>4.20</td><td>1245.03</td><td>237.39</td><td>143.93</td><td>40.32</td><td>39,62</td></tr><tr><td>#Params</td><td>2,177,406</td><td>2,101,571</td><td>2,130,227</td><td>2,378,371</td><td>20,971,020</td><td>2,184,963</td><td>2,184,730</td></tr><tr><td>F1 score</td><td>39.12 ± 1.21</td><td>35.81 ± 0.85</td><td>41.11 ± 0.90</td><td>41.14 ± 0.31</td><td>36.52 ± 0.84</td><td>42.12 ± 1.18</td><td>44.63 ± 1.65</td></tr><tr><td rowspan="3">Medium</td><td>MFLOPs</td><td>111.27</td><td>45.28</td><td>6803,84</td><td>2830.37</td><td>286.02</td><td>263.94</td><td>268.62</td></tr><tr><td>#Params</td><td>11,137,046</td><td>11,320,153</td><td>11,469,437</td><td>11,490,403</td><td>11,524,392</td><td>11,371,473</td><td>11,330,062</td></tr><tr><td>F1 score</td><td>41.56 ± 0.67</td><td>38.62 ± 0.38</td><td>43.21 ± 0.56</td><td>42.44 ± 0.79</td><td>39.44 ± 0.81</td><td>43.78 ± 0.36</td><td>45.37 ± 1.73</td></tr><tr><td rowspan="3">Large</td><td>MFLOPs</td><td>331.87</td><td>133.47</td><td>19668.02</td><td>9282,03</td><td>308.14</td><td>1181.48</td><td>1078,82</td></tr><tr><td>#Params</td><td>33,203,156</td><td>33,368,335</td><td>33,000,827</td><td>33,428,969</td><td>33,182,556</td><td>33,385,803</td><td>33,398,654</td></tr><tr><td>F1 score</td><td>42.82 ± 0.74</td><td>37.64 ± 0.88</td><td>43.45 ± 0.82</td><td>41.50 ± 0.66</td><td>40.84 ± 0.67</td><td>43.46 ± 1.36</td><td>45.55 ± 1.69</td></tr></table>

Table 14. Ablation II: Module dropout. CMU-MOSI adopt 50% missing in Experiment II

<table><tr><td rowspan="2">Variants</td><td colspan="2">MIMIC-III</td><td colspan="2">CMU-MOSI</td></tr><tr><td>F1</td><td>AUC</td><td>F1</td><td>AUC</td></tr><tr><td>w/o Conf</td><td>48.59 ± 1.97</td><td>85.91 ± 0.84</td><td>42.47 ± 0.94</td><td>68.77 ± 1.66</td></tr><tr><td>w/o impute</td><td>49.59 ± 0.29</td><td>86.31 ± 0.12</td><td>42.46 ± 2.29</td><td>68.44 ± 1.82</td></tr><tr><td>w/o post-impute</td><td>49.86 ± 1.89</td><td>86.53 ± 0.10</td><td>43.14 ± 1.32</td><td>69.13 ± 1.45</td></tr><tr><td>w/o impute &amp; Conf</td><td>46.32 ± 1.66</td><td>85.15 ± 0.57</td><td>41.98 ± 0.74</td><td>68.48 ± 1.90</td></tr><tr><td>ConfSMoE-T</td><td>53.44 ± 0.27</td><td>87.05 ± 0.58</td><td>44.34 ± 0.77</td><td>70.41 ± 1.13</td></tr></table>

Ablation III: We evaluate ConfNet in supervised learning as it is one of the most foundational learning paradiam. For sure, we can adapt ConfSMoE to unsupervised learning setting with proper constructed unsupervied learning loss or proxy task. A typical example is contrastive learning. The supervision signal will be confidence of anchor to it’s positive samples. In multimodal setting, contrasitve loss can be computed as the confidence score between two modality in one instance. But this can be combinatorial complexity when the number of modality grows. Specifically, given an instance containing multimodal data $M = \{ M _ { 0 } , M _ { 1 } , \cdots , M _ { b } \}$ . The contrastive loss of any arbitary modality $M _ { i }$ is defined as:

$$
\mathcal {L} = - l o g \frac {e ^ {M _ {i} \cdot \hat {M} _ {i}} / T}{\sum_ {i \neq j} ^ {B} e ^ {M _ {i} \cdot \hat {M} _ {j}} / T}\tag{20}
$$

Where, $\hat { M _ { i } }$ is interacted modality representation of other modadlity data in one instance. In our setting, $\hat { M _ { i } }$ is the mean representation of other modality. The negative samples are the interacted modality representation of other instances. We first pre-train ConSMoE with contrastive loss stated above and finetune a 3 layer MLP for performance evaluation as it is a common setting for constrastive learning.

As shown in Table 15, we evaluate the unsupervised variant ConfNet on MIMIC-III-48IHM task and CMU-MOSI with 50% missingness. It is clear that the supervised learning setting does not outperform ConfSMoE under supervised learning setting (ConfSMoE-SuP) since supervised learning usually wins well due to the direct supervision signal for a relative small dataset. However, ConfSMoE-UnS significantly outperform FuseMoE with softmax gate (FuseMoE-S), ShaSpec, TF, and achieve comparable performance to LIMoE, mmFormer and FlexMoE under supervised learning setting. This experiment should be sufficient to show that ConfSMoE can be extended to unsupervised learning scenario. We also highlight that the performance may be impacted by the proxy task as it dirrect impact the quality of representation.

Table 15. Ablation III: Verification of ConfNet on Unsupervised Learning Setting

<table><tr><td>Dataset</td><td>Metric</td><td>ShaSpec</td><td>TF</td><td>mmFormer</td><td>LIMoE</td><td>FuseMoE-S</td><td>FuseMoE-L</td><td>FlexMoE</td><td>ConfSMoE-UnS</td><td>ConfSMoE-SuP</td></tr><tr><td rowspan="2">MIMIC-III</td><td>F1</td><td>34.36 ± 0.73</td><td>43.80 ± 0.67</td><td>23.09 ± 1.13</td><td>47.62 ± 0.21</td><td>48.62 ± 0.27</td><td>51.63 ± 0.39</td><td>47.81 ± 0.31</td><td>51.70 ± 0.63</td><td>53.44 ± 0.27</td></tr><tr><td>AUC</td><td>79.86 ± 0.53</td><td>81.27 ± 0.76</td><td>78.47 ± 0.65</td><td>83.30 ± 0.64</td><td>85.81 ± 0.13</td><td>86.22 ± 0.15</td><td>85.10 ± 0.61</td><td>86.88 ± 0.88</td><td>87.05 ± 0.58</td></tr><tr><td rowspan="2">CMU-MOSI-50%</td><td>F1</td><td>36.39 ± 0.97</td><td>38.46 ± 1.09</td><td>41.14 ± 0.31</td><td>41.54 ± 0.77</td><td>38.55 ± 0.34</td><td>40.90 ± 0.49</td><td>41.95 ± 0.48</td><td>40.78 ± 0.39</td><td>44.34 ± 0.77</td></tr><tr><td>AUC</td><td>55.60 ± 0.12</td><td>60.49 ± 0.80</td><td>61.87 ± 0.67</td><td>67.43 ± 0.34</td><td>62.28 ± 0.28</td><td>65.73 ± 0.30</td><td>66.47 ± 0.49</td><td>67.48 ± 0.15</td><td>70.41 ± 1.31</td></tr></table>

Table 16. Ablation IV: Sensitivity Analysis on Sparsity Hyperparameter (B) in Post-imputation

<table><tr><td>Metric</td><td>B=1</td><td>B=2</td><td>B=3</td><td>B=4</td><td>B=5</td><td>B=6</td><td>B=7</td></tr><tr><td>F1</td><td>44.71±1.72</td><td>43.37±1.41</td><td>43.13±0.32</td><td>44.34±0.77</td><td>43.33±0.48</td><td>43.51±0.71</td><td>43.19±0.19</td></tr><tr><td>AUC</td><td>69.33±0.97</td><td>68.45±0.57</td><td>69.45±1.60</td><td>70.41±1.31</td><td>69.77±1.31</td><td>68.92±1.15</td><td>68.12±0.23</td></tr></table>

Ablation IV: The sparsity hyperparameter in post-imputation determines the amount of feature retrieved from available modality and filtering out irrelavant feature from them. The higher the sparsity B is, the sparser the attention mechanism will be. The post-imputation module will be standard attention if $B = 1$ . In the paper, we keep $B = 4$ as this is the best parameter we search in range [1, 7]. To show the sensitivity of B, we implemented experiment to evaluate how B hyperparameter impact the model performance as shown in Table 16

Table 17. Ablation V: Sensitivity Analysis on Calibration of Confidence Supervision

<table><tr><td>Metric</td><td>Temp=0.3</td><td>Temp=0.6</td><td>Temp=1</td><td>Temp=2</td><td>Temp=3</td></tr><tr><td>F1</td><td>43.62 ± 1.07</td><td>43.77 ± 0.94</td><td>44.35 ± 0.77</td><td>44.18 ± 0.11</td><td>43.08 ± 0.37</td></tr><tr><td>AUC</td><td>69.75 ± 1.34</td><td>68.74 ± 0.38</td><td>70.41 ± 1.31</td><td>71.14 ± 0.61</td><td>69.22 ± 0.6</td></tr><tr><td>ECE(%)</td><td>10.85 ± 1.72</td><td>8.61 ± 1.27</td><td>8.32 ± 1.27</td><td>6.34 ± 2.80</td><td>9.01 ± 0.96</td></tr></table>

Ablation V: As shown in Table. 17, by changing the temperature parameter of softmax in downstream task head, we can easily control the calibration of model. We use a wildly used metrics Expected Calibration Error (ECE) to measure how well the model is calibrated to actual accuracy. The ECE is closer to 0, the better the calibration is. Specifically, we set the temperature as 1 to indicate normal softmax, and large temperature value to make over-calibrated model and small temperature to make under-calibrated model. Both cases are not well-calibrated. We can clearly observed that temp = 2 is the best calibration setting and it is also the best performance in terms of AUC and comparable performance in F1 score. we can observed that worse calibrated confidence is definitely harmful to ConfNet as it is a true reflection of the instance contribution to downstream task. But the model performance is not very sensitive to calibration of model. A clearer trend is that better calibration may lead to better performance and vice versa.

## G.2. Further Clarification

Connection of Both ConfNet and Tow-Stage Imputation: Conceptually, when a modality is missing, the input signal to a standard softmax-based gating network is partial, producing unreliable representations for gating score learning (Eq. 3). Traditional softmax gating always produces high gating scores for the selected expert due to the natural exponential function of softmax even if the input signal is unreliable. This is counterintuitive: an unreliable modality representation receives a high gating score. The model will propagate this error during training: it always produces strong gating scores no matter the quality of the modality representation. This leads to worse expert collapse and thus worse performance and unreliable routing.

ConfNet gating mechanism, however, measures the input signal’s downstream task confidence. When the input signal is unreliable, the confidence score will be relatively small for the downstream task. We take this low confidence score as the gating score to select experts such that the output of the selected expert will contribute less to the final representation from this unreliable signal. Therefore, the router will tend to select other experts for better representation learning for the next round, leading to a natural balance of expert load. Our two-modality imputation here is to reconstruct the missing modality to guide the routing process with the confidence score to learn better gating scores w.r.t. the quality of representation.

In addition, the key characteristic of post-imputation is to integrate the “opinion” from different experts, which brings better imputation capability than a single model and this is also the key difference compared to other single-model imputation

## H. Visualization of Experiment

In this section, we provide visual evidence to further support our claims regarding expert selection dynamics and modality robustness.

Figure 4 shows the UMAP projection of multi-modal embeddings on CMU-MOSI. It clearly demonstrates that imputed modalities form distributions consistent with their original counterparts, suggesting that our imputation module maintains semantic alignment across modalities.

Figure 5 illustrates the softmax gating mechanism without load balance regularization, which exhibits severe expert collapse where only a few experts are consistently selected throughout training. In contrast, Figure 6 shows that our proposed ConfNet gating maintains both load balance and expert specialization, effectively mitigating collapse and enabling more stable and diverse expert routing. We further compared the visualization of our proposed method with Figure 7. SoftMax gating with load balance loss indicate severe ambiguous selection, experts that were heavily selected in one epoch tend to be suppressed in the next epoch. This is a clear empirical result to our gradient analysis that the optimization process of load balance is opposite to learning better routing score. This ambiguous selection, ”Sinusoidal Wave” in another word, is also observed in Mean and Gaussian gating as shown in Figure 9 and Figure 11. Mean gating considers all experts equally important and failed to reflect the specification of each expert, resulting suboptimal performance shown in Table 2. By comparing Figure 7 and Figure 9, 11, we observe softmax and gaussian exhibits similar ”Sinusoidal Wave” to Mean selection. We can draw a preliminary conclusion that this ambiguous selection, usually leads to suboptimal solution given empirical facts in 2. Moreover, although Laplacian and ConfNet gating are not fully balanced, the ”Sinusoidal Wave” exists only to a mild extent and lead to a worth noting performance in 2. All these empirical findings are consistent with our gradient analysis and further support our claim that load distribution should preserve specialization while ensuring a non-trivial load is assigned to less active experts.

Finally, Figures 12 and 13 report and visualize Experiment III results. ConfMoE demonstrates superior resilience across increasing missing rates, with both F1 and AUC metrics degrading gracefully. These results visually confirm the effectiveness of confidence-guided gating and modality imputation under challenging conditions.

![](images/7f11098410048f9e67f66ba3d449f72087f929319e11319808577fbb9df50421.jpg)  
Figure 4. UMAP Visualization of Multi-modal Embedding Space: CMU-MOSI

![](images/876deeec14c54f9c2efc88184e7c0b6614ee3dff29d0ba7cf45770181b40f27a.jpg)  
Figure 5. Softmax Score-based without Load Balance Expert Selection: Expert collapse is consistently occurred after epochs 10. While a few certain experts are preferred, this preferred selection becomes worst when the training progresses

![](images/4235038285ba7509b3b9a89389c8225eb60705709c8fc3aefc54fc3a62b699da.jpg)  
Figure 6. ConfNet Gating Expert Selection: Expert collapse is consistently mitigated throughout training. While certain experts are preferred, less frequently selected experts are still actively utilized. Moreover, expert selection becomes increasingly balanced as training progresses, indicating improved stability and diversity in routing.

![](images/c20ab2a73cd7271ca3d08455773063f90d67430983e570a40db099b31cbecf1e.jpg)  
0 2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50 52 54 56 58 60 62 64 66 68 70 72 74 76 78 80 82 84 86 88 90 92 94 96 98 Epochs  
Figure 7. Softmax Gate with Load Balance Loss Expert Selection: An optimization conflict arises, often reflected in a ”Sharp Sinusoidal Wave” pattern, experts that were heavily selected in one epoch tend to be suppressed in the next. This oscillatory behavior indicates that the typical load balancing loss does not promote true specialization or expertise among experts. Instead, it merely enforces uniform usage, potentially at the cost of performance, by prioritizing balanced selection over actual expert quality.

![](images/1d8208bb9db0a70122da7ae10c4c33c34dc11d5e0369d91c19d82afee6260e74.jpg)  
1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 31 33 35 37 39 41 43 45 47 49 51 53 55 57 59 61 63 65 67 69 71 73 75 77 79 81 83 85 87 89 91 93 95 97 99 Epochs  
Figure 8. Laplacian Gating Expert Selection: Laplacian gating can partially alleviate the load imbalance issue and achieves better expert utilization than softmax. However, as training progresses, selection becomes increasingly skewed, with only a few experts being consistently chosen. This eventually leads to expert collapse, where most experts become inactive and underutilized.

![](images/7134c941a39cc4e49e678041ca1058eec379dc85a43f4b114a0d6a80420741ae.jpg)  
1 -0 -2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50 52 54 56 58 60 62 64 6668 70 72 74 76 78 80 82 84 86 88 90 92 94 96 98 Epochs  
Figure 9. Mean Gating Expert Selection: The ”Sharp Sinusoidal $ { \mathrm { W a v e } } ^ {  { \mathbf { \mathsf { y } } } }$ pattern persists under mean gating, where experts heavily selected in one epoch are suppressed in the next. This oscillatory behavior reflects ambiguity in expert selection, stemming from the absence of explicit guidance in the routing mechanism. While mean gating achieves better load balance than Softmax with $\dot { \mathcal { L } } _ { \mathrm { l o a d } } .$ it ultimately results in inferior performance, as shown in Table 2.

![](images/4d277007bb7104126e08fdb76377b24f908e753b247608824d8576d11fc91348.jpg)  
Figure 10. Gaussian Gating Expert Selection: The ”Sharp Sinusoidal Wave” pattern persists under Gaussian gating, where experts heavily selected in one epoch are suppressed in the next. This oscillatory behavior reflects ambiguity in expert selection, stemming from the inappropriate gating score guided from Gaussian. While mean gating achieves better load balance than Softmax with $\mathcal { L } _ { \mathrm { l o a d } }$ , it ultimately results in inferior performance, as shown in Table 2.

![](images/c294c8b57651c018ba0085246492ec61c09526f5c5d861b7f1aeb3dc62f9027f.jpg)  
0 1 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50 52 54 56 58 60 62 64 66 68 70 72 74 76 78 80 82 84 86 88 90 92 94 96 98 Epochs  
Figure 11. Loss-Free Balance Expert Selection: The ”Sharp Sinusoidal Wave” pattern is mitigated under Loss-Free Balance. But this balance technique works too slow as it start balancing load since epoch 50.

![](images/10713c34ac7c4f2244b3a3c5f709fe8086658c7fae66cd5c1ca6b29e4cce06d3.jpg)

![](images/83dcb3ea632fb2562e94801fc2fe375f38241a6d38512c6c704b9b4ab6ab370b.jpg)  
Figure 12. Experiment III: CMU-MOSEI Performance Plot

![](images/4c79c49e3bc694c2b69f6f00c6465758d01d05df36843a181268fdc77d0b9717.jpg)

![](images/58eec801d360e6088e1362052f5383e8c95b572d68bad5c35fc6ed9bba96dfac.jpg)  
Figure 13. Experiment III: CMU-MOSI Performance Plot

![](images/edcda2199546eed48c02879a94999ceeb1d2a580aeba150082376013e90ab8ea.jpg)

![](images/f114a0d3a28475aaed34cc5a111f58b2421c5c57f57aa634a21fff02786ff73f.jpg)  
Figure 14. Attention Map from post-imputation: Text as query and Vision, Audio as key. The key tokens are obtained by concatenating tokens from K=2 expert, resulting 100 length of token. The darker the color, the lower attention weight is.

![](images/34b165a9fc3e8c795ed22d7b3eb31fc9ecb9053878700e388e4a8b3bcdc44164.jpg)

![](images/56dd6a997e2fbc5828600a401f8d6d04b72654fd03aebb346ce0d92568f4eb41.jpg)  
Figure 15. Attention Map from post-imputation: Vision as query and Audio, Text as key. The key tokens are obtained by concatenating tokens from K=2 expert, resulting 100 length of token. The darker the color, the lower attention weight is.

![](images/ff4087bdf15f5c2f736191aa37f898ba9a16e56b67736fcdd6fd88bc10af1fac.jpg)

![](images/4cdbdf65631406c83d77cbf35a421cfc1a46ee08907a0a5febc6abd254cea023.jpg)  
Figure 16. Attention Map from post-imputation: Audio as query and Vision, Text as key. The key tokens are obtained by concatenating tokens from K=2 expert, resulting 100 length of token. The darker the color, the lower attention weight is.

From Figure 14 15 16, we can clearly observed that the attention map are distinctly different when the key are set to different modalities. This indicate that the post-imputation module can dynamically learn, which token are needed depending on characteristics of token and experts. For example, the Figure 16 indicates that 25 - 45th tokens of the first expert are more important than others while the text modalities shows that the second experts are more important. Similar observation are also shows in 14 15 as well. This observation also indicates that modality not only dynamically select information from existing modality but also the specialization of experts. Therefore, we can conclude that the post-imputation can capture expertise of different expert and refine the missing modality accordingly.